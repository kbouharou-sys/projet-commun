import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type UserRole = 'admin_principal' | 'admin_2' | 'admin_3' | 'lecteur';

export interface UserProfile {
  id: string;
  email: string;
  role: UserRole;
}

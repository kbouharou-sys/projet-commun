import { useState } from 'react';
import { NavLink, useLocation, Outlet } from 'react-router-dom';
import {
  BookOpen,
  BookText,
  Search,
  Settings,
  Shield,
  LogIn,
  LogOut,
  Menu,
  X,
  Brain,
  Bookmark,
  Download,
  Home,
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

interface NavItem {
  to: string;
  label: string;
  icon: typeof BookOpen;
  end?: boolean;
}

const navItems: NavItem[] = [
  { to: '/', label: 'Accueil', icon: Home, end: true },
  { to: '/quran', label: 'Le Coran', icon: BookOpen },
  { to: '/dictionary', label: 'Dictionnaire', icon: BookText },
  { to: '/search', label: 'Recherche', icon: Search },
  { to: '/quiz', label: 'Quiz', icon: Brain },
  { to: '/bookmarks', label: 'Marque-pages', icon: Bookmark },
  { to: '/settings', label: 'Paramètres', icon: Settings },
];

const adminItem: NavItem = { to: '/admin', label: 'Import de versets', icon: Download };

export default function Layout() {
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const { user, role, signOut } = useAuth();
  const location = useLocation();

  const isAdmin = role === 'admin_principal' || role === 'admin_2' || role === 'admin_3';
  const allNavItems = isAdmin ? [...navItems, adminItem] : navItems;

  const roleLabel: Record<string, string> = {
    admin_principal: 'Administrateur Principal',
    admin_2: 'Administrateur 2',
    admin_3: 'Administrateur 3',
    lecteur: 'Lecteur',
  };

  return (
    <div className="min-h-screen bg-white flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-64 flex-col border-r border-neutral-200 bg-neutral-50 fixed h-screen">
        <div className="p-6 border-b border-neutral-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary-600 flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-semibold text-neutral-900 text-sm">Coran & Dictionnaire</h1>
              <p className="text-xs text-neutral-500">Lecture, dictionnaire & révision</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {allNavItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-primary-50 text-primary-700'
                    : 'text-neutral-600 hover:bg-neutral-100 hover:text-neutral-900'
                }`
              }
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="p-4 border-t border-neutral-200">
          {user ? (
            <div className="space-y-3">
              <div className="px-3 py-2 rounded-lg bg-neutral-100">
                <p className="text-xs text-neutral-500">Connecté en tant que</p>
                <p className="text-sm font-medium text-neutral-900 truncate">{user.email}</p>
                {role && (
                  <p className="text-xs text-primary-600 mt-1">{roleLabel[role]}</p>
                )}
              </div>
              <button
                onClick={signOut}
                className="flex items-center gap-2 w-full px-3 py-2 rounded-lg text-sm font-medium text-neutral-600 hover:bg-neutral-100 hover:text-neutral-900 transition-colors"
              >
                <LogOut className="w-4 h-4" />
                Déconnexion
              </button>
            </div>
          ) : (
            <NavLink
              to="/login"
              className="flex items-center gap-2 w-full px-3 py-2 rounded-lg text-sm font-medium text-primary-600 hover:bg-primary-50 transition-colors"
            >
              <LogIn className="w-4 h-4" />
              Connexion
            </NavLink>
          )}
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-30 bg-white border-b border-neutral-200 px-4 h-14 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary-600 flex items-center justify-center">
            <BookOpen className="w-4 h-4 text-white" />
          </div>
          <span className="font-semibold text-sm text-neutral-900">Coran & Dictionnaire</span>
        </div>
        <div className="flex items-center gap-2">
          {isAdmin && (
            <NavLink
              to="/admin"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-white bg-primary-600 hover:bg-primary-700 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              Import
            </NavLink>
          )}
          <button
            onClick={() => setMobileNavOpen(!mobileNavOpen)}
            className="p-2 rounded-lg hover:bg-neutral-100"
          >
            {mobileNavOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Nav Drawer */}
      {mobileNavOpen && (
        <div className="lg:hidden fixed inset-0 z-20 bg-black/20" onClick={() => setMobileNavOpen(false)}>
          <div
            className="absolute top-14 left-0 right-0 bg-white border-b border-neutral-200 shadow-lg animate-fade-in"
            onClick={(e) => e.stopPropagation()}
          >
            <nav className="p-4 space-y-1">
              {allNavItems.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  end={item.end}
                  onClick={() => setMobileNavOpen(false)}
                  className={({ isActive }) =>
                    `flex items-center gap-3 px-3 py-3 rounded-lg text-sm font-medium transition-colors ${
                      isActive
                        ? 'bg-primary-50 text-primary-700'
                        : 'text-neutral-600 hover:bg-neutral-100'
                    }`
                  }
                >
                  <item.icon className="w-5 h-5" />
                  {item.label}
                </NavLink>
              ))}

              <div className="pt-2 mt-2 border-t border-neutral-200">
                {user ? (
                  <div className="space-y-2">
                    <div className="px-3 py-2 rounded-lg bg-neutral-100">
                      <p className="text-xs text-neutral-500">{user.email}</p>
                      {role && (
                        <p className="text-xs text-primary-600 mt-0.5">{roleLabel[role]}</p>
                      )}
                    </div>
                    <button
                      onClick={() => {
                        signOut();
                        setMobileNavOpen(false);
                      }}
                      className="flex items-center gap-2 w-full px-3 py-2.5 rounded-lg text-sm font-medium text-neutral-600 hover:bg-neutral-100"
                    >
                      <LogOut className="w-4 h-4" />
                      Déconnexion
                    </button>
                  </div>
                ) : (
                  <NavLink
                    to="/login"
                    onClick={() => setMobileNavOpen(false)}
                    className="flex items-center gap-2 w-full px-3 py-2.5 rounded-lg text-sm font-medium text-primary-600 hover:bg-primary-50"
                  >
                    <LogIn className="w-4 h-4" />
                    Connexion
                  </NavLink>
                )}
              </div>
            </nav>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 lg:ml-64 pt-14 lg:pt-0">
        <div key={location.pathname} className="animate-fade-in">
          <Outlet />
        </div>
      </main>
    </div>
  );
}

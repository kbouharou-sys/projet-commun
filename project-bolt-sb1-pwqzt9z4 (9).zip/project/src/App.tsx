import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '@/contexts/AuthContext';
import Layout from '@/components/Layout';
import Home from '@/pages/Home';
import QuranList from '@/pages/QuranList';
import QuranReader from '@/pages/QuranReader';
import DictionaryPage from '@/pages/Dictionary';
import SearchPage from '@/pages/Search';
import QuizPage from '@/pages/Quiz';
import BookmarksPage from '@/pages/Bookmarks';
import SettingsPage from '@/pages/Settings';
import AdminPage from '@/pages/Admin';
import LoginPage from '@/pages/Login';

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<Home />} />
            <Route path="/quran" element={<QuranList />} />
            <Route path="/quran/:id" element={<QuranReader />} />
            <Route path="/dictionary" element={<DictionaryPage />} />
            <Route path="/search" element={<SearchPage />} />
            <Route path="/quiz" element={<QuizPage />} />
            <Route path="/bookmarks" element={<BookmarksPage />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="/admin" element={<AdminPage />} />
            <Route path="/login" element={<LoginPage />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

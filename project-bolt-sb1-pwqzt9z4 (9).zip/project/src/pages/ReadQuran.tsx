import { useEffect, useState, useCallback, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import {
  BookOpen,
  ChevronRight,
  AlertCircle,
  Search,
  ChevronLeft,
  BookMarked,
  Loader2,
  Check,
  Bookmark,
  BookmarkCheck,
  BarChart3,
  ArrowLeft,
  Home,
} from 'lucide-react';

interface Surah {
  id: string;
  number: number;
  name_fr: string;
  name_ar: string;
  revelation_type: string | null;
  verse_count: number;
}

interface Verse {
  id: string;
  surah_id: string;
  verse_number: number;
  arabic_uthmani: string;
  french_pretranslation: string;
  order_index: number;
}

export default function ReadQuran() {
  const { user } = useAuth();
  const [surahs, setSurahs] = useState<Surah[]>([]);
  const [selectedSurah, setSelectedSurah] = useState<Surah | null>(null);
  const [verses, setVerses] = useState<Verse[]>([]);
  const [loading, setLoading] = useState(true);
  const [versesLoading, setVersesLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [bookmarkedVerseIds, setBookmarkedVerseIds] = useState<Set<string>>(new Set());
  const [progressMap, setProgressMap] = useState<Map<string, { last_verse: number; completed: boolean }>>(new Map());
  const [bookmarkLoading, setBookmarkLoading] = useState<string | null>(null);
  const versesRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    async function fetchData() {
      const { data: surahData, error: surahError } = await supabase
        .from('surahs')
        .select('id, number, name_fr, name_ar, revelation_type, verse_count')
        .order('number', { ascending: true });

      if (surahError) {
        setError(surahError.message);
        setLoading(false);
        return;
      }

      setSurahs(surahData ?? []);

      if (user) {
        const [bmRes, progRes] = await Promise.all([
          supabase.from('bookmarks').select('verse_id').eq('user_id', user.id),
          supabase.from('reading_progress').select('surah_id, last_verse_number, is_completed').eq('user_id', user.id),
        ]);

        if (bmRes.data) {
          setBookmarkedVerseIds(new Set(bmRes.data.map((b) => b.verse_id)));
        }
        if (progRes.data) {
          const map = new Map<string, { last_verse: number; completed: boolean }>();
          progRes.data.forEach((p) => {
            map.set(p.surah_id, { last_verse: p.last_verse_number, completed: p.is_completed });
          });
          setProgressMap(map);
        }
      }

      setLoading(false);
    }
    fetchData();
  }, [user]);

  const selectSurah = useCallback(async (surah: Surah) => {
    setSelectedSurah(surah);
    setVersesLoading(true);
    setError(null);
    setVerses([]);

    const { data, error: vError } = await supabase
      .from('verses')
      .select('*')
      .eq('surah_id', surah.id)
      .order('verse_number', { ascending: true });

    if (vError) {
      setError(vError.message);
    } else {
      setVerses(data ?? []);
    }
    setVersesLoading(false);

    setTimeout(() => {
      versesRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
  }, []);

  const updateProgress = useCallback(async (surah: Surah, lastVerseNumber: number, totalVerses: number) => {
    if (!user) return;
    const isCompleted = lastVerseNumber >= totalVerses;

    await supabase
      .from('reading_progress')
      .upsert({
        user_id: user.id,
        surah_id: surah.id,
        last_verse_number: lastVerseNumber,
        is_completed: isCompleted,
        updated_at: new Date().toISOString(),
      }, { onConflict: 'user_id,surah_id' });

    setProgressMap((prev) => {
      const next = new Map(prev);
      next.set(surah.id, { last_verse: lastVerseNumber, completed: isCompleted });
      return next;
    });
  }, [user]);

  const toggleBookmark = useCallback(async (verse: Verse, surah: Surah) => {
    if (!user) return;
    setBookmarkLoading(verse.id);

    const isBookmarked = bookmarkedVerseIds.has(verse.id);
    if (isBookmarked) {
      await supabase
        .from('bookmarks')
        .delete()
        .eq('user_id', user.id)
        .eq('verse_id', verse.id);
      setBookmarkedVerseIds((prev) => {
        const next = new Set(prev);
        next.delete(verse.id);
        return next;
      });
    } else {
      await supabase
        .from('bookmarks')
        .insert({
          user_id: user.id,
          verse_id: verse.id,
          surah_id: surah.id,
        });
      setBookmarkedVerseIds((prev) => new Set(prev).add(verse.id));
    }
    setBookmarkLoading(null);
  }, [user, bookmarkedVerseIds]);

  function goToAdjacentSurah(direction: 'prev' | 'next') {
    if (!selectedSurah) return;
    const targetNumber =
      direction === 'prev' ? selectedSurah.number - 1 : selectedSurah.number + 1;
    const target = surahs.find((s) => s.number === targetNumber);
    if (target) selectSurah(target);
  }

  function closeSurah() {
    setSelectedSurah(null);
    setVerses([]);
    setError(null);
    setTimeout(() => {
      versesRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 50);
  }

  const filteredSurahs = surahs.filter((s) => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      s.name_fr.toLowerCase().includes(q) ||
      s.name_ar.includes(searchQuery.trim()) ||
      String(s.number) === q
    );
  });

  const hasVerses = verses.length > 0;
  const canGoPrev = selectedSurah && selectedSurah.number > 1;
  const canGoNext = selectedSurah && selectedSurah.number < 114;
  const currentProgress = selectedSurah ? progressMap.get(selectedSurah.id) : null;

  if (loading) {
    return (
      <div className="p-8 max-w-6xl mx-auto">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-neutral-200 rounded w-1/3" />
          <div className="h-4 bg-neutral-200 rounded w-1/2" />
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
            <div className="h-64 bg-neutral-200 rounded-xl" />
            <div className="h-64 bg-neutral-200 rounded-xl lg:col-span-2" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 max-w-6xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl lg:text-3xl font-bold text-neutral-900 mb-2 flex items-center gap-2">
          <BookOpen className="w-7 h-7 text-primary-600" />
          Lire le Coran
        </h1>
        <p className="text-sm text-neutral-500">
          {surahs.length} sourates — {verses.length} versets affichés. Sélectionnez une sourate pour afficher ses versets.
        </p>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-red-800">Erreur de chargement</p>
            <p className="text-xs text-red-600 mt-1">{error}</p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Surah List */}
        <div className="lg:col-span-1">
          <div className="bg-white border border-neutral-200 rounded-xl overflow-hidden lg:sticky lg:top-4">
            <div className="p-4 border-b border-neutral-200 bg-neutral-50">
              <h2 className="font-semibold text-sm text-neutral-700 mb-3 flex items-center gap-2">
                <BookMarked className="w-4 h-4 text-primary-600" />
                Sourates
              </h2>
              <div className="relative">
                <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Nom ou numéro..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-sm border border-neutral-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-300"
                />
              </div>
              <p className="text-xs text-neutral-400 mt-2">
                {filteredSurahs.length} sourate(s)
                {user && bookmarkedVerseIds.size > 0 && (
                  <span className="ml-2 text-primary-600">• {bookmarkedVerseIds.size} marque-page(s)</span>
                )}
              </p>
            </div>
            <div className="max-h-[400px] lg:max-h-[calc(100vh-320px)] overflow-y-auto">
              {filteredSurahs.length === 0 ? (
                <div className="p-6 text-center">
                  <p className="text-sm text-neutral-400">Aucun résultat</p>
                </div>
              ) : (
                filteredSurahs.map((surah) => {
                  const prog = progressMap.get(surah.id);
                  return (
                    <button
                      key={surah.id}
                      onClick={() => selectSurah(surah)}
                      className={`w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-neutral-50 transition-colors border-b border-neutral-100 ${
                        selectedSurah?.id === surah.id ? 'bg-primary-50' : ''
                      }`}
                    >
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-semibold flex-shrink-0 ${
                        selectedSurah?.id === surah.id
                          ? 'bg-primary-600 text-white'
                          : 'bg-neutral-100 text-neutral-600'
                      }`}>
                        {surah.number}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-neutral-900 truncate">
                          {surah.name_fr}
                        </p>
                        <p className="font-arabic text-sm text-neutral-500 truncate">
                          {surah.name_ar}
                        </p>
                        {user && prog && (
                          <div className="flex items-center gap-1 mt-0.5">
                            <div className="h-1 flex-1 bg-neutral-200 rounded-full overflow-hidden max-w-[60px]">
                              <div
                                className="h-full bg-primary-500 rounded-full"
                                style={{ width: `${Math.min((prog.last_verse / surah.verse_count) * 100, 100)}%` }}
                              />
                            </div>
                            {prog.completed && <Check className="w-3 h-3 text-primary-600 flex-shrink-0" />}
                          </div>
                        )}
                      </div>
                      <div className="flex flex-col items-end flex-shrink-0">
                        <span className="text-xs text-neutral-400 mt-0.5">{surah.verse_count} v.</span>
                        {surah.revelation_type && (
                          <span className={`text-[10px] mt-0.5 px-1.5 py-0.5 rounded ${
                            surah.revelation_type === 'meccan'
                              ? 'bg-accent-50 text-accent-700'
                              : 'bg-primary-50 text-primary-700'
                          }`}>
                            {surah.revelation_type === 'meccan' ? 'Mecquoise' : 'Médinoise'}
                          </span>
                        )}
                      </div>
                      <ChevronRight className="w-4 h-4 text-neutral-300 flex-shrink-0" />
                    </button>
                  );
                })
              )}
            </div>
          </div>
        </div>

        {/* Verses Display */}
        <div className="lg:col-span-2" ref={versesRef}>
          {!selectedSurah ? (
            <div className="bg-white border border-neutral-200 rounded-xl p-12 text-center">
              <BookOpen className="w-12 h-12 text-neutral-300 mx-auto mb-4" />
              <p className="text-neutral-500 font-medium">Aucune sourate sélectionnée</p>
              <p className="text-sm text-neutral-400 mt-1">
                Choisissez une sourate dans la liste pour afficher ses versets.
              </p>
            </div>
          ) : (
            <div>
              {/* Back to surah list */}
              <div className="flex items-center gap-2 mb-4">
                <button
                  onClick={closeSurah}
                  className="flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-lg bg-primary-600 text-white hover:bg-primary-700 transition-colors shadow-sm"
                >
                  <Home className="w-4 h-4" />
                  Retour à la liste des sourates
                </button>
              </div>

              {/* Surah header */}
              <div className="bg-gradient-to-r from-primary-700 to-primary-600 text-white rounded-xl p-6 mb-4 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -translate-y-16 translate-x-16" />
                <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/5 rounded-full translate-y-12 -translate-x-12" />
                <div className="relative flex items-center justify-between">
                  <div className="flex-1 min-w-0">
                    <button
                      onClick={closeSurah}
                      className="lg:hidden flex items-center gap-1 text-xs text-primary-100 hover:text-white transition-colors mb-2"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                      Retour
                    </button>
                    <h2 className="text-xl lg:text-2xl font-bold">{selectedSurah.name_fr}</h2>
                    <p className="font-arabic text-2xl mt-2">{selectedSurah.name_ar}</p>
                  </div>
                  <div className="text-right">
                    <div className="inline-flex items-center justify-center w-14 h-14 rounded-full border-2 border-white/30 mb-2">
                      <span className="text-lg font-bold">{selectedSurah.number}</span>
                    </div>
                    {selectedSurah.revelation_type && (
                      <p className="text-xs text-primary-100">
                        {selectedSurah.revelation_type === 'meccan' ? 'Mecquoise' : 'Médinoise'}
                      </p>
                    )}
                    <p className="text-xs text-primary-100 mt-0.5">
                      {selectedSurah.verse_count} versets
                    </p>
                  </div>
                </div>
                {user && currentProgress && (
                  <div className="relative mt-4 pt-4 border-t border-white/20">
                    <div className="flex items-center gap-2">
                      <BarChart3 className="w-3.5 h-3.5 text-primary-100" />
                      <span className="text-xs text-primary-100">
                        Progression: verset {currentProgress.last_verse}/{selectedSurah.verse_count}
                        {currentProgress.completed && ' — terminée'}
                      </span>
                    </div>
                    <div className="h-1.5 bg-white/20 rounded-full mt-2 overflow-hidden">
                      <div
                        className="h-full bg-white rounded-full transition-all duration-500"
                        style={{ width: `${Math.min((currentProgress.last_verse / selectedSurah.verse_count) * 100, 100)}%` }}
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Navigation between surahs */}
              <div className="flex items-center justify-between gap-3 mb-4">
                <button
                  onClick={() => goToAdjacentSurah('prev')}
                  disabled={!canGoPrev}
                  className="flex items-center gap-1.5 px-4 py-2 text-sm font-medium rounded-lg border border-neutral-200 text-neutral-700 hover:bg-neutral-50 hover:border-neutral-300 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <ChevronLeft className="w-4 h-4" />
                  Précédente
                </button>
                <span className="text-xs text-neutral-400">
                  Sourate {selectedSurah.number} / 114
                </span>
                <button
                  onClick={() => goToAdjacentSurah('next')}
                  disabled={!canGoNext}
                  className="flex items-center gap-1.5 px-4 py-2 text-sm font-medium rounded-lg border border-neutral-200 text-neutral-700 hover:bg-neutral-50 hover:border-neutral-300 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  Suivante
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              {/* Verses with alternating block colors */}
              {versesLoading ? (
                <div className="bg-white border border-neutral-200 rounded-xl p-8">
                  <div className="flex items-center justify-center gap-2 text-neutral-400">
                    <Loader2 className="w-5 h-5 animate-spin" />
                    <span className="text-sm">Chargement des versets...</span>
                  </div>
                </div>
              ) : !hasVerses ? (
                <div className="bg-white border border-neutral-200 rounded-xl p-8 text-center">
                  <BookOpen className="w-10 h-10 text-neutral-300 mx-auto mb-3" />
                  <p className="text-sm text-neutral-500 font-medium">
                    Aucun verset disponible
                  </p>
                  <p className="text-xs text-neutral-400 mt-1 max-w-md mx-auto">
                    Les versets de cette sourate n'ont pas encore été intégrés.
                  </p>
                </div>
              ) : (
                <div className="bg-white border border-neutral-200 rounded-xl overflow-hidden">
                  {verses.map((verse, index) => {
                    const isBookmarked = bookmarkedVerseIds.has(verse.id);
                    return (
                      <div
                        key={verse.id}
                        className={`p-5 lg:p-6 group ${
                          index % 2 === 0 ? 'verse-block-white' : 'verse-block-beige'
                        } ${index > 0 ? 'border-t border-neutral-100' : ''}`}
                      >
                        <div className="flex items-start gap-4">
                          <div className="w-9 h-9 rounded-full border-2 border-primary-300 bg-primary-50 flex items-center justify-center text-xs font-semibold text-primary-700 flex-shrink-0 mt-1">
                            {verse.verse_number}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-arabic text-2xl lg:text-3xl font-semibold text-neutral-900 leading-loose mb-3 text-right" dir="rtl">
                              {verse.arabic_uthmani}
                            </p>
                            {verse.french_pretranslation ? (
                              <p className="text-base text-neutral-700 leading-relaxed">
                                {verse.french_pretranslation}
                              </p>
                            ) : (
                              <p className="text-sm text-neutral-400 italic">
                                Traduction française à venir
                              </p>
                            )}
                          </div>
                          {user && (
                            <button
                              onClick={() => toggleBookmark(verse, selectedSurah)}
                              disabled={bookmarkLoading === verse.id}
                              title={isBookmarked ? 'Retirer le marque-page' : 'Marquer ce verset'}
                              className={`flex-shrink-0 mt-1 p-2 rounded-lg transition-all ${
                                isBookmarked
                                  ? 'text-primary-600 bg-primary-50 hover:bg-primary-100'
                                  : 'text-neutral-300 hover:text-primary-600 hover:bg-neutral-100 opacity-0 group-hover:opacity-100'
                              }`}
                            >
                              {isBookmarked
                                ? <BookmarkCheck className="w-5 h-5" />
                                : <Bookmark className="w-5 h-5" />}
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                  {user && hasVerses && (
                    <div className="p-4 bg-neutral-50 border-t border-neutral-200">
                      <button
                        onClick={() => updateProgress(selectedSurah, verses.length, selectedSurah.verse_count)}
                        className="w-full px-4 py-2.5 bg-primary-600 text-white rounded-lg font-medium text-sm hover:bg-primary-700 transition-colors flex items-center justify-center gap-2"
                      >
                        <Check className="w-4 h-4" />
                        Marquer comme lu ({verses.length}/{selectedSurah.verse_count} versets)
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Bottom navigation */}
              {hasVerses && (
                <div className="flex items-center justify-between gap-3 mt-4">
                  <button
                    onClick={() => goToAdjacentSurah('prev')}
                    disabled={!canGoPrev}
                    className="flex items-center gap-1.5 px-4 py-2 text-sm font-medium rounded-lg border border-neutral-200 text-neutral-700 hover:bg-neutral-50 hover:border-neutral-300 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    Sourate précédente
                  </button>
                  <button
                    onClick={() => goToAdjacentSurah('next')}
                    disabled={!canGoNext}
                    className="flex items-center gap-1.5 px-4 py-2 text-sm font-medium rounded-lg border border-neutral-200 text-neutral-700 hover:bg-neutral-50 hover:border-neutral-300 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                  >
                    Sourate suivante
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

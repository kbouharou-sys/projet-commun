import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import {
  Brain,
  Check,
  X,
  RotateCcw,
  Trophy,
  ChevronRight,
  Loader2,
  Sparkles,
  TrendingUp,
  History,
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

interface Root {
  id: string;
  arabic_root: string;
  root_translation: string | null;
  occurrence_count: number;
}

interface Question {
  root: Root;
  options: string[];
  correctAnswer: string;
}

type QuizMode = 'ar_to_fr' | 'fr_to_ar';
type GameState = 'idle' | 'playing' | 'finished';

function shuffleArray<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function buildQuestion(
  root: Root,
  allRoots: Root[],
  mode: QuizMode
): Question {
  const distractors = shuffleArray(
    allRoots.filter((r) => r.id !== root.id && r.root_translation)
  ).slice(0, 3);

  if (mode === 'ar_to_fr') {
    const correct = root.root_translation ?? '';
    const options = shuffleArray([
      correct,
      ...(distractors.map((d) => d.root_translation ?? '')),
    ]);
    return { root, options, correctAnswer: correct };
  } else {
    const correct = root.arabic_root;
    const options = shuffleArray([
      correct,
      ...(distractors.map((d) => d.arabic_root)),
    ]);
    return { root, options, correctAnswer: correct };
  }
}

export default function Quiz() {
  const { user } = useAuth();
  const [roots, setRoots] = useState<Root[]>([]);
  const [loading, setLoading] = useState(true);
  const [gameState, setGameState] = useState<GameState>('idle');
  const [quizMode, setQuizMode] = useState<QuizMode>('ar_to_fr');
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [bestStreak, setBestStreak] = useState(0);
  const [answeredCount, setAnsweredCount] = useState(0);
  const [wrongRoots, setWrongRoots] = useState<Root[]>([]);
  const [quizHistory, setQuizHistory] = useState<{ score: number; total: number; mode: string; created_at: string; best_streak: number }[]>([]);

  useEffect(() => {
    async function fetchRoots() {
      const { data } = await supabase
        .from('roots')
        .select('id, arabic_root, root_translation, occurrence_count')
        .not('root_translation', 'is', null);

      if (data && data.length >= 4) {
        setRoots(data);
      }

      if (user) {
        const { data: histData } = await supabase
          .from('quiz_results')
          .select('score, total, mode, created_at, best_streak')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })
          .limit(5);
        if (histData) {
          setQuizHistory(histData);
        }
      }

      setLoading(false);
    }
    fetchRoots();
  }, [user]);

  const startQuiz = useCallback(
    (mode: QuizMode) => {
      if (roots.length < 4) return;
      const selected = shuffleArray(roots).slice(0, Math.min(10, roots.length));
      const built = selected.map((r) => buildQuestion(r, roots, mode));
      setQuizMode(mode);
      setQuestions(built);
      setCurrentIndex(0);
      setSelectedAnswer(null);
      setShowResult(false);
      setScore(0);
      setStreak(0);
      setBestStreak(0);
      setAnsweredCount(0);
      setWrongRoots([]);
      setGameState('playing');
    },
    [roots]
  );

  const handleAnswer = useCallback(
    (answer: string) => {
      if (showResult) return;
      const current = questions[currentIndex];
      setSelectedAnswer(answer);
      setShowResult(true);
      setAnsweredCount((c) => c + 1);

      if (answer === current.correctAnswer) {
        setScore((s) => s + 1);
        setStreak((s) => {
          const newStreak = s + 1;
          setBestStreak((b) => Math.max(b, newStreak));
          return newStreak;
        });
      } else {
        setStreak(0);
        setWrongRoots((w) => [...w, current.root]);
      }
    },
    [showResult, questions, currentIndex]
  );

  const nextQuestion = useCallback(() => {
    if (currentIndex + 1 >= questions.length) {
      setGameState('finished');
      if (user) {
        supabase
          .from('quiz_results')
          .insert({
            user_id: user.id,
            mode: quizMode,
            score,
            total: questions.length,
            best_streak: bestStreak,
          })
          .then(() => {
            supabase
              .from('quiz_results')
              .select('score, total, mode, created_at, best_streak')
              .eq('user_id', user.id)
              .order('created_at', { ascending: false })
              .limit(5)
              .then(({ data }) => {
                if (data) setQuizHistory(data);
              });
          });
      }
    } else {
      setCurrentIndex((i) => i + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    }
  }, [currentIndex, questions.length, user, quizMode, score, bestStreak]);

  const progress = questions.length > 0 ? ((currentIndex + (showResult ? 1 : 0)) / questions.length) * 100 : 0;

  if (loading) {
    return (
      <div className="p-4 lg:p-8 max-w-3xl mx-auto">
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-6 h-6 animate-spin text-primary-600" />
        </div>
      </div>
    );
  }

  if (roots.length < 4) {
    return (
      <div className="p-4 lg:p-8 max-w-3xl mx-auto">
        <div className="bg-white border border-neutral-200 rounded-xl p-12 text-center">
          <Brain className="w-12 h-12 text-neutral-300 mx-auto mb-4" />
          <p className="text-neutral-500 font-medium">Données insuffisantes</p>
          <p className="text-sm text-neutral-400 mt-1">
            Le quiz nécessite au moins 4 racines dans le dictionnaire.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 max-w-3xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl lg:text-3xl font-bold text-neutral-900 mb-2 flex items-center gap-2">
          <Brain className="w-7 h-7 text-primary-600" />
          Révision & Quiz
        </h1>
        <p className="text-sm text-neutral-500">
          Testez vos connaissances des racines arabes du Coran.
        </p>
      </div>

      {/* IDLE: Mode selection */}
      {gameState === 'idle' && (
        <div className="space-y-4 animate-fade-in">
          <div className="bg-white border border-neutral-200 rounded-xl p-6">
            <h2 className="font-semibold text-neutral-900 mb-2">Choisissez un mode</h2>
            <p className="text-sm text-neutral-500 mb-4">
              {roots.length} racines disponibles — 10 questions par session
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                onClick={() => startQuiz('ar_to_fr')}
                className="group flex flex-col items-start p-5 bg-white border-2 border-neutral-200 rounded-xl hover:border-primary-400 hover:shadow-md transition-all text-left"
              >
                <div className="w-10 h-10 rounded-lg bg-primary-50 flex items-center justify-center mb-3">
                  <span className="font-arabic text-lg text-primary-700">عربي</span>
                </div>
                <p className="font-semibold text-neutral-900 text-sm">Arabe → Français</p>
                <p className="text-xs text-neutral-500 mt-1">
                  On vous donne une racine arabe, trouvez sa traduction
                </p>
                <ChevronRight className="w-4 h-4 text-neutral-300 group-hover:text-primary-600 mt-3 transition-colors" />
              </button>

              <button
                onClick={() => startQuiz('fr_to_ar')}
                className="group flex flex-col items-start p-5 bg-white border-2 border-neutral-200 rounded-xl hover:border-primary-400 hover:shadow-md transition-all text-left"
              >
                <div className="w-10 h-10 rounded-lg bg-accent-50 flex items-center justify-center mb-3">
                  <span className="font-semibold text-sm text-accent-700">FR</span>
                </div>
                <p className="font-semibold text-neutral-900 text-sm">Français → Arabe</p>
                <p className="text-xs text-neutral-500 mt-1">
                  On vous donne une traduction, trouvez la racine arabe
                </p>
                <ChevronRight className="w-4 h-4 text-neutral-300 group-hover:text-primary-600 mt-3 transition-colors" />
              </button>
            </div>
          </div>

          <div className="bg-primary-50 border border-primary-200 rounded-xl p-5">
            <div className="flex items-start gap-3">
              <Sparkles className="w-5 h-5 text-primary-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-primary-800">Comment ça marche</p>
                <p className="text-xs text-primary-700 mt-1 leading-relaxed">
                  Chaque session tire 10 racines au hasard parmi les {roots.length} disponibles.
                  Choisissez la bonne réponse parmi 4 options. Suivez votre score et votre série
                  de bonnes réponses consécutives.
                </p>
              </div>
            </div>
          </div>

          {user && quizHistory.length > 0 && (
            <div className="bg-white border border-neutral-200 rounded-xl p-5">
              <h3 className="font-semibold text-sm text-neutral-700 mb-3 flex items-center gap-2">
                <History className="w-4 h-4 text-primary-600" />
                Historique récent
              </h3>
              <div className="space-y-2">
                {quizHistory.map((h, i) => (
                  <div key={i} className="flex items-center justify-between p-3 bg-neutral-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <span className={`text-xs px-2 py-0.5 rounded ${
                        h.mode === 'ar_to_fr' ? 'bg-primary-100 text-primary-700' : 'bg-accent-100 text-accent-700'
                      }`}>
                        {h.mode === 'ar_to_fr' ? 'AR → FR' : 'FR → AR'}
                      </span>
                      <span className="text-sm font-medium text-neutral-700">
                        {h.score}/{h.total}
                      </span>
                      {h.best_streak > 0 && (
                        <span className="text-xs text-neutral-400 flex items-center gap-0.5">
                          <TrendingUp className="w-3 h-3" />
                          {h.best_streak}
                        </span>
                      )}
                    </div>
                    <span className="text-xs text-neutral-400">
                      {new Date(h.created_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* PLAYING: Quiz questions */}
      {gameState === 'playing' && questions.length > 0 && (
        <div className="space-y-4 animate-fade-in">
          {/* Stats bar */}
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-white border border-neutral-200 rounded-lg p-3 text-center">
              <p className="text-xs text-neutral-400">Score</p>
              <p className="text-xl font-bold text-primary-600">{score}</p>
            </div>
            <div className="bg-white border border-neutral-200 rounded-lg p-3 text-center">
              <p className="text-xs text-neutral-400">Série</p>
              <p className="text-xl font-bold text-accent-600 flex items-center justify-center gap-1">
                {streak > 0 && <TrendingUp className="w-4 h-4" />}
                {streak}
              </p>
            </div>
            <div className="bg-white border border-neutral-200 rounded-lg p-3 text-center">
              <p className="text-xs text-neutral-400">Question</p>
              <p className="text-xl font-bold text-neutral-700">
                {currentIndex + 1}/{questions.length}
              </p>
            </div>
          </div>

          {/* Progress bar */}
          <div className="h-2 bg-neutral-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-primary-600 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>

          {/* Question card */}
          <div className="bg-white border border-neutral-200 rounded-xl overflow-hidden">
            <div className="p-6 bg-gradient-to-br from-primary-700 to-primary-600 text-white text-center">
              <p className="text-xs text-primary-100 mb-3 uppercase tracking-wide">
                {quizMode === 'ar_to_fr' ? 'Quelle est la traduction ?' : 'Quelle est la racine arabe ?'}
              </p>
              <p
                className={`${
                  quizMode === 'ar_to_fr' ? 'font-arabic text-5xl' : 'text-2xl font-semibold'
                } leading-relaxed`}
              >
                {quizMode === 'ar_to_fr'
                  ? questions[currentIndex].root.arabic_root
                  : questions[currentIndex].root.root_translation}
              </p>
              <p className="text-xs text-primary-200 mt-3">
                {questions[currentIndex].root.occurrence_count} occurrences dans le Coran
              </p>
            </div>

            {/* Options */}
            <div className="p-4 space-y-2">
              {questions[currentIndex].options.map((option) => {
                const isCorrect = option === questions[currentIndex].correctAnswer;
                const isSelected = option === selectedAnswer;
                const showCorrect = showResult && isCorrect;
                const showWrong = showResult && isSelected && !isCorrect;

                return (
                  <button
                    key={option}
                    onClick={() => handleAnswer(option)}
                    disabled={showResult}
                    className={`w-full flex items-center justify-between px-4 py-3.5 rounded-lg border-2 text-left transition-all ${
                      showCorrect
                        ? 'border-primary-500 bg-primary-50'
                        : showWrong
                        ? 'border-red-400 bg-red-50'
                        : isSelected
                        ? 'border-primary-400 bg-primary-50'
                        : 'border-neutral-200 hover:border-primary-300 hover:bg-neutral-50'
                    } ${showResult ? 'cursor-default' : 'cursor-pointer'} ${
                      quizMode === 'fr_to_ar' && !showResult ? 'font-arabic text-lg' : ''
                    }`}
                  >
                    <span className={`${
                      quizMode === 'fr_to_ar' && !showResult ? 'text-neutral-900' : 'text-sm font-medium text-neutral-800'
                    }`}>
                      {option}
                    </span>
                    {showCorrect && <Check className="w-5 h-5 text-primary-600 flex-shrink-0" />}
                    {showWrong && <X className="w-5 h-5 text-red-500 flex-shrink-0" />}
                  </button>
                );
              })}
            </div>

            {/* Feedback + Next button */}
            {showResult && (
              <div className="px-4 pb-4 animate-fade-in">
                {selectedAnswer === questions[currentIndex].correctAnswer ? (
                  <div className="flex items-center gap-2 text-primary-700 mb-3">
                    <Check className="w-4 h-4" />
                    <span className="text-sm font-medium">Correct !</span>
                  </div>
                ) : (
                  <div className="mb-3">
                    <div className="flex items-center gap-2 text-red-600 mb-1">
                      <X className="w-4 h-4" />
                      <span className="text-sm font-medium">Incorrect</span>
                    </div>
                    <p className="text-xs text-neutral-500">
                      La bonne réponse était:{' '}
                      <span className={`${
                        quizMode === 'fr_to_ar' ? 'font-arabic text-base' : 'font-medium'
                      } text-primary-700`}>
                        {questions[currentIndex].correctAnswer}
                      </span>
                    </p>
                  </div>
                )}
                <button
                  onClick={nextQuestion}
                  className="w-full px-4 py-3 bg-primary-600 text-white rounded-lg font-semibold hover:bg-primary-700 transition-colors flex items-center justify-center gap-2"
                >
                  {currentIndex + 1 >= questions.length ? 'Voir les résultats' : 'Question suivante'}
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* FINISHED: Results screen */}
      {gameState === 'finished' && (
        <div className="space-y-4 animate-fade-in">
          <div className="bg-white border border-neutral-200 rounded-xl p-8 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary-50 mb-4">
              <Trophy className="w-8 h-8 text-primary-600" />
            </div>
            <h2 className="text-2xl font-bold text-neutral-900 mb-1">Quiz terminé !</h2>
            <p className="text-sm text-neutral-500 mb-6">
              Vous avez répondu à {questions.length} questions
            </p>

            <div className="grid grid-cols-3 gap-3 mb-6">
              <div className="p-4 bg-primary-50 rounded-lg">
                <p className="text-xs text-primary-600 mb-1">Score</p>
                <p className="text-2xl font-bold text-primary-700">
                  {score}/{questions.length}
                </p>
              </div>
              <div className="p-4 bg-accent-50 rounded-lg">
                <p className="text-xs text-accent-600 mb-1">Meilleure série</p>
                <p className="text-2xl font-bold text-accent-700">{bestStreak}</p>
              </div>
              <div className="p-4 bg-neutral-50 rounded-lg">
                <p className="text-xs text-neutral-500 mb-1">Précision</p>
                <p className="text-2xl font-bold text-neutral-700">
                  {Math.round((score / questions.length) * 100)}%
                </p>
              </div>
            </div>

            {/* Score message */}
            <div className="mb-6">
              {score === questions.length && (
                <p className="text-sm font-medium text-primary-600">Parfait ! Vous maîtrisez toutes les racines de cette session.</p>
              )}
              {score >= questions.length * 0.7 && score < questions.length && (
                <p className="text-sm font-medium text-primary-600">Très bien ! Vous connaissez bien vos racines.</p>
              )}
              {score >= questions.length * 0.5 && score < questions.length * 0.7 && (
                <p className="text-sm font-medium text-accent-600">Bon début ! Continuez à réviser.</p>
              )}
              {score < questions.length * 0.5 && (
                <p className="text-sm font-medium text-neutral-500">Pas de souci, la pratique mène à la maîtrise !</p>
              )}
            </div>

            {/* Wrong roots review */}
            {wrongRoots.length > 0 && (
              <div className="text-left mb-6">
                <h3 className="text-sm font-semibold text-neutral-700 mb-3 flex items-center gap-2">
                  <X className="w-4 h-4 text-red-400" />
                  Racines à revoir ({wrongRoots.length})
                </h3>
                <div className="space-y-2">
                  {wrongRoots.map((root) => (
                    <div
                      key={root.id}
                      className="flex items-center gap-3 p-3 bg-red-50 border border-red-100 rounded-lg"
                    >
                      <p className="font-arabic text-xl text-neutral-900 flex-shrink-0">
                        {root.arabic_root}
                      </p>
                      <p className="text-sm text-neutral-600">
                        {root.root_translation}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <button
              onClick={() => startQuiz(quizMode)}
              className="w-full px-4 py-3 bg-primary-600 text-white rounded-lg font-semibold hover:bg-primary-700 transition-colors flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              Rejouer ({quizMode === 'ar_to_fr' ? 'Arabe → Français' : 'Français → Arabe'})
            </button>
            <button
              onClick={() => setGameState('idle')}
              className="w-full px-4 py-2.5 mt-2 text-sm font-medium text-neutral-600 hover:text-neutral-900 transition-colors"
            >
              Changer de mode
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

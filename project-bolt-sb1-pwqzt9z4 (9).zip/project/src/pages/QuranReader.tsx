import { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import {
  BookOpen,
  ChevronRight,
  ChevronLeft,
  AlertCircle,
  Loader2,
  Check,
  Bookmark,
  BookmarkCheck,
  BarChart3,
  ArrowLeft,
  Grid3x3,
} from 'lucide-react';

interface Surah {
  id: string;
  number: number;
  name_fr: string;
  name_ar: string;
  revelation_type: string | null;
  verse_count: number;
}

interface Verse {
  id: string;
  surah_id: string;
  verse_number: number;
  arabic_uthmani: string;
  french_pretranslation: string;
  order_index: number;
}

interface VerseWord {
  id: string;
  verse_id: string;
  position: number;
  arabic_form: string;
  root_id: string | null;
}

export default function QuranReader() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [surah, setSurah] = useState<Surah | null>(null);
  const [allSurahs, setAllSurahs] = useState<Surah[]>([]);
  const [verses, setVerses] = useState<Verse[]>([]);
  const [verseWordsMap, setVerseWordsMap] = useState<Map<string, VerseWord[]>>(new Map());
  const [loading, setLoading] = useState(true);
  const [versesLoading, setVersesLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [bookmarkedVerseIds, setBookmarkedVerseIds] = useState<Set<string>>(new Set());
  const [currentProgress, setCurrentProgress] = useState<{ last_verse: number; completed: boolean } | null>(null);
  const [bookmarkLoading, setBookmarkLoading] = useState<string | null>(null);

  useEffect(() => {
    async function fetchSurahList() {
      const { data } = await supabase
        .from('surahs')
        .select('id, number, name_fr, name_ar, revelation_type, verse_count')
        .order('number', { ascending: true });
      if (data) setAllSurahs(data);
    }
    fetchSurahList();
  }, []);

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    setError(null);
    setVerses([]);
    setVerseWordsMap(new Map());

    async function fetchSurah() {
      const { data, error: err } = await supabase
        .from('surahs')
        .select('id, number, name_fr, name_ar, revelation_type, verse_count')
        .eq('id', id)
        .single();

      if (err || !data) {
        setError('Sourate introuvable');
        setLoading(false);
        return;
      }
      setSurah(data);
      setLoading(false);
    }
    fetchSurah();
  }, [id]);

  const fetchVerses = useCallback(async () => {
    if (!surah) return;
    setVersesLoading(true);

    const { data, error: vError } = await supabase
      .from('verses')
      .select('*')
      .eq('surah_id', surah.id)
      .order('verse_number', { ascending: true });

    if (vError) {
      setError(vError.message);
    } else {
      const verseList = data ?? [];
      setVerses(verseList);

      // Fetch verse_words for these verses
      if (verseList.length > 0) {
        const verseIds = verseList.map((v) => v.id);
        const { data: vwData } = await supabase
          .from('verse_words')
          .select('id, verse_id, position, arabic_form, root_id')
          .in('verse_id', verseIds)
          .order('position', { ascending: true });

        if (vwData) {
          const vwMap = new Map<string, VerseWord[]>();
          for (const vw of vwData) {
            const arr = vwMap.get(vw.verse_id) ?? [];
            arr.push(vw);
            vwMap.set(vw.verse_id, arr);
          }
          setVerseWordsMap(vwMap);
        }
      }
    }
    setVersesLoading(false);

    if (user) {
      const [bmRes, progRes] = await Promise.all([
        supabase.from('bookmarks').select('verse_id').eq('user_id', user.id),
        supabase.from('reading_progress')
          .select('last_verse_number, is_completed')
          .eq('user_id', user.id)
          .eq('surah_id', surah.id)
          .maybeSingle(),
      ]);

      if (bmRes.data) setBookmarkedVerseIds(new Set(bmRes.data.map((b) => b.verse_id)));
      if (progRes.data) {
        setCurrentProgress({
          last_verse: progRes.data.last_verse_number,
          completed: progRes.data.is_completed,
        });
      } else {
        setCurrentProgress(null);
      }
    }
  }, [surah, user]);

  useEffect(() => {
    fetchVerses();
  }, [fetchVerses]);

  const updateProgress = useCallback(async (lastVerseNumber: number, totalVerses: number) => {
    if (!user || !surah) return;
    const isCompleted = lastVerseNumber >= totalVerses;

    await supabase
      .from('reading_progress')
      .upsert({
        user_id: user.id,
        surah_id: surah.id,
        last_verse_number: lastVerseNumber,
        is_completed: isCompleted,
        updated_at: new Date().toISOString(),
      }, { onConflict: 'user_id,surah_id' });

    setCurrentProgress({ last_verse: lastVerseNumber, completed: isCompleted });
  }, [user, surah]);

  const toggleBookmark = useCallback(async (verse: Verse) => {
    if (!user || !surah) return;
    setBookmarkLoading(verse.id);

    const isBookmarked = bookmarkedVerseIds.has(verse.id);
    if (isBookmarked) {
      await supabase
        .from('bookmarks')
        .delete()
        .eq('user_id', user.id)
        .eq('verse_id', verse.id);
      setBookmarkedVerseIds((prev) => {
        const next = new Set(prev);
        next.delete(verse.id);
        return next;
      });
    } else {
      await supabase
        .from('bookmarks')
        .insert({
          user_id: user.id,
          verse_id: verse.id,
          surah_id: surah.id,
        });
      setBookmarkedVerseIds((prev) => new Set(prev).add(verse.id));
    }
    setBookmarkLoading(null);
  }, [user, surah, bookmarkedVerseIds]);

  function goToAdjacentSurah(direction: 'prev' | 'next') {
    if (!surah) return;
    const targetNumber = direction === 'prev' ? surah.number - 1 : surah.number + 1;
    const target = allSurahs.find((s) => s.number === targetNumber);
    if (target) navigate(`/quran/${target.id}`);
  }

  function renderArabicWords(verse: Verse) {
    const words = verseWordsMap.get(verse.id);
    if (!words || words.length === 0) {
      return <span>{verse.arabic_uthmani}</span>;
    }

    // Sort words by position to maintain reading order
    const sortedWords = [...words].sort((a, b) => a.position - b.position);

    // Build a map of arabic_form -> word for quick lookup
    const formToWord = new Map<string, VerseWord>();
    for (const w of sortedWords) {
      if (!formToWord.has(w.arabic_form)) {
        formToWord.set(w.arabic_form, w);
      }
    }

    // Split the verse text by spaces and render each token
    // If a token matches a known word form, make it clickable
    const tokens = verse.arabic_uthmani.split(/\s+/);
    const usedIds = new Set<string>();

    return (
      <>
        {tokens.map((token, i) => {
          const matchedWord = formToWord.get(token);
          // Also try without diacritics differences by checking if any word form is contained
          if (matchedWord && !usedIds.has(matchedWord.id)) {
            usedIds.add(matchedWord.id);
            return (
              <span key={i}>
                <Link
                  to={matchedWord.root_id ? `/dictionary?root=${matchedWord.root_id}` : '/dictionary'}
                  className="bg-primary-50 hover:bg-primary-100 text-primary-700 rounded px-1 transition-colors cursor-pointer underline decoration-primary-300 underline-offset-4"
                  title={matchedWord.root_id ? 'Voir dans le dictionnaire' : 'Non lié à une racine'}
                >
                  {token}
                </Link>
                {i < tokens.length - 1 ? ' ' : ''}
              </span>
            );
          }
          return (
            <span key={i}>
              {token}
              {i < tokens.length - 1 ? ' ' : ''}
            </span>
          );
        })}
      </>
    );
  }

  const hasVerses = verses.length > 0;
  const canGoPrev = surah && surah.number > 1;
  const canGoNext = surah && surah.number < 114;

  if (loading) {
    return (
      <div className="p-8 max-w-4xl mx-auto">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-neutral-200 rounded w-1/3" />
          <div className="h-32 bg-neutral-200 rounded-xl" />
          <div className="h-16 bg-neutral-200 rounded" />
          <div className="h-16 bg-neutral-200 rounded" />
        </div>
      </div>
    );
  }

  if (error && !surah) {
    return (
      <div className="p-8 max-w-4xl mx-auto">
        <div className="bg-white border border-neutral-200 rounded-xl p-12 text-center">
          <AlertCircle className="w-12 h-12 text-neutral-300 mx-auto mb-4" />
          <p className="text-neutral-500 font-medium">{error}</p>
          <Link to="/quran" className="inline-flex items-center gap-2 mt-4 text-sm text-primary-600 hover:text-primary-700">
            <ArrowLeft className="w-4 h-4" />
            Retour aux sourates
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 max-w-4xl mx-auto">
      {/* Back to surah list */}
      <div className="flex items-center justify-between mb-4">
        <Link
          to="/quran"
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-lg bg-neutral-100 text-neutral-700 hover:bg-neutral-200 transition-colors"
        >
          <Grid3x3 className="w-4 h-4" />
          Toutes les sourates
        </Link>
        <div className="flex items-center gap-2">
          <button
            onClick={() => goToAdjacentSurah('prev')}
            disabled={!canGoPrev}
            className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium rounded-lg border border-neutral-200 text-neutral-700 hover:bg-neutral-50 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <ChevronLeft className="w-4 h-4" />
            Précédente
          </button>
          <button
            onClick={() => goToAdjacentSurah('next')}
            disabled={!canGoNext}
            className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium rounded-lg border border-neutral-200 text-neutral-700 hover:bg-neutral-50 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
          >
            Suivante
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Surah header */}
      <div className="bg-gradient-to-r from-primary-800 to-primary-600 text-white rounded-xl p-6 mb-4 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -translate-y-16 translate-x-16" />
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/5 rounded-full translate-y-12 -translate-x-12" />
        <div className="relative flex items-center justify-between">
          <div className="flex-1 min-w-0">
            <h2 className="text-xl lg:text-2xl font-bold">{surah!.name_fr}</h2>
            <p className="font-arabic text-2xl mt-2">{surah!.name_ar}</p>
          </div>
          <div className="text-right">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-full border-2 border-white/30 mb-2">
              <span className="text-lg font-bold">{surah!.number}</span>
            </div>
            {surah!.revelation_type && (
              <p className="text-xs text-primary-100">
                {surah!.revelation_type === 'meccan' ? 'Mecquoise' : 'Médinoise'}
              </p>
            )}
            <p className="text-xs text-primary-100 mt-0.5">
              {surah!.verse_count} versets
            </p>
          </div>
        </div>
        {user && currentProgress && (
          <div className="relative mt-4 pt-4 border-t border-white/20">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-3.5 h-3.5 text-primary-100" />
              <span className="text-xs text-primary-100">
                Progression: verset {currentProgress.last_verse}/{surah!.verse_count}
                {currentProgress.completed && ' — terminée'}
              </span>
            </div>
            <div className="h-1.5 bg-white/20 rounded-full mt-2 overflow-hidden">
              <div
                className="h-full bg-white rounded-full transition-all duration-500"
                style={{ width: `${Math.min((currentProgress.last_verse / surah!.verse_count) * 100, 100)}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* Verses */}
      {versesLoading ? (
        <div className="bg-white border border-neutral-200 rounded-xl p-8">
          <div className="flex items-center justify-center gap-2 text-neutral-400">
            <Loader2 className="w-5 h-5 animate-spin" />
            <span className="text-sm">Chargement des versets...</span>
          </div>
        </div>
      ) : !hasVerses ? (
        <div className="bg-white border border-neutral-200 rounded-xl p-8 text-center">
          <BookOpen className="w-10 h-10 text-neutral-300 mx-auto mb-3" />
          <p className="text-sm text-neutral-500 font-medium">Aucun verset disponible</p>
          <p className="text-xs text-neutral-400 mt-1 max-w-md mx-auto">
            Les versets de cette sourate n'ont pas encore été intégrés.
          </p>
        </div>
      ) : (
        <div className="bg-white border border-neutral-200 rounded-xl overflow-hidden">
          {verses.map((verse, index) => {
            const isBookmarked = bookmarkedVerseIds.has(verse.id);
            const linkedWords = verseWordsMap.get(verse.id);
            const hasLinkedWords = linkedWords && linkedWords.length > 0;
            return (
              <div
                key={verse.id}
                className={`p-5 lg:p-6 group ${
                  index % 2 === 0 ? 'verse-block-white' : 'verse-block-beige'
                } ${index > 0 ? 'border-t border-neutral-100' : ''}`}
              >
                <div className="flex items-start gap-4">
                  <div className="w-9 h-9 rounded-full border-2 border-primary-300 bg-primary-50 flex items-center justify-center text-xs font-semibold text-primary-700 flex-shrink-0 mt-1">
                    {verse.verse_number}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-arabic text-2xl lg:text-3xl font-semibold text-neutral-900 leading-loose mb-3 text-right" dir="rtl">
                      {renderArabicWords(verse)}
                    </p>
                    {verse.french_pretranslation ? (
                      <p className="text-base text-neutral-700 leading-relaxed">
                        {verse.french_pretranslation}
                      </p>
                    ) : (
                      <p className="text-sm text-neutral-400 italic">Traduction française à venir</p>
                    )}
                    {hasLinkedWords && (
                      <p className="text-xs text-primary-500 mt-2">
                        {linkedWords!.length} mot(s) lié(s) à une racine — cliquez pour ouvrir le dictionnaire
                      </p>
                    )}
                  </div>
                  {user && (
                    <button
                      onClick={() => toggleBookmark(verse)}
                      disabled={bookmarkLoading === verse.id}
                      title={isBookmarked ? 'Retirer le marque-page' : 'Marquer ce verset'}
                      className={`flex-shrink-0 mt-1 p-2 rounded-lg transition-all ${
                        isBookmarked
                          ? 'text-primary-600 bg-primary-50 hover:bg-primary-100'
                          : 'text-neutral-300 hover:text-primary-600 hover:bg-neutral-100 opacity-0 group-hover:opacity-100'
                      }`}
                    >
                      {isBookmarked
                        ? <BookmarkCheck className="w-5 h-5" />
                        : <Bookmark className="w-5 h-5" />}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
          {user && hasVerses && (
            <div className="p-4 bg-neutral-50 border-t border-neutral-200">
              <button
                onClick={() => updateProgress(verses.length, surah!.verse_count)}
                className="w-full px-4 py-2.5 bg-primary-600 text-white rounded-lg font-medium text-sm hover:bg-primary-700 transition-colors flex items-center justify-center gap-2"
              >
                <Check className="w-4 h-4" />
                Marquer comme lu ({verses.length}/{surah!.verse_count} versets)
              </button>
            </div>
          )}
        </div>
      )}

      {/* Bottom navigation */}
      {hasVerses && (
        <div className="flex items-center justify-between gap-3 mt-4">
          <button
            onClick={() => goToAdjacentSurah('prev')}
            disabled={!canGoPrev}
            className="flex items-center gap-1.5 px-4 py-2 text-sm font-medium rounded-lg border border-neutral-200 text-neutral-700 hover:bg-neutral-50 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <ChevronLeft className="w-4 h-4" />
            Sourate précédente
          </button>
          <Link
            to="/quran"
            className="flex items-center gap-1.5 px-4 py-2 text-sm font-medium rounded-lg border border-neutral-200 text-neutral-700 hover:bg-neutral-50 transition-colors"
          >
            <Grid3x3 className="w-4 h-4" />
            Liste
          </Link>
          <button
            onClick={() => goToAdjacentSurah('next')}
            disabled={!canGoNext}
            className="flex items-center gap-1.5 px-4 py-2 text-sm font-medium rounded-lg border border-neutral-200 text-neutral-700 hover:bg-neutral-50 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
          >
            Sourate suivante
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
}

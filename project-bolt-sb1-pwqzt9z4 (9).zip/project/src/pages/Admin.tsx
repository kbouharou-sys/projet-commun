import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import {
  Shield,
  Users,
  Database,
  History,
  Lock,
  CheckCircle,
  BookOpen,
  Download,
  Loader2,
  RefreshCw,
  BookText,
  Plus,
  Search as SearchIcon,
  Trash2,
} from 'lucide-react';

interface ChangeLogEntry {
  id: string;
  user_id: string | null;
  action: string;
  table_name: string;
  row_id: string | null;
  created_at: string;
}

interface Surah {
  id: string;
  number: number;
  name_fr: string;
  name_ar: string;
  verse_count: number;
  has_verses: boolean;
}

interface ImportProgress {
  current: number;
  total: number;
  surahName: string;
  status: 'idle' | 'running' | 'done' | 'error';
  imported: number;
  errors: string[];
  log: string[];
}

export default function AdminPage() {
  const { user, role } = useAuth();
  const isAdmin = role === 'admin_principal' || role === 'admin_2' || role === 'admin_3';
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'data' | 'dictionary' | 'logs'>('data');
  const [logEntries, setLogEntries] = useState<ChangeLogEntry[]>([]);
  const [logLoading, setLogLoading] = useState(false);
  const [tableCounts, setTableCounts] = useState<Record<string, number>>({});
  const [surahs, setSurahs] = useState<Surah[]>([]);
  const [surahsLoading, setSurahsLoading] = useState(false);
  const [importProgress, setImportProgress] = useState<ImportProgress>({
    current: 0,
    total: 0,
    surahName: '',
    status: 'idle',
    imported: 0,
    errors: [],
    log: [],
  });
  const [dictStats, setDictStats] = useState<{ roots: number; verseWords: number; variations: number } | null>(null);
  const [newRootArabic, setNewRootArabic] = useState('');
  const [newRootOthmani, setNewRootOthmani] = useState('');
  const [newRootTranslation, setNewRootTranslation] = useState('');
  const [newRootOccurrence, setNewRootOccurrence] = useState('');
  const [newRootRank, setNewRootRank] = useState('');
  const [creatingRoot, setCreatingRoot] = useState(false);
  const [rootCreateMsg, setRootCreateMsg] = useState<string | null>(null);
  const [rootSearch, setRootSearch] = useState('');
  const [allRoots, setAllRoots] = useState<{ id: string; arabic_root: string; othmani_root: string | null; root_translation: string | null; occurrence_count: number | null; frequency_rank: number | null }[]>([]);
  const [linkVerseId, setLinkVerseId] = useState('');
  const [linkArabicForm, setLinkArabicForm] = useState('');
  const [linkRootId, setLinkRootId] = useState('');
  const [linkPosition, setLinkPosition] = useState('1');
  const [creatingLink, setCreatingLink] = useState(false);
  const [linkCreateMsg, setLinkCreateMsg] = useState<string | null>(null);

  useEffect(() => {
    if (activeTab === 'logs') {
      fetchLogs();
    }
    if (activeTab === 'overview') {
      fetchTableCounts();
    }
    if (activeTab === 'data') {
      fetchSurahs();
    }
    if (activeTab === 'dictionary') {
      fetchDictionaryStats();
    }
  }, [activeTab]);

  async function fetchLogs() {
    setLogLoading(true);
    const { data } = await supabase
      .from('change_log')
      .select('id, user_id, action, table_name, row_id, created_at')
      .order('created_at', { ascending: false })
      .limit(50);
    setLogEntries(data ?? []);
    setLogLoading(false);
  }

  async function fetchTableCounts() {
    const tables = ['surahs', 'verses', 'verse_words', 'roots', 'variations', 'user_roles'];
    const counts: Record<string, number> = {};
    for (const table of tables) {
      const { count } = await supabase.from(table).select('*', { count: 'exact', head: true });
      counts[table] = count ?? 0;
    }
    setTableCounts(counts);
  }

  async function fetchSurahs() {
    setSurahsLoading(true);
    const { data: surahData } = await supabase
      .from('surahs')
      .select('id, number, name_fr, name_ar, verse_count')
      .order('number', { ascending: true });

    const { data: verseData } = await supabase.from('verses').select('surah_id');

    const surahsWithVerses = new Set((verseData ?? []).map((v) => v.surah_id));
    const mapped: Surah[] = (surahData ?? []).map((s) => ({
      ...s,
      has_verses: surahsWithVerses.has(s.id),
    }));
    setSurahs(mapped);
    setSurahsLoading(false);
  }

  async function fetchDictionaryStats() {
    const [rootsRes, vwRes, varRes] = await Promise.all([
      supabase.from('roots').select('*', { count: 'exact', head: true }),
      supabase.from('verse_words').select('*', { count: 'exact', head: true }),
      supabase.from('variations').select('*', { count: 'exact', head: true }),
    ]);
    setDictStats({
      roots: rootsRes.count ?? 0,
      verseWords: vwRes.count ?? 0,
      variations: varRes.count ?? 0,
    });

    const { data: rootData } = await supabase
      .from('roots')
      .select('id, arabic_root, othmani_root, root_translation, occurrence_count, frequency_rank')
      .order('frequency_rank', { ascending: true, nullsFirst: false });
    setAllRoots(rootData ?? []);
  }

  async function createRoot() {
    if (!newRootArabic.trim()) {
      setRootCreateMsg('La racine arabe est obligatoire');
      return;
    }
    setCreatingRoot(true);
    setRootCreateMsg(null);

    const insertData: Record<string, unknown> = {
      arabic_root: newRootArabic.trim(),
      othmani_root: newRootOthmani.trim() || null,
      root_translation: newRootTranslation.trim() || null,
    };
    if (newRootOccurrence.trim()) insertData.occurrence_count = parseInt(newRootOccurrence, 10);
    if (newRootRank.trim()) insertData.frequency_rank = parseInt(newRootRank, 10);

    const { error: insertError } = await supabase.from('roots').insert(insertData);

    if (insertError) {
      setRootCreateMsg(`Erreur: ${insertError.message}`);
    } else {
      setRootCreateMsg('Racine créée avec succès');
      setNewRootArabic('');
      setNewRootOthmani('');
      setNewRootTranslation('');
      setNewRootOccurrence('');
      setNewRootRank('');
      await fetchDictionaryStats();
      setTimeout(() => setRootCreateMsg(null), 3000);
    }
    setCreatingRoot(false);
  }

  async function deleteRoot(rootId: string) {
    const { error } = await supabase.from('roots').delete().eq('id', rootId);
    if (error) {
      setRootCreateMsg(`Erreur suppression: ${error.message}`);
    } else {
      await fetchDictionaryStats();
    }
  }

  async function createVerseWordLink() {
    if (!linkVerseId.trim() || !linkArabicForm.trim() || !linkRootId) {
      setLinkCreateMsg('Verse ID, forme arabe et racine sont obligatoires');
      return;
    }
    setCreatingLink(true);
    setLinkCreateMsg(null);

    const { error: insertError } = await supabase.from('verse_words').insert({
      verse_id: linkVerseId.trim(),
      arabic_form: linkArabicForm.trim(),
      root_id: linkRootId,
      position: parseInt(linkPosition, 10) || 1,
    });

    if (insertError) {
      setLinkCreateMsg(`Erreur: ${insertError.message}`);
    } else {
      setLinkCreateMsg('Lien créé avec succès');
      setLinkVerseId('');
      setLinkArabicForm('');
      setLinkRootId('');
      setLinkPosition('1');
      await fetchDictionaryStats();
      setTimeout(() => setLinkCreateMsg(null), 3000);
    }
    setCreatingLink(false);
  }

  const importMissingVerses = useCallback(async () => {
    const missingSurahs = surahs.filter((s) => !s.has_verses);
    if (missingSurahs.length === 0) return;

    const { data: sessionData } = await supabase.auth.getSession();
    const accessToken = sessionData?.session?.access_token;
    if (!accessToken) {
      setImportProgress({
        current: 0,
        total: 0,
        surahName: '',
        status: 'error',
        imported: 0,
        errors: ['Session expirée. Reconnectez-vous.'],
        log: [],
      });
      return;
    }

    setImportProgress({
      current: 0,
      total: missingSurahs.length,
      surahName: '',
      status: 'running',
      imported: 0,
      errors: [],
      log: [],
    });

    let totalImported = 0;
    const allErrors: string[] = [];
    const allLog: string[] = [];

    const functionUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/quran-import`;

    for (let i = 0; i < missingSurahs.length; i++) {
      const surah = missingSurahs[i];
      setImportProgress((prev) => ({
        ...prev,
        current: i,
        surahName: `${surah.name_fr} (${surah.number})`,
      }));

      try {
        const res = await fetch(functionUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
          body: JSON.stringify({ surahNumber: surah.number, surahId: surah.id }),
        });

        if (!res.ok) {
          const errBody = await res.json().catch(() => ({}));
          const msg = errBody.error ?? `HTTP ${res.status}`;
          allErrors.push(`${surah.name_fr}: ${msg}`);
          allLog.push(`${surah.name_fr}: ECHEC - ${msg}`);
        } else {
          const data = await res.json();
          totalImported += data.imported ?? 0;
          allLog.push(
            `${surah.name_fr}: ${data.imported} versets importes (${data.frenchTranslations ?? 0} traductions FR)`,
          );
        }
      } catch (err) {
        const errMsg = err instanceof Error ? err.message : 'erreur inconnue';
        allErrors.push(`${surah.name_fr}: ${errMsg}`);
        allLog.push(`${surah.name_fr}: ECHEC - ${errMsg}`);
      }

      setImportProgress((prev) => ({
        ...prev,
        imported: totalImported,
        errors: [...allErrors],
        log: [...allLog],
      }));
    }

    setImportProgress((prev) => ({
      ...prev,
      current: missingSurahs.length,
      surahName: '',
      status: allErrors.length > 0 && totalImported === 0 ? 'error' : 'done',
    }));

    await fetchSurahs();
    await fetchTableCounts();
  }, [surahs]);

  if (!user || !isAdmin) {
    return (
      <div className="p-4 lg:p-8 max-w-4xl mx-auto">
        <div className="bg-white border border-neutral-200 rounded-xl p-12 text-center">
          <Lock className="w-12 h-12 text-neutral-300 mx-auto mb-4" />
          <p className="text-neutral-600 font-medium">Accès refusé</p>
          <p className="text-sm text-neutral-400 mt-1">
            Vous devez être connecté en tant qu'administrateur pour accéder à cette page.
          </p>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: 'overview' as const, label: "Vue d'ensemble", icon: Shield },
    { id: 'users' as const, label: 'Utilisateurs', icon: Users },
    { id: 'data' as const, label: 'Donnees', icon: Database },
    { id: 'dictionary' as const, label: 'Dictionnaire', icon: BookText },
    { id: 'logs' as const, label: 'Journal', icon: History },
  ];

  const missingCount = surahs.filter((s) => !s.has_verses).length;
  const isImporting = importProgress.status === 'running';

  return (
    <div className="p-4 lg:p-8 max-w-6xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl lg:text-3xl font-bold text-neutral-900 mb-2 flex items-center gap-2">
          <Database className="w-7 h-7 text-primary-600" />
          Import de versets
        </h1>
        <p className="text-sm text-neutral-500">
          Import automatique depuis l API Quran.com.
        </p>
      </div>

      <div className="flex gap-1 mb-6 border-b border-neutral-200 overflow-x-auto">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
              activeTab === tab.id
                ? 'border-primary-600 text-primary-600'
                : 'border-transparent text-neutral-500 hover:text-neutral-700'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === 'overview' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { label: 'Sourates', table: 'surahs', icon: BookOpen },
              { label: 'Versets', table: 'verses', icon: BookOpen },
              { label: 'Mots de versets', table: 'verse_words', icon: BookOpen },
              { label: 'Racines', table: 'roots', icon: Database },
              { label: 'Variations', table: 'variations', icon: Database },
              { label: 'Utilisateurs', table: 'user_roles', icon: Users },
            ].map((item) => (
              <div key={item.table} className="bg-white border border-neutral-200 rounded-xl p-5">
                <div className="flex items-center justify-between mb-2">
                  <item.icon className="w-5 h-5 text-neutral-400" />
                  <span className="text-2xl font-bold text-neutral-900">
                    {tableCounts[item.table] ?? '—'}
                  </span>
                </div>
                <p className="text-sm text-neutral-500">{item.label}</p>
              </div>
            ))}
          </div>

          <div className="bg-white border border-neutral-200 rounded-xl p-6">
            <h3 className="font-semibold text-neutral-900 mb-3">Niveaux d acces</h3>
            <div className="space-y-2">
              {[
                { role: 'admin_principal', label: 'Administrateur Principal', desc: 'Controle superieur, gestion des administrateurs et permissions' },
                { role: 'admin_2', label: 'Administrateur 2', desc: 'Permissions definies par l administrateur principal' },
                { role: 'admin_3', label: 'Administrateur 3', desc: 'Permissions definies par l administrateur principal' },
                { role: 'lecteur', label: 'Lecteur', desc: 'Consultation, lecture et recherche uniquement' },
              ].map((r) => (
                <div key={r.role} className="flex items-start gap-3 p-3 bg-neutral-50 rounded-lg">
                  <div className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${
                    r.role === 'admin_principal' ? 'bg-primary-600' :
                    r.role === 'admin_2' ? 'bg-primary-400' :
                    r.role === 'admin_3' ? 'bg-primary-300' : 'bg-neutral-400'
                  }`} />
                  <div>
                    <p className="text-sm font-medium text-neutral-900">{r.label}</p>
                    <p className="text-xs text-neutral-500 mt-0.5">{r.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'users' && (
        <div className="bg-white border border-neutral-200 rounded-xl p-8 text-center">
          <Users className="w-10 h-10 text-neutral-300 mx-auto mb-3" />
          <p className="text-sm font-medium text-neutral-600">Gestion des utilisateurs</p>
          <p className="text-xs text-neutral-400 mt-1 max-w-md mx-auto">
            La gestion complete des utilisateurs sera developpee dans une etape ulterieure.
          </p>
        </div>
      )}

      {activeTab === 'data' && (
        <div className="space-y-4">
          {/* Import versets manquants */}
          <div className="bg-white border border-neutral-200 rounded-xl p-6">
            <h3 className="font-semibold text-neutral-900 mb-2 flex items-center gap-2">
              <Download className="w-5 h-5 text-primary-600" />
              Import automatique des versets manquants
            </h3>
            <p className="text-sm text-neutral-500 mb-4">
              Recupere le texte arabe (Uthmani) et la traduction francaise (Hamidullah)
              depuis l API Quran.com pour toutes les sourates qui n ont pas encore
              de versets dans la base, puis les insere dans Supabase.
            </p>

            {surahsLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-6 h-6 animate-spin text-primary-600" />
              </div>
            ) : (
              <>
                <div className="flex items-center gap-4 mb-4">
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium text-neutral-700">
                        Sourates avec versets
                      </span>
                      <span className="text-sm text-neutral-500">
                        {surahs.length - missingCount} / {surahs.length}
                      </span>
                    </div>
                    <div className="h-2 bg-neutral-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary-600 rounded-full transition-all"
                        style={{
                          width: `${surahs.length > 0 ? ((surahs.length - missingCount) / surahs.length) * 100 : 0}%`,
                        }}
                      />
                    </div>
                  </div>
                  {missingCount > 0 && (
                    <span className="text-sm font-medium text-accent-700 bg-accent-50 px-3 py-1.5 rounded-lg whitespace-nowrap">
                      {missingCount} manquante{missingCount > 1 ? 's' : ''}
                    </span>
                  )}
                </div>

                {missingCount === 0 && importProgress.status !== 'running' ? (
                  <div className="flex items-center gap-2 p-4 bg-primary-50 border border-primary-200 rounded-lg">
                    <CheckCircle className="w-5 h-5 text-primary-600" />
                    <p className="text-sm font-medium text-primary-700">
                      Toutes les sourates ont des versets. Aucun import necessaire.
                    </p>
                  </div>
                ) : (
                  <button
                    onClick={importMissingVerses}
                    disabled={isImporting || missingCount === 0}
                    className="flex items-center gap-2 px-5 py-3 bg-primary-600 text-white rounded-lg font-medium text-sm hover:bg-primary-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isImporting ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Import en cours...
                      </>
                    ) : (
                      <>
                        <Download className="w-4 h-4" />
                        Importer {missingCount} sourate{missingCount > 1 ? 's' : ''} manquante{missingCount > 1 ? 's' : ''}
                      </>
                    )}
                  </button>
                )}

                {/* Progress during import */}
                {isImporting && (
                  <div className="mt-4 space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-neutral-600">
                        {importProgress.surahName
                          ? `Import: ${importProgress.surahName}`
                          : 'Initialisation...'}
                      </span>
                      <span className="text-neutral-500">
                        {importProgress.current} / {importProgress.total}
                      </span>
                    </div>
                    <div className="h-2 bg-neutral-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary-600 rounded-full transition-all duration-300"
                        style={{
                          width: `${importProgress.total > 0 ? (importProgress.current / importProgress.total) * 100 : 0}%`,
                        }}
                      />
                    </div>
                    <div className="flex items-center gap-2 text-sm text-neutral-600">
                      <span className="font-medium text-primary-600">{importProgress.imported}</span>
                      <span>versets importes</span>
                    </div>
                  </div>
                )}

                {/* Results after import */}
                {importProgress.status === 'done' && (
                  <div className="mt-4 space-y-3 animate-fade-in">
                    <div className="flex items-center gap-2 p-4 bg-primary-50 border border-primary-200 rounded-lg">
                      <CheckCircle className="w-5 h-5 text-primary-600" />
                      <p className="text-sm font-medium text-primary-700">
                        Import termine: {importProgress.imported} versets importes
                        {importProgress.errors.length > 0 && `, ${importProgress.errors.length} erreur(s)`}
                      </p>
                    </div>

                    {importProgress.log.length > 0 && (
                      <div className="bg-neutral-50 border border-neutral-200 rounded-lg p-4 max-h-64 overflow-y-auto">
                        <p className="text-xs font-medium text-neutral-500 mb-2">Journal d import</p>
                        <div className="space-y-1">
                          {importProgress.log.map((entry, i) => (
                            <p
                              key={i}
                              className={`text-xs font-mono ${
                                entry.includes('erreur') || entry.includes('erreur inconnue')
                                  ? 'text-red-600'
                                  : 'text-neutral-600'
                              }`}
                            >
                              {entry}
                            </p>
                          ))}
                        </div>
                      </div>
                    )}

                    <button
                      onClick={() =>
                        setImportProgress({
                          current: 0,
                          total: 0,
                          surahName: '',
                          status: 'idle',
                          imported: 0,
                          errors: [],
                          log: [],
                        })
                      }
                      className="flex items-center gap-2 text-sm text-neutral-500 hover:text-neutral-700 transition-colors"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      Reinitialiser
                    </button>
                  </div>
                )}

                {/* List of missing surahs */}
                {missingCount > 0 && !isImporting && importProgress.status === 'idle' && (
                  <div className="mt-4">
                    <p className="text-xs font-medium text-neutral-500 mb-2">
                      Sourates manquantes:
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {surahs
                        .filter((s) => !s.has_verses)
                        .map((s) => (
                          <span
                            key={s.id}
                            className="text-xs px-2 py-1 bg-neutral-100 text-neutral-600 rounded"
                          >
                            {s.number}. {s.name_fr}
                          </span>
                        ))}
                    </div>
                  </div>
                )}
              </>
            )}
          </div>

          {/* Other data management placeholders */}
          <div className="bg-white border border-neutral-200 rounded-xl p-6">
            <h3 className="font-semibold text-neutral-900 mb-4 flex items-center gap-2">
              <Database className="w-5 h-5 text-primary-600" />
              Autres operations
            </h3>
            <div className="space-y-2">
              {[
                { label: 'Import des sourates', desc: 'Ajouter ou modifier les sourates du Coran' },
                { label: 'Sauvegarde / Restauration', desc: 'Exporter et importer les donnees' },
              ].map((item) => (
                <div key={item.label} className="flex items-center justify-between p-3 bg-neutral-50 rounded-lg">
                  <div>
                    <p className="text-sm font-medium text-neutral-700">{item.label}</p>
                    <p className="text-xs text-neutral-400 mt-0.5">{item.desc}</p>
                  </div>
                  <span className="text-xs text-neutral-400 px-2 py-1 bg-neutral-200 rounded">A venir</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'dictionary' && (
        <div className="space-y-4">
          {/* Stats */}
          {dictStats && (
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-white border border-neutral-200 rounded-xl p-5">
                <div className="flex items-center justify-between mb-2">
                  <BookText className="w-5 h-5 text-neutral-400" />
                  <span className="text-2xl font-bold text-neutral-900">{dictStats.roots}</span>
                </div>
                <p className="text-sm text-neutral-500">Racines</p>
              </div>
              <div className="bg-white border border-neutral-200 rounded-xl p-5">
                <div className="flex items-center justify-between mb-2">
                  <BookOpen className="w-5 h-5 text-neutral-400" />
                  <span className="text-2xl font-bold text-neutral-900">{dictStats.verseWords}</span>
                </div>
                <p className="text-sm text-neutral-500">Mots liés</p>
              </div>
              <div className="bg-white border border-neutral-200 rounded-xl p-5">
                <div className="flex items-center justify-between mb-2">
                  <Database className="w-5 h-5 text-neutral-400" />
                  <span className="text-2xl font-bold text-neutral-900">{dictStats.variations}</span>
                </div>
                <p className="text-sm text-neutral-500">Variations</p>
              </div>
            </div>
          )}

          {/* Create root */}
          <div className="bg-white border border-neutral-200 rounded-xl p-6">
            <h3 className="font-semibold text-neutral-900 mb-4 flex items-center gap-2">
              <Plus className="w-5 h-5 text-primary-600" />
              Créer une nouvelle racine
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              <div>
                <label className="text-xs font-medium text-neutral-500 mb-1 block">Racine (lettres séparées) *</label>
                <input
                  type="text"
                  value={newRootArabic}
                  onChange={(e) => setNewRootArabic(e.target.value)}
                  placeholder="ك ت ب"
                  className="w-full px-3 py-2 text-sm border border-neutral-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-300 font-arabic text-lg"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-neutral-500 mb-1 block">Forme Othmani</label>
                <input
                  type="text"
                  value={newRootOthmani}
                  onChange={(e) => setNewRootOthmani(e.target.value)}
                  placeholder="كتب"
                  className="w-full px-3 py-2 text-sm border border-neutral-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-300 font-arabic text-lg"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-neutral-500 mb-1 block">Traduction française</label>
                <input
                  type="text"
                  value={newRootTranslation}
                  onChange={(e) => setNewRootTranslation(e.target.value)}
                  placeholder="écrire, livre"
                  className="w-full px-3 py-2 text-sm border border-neutral-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-300"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-neutral-500 mb-1 block">Occurrences</label>
                <input
                  type="number"
                  value={newRootOccurrence}
                  onChange={(e) => setNewRootOccurrence(e.target.value)}
                  placeholder="0"
                  className="w-full px-3 py-2 text-sm border border-neutral-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-300"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-neutral-500 mb-1 block">Rang fréquence</label>
                <input
                  type="number"
                  value={newRootRank}
                  onChange={(e) => setNewRootRank(e.target.value)}
                  placeholder="—"
                  className="w-full px-3 py-2 text-sm border border-neutral-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-300"
                />
              </div>
              <div className="flex items-end">
                <button
                  onClick={createRoot}
                  disabled={creatingRoot}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg font-medium text-sm hover:bg-primary-700 transition-colors disabled:opacity-50"
                >
                  {creatingRoot ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                  Créer
                </button>
              </div>
            </div>
            {rootCreateMsg && (
              <p className={`text-xs mt-3 ${rootCreateMsg.includes('Erreur') ? 'text-red-600' : 'text-primary-600'}`}>
                {rootCreateMsg}
              </p>
            )}
          </div>

          {/* Link verse word to root */}
          <div className="bg-white border border-neutral-200 rounded-xl p-6">
            <h3 className="font-semibold text-neutral-900 mb-4 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-primary-600" />
              Lier un mot de verset à une racine
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <div>
                <label className="text-xs font-medium text-neutral-500 mb-1 block">ID du verset *</label>
                <input
                  type="text"
                  value={linkVerseId}
                  onChange={(e) => setLinkVerseId(e.target.value)}
                  placeholder="uuid"
                  className="w-full px-3 py-2 text-xs border border-neutral-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-300 font-mono"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-neutral-500 mb-1 block">Forme arabe *</label>
                <input
                  type="text"
                  value={linkArabicForm}
                  onChange={(e) => setLinkArabicForm(e.target.value)}
                  placeholder="كتاب"
                  className="w-full px-3 py-2 text-sm border border-neutral-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-300 font-arabic text-lg"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-neutral-500 mb-1 block">Racine *</label>
                <select
                  value={linkRootId}
                  onChange={(e) => setLinkRootId(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-neutral-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-300"
                >
                  <option value="">— Choisir —</option>
                  {allRoots.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.othmani_root ?? r.arabic_root} — {r.root_translation ?? '—'}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex items-end gap-2">
                <div className="flex-1">
                  <label className="text-xs font-medium text-neutral-500 mb-1 block">Position</label>
                  <input
                    type="number"
                    value={linkPosition}
                    onChange={(e) => setLinkPosition(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-neutral-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-300"
                  />
                </div>
                <button
                  onClick={createVerseWordLink}
                  disabled={creatingLink}
                  className="flex items-center justify-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg font-medium text-sm hover:bg-primary-700 transition-colors disabled:opacity-50 whitespace-nowrap"
                >
                  {creatingLink ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                  Lier
                </button>
              </div>
            </div>
            {linkCreateMsg && (
              <p className={`text-xs mt-3 ${linkCreateMsg.includes('Erreur') ? 'text-red-600' : 'text-primary-600'}`}>
                {linkCreateMsg}
              </p>
            )}
          </div>

          {/* Root list with search */}
          <div className="bg-white border border-neutral-200 rounded-xl p-6">
            <h3 className="font-semibold text-neutral-900 mb-4 flex items-center gap-2">
              <BookText className="w-5 h-5 text-primary-600" />
              Racines existantes ({allRoots.length})
            </h3>
            <div className="relative mb-4">
              <SearchIcon className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Rechercher..."
                value={rootSearch}
                onChange={(e) => setRootSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-sm border border-neutral-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-300"
              />
            </div>
            <div className="max-h-96 overflow-y-auto divide-y divide-neutral-100">
              {allRoots
                .filter((r) =>
                  r.arabic_root.includes(rootSearch) ||
                  (r.othmani_root ?? '').includes(rootSearch) ||
                  (r.root_translation ?? '').toLowerCase().includes(rootSearch.toLowerCase())
                )
                .map((root) => (
                  <div key={root.id} className="flex items-center gap-3 py-3">
                    <div className="w-8 h-8 rounded-lg bg-neutral-100 flex items-center justify-center text-[10px] font-semibold text-neutral-500 flex-shrink-0">
                      {root.frequency_rank ?? '—'}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-arabic text-lg text-neutral-900">
                        {root.othmani_root ?? root.arabic_root}
                      </p>
                      <p className="text-xs text-neutral-500 truncate">
                        {root.root_translation ?? '—'} • {root.occurrence_count ?? 0} occ.
                      </p>
                    </div>
                    <button
                      onClick={() => deleteRoot(root.id)}
                      className="p-1.5 rounded-lg text-neutral-400 hover:text-red-500 hover:bg-red-50 transition-colors"
                      title="Supprimer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'logs' && (
        <div className="bg-white border border-neutral-200 rounded-xl overflow-hidden">
          <div className="p-4 border-b border-neutral-200 bg-neutral-50">
            <h3 className="font-semibold text-sm text-neutral-700 flex items-center gap-2">
              <History className="w-4 h-4" />
              Journal des modifications
            </h3>
          </div>
          {logLoading ? (
            <div className="p-8 space-y-3 animate-pulse">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-12 bg-neutral-200 rounded" />
              ))}
            </div>
          ) : logEntries.length === 0 ? (
            <div className="p-8 text-center">
              <History className="w-10 h-10 text-neutral-300 mx-auto mb-3" />
              <p className="text-sm text-neutral-400">
                Aucune modification enregistree pour le moment.
              </p>
            </div>
          ) : (
            <div className="divide-y divide-neutral-100">
              {logEntries.map((entry) => (
                <div key={entry.id} className="p-4 flex items-center gap-4">
                  <div className={`w-2 h-2 rounded-full flex-shrink-0 ${
                    entry.action === 'insert' ? 'bg-primary-500' :
                    entry.action === 'update' ? 'bg-accent-500' : 'bg-red-500'
                  }`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-neutral-700 capitalize">
                      {entry.action} — {entry.table_name}
                    </p>
                    <p className="text-xs text-neutral-400">
                      {new Date(entry.created_at).toLocaleString('fr-FR')}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

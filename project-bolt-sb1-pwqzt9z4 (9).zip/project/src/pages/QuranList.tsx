import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import {
  BookOpen,
  Search,
  Loader2,
  AlertCircle,
  Check,
} from 'lucide-react';

interface Surah {
  id: string;
  number: number;
  name_fr: string;
  name_ar: string;
  revelation_type: string | null;
  verse_count: number;
}

export default function QuranList() {
  const { user } = useAuth();
  const [surahs, setSurahs] = useState<Surah[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [progressMap, setProgressMap] = useState<Map<string, { last_verse: number; completed: boolean }>>(new Map());

  useEffect(() => {
    async function fetchData() {
      const { data, error: err } = await supabase
        .from('surahs')
        .select('id, number, name_fr, name_ar, revelation_type, verse_count')
        .order('number', { ascending: true });

      if (err) {
        setError(err.message);
        setLoading(false);
        return;
      }
      setSurahs(data ?? []);

      if (user) {
        const { data: progData } = await supabase
          .from('reading_progress')
          .select('surah_id, last_verse_number, is_completed')
          .eq('user_id', user.id);
        if (progData) {
          const map = new Map<string, { last_verse: number; completed: boolean }>();
          progData.forEach((p) => {
            map.set(p.surah_id, { last_verse: p.last_verse_number, completed: p.is_completed });
          });
          setProgressMap(map);
        }
      }
      setLoading(false);
    }
    fetchData();
  }, [user]);

  const filteredSurahs = surahs.filter((s) => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      s.name_fr.toLowerCase().includes(q) ||
      s.name_ar.includes(searchQuery.trim()) ||
      String(s.number) === q
    );
  });

  if (loading) {
    return (
      <div className="p-8 max-w-5xl mx-auto">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-neutral-200 rounded w-1/3" />
          <div className="h-10 bg-neutral-200 rounded w-full" />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
            {[...Array(9)].map((_, i) => (
              <div key={i} className="h-28 bg-neutral-200 rounded-xl" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 max-w-5xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl lg:text-3xl font-bold text-neutral-900 mb-2 flex items-center gap-2">
          <BookOpen className="w-7 h-7 text-primary-600" />
          Le Coran
        </h1>
        <p className="text-sm text-neutral-500">
          {surahs.length} sourates — cliquez sur une sourate pour afficher ses versets.
        </p>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-red-800">Erreur de chargement</p>
            <p className="text-xs text-red-600 mt-1">{error}</p>
          </div>
        </div>
      )}

      {/* Search */}
      <div className="relative mb-6">
        <Search className="w-5 h-5 text-neutral-400 absolute left-4 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          placeholder="Rechercher par nom ou numéro..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-12 pr-4 py-3 text-sm border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-300 bg-white"
        />
      </div>

      {/* Surah Grid */}
      {filteredSurahs.length === 0 ? (
        <div className="bg-white border border-neutral-200 rounded-xl p-12 text-center">
          <Search className="w-10 h-10 text-neutral-300 mx-auto mb-3" />
          <p className="text-sm text-neutral-400">Aucun résultat pour « {searchQuery} »</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {filteredSurahs.map((surah) => {
            const prog = progressMap.get(surah.id);
            return (
              <Link
                key={surah.id}
                to={`/quran/${surah.id}`}
                className="group bg-white border border-neutral-200 rounded-xl p-4 hover:border-primary-300 hover:shadow-sm transition-all"
              >
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-lg bg-primary-50 flex items-center justify-center text-sm font-bold text-primary-700 group-hover:bg-primary-600 group-hover:text-white transition-colors flex-shrink-0">
                    {surah.number}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-neutral-900 truncate">
                      {surah.name_fr}
                    </p>
                    <p className="font-arabic text-base text-neutral-500 truncate">
                      {surah.name_ar}
                    </p>
                  </div>
                  {prog?.completed && (
                    <Check className="w-4 h-4 text-primary-600 flex-shrink-0" />
                  )}
                </div>
                <div className="flex items-center gap-2 text-xs text-neutral-400">
                  <span>{surah.verse_count} versets</span>
                  {surah.revelation_type && (
                    <span className={`px-1.5 py-0.5 rounded ${
                      surah.revelation_type === 'meccan'
                        ? 'bg-accent-50 text-accent-700'
                        : 'bg-primary-50 text-primary-700'
                    }`}>
                      {surah.revelation_type === 'meccan' ? 'Mecquoise' : 'Médinoise'}
                    </span>
                  )}
                  {user && prog && !prog.completed && (
                    <span className="text-primary-500 ml-auto">
                      {prog.last_verse}/{surah.verse_count}
                    </span>
                  )}
                </div>
                {user && prog && !prog.completed && surah.verse_count > 0 && (
                  <div className="h-1 bg-neutral-100 rounded-full mt-2 overflow-hidden">
                    <div
                      className="h-full bg-primary-400 rounded-full transition-all"
                      style={{ width: `${Math.min((prog.last_verse / surah.verse_count) * 100, 100)}%` }}
                    />
                  </div>
                )}
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}

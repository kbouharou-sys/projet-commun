import { useEffect, useState, useCallback } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import {
  BookText,
  Search,
  AlertCircle,
  ChevronRight,
  Loader2,
  BookOpen,
  Languages,
  TrendingUp,
  Star,
  AlertTriangle,
  Edit3,
  Check,
  X,
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

interface Root {
  id: string;
  arabic_root: string;
  othmani_root: string | null;
  root_translation: string | null;
  occurrence_count: number;
  frequency_rank: number | null;
}

interface Variation {
  id: string;
  prefix: string | null;
  infix: string | null;
  suffix: string | null;
  arabic_form: string;
  french_translation: string | null;
}

interface VerseOccurrence {
  id: string;
  verse_number: number;
  arabic_uthmani: string;
  french_pretranslation: string;
  surah_name_fr: string;
  surah_number: number;
  arabic_form: string;
}

interface DuplicateInfo {
  roots: { arabic_root: string; othmani_root: string | null }[];
}

export default function DictionaryPage() {
  const { user } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const [roots, setRoots] = useState<Root[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRoot, setSelectedRoot] = useState<Root | null>(null);
  const [variations, setVariations] = useState<Variation[]>([]);
  const [occurrences, setOccurrences] = useState<VerseOccurrence[]>([]);
  const [loading, setLoading] = useState(true);
  const [detailLoading, setDetailLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [favoriteRootIds, setFavoriteRootIds] = useState<Set<string>>(new Set());
  const [favLoading, setFavLoading] = useState(false);
  const [editingTranslation, setEditingTranslation] = useState(false);
  const [translationDraft, setTranslationDraft] = useState('');
  const [savingTranslation, setSavingTranslation] = useState(false);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);
  const [duplicateRoots, setDuplicateRoots] = useState<DuplicateInfo | null>(null);
  const [duplicateMap, setDuplicateMap] = useState<Map<string, DuplicateInfo>>(new Map());

  useEffect(() => {
    async function fetchRoots() {
      const { data, error: err } = await supabase
        .from('roots')
        .select('id, arabic_root, othmani_root, root_translation, occurrence_count, frequency_rank')
        .order('frequency_rank', { ascending: true, nullsFirst: false });

      if (err) {
        setError(err.message);
        setLoading(false);
        return;
      }

      const rootList = data ?? [];
      setRoots(rootList);

      // Build duplicate map: group by root_translation
      const dupMap = new Map<string, DuplicateInfo>();
      const byTranslation = new Map<string, Root[]>();
      for (const r of rootList) {
        const key = (r.root_translation ?? '').trim().toLowerCase();
        if (!key) continue;
        const arr = byTranslation.get(key) ?? [];
        arr.push(r);
        byTranslation.set(key, arr);
      }
      for (const [key, group] of byTranslation) {
        if (group.length > 1) {
          dupMap.set(key, {
            roots: group.map((r) => ({ arabic_root: r.arabic_root, othmani_root: r.othmani_root })),
          });
        }
      }
      setDuplicateMap(dupMap);

      if (user) {
        const { data: favData } = await supabase
          .from('favorite_roots')
          .select('root_id')
          .eq('user_id', user.id);
        if (favData) {
          setFavoriteRootIds(new Set(favData.map((f) => f.root_id)));
        }
      }

      setLoading(false);
    }
    fetchRoots();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  // Handle ?root=ID param changes (e.g. navigating from QuranReader)
  useEffect(() => {
    const rootIdParam = searchParams.get('root');
    if (rootIdParam && roots.length > 0) {
      const target = roots.find((r) => r.id === rootIdParam);
      if (target && target.id !== selectedRoot?.id) {
        handleSelectRoot(target);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams, roots]);

  const handleSelectRoot = useCallback(async (root: Root) => {
    setSelectedRoot(root);
    setDetailLoading(true);
    setVariations([]);
    setOccurrences([]);
    setEditingTranslation(false);
    setSaveMessage(null);
    setTranslationDraft(root.root_translation ?? '');

    // Check for duplicate translations
    const translationKey = (root.root_translation ?? '').trim().toLowerCase();
    if (translationKey && duplicateMap.has(translationKey)) {
      const dup = duplicateMap.get(translationKey)!;
      setDuplicateRoots({
        roots: dup.roots.filter((r) => r.arabic_root !== root.arabic_root),
      });
    } else {
      setDuplicateRoots(null);
    }

    const [varRes, occRes] = await Promise.all([
      supabase
        .from('variations')
        .select('id, prefix, infix, suffix, arabic_form, french_translation')
        .eq('root_id', root.id),
      supabase
        .from('verse_words')
        .select(`
          id,
          arabic_form,
          verse:verses (
            id,
            verse_number,
            arabic_uthmani,
            french_pretranslation,
            surah:surahs (
              number,
              name_fr
            )
          )
        `)
        .eq('root_id', root.id)
        .limit(50),
    ]);

    setVariations(varRes.data ?? []);

    const occData: VerseOccurrence[] = (occRes.data ?? [])
      .filter((item: any) => item.verse)
      .map((item: any) => ({
        id: item.verse.id,
        verse_number: item.verse.verse_number,
        arabic_uthmani: item.verse.arabic_uthmani,
        french_pretranslation: item.verse.french_pretranslation,
        surah_name_fr: item.verse.surah?.name_fr ?? '',
        surah_number: item.verse.surah?.number ?? 0,
        arabic_form: item.arabic_form ?? '',
      }));

    setOccurrences(occData);
    setDetailLoading(false);
  }, [duplicateMap]);

  function selectRoot(root: Root) {
    const newParams = new URLSearchParams(searchParams);
    newParams.set('root', root.id);
    setSearchParams(newParams, { replace: true });
    handleSelectRoot(root);
  }

  const toggleFavorite = useCallback(async (rootId: string) => {
    if (!user) return;
    setFavLoading(true);
    const isFav = favoriteRootIds.has(rootId);
    if (isFav) {
      await supabase.from('favorite_roots').delete().eq('user_id', user.id).eq('root_id', rootId);
      setFavoriteRootIds((prev) => {
        const next = new Set(prev);
        next.delete(rootId);
        return next;
      });
    } else {
      await supabase.from('favorite_roots').insert({ user_id: user.id, root_id: rootId });
      setFavoriteRootIds((prev) => new Set(prev).add(rootId));
    }
    setFavLoading(false);
  }, [user, favoriteRootIds]);

  const saveTranslation = useCallback(async () => {
    if (!selectedRoot) return;
    setSavingTranslation(true);
    setSaveMessage(null);

    const { error: updateError } = await supabase
      .from('roots')
      .update({ root_translation: translationDraft.trim() || null })
      .eq('id', selectedRoot.id);

    if (updateError) {
      setSaveMessage(`Erreur: ${updateError.message}`);
    } else {
      setSaveMessage('Traduction mise à jour');
      const updatedRoot = { ...selectedRoot, root_translation: translationDraft.trim() || null };
      setSelectedRoot(updatedRoot);
      setRoots((prev) => prev.map((r) => (r.id === selectedRoot.id ? updatedRoot : r)));

      // Re-check duplicates after update
      const newKey = translationDraft.trim().toLowerCase();
      if (newKey && duplicateMap.has(newKey)) {
        const dup = duplicateMap.get(newKey)!;
        setDuplicateRoots({
          roots: dup.roots.filter((r) => r.arabic_root !== selectedRoot.arabic_root),
        });
      } else {
        setDuplicateRoots(null);
      }

      setEditingTranslation(false);
      setTimeout(() => setSaveMessage(null), 3000);
    }
    setSavingTranslation(false);
  }, [selectedRoot, translationDraft, duplicateMap]);

  const filteredRoots = roots.filter(
    (r) =>
      r.arabic_root.includes(searchTerm) ||
      (r.othmani_root ?? '').includes(searchTerm) ||
      (r.root_translation ?? '').toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-4 lg:p-8 max-w-6xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl lg:text-3xl font-bold text-neutral-900 mb-2 flex items-center gap-2">
          <BookText className="w-7 h-7 text-primary-600" />
          Dictionnaire
        </h1>
        <p className="text-sm text-neutral-500">
          {roots.length} racines arabes — classées par fréquence dans le Coran.
          {user && favoriteRootIds.size > 0 && (
            <span className="ml-2 text-accent-600">• {favoriteRootIds.size} favori(s)</span>
          )}
        </p>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-red-800">Erreur de chargement</p>
            <p className="text-xs text-red-600 mt-1">{error}</p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Root List + Search */}
        <div className="lg:col-span-1">
          <div className="bg-white border border-neutral-200 rounded-xl overflow-hidden lg:sticky lg:top-4">
            <div className="p-4 border-b border-neutral-200 bg-neutral-50">
              <h2 className="font-semibold text-sm text-neutral-700 mb-3 flex items-center gap-2">
                <BookText className="w-4 h-4 text-primary-600" />
                Racines
              </h2>
              <div className="relative">
                <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Racine ou traduction..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-sm border border-neutral-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-300"
                />
              </div>
              <p className="text-xs text-neutral-400 mt-2">
                {filteredRoots.length} racine(s)
              </p>
            </div>
            <div className="max-h-[400px] lg:max-h-[calc(100vh-320px)] overflow-y-auto">
              {loading ? (
                <div className="p-8 space-y-3 animate-pulse">
                  {[...Array(4)].map((_, i) => (
                    <div key={i} className="h-12 bg-neutral-200 rounded" />
                  ))}
                </div>
              ) : filteredRoots.length === 0 ? (
                <div className="p-8 text-center">
                  <BookText className="w-10 h-10 text-neutral-300 mx-auto mb-3" />
                  <p className="text-sm text-neutral-400">
                    {roots.length === 0 ? 'Aucune racine.' : 'Aucun résultat.'}
                  </p>
                </div>
              ) : (
                filteredRoots.map((root) => {
                  const transKey = (root.root_translation ?? '').trim().toLowerCase();
                  const hasDuplicate = transKey && duplicateMap.has(transKey);
                  return (
                    <button
                      key={root.id}
                      onClick={() => selectRoot(root)}
                      className={`w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-neutral-50 transition-colors border-b border-neutral-100 ${
                        selectedRoot?.id === root.id ? 'bg-primary-50' : ''
                      }`}
                    >
                      <div className="w-7 h-7 rounded-lg bg-neutral-100 flex items-center justify-center text-[10px] font-semibold text-neutral-500 flex-shrink-0">
                        {root.frequency_rank ?? '—'}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-arabic text-lg text-neutral-900">
                          {root.othmani_root ?? root.arabic_root}
                        </p>
                        <p className="text-xs text-neutral-500 truncate flex items-center gap-1">
                          {root.root_translation ?? '—'}
                          {hasDuplicate && (
                            <AlertTriangle className="w-3 h-3 text-accent-500 flex-shrink-0" />
                          )}
                        </p>
                      </div>
                      <div className="flex flex-col items-end flex-shrink-0">
                        <span className="text-xs text-neutral-400">{root.occurrence_count} occ.</span>
                        {user && favoriteRootIds.has(root.id) && (
                          <Star className="w-3 h-3 text-accent-500 mt-0.5" fill="currentColor" />
                        )}
                      </div>
                      <ChevronRight className="w-4 h-4 text-neutral-300 flex-shrink-0" />
                    </button>
                  );
                })
              )}
            </div>
          </div>
        </div>

        {/* Root Detail */}
        <div className="lg:col-span-2">
          {!selectedRoot ? (
            <div className="bg-white border border-neutral-200 rounded-xl p-12 text-center">
              <BookText className="w-12 h-12 text-neutral-300 mx-auto mb-4" />
              <p className="text-neutral-500 font-medium">Aucune racine sélectionnée</p>
              <p className="text-sm text-neutral-400 mt-1">
                Sélectionnez une racine pour voir ses variations et occurrences dans le Coran.
              </p>
            </div>
          ) : detailLoading ? (
            <div className="bg-white border border-neutral-200 rounded-xl p-8">
              <div className="flex items-center justify-center gap-2 text-neutral-400">
                <Loader2 className="w-5 h-5 animate-spin" />
                <span className="text-sm">Chargement des détails...</span>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Root header */}
              <div className="bg-gradient-to-r from-primary-800 to-primary-600 text-white rounded-xl p-6 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -translate-y-16 translate-x-16" />
                <div className="relative">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <p className="font-arabic text-5xl font-bold mb-2">
                        {selectedRoot.othmani_root ?? selectedRoot.arabic_root}
                      </p>
                      <p className="text-primary-100 text-xs mb-1">
                        Racine: {selectedRoot.arabic_root}
                      </p>

                      {/* Editable translation */}
                      {editingTranslation ? (
                        <div className="mt-2">
                          <div className="flex items-center gap-2">
                            <input
                              type="text"
                              value={translationDraft}
                              onChange={(e) => setTranslationDraft(e.target.value)}
                              autoFocus
                              className="flex-1 px-3 py-1.5 text-sm text-neutral-900 rounded-lg border-2 border-white/30 bg-white/90 focus:outline-none focus:ring-2 focus:ring-white/50"
                            />
                            <button
                              onClick={saveTranslation}
                              disabled={savingTranslation}
                              className="p-1.5 rounded-lg bg-white/20 hover:bg-white/30 transition-colors"
                              title="Enregistrer"
                            >
                              {savingTranslation ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                            </button>
                            <button
                              onClick={() => {
                                setEditingTranslation(false);
                                setTranslationDraft(selectedRoot.root_translation ?? '');
                              }}
                              className="p-1.5 rounded-lg bg-white/20 hover:bg-white/30 transition-colors"
                              title="Annuler"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2 mt-1">
                          <p className="text-primary-100 text-lg">
                            {selectedRoot.root_translation ?? 'Traduction non définie'}
                          </p>
                          {user && (
                            <button
                              onClick={() => setEditingTranslation(true)}
                              className="p-1 rounded hover:bg-white/10 transition-colors"
                              title="Modifier la traduction"
                            >
                              <Edit3 className="w-3.5 h-3.5 text-primary-100" />
                            </button>
                          )}
                        </div>
                      )}

                      {/* Duplicate warning */}
                      {duplicateRoots && duplicateRoots.roots.length > 0 && (
                        <div className="mt-3 p-3 bg-accent-500/20 border border-accent-400/30 rounded-lg">
                          <div className="flex items-start gap-2">
                            <AlertTriangle className="w-4 h-4 text-accent-300 flex-shrink-0 mt-0.5" />
                            <div>
                              <p className="text-xs font-medium text-accent-100">
                                Traduction en double
                              </p>
                              <p className="text-xs text-accent-200 mt-0.5">
                                Autres racines avec la même traduction:
                              </p>
                              <div className="flex flex-wrap gap-1.5 mt-1.5">
                                {duplicateRoots.roots.map((r, i) => (
                                  <span
                                    key={i}
                                    className="text-xs font-arabic px-2 py-0.5 bg-white/10 rounded text-white"
                                  >
                                    {r.othmani_root ?? r.arabic_root}
                                  </span>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>
                      )}

                      {saveMessage && (
                        <p className={`text-xs mt-2 ${saveMessage.includes('Erreur') ? 'text-red-300' : 'text-accent-300'}`}>
                          {saveMessage}
                        </p>
                      )}
                    </div>
                    <div className="flex flex-col items-center gap-2">
                      {selectedRoot.frequency_rank && (
                        <div className="inline-flex flex-col items-center justify-center w-16 h-16 rounded-full border-2 border-white/30">
                          <TrendingUp className="w-4 h-4 text-primary-100 mb-1" />
                          <span className="text-sm font-bold">#{selectedRoot.frequency_rank}</span>
                        </div>
                      )}
                      {user && (
                        <button
                          onClick={() => toggleFavorite(selectedRoot.id)}
                          disabled={favLoading}
                          className={`p-2 rounded-lg transition-colors ${
                            favoriteRootIds.has(selectedRoot.id)
                              ? 'text-accent-300 bg-white/10'
                              : 'text-white/60 hover:text-white hover:bg-white/10'
                          }`}
                          title={favoriteRootIds.has(selectedRoot.id) ? 'Retirer des favoris' : 'Ajouter aux favoris'}
                        >
                          <Star className="w-5 h-5" fill={favoriteRootIds.has(selectedRoot.id) ? 'currentColor' : 'none'} />
                        </button>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-6 mt-4">
                    <div className="flex items-center gap-2">
                      <BookOpen className="w-4 h-4 text-primary-100" />
                      <div>
                        <span className="text-xs text-primary-100 block">Occurrences</span>
                        <span className="font-semibold text-sm">{selectedRoot.occurrence_count}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Languages className="w-4 h-4 text-primary-100" />
                      <div>
                        <span className="text-xs text-primary-100 block">Variations</span>
                        <span className="font-semibold text-sm">{variations.length}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <BookText className="w-4 h-4 text-primary-100" />
                      <div>
                        <span className="text-xs text-primary-100 block">Versets liés</span>
                        <span className="font-semibold text-sm">{occurrences.length}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Variations */}
              <div className="bg-white border border-neutral-200 rounded-xl overflow-hidden">
                <div className="p-4 border-b border-neutral-200 bg-neutral-50">
                  <h3 className="font-semibold text-sm text-neutral-700">Variations morphologiques</h3>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    {variations.length} variation(s)
                  </p>
                </div>
                {variations.length === 0 ? (
                  <div className="p-8 text-center">
                    <p className="text-sm text-neutral-400">
                      Aucune variation enregistrée pour cette racine.
                    </p>
                  </div>
                ) : (
                  <div className="divide-y divide-neutral-100">
                    {variations.map((v) => (
                      <div key={v.id} className="p-4 flex items-start gap-4">
                        <p className="font-arabic text-xl text-neutral-900 flex-shrink-0 min-w-[120px]">
                          {v.arabic_form}
                        </p>
                        <div className="flex-1">
                          <p className="text-sm text-neutral-700">
                            {v.french_translation ?? '—'}
                          </p>
                          <div className="flex gap-2 mt-1 flex-wrap">
                            {v.prefix && (
                              <span className="text-xs px-2 py-0.5 bg-blue-50 text-blue-700 rounded">
                                Préfixe: {v.prefix}
                              </span>
                            )}
                            {v.infix && (
                              <span className="text-xs px-2 py-0.5 bg-accent-50 text-accent-700 rounded">
                                Infixe: {v.infix}
                              </span>
                            )}
                            {v.suffix && (
                              <span className="text-xs px-2 py-0.5 bg-primary-50 text-primary-700 rounded">
                                Suffixe: {v.suffix}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Occurrences in Quran */}
              {occurrences.length > 0 && (
                <div className="bg-white border border-neutral-200 rounded-xl overflow-hidden">
                  <div className="p-4 border-b border-neutral-200 bg-neutral-50">
                    <h3 className="font-semibold text-sm text-neutral-700 flex items-center gap-2">
                      <BookOpen className="w-4 h-4 text-primary-600" />
                      Occurrences dans le Coran
                    </h3>
                    <p className="text-xs text-neutral-400 mt-0.5">
                      {occurrences.length} occurrence(s) liée(s) — forme: <span className="font-arabic text-sm text-neutral-700">{occurrences[0]?.arabic_form}</span>
                    </p>
                  </div>
                  <div className="divide-y divide-neutral-100">
                    {occurrences.map((occ) => (
                      <div key={occ.id} className="p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <Link
                            to={`/quran/${occ.id}`}
                            className="text-xs font-medium text-primary-600 hover:text-primary-700"
                          >
                            {occ.surah_name_fr} — Verset {occ.verse_number}
                          </Link>
                        </div>
                        <p className="font-arabic text-lg text-neutral-900 mb-1 text-right" dir="rtl">
                          {occ.arabic_uthmani}
                        </p>
                        <p className="text-xs text-neutral-600">
                          {occ.french_pretranslation}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

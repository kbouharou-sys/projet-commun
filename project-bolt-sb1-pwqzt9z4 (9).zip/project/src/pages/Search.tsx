import { useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { Search as SearchIcon, Loader2, BookOpen, BookText, AlertCircle } from 'lucide-react';

type SearchType = 'root' | 'word' | 'translation';

interface SearchResult {
  id: string;
  verse_number: number;
  arabic_uthmani: string;
  french_pretranslation: string;
  surah_number: number;
  surah_name_fr: string;
  surah_name_ar: string;
}

export default function SearchPage() {
  const [query, setQuery] = useState('');
  const [searchType, setSearchType] = useState<SearchType>('translation');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setLoading(true);
    setError(null);
    setHasSearched(true);
    setResults([]);

    try {
      let data: SearchResult[] = [];

      if (searchType === 'translation') {
        const { data: verseData, error: verseError } = await supabase
          .from('verses')
          .select(`
            id,
            verse_number,
            arabic_uthmani,
            french_pretranslation,
            surah:surahs ( number, name_fr, name_ar )
          `)
          .ilike('french_pretranslation', `%${query.trim()}%`)
          .limit(50);

        if (verseError) throw verseError;

        data = (verseData ?? []).map((v: any) => ({
          id: v.id,
          verse_number: v.verse_number,
          arabic_uthmani: v.arabic_uthmani,
          french_pretranslation: v.french_pretranslation,
          surah_number: v.surah?.number ?? 0,
          surah_name_fr: v.surah?.name_fr ?? '',
          surah_name_ar: v.surah?.name_ar ?? '',
        }));
      } else if (searchType === 'word') {
        const { data: verseData, error: verseError } = await supabase
          .from('verses')
          .select(`
            id,
            verse_number,
            arabic_uthmani,
            french_pretranslation,
            surah:surahs ( number, name_fr, name_ar )
          `)
          .ilike('arabic_uthmani', `%${query.trim()}%`)
          .limit(50);

        if (verseError) throw verseError;

        data = (verseData ?? []).map((v: any) => ({
          id: v.id,
          verse_number: v.verse_number,
          arabic_uthmani: v.arabic_uthmani,
          french_pretranslation: v.french_pretranslation,
          surah_number: v.surah?.number ?? 0,
          surah_name_fr: v.surah?.name_fr ?? '',
          surah_name_ar: v.surah?.name_ar ?? '',
        }));
      } else if (searchType === 'root') {
        const { data: rootData } = await supabase
          .from('roots')
          .select('id')
          .ilike('arabic_root', `%${query.trim()}%`);

        if (rootData && rootData.length > 0) {
          const rootIds = rootData.map((r) => r.id);
          const { data: wordData } = await supabase
            .from('verse_words')
            .select(`
              id,
              verse:verses (
                id,
                verse_number,
                arabic_uthmani,
                french_pretranslation,
                surah:surahs ( number, name_fr, name_ar )
              )
            `)
            .in('root_id', rootIds)
            .limit(50);

          const seen = new Set<string>();
          data = (wordData ?? [])
            .filter((w: any) => w.verse && !seen.has(w.verse.id))
            .map((w: any) => {
              seen.add(w.verse.id);
              return {
                id: w.verse.id,
                verse_number: w.verse.verse_number,
                arabic_uthmani: w.verse.arabic_uthmani,
                french_pretranslation: w.verse.french_pretranslation,
                surah_number: w.verse.surah?.number ?? 0,
                surah_name_fr: w.verse.surah?.name_fr ?? '',
                surah_name_ar: w.verse.surah?.name_ar ?? '',
              };
            });
        }
      }

      setResults(data);
    } catch (err: any) {
      setError(err.message ?? 'Une erreur est survenue');
    } finally {
      setLoading(false);
    }
  }, [query, searchType]);

  const searchTypeLabels: Record<SearchType, string> = {
    root: 'Racine arabe',
    word: 'Mot arabe',
    translation: 'Traduction française',
  };

  return (
    <div className="p-4 lg:p-8 max-w-4xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl lg:text-3xl font-bold text-neutral-900 mb-2 flex items-center gap-2">
          <SearchIcon className="w-7 h-7 text-primary-600" />
          Recherche
        </h1>
        <p className="text-sm text-neutral-500">
          Rechercher dans le Coran par racine, mot arabe ou traduction française.
        </p>
      </div>

      <form onSubmit={handleSearch} className="mb-6">
        <div className="bg-white border border-neutral-200 rounded-xl p-6">
          <div className="mb-4">
            <label className="text-sm font-medium text-neutral-700 mb-2 block">
              Type de recherche
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(Object.keys(searchTypeLabels) as SearchType[]).map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => setSearchType(type)}
                  className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    searchType === type
                      ? 'bg-primary-600 text-white'
                      : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
                  }`}
                >
                  {searchTypeLabels[type]}
                </button>
              ))}
            </div>
          </div>

          <div className="relative">
            <SearchIcon className="w-5 h-5 text-neutral-400 absolute left-4 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={
                searchType === 'root'
                  ? 'Entrer une racine arabe (ex: كتب)'
                  : searchType === 'word'
                  ? 'Entrer un mot arabe'
                  : 'Entrer un mot en français (ex: miséricorde)'
              }
              className={`w-full pl-12 pr-4 py-3 text-base border border-neutral-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-300 ${
                searchType !== 'translation' ? 'font-arabic text-lg' : ''
              }`}
            />
          </div>

          <button
            type="submit"
            disabled={loading || !query.trim()}
            className="mt-4 w-full px-4 py-3 bg-primary-600 text-white rounded-lg font-semibold hover:bg-primary-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Recherche en cours...' : 'Rechercher'}
          </button>
        </div>
      </form>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-red-800">Erreur</p>
            <p className="text-xs text-red-600 mt-1">{error}</p>
          </div>
        </div>
      )}

      {hasSearched && !loading && (
        <div className="mb-4 flex items-center justify-between">
          <p className="text-sm text-neutral-500">
            {results.length} résultat(s) pour «{query}»
          </p>
          <span className="text-xs text-neutral-400">{searchTypeLabels[searchType]}</span>
        </div>
      )}

      {loading && (
        <div className="bg-white border border-neutral-200 rounded-xl p-8">
          <div className="flex items-center justify-center gap-2 text-neutral-400">
            <Loader2 className="w-5 h-5 animate-spin" />
            <span className="text-sm">Recherche en cours...</span>
          </div>
        </div>
      )}

      {!loading && hasSearched && results.length === 0 && !error && (
        <div className="bg-white border border-neutral-200 rounded-xl p-8 text-center">
          <SearchIcon className="w-10 h-10 text-neutral-300 mx-auto mb-3" />
          <p className="text-sm font-medium text-neutral-600">Aucun résultat</p>
          <p className="text-xs text-neutral-400 mt-1">
            Essayez avec d''autres mots-clés ou un autre type de recherche.
          </p>
        </div>
      )}

      {!loading && results.length > 0 && (
        <div className="space-y-3">
          {results.map((result) => (
            <div
              key={result.id}
              className="bg-white border border-neutral-200 rounded-xl p-5 hover:border-primary-300 transition-colors"
            >
              <div className="flex items-center gap-2 mb-3">
                <div className="w-7 h-7 rounded-lg bg-primary-50 flex items-center justify-center">
                  <BookOpen className="w-3.5 h-3.5 text-primary-600" />
                </div>
                <span className="text-xs font-medium text-primary-600">
                  {result.surah_name_fr} — Verset {result.verse_number}
                </span>
                <span className="font-arabic text-sm text-neutral-400 mr-auto">
                  {result.surah_name_ar}
                </span>
              </div>
              <p className="font-arabic text-2xl text-neutral-900 mb-2 text-right leading-loose" dir="rtl">
                {result.arabic_uthmani}
              </p>
              <p className="text-sm text-neutral-700 leading-relaxed">
                {result.french_pretranslation}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

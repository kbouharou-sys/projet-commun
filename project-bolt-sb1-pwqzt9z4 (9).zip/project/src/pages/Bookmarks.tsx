import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import {
  Bookmark,
  Trash2,
  BookOpen,
  Loader2,
  AlertCircle,
  ChevronRight,
} from 'lucide-react';
import { Link } from 'react-router-dom';

interface BookmarkItem {
  id: string;
  verse_id: string;
  surah_id: string;
  note: string | null;
  created_at: string;
  verse: {
    id: string;
    verse_number: number;
    arabic_uthmani: string;
    french_pretranslation: string;
  };
  surah: {
    number: number;
    name_fr: string;
    name_ar: string;
  };
}

export default function Bookmarks() {
  const { user } = useAuth();
  const [bookmarks, setBookmarks] = useState<BookmarkItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    async function fetchBookmarks() {
      const { data, error } = await supabase
        .from('bookmarks')
        .select(`
          id,
          verse_id,
          surah_id,
          note,
          created_at,
          verse:verses (
            id,
            verse_number,
            arabic_uthmani,
            french_pretranslation
          ),
          surah:surahs (
            number,
            name_fr,
            name_ar
          )
        `)
        .eq('user_id', user!.id)
        .order('created_at', { ascending: false });

      if (error) {
        setError(error.message);
      } else {
        setBookmarks((data ?? []) as unknown as BookmarkItem[]);
      }
      setLoading(false);
    }

    fetchBookmarks();
  }, [user]);

  async function removeBookmark(bookmarkId: string) {
    setBookmarks((prev) => prev.filter((b) => b.id !== bookmarkId));
    await supabase.from('bookmarks').delete().eq('id', bookmarkId);
  }

  if (!user) {
    return (
      <div className="p-4 lg:p-8 max-w-4xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl lg:text-3xl font-bold text-neutral-900 mb-2 flex items-center gap-2">
            <Bookmark className="w-7 h-7 text-primary-600" />
            Marque-pages
          </h1>
        </div>
        <div className="bg-white border border-neutral-200 rounded-xl p-12 text-center">
          <Bookmark className="w-12 h-12 text-neutral-300 mx-auto mb-4" />
          <p className="text-neutral-500 font-medium">Connexion requise</p>
          <p className="text-sm text-neutral-400 mt-1">
            Connectez-vous pour sauvegarder et consulter vos versets marqués.
          </p>
          <Link
            to="/login"
            className="inline-flex items-center gap-2 mt-4 px-4 py-2 bg-primary-600 text-white rounded-lg text-sm font-medium hover:bg-primary-700 transition-colors"
          >
            Se connecter
            <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 max-w-4xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl lg:text-3xl font-bold text-neutral-900 mb-2 flex items-center gap-2">
          <Bookmark className="w-7 h-7 text-primary-600" />
          Marque-pages
        </h1>
        <p className="text-sm text-neutral-500">
          {bookmarks.length} verset(s) marqué(s)
        </p>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-red-800">Erreur</p>
            <p className="text-xs text-red-600 mt-1">{error}</p>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-6 h-6 animate-spin text-primary-600" />
        </div>
      ) : bookmarks.length === 0 ? (
        <div className="bg-white border border-neutral-200 rounded-xl p-12 text-center">
          <Bookmark className="w-12 h-12 text-neutral-300 mx-auto mb-4" />
          <p className="text-neutral-500 font-medium">Aucun marque-page</p>
          <p className="text-sm text-neutral-400 mt-1 mb-4">
            Parcourez le Coran et cliquez sur l'icône marque-page pour sauvegarder un verset.
          </p>
          <Link
            to="/read"
            className="inline-flex items-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg text-sm font-medium hover:bg-primary-700 transition-colors"
          >
            <BookOpen className="w-4 h-4" />
            Lire le Coran
          </Link>
        </div>
      ) : (
        <div className="space-y-3">
          {bookmarks.map((bm) => (
            <div
              key={bm.id}
              className="bg-white border border-neutral-200 rounded-xl p-5 hover:border-primary-300 transition-colors group"
            >
              <div className="flex items-center gap-2 mb-3">
                <div className="w-7 h-7 rounded-lg bg-primary-50 flex items-center justify-center">
                  <Bookmark className="w-3.5 h-3.5 text-primary-600" fill="currentColor" />
                </div>
                <span className="text-xs font-medium text-primary-600">
                  {bm.surah.name_fr} — Verset {bm.verse.verse_number}
                </span>
                <span className="font-arabic text-sm text-neutral-400 mr-auto">
                  {bm.surah.name_ar}
                </span>
                <button
                  onClick={() => removeBookmark(bm.id)}
                  className="p-1.5 rounded-lg text-neutral-300 hover:text-red-500 hover:bg-red-50 transition-colors opacity-0 group-hover:opacity-100"
                  title="Retirer le marque-page"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              <p className="font-arabic text-2xl text-neutral-900 mb-2 text-right leading-loose" dir="rtl">
                {bm.verse.arabic_uthmani}
              </p>
              <p className="text-sm text-neutral-700 leading-relaxed">
                {bm.verse.french_pretranslation}
              </p>
              <p className="text-xs text-neutral-400 mt-3">
                Marqué le {new Date(bm.created_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

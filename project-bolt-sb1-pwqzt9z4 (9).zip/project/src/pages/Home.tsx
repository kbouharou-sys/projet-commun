import { Link } from 'react-router-dom';
import {
  BookOpen,
  BookText,
  Search,
  Brain,
  Bookmark,
  Settings,
  ArrowRight,
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

interface MenuCard {
  to: string;
  label: string;
  description: string;
  icon: typeof BookOpen;
}

const menuCards: MenuCard[] = [
  { to: '/quran', label: 'Lire le Coran', description: '114 sourates en arabe avec traduction française', icon: BookOpen },
  { to: '/dictionary', label: 'Dictionnaire', description: 'Racines arabes, fréquence et occurrences', icon: BookText },
  { to: '/search', label: 'Recherche', description: 'Rechercher un mot ou un verset', icon: Search },
  { to: '/quiz', label: 'Quiz', description: 'Testez vos connaissances', icon: Brain },
  { to: '/bookmarks', label: 'Marque-pages', description: 'Vos versets favoris', icon: Bookmark },
  { to: '/settings', label: 'Paramètres', description: 'Préférences du compte', icon: Settings },
];

export default function Home() {
  const { user } = useAuth();

  return (
    <div className="min-h-[calc(100vh-3.5rem)] lg:min-h-[calc(100vh-0px)]">
      {/* Hero Section */}
      <section className="relative h-[420px] lg:h-[560px] flex items-center justify-center overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage:
              "url('https://images.pexels.com/photos/28209449/pexels-photo-28209449.jpeg?auto=compress&cs=tinysrgb&h=650&w=940')",
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/40 to-black/70" />

        <div className="relative z-10 text-center px-4 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 mb-6">
            <BookOpen className="w-4 h-4 text-accent-300" />
            <span className="text-xs font-medium text-white tracking-wide">Coran & Dictionnaire</span>
          </div>
          <h1 className="text-3xl lg:text-5xl font-bold text-white mb-4 leading-tight">
            Lire, comprendre et méditer
          </h1>
          <p className="text-base lg:text-lg text-white/80 mb-8 leading-relaxed">
            Le Coran en arabe avec traduction française, dictionnaire des racines,
            recherche et quiz — dans une seule application.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <Link
              to="/quran"
              className="inline-flex items-center gap-2 px-6 py-3 bg-accent-500 hover:bg-accent-600 text-white rounded-xl font-semibold text-sm transition-colors shadow-lg"
            >
              <BookOpen className="w-5 h-5" />
              Commencer la lecture
            </Link>
            <Link
              to="/dictionary"
              className="inline-flex items-center gap-2 px-6 py-3 bg-white/10 hover:bg-white/20 backdrop-blur-sm text-white rounded-xl font-semibold text-sm transition-colors border border-white/20"
            >
              <BookText className="w-5 h-5" />
              Dictionnaire des racines
            </Link>
          </div>
        </div>
      </section>

      {/* Menu Grid */}
      <section className="px-4 lg:px-8 py-10 lg:py-14 max-w-6xl mx-auto">
        <div className="mb-6">
          <h2 className="text-xl lg:text-2xl font-bold text-neutral-900 mb-1">
            {user ? 'Bienvenue' : 'Explorez le Coran'}
          </h2>
          <p className="text-sm text-neutral-500">
            Choisissez une section pour commencer.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {menuCards.map((card) => (
            <Link
              key={card.to}
              to={card.to}
              className="group bg-white border border-neutral-200 rounded-2xl p-6 hover:border-primary-300 hover:shadow-md transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 rounded-xl bg-primary-50 flex items-center justify-center group-hover:bg-primary-100 transition-colors">
                  <card.icon className="w-6 h-6 text-primary-600" />
                </div>
                <ArrowRight className="w-5 h-5 text-neutral-300 group-hover:text-primary-500 group-hover:translate-x-1 transition-all" />
              </div>
              <h3 className="text-base font-semibold text-neutral-900 mb-1">
                {card.label}
              </h3>
              <p className="text-sm text-neutral-500 leading-relaxed">
                {card.description}
              </p>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}

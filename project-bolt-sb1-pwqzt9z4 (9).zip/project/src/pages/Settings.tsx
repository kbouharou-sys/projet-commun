import { useState } from 'react';
import { Settings as SettingsIcon, Type, Globe, Moon, Sun, Monitor } from 'lucide-react';

export default function SettingsPage() {
  const [fontSize, setFontSize] = useState<'small' | 'medium' | 'large'>('medium');
  const [arabicFont, setArabicFont] = useState<'naskh' | 'amiri'>('naskh');
  const [language, setLanguage] = useState<'fr' | 'ar'>('fr');
  const [theme, setTheme] = useState<'light' | 'dark' | 'auto'>('light');

  return (
    <div className="p-4 lg:p-8 max-w-3xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl lg:text-3xl font-bold text-neutral-900 mb-2 flex items-center gap-2">
          <SettingsIcon className="w-7 h-7 text-primary-600" />
          Paramètres
        </h1>
        <p className="text-sm text-neutral-500">
          Personnalisez votre expérience de lecture.
        </p>
      </div>

      <div className="space-y-4">
        {/* Font size */}
        <div className="bg-white border border-neutral-200 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <Type className="w-5 h-5 text-primary-600" />
            <h2 className="font-semibold text-neutral-900">Taille du texte</h2>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {(['small', 'medium', 'large'] as const).map((size) => (
              <button
                key={size}
                onClick={() => setFontSize(size)}
                className={`px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                  fontSize === size
                    ? 'bg-primary-600 text-white'
                    : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
                }`}
              >
                {size === 'small' ? 'Petit' : size === 'medium' ? 'Moyen' : 'Grand'}
              </button>
            ))}
          </div>
          <div className="mt-4 p-4 bg-neutral-50 rounded-lg">
            <p className="font-arabic text-neutral-900 text-right rtl" style={{
              fontSize: fontSize === 'small' ? '1.25rem' : fontSize === 'medium' ? '1.75rem' : '2.25rem',
            }}>
              بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
            </p>
            <p className="text-sm text-neutral-600 mt-2" style={{
              fontSize: fontSize === 'small' ? '0.75rem' : fontSize === 'medium' ? '0.875rem' : '1rem',
            }}>
              Au nom d'Allah, le Tout Miséricordieux, le Très Miséricordieux
            </p>
          </div>
        </div>

        {/* Arabic font */}
        <div className="bg-white border border-neutral-200 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <Type className="w-5 h-5 text-primary-600" />
            <h2 className="font-semibold text-neutral-900">Police arabe</h2>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => setArabicFont('naskh')}
              className={`px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                arabicFont === 'naskh'
                  ? 'bg-primary-600 text-white'
                  : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
              }`}
            >
              <span className="font-arabic">نسخ</span>
              <span className="block text-xs mt-1">Noto Naskh</span>
            </button>
            <button
              onClick={() => setArabicFont('amiri')}
              className={`px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                arabicFont === 'amiri'
                  ? 'bg-primary-600 text-white'
                  : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
              }`}
            >
              <span className="font-amiri">أميري</span>
              <span className="block text-xs mt-1">Amiri</span>
            </button>
          </div>
        </div>

        {/* Language */}
        <div className="bg-white border border-neutral-200 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <Globe className="w-5 h-5 text-primary-600" />
            <h2 className="font-semibold text-neutral-900">Langue de l'interface</h2>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => setLanguage('fr')}
              className={`px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                language === 'fr'
                  ? 'bg-primary-600 text-white'
                  : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
              }`}
            >
              Français
            </button>
            <button
              onClick={() => setLanguage('ar')}
              className={`px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                language === 'ar'
                  ? 'bg-primary-600 text-white'
                  : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
              }`}
            >
              العربية
            </button>
          </div>
        </div>

        {/* Theme */}
        <div className="bg-white border border-neutral-200 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            {theme === 'light' ? <Sun className="w-5 h-5 text-primary-600" /> : theme === 'dark' ? <Moon className="w-5 h-5 text-primary-600" /> : <Monitor className="w-5 h-5 text-primary-600" />}
            <h2 className="font-semibold text-neutral-900">Thème</h2>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => setTheme('light')}
              className={`flex flex-col items-center gap-1 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                theme === 'light'
                  ? 'bg-primary-600 text-white'
                  : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
              }`}
            >
              <Sun className="w-4 h-4" />
              Clair
            </button>
            <button
              onClick={() => setTheme('dark')}
              className={`flex flex-col items-center gap-1 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                theme === 'dark'
                  ? 'bg-primary-600 text-white'
                  : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
              }`}
            >
              <Moon className="w-4 h-4" />
              Sombre
            </button>
            <button
              onClick={() => setTheme('auto')}
              className={`flex flex-col items-center gap-1 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                theme === 'auto'
                  ? 'bg-primary-600 text-white'
                  : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
              }`}
            >
              <Monitor className="w-4 h-4" />
              Auto
            </button>
          </div>
        </div>
      </div>

      <div className="mt-6 p-4 bg-neutral-50 border border-neutral-200 rounded-lg">
        <p className="text-xs text-neutral-500">
          Les paramètres seront sauvegardés par compte utilisateur dans une étape ultérieure.
          À ce stade, ils sont conservés pendant la session.
        </p>
      </div>
    </div>
  );
}

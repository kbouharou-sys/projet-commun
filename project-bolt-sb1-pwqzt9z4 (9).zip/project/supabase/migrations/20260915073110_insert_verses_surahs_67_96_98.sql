/*
# Insert verses for surahs 67, 96, 98

## Surahs added:
- 67: Al-Mulk (30 verses)
- 96: Al-Alaq (19 verses)
- 98: Al-Bayyina (8 verses)
*/

-- =========================================================
-- SURAH 67: Al-Mulk (30 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 67), 1, 'تَبَارَكَ الَّذِي بِيَدِهِ الْمُلْكُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ', 'Béni soit Celui dans la main de Qui est la royauté, et Qui est Omnipotent.', 1),
((SELECT id FROM public.surahs WHERE number = 67), 2, 'الَّذِي خَلَقَ الْمَوْتَ وَالْحَيَاةَ لِيَبْلُوَكُمْ أَيُّكُمْ أَحْسَنُ عَمَلًا ۚ وَهُوَ الْعَزِيزُ الْغَفُورُ', 'Celui Qui a créé la mort et la vie afin de vous éprouver et de voir qui de vous est le meilleur en œuvre, et Il est le Puissant, le Pardonneur.', 2),
((SELECT id FROM public.surahs WHERE number = 67), 3, 'الَّذِي خَلَقَ سَبْعَ سَمَاوَاتٍ طِبَاقًا ۖ مَّا تَرَىٰ فِي خَلْقِ الرَّحْمَٰنِ مِن تَفَاوُتٍ ۖ فَارْجِعِ الْبَصَرَ هَلْ تَرَىٰ مِن فُطُورٍ', 'Celui Qui a créé sept cieux superposés. Tu ne vois dans la création du Tout Miséricordieux aucune disproportion. Regarde encore: y vois-tu une brèche?', 3),
((SELECT id FROM public.surahs WHERE number = 67), 4, 'ثُمَّ ارْجِعِ الْبَصَرَ كَرَّتَيْنِ يَنقَلِبْ إِلَيْكَ الْبَصَرُ خَاسِئًا وَهُوَ حَسِيرٌ', 'Regarde encore une fois et une fois encore: ta vue retournera affaiblie et frustrée.', 4),
((SELECT id FROM public.surahs WHERE number = 67), 5, 'وَلَقَدْ زَيَّنَّا السَّمَاءَ الدُّنْيَا بِمَصَابِيحَ وَجَعَلْنَاهَا رُجُومًا لِّلشَّيَاطِينِ ۖ وَأَعْتَدْنَا لَهُمْ عَذَابَ السَّعِيرِ', 'Nous avons certes embelli le ciel le plus proche avec des lampes dont Nous avons fait des projectiles contre les diables, et Nous leur avons préparé le châtiment de la Fournaise.', 5),
((SELECT id FROM public.surahs WHERE number = 67), 6, 'وَلِلَّذِينَ كَفَرُوا بِرَبِّهِمْ عَذَابُ جَهَنَّمَ ۚ وَبِئْسَ الْمَصِيرُ', 'Et pour ceux qui ne croient pas en leur Seigneur, il y a le châtiment de la Fournaise. Et quel horrible destin!', 6),
((SELECT id FROM public.surahs WHERE number = 67), 7, 'إِذَا أُلْقُوا فِيهَا سَمِعُوا لَهَا شَهِيقًا وَهِيَ تَفُورُ', 'Quand ils y seront jetés, ils lui entendront un gémissement, tandis qu''elle bouillonne.', 7),
((SELECT id FROM public.surahs WHERE number = 67), 8, 'تَكَادُ تَمَيَّزُ مِنَ الْغَيْظِ ۖ كُلَّمَا أُلْقِيَ فِيهَا فَوْجٌ سَأَلَهُمْ خَزَنَتُهَا أَلَمْ يَأْتِكُمْ نَذِيرٌ', 'Peu s''en faut qu''elle n''éclate de rage. Chaque fois qu''un groupe y est jeté, ses gardiens leur demandent: Ne vous est-il pas venu un avertisseur?', 8),
((SELECT id FROM public.surahs WHERE number = 67), 9, 'قَالُوا بَلَىٰ قَدْ جَاءَنَا نَذِيرٌ فَكَذَّبْنَا وَقُلْنَا مَا نَزَّلَ اللَّهُ مِن شَيْءٍ إِنْ أَنتُمْ إِلَّا فِي ضَلَالٍ كَبِيرٍ', 'Ils dirent: Si! Un avertisseur nous était venu, mais nous avons crié au mensonge et avons dit: Allah n''a rien fait descendre; vous n''êtes que dans un grand égarement.', 9),
((SELECT id FROM public.surahs WHERE number = 67), 10, 'وَقَالُوا لَوْ كُنَّا نَسْمَعُ أَوْ نَعْقِلُ مَا كُنَّا فِي أَصْحَابِ السَّعِيرِ', 'Et ils dirent: Si nous avions écouté ou réfléchi, nous ne serions pas parmi les gens de la Fournaise.', 10),
((SELECT id FROM public.surahs WHERE number = 67), 11, 'فَاعْتَرَفُوا بِذَنبِهِمْ فَسُحْقًا لِّأَصْحَابِ السَّعِيرِ', 'Ils ont reconnu leur péché. Que les gens de la Fournaise soient anéantis!', 11),
((SELECT id FROM public.surahs WHERE number = 67), 12, 'إِنَّ الَّذِينَ يَخْشَوْنَ رَبَّهُم بِالْغَيْبِ لَهُم مَّغْفِرَةٌ وَأَجْرٌ كَبِيرٌ', 'Ceux qui craignent leur Seigneur dans le secret auront un pardon et une grande récompense.', 12),
((SELECT id FROM public.surahs WHERE number = 67), 13, 'وَأَسِرُّوا قَوْلَكُمْ أَوِ اجْهَرُوا بِهِ ۖ إِنَّهُ عَلِيمٌ بِذَاتِ الصُّدُورِ', 'Que vous cachiez votre parole ou que vous la divulguiez, Il connaît bien le contenu des poitrines.', 13),
((SELECT id FROM public.surahs WHERE number = 67), 14, 'أَلَا يَعْلَمُ مَنْ خَلَقَ وَهُوَ اللَّطِيفُ الْخَبِيرُ', 'Ne connaît-Il pas ce qu''Il a créé, alors qu''Il est le Subtil, le Bien-Informé?', 14),
((SELECT id FROM public.surahs WHERE number = 67), 15, 'هُوَ الَّذِي جَعَلَ لَكُمُ الْأَرْضَ ذَلُولًا فَامْشُوا فِي مَنَاكِبِهَا وَكُلُوا مِن رِّزْقِهِ ۖ وَإِلَيْهِ النُّشُورُ', 'C''est Lui Qui vous a soumis la terre: parcourez donc ses vastes espaces et mangez de Sa subsistance. Et vers Lui est la Résurrection.', 15),
((SELECT id FROM public.surahs WHERE number = 67), 16, 'أَأَمِنتُم مَّن فِي السَّمَاءِ أَن يَخْسِفَ بِكُمُ الْأَرْضَ فَإِذَا هِيَ تَمُورُ', 'Êtes-vous à l''abri que Celui Qui est au ciel enfouisse la terre sous vos pieds? Et voilà qu''elle tremble!', 16),
((SELECT id FROM public.surahs WHERE number = 67), 17, 'أَمْ أَمِنتُم مَّن فِي السَّمَاءِ أَن يُرْسِلَ عَلَيْكُمْ حَاصِبًا ۖ فَسَتَعْلَمُونَ كَيْفَ نَذِيرِ', 'Ou êtes-vous à l''abri que Celui Qui est au ciel envoie contre vous un ouragan de pierres? Vous saurez alors ce qu''est Mon avertissement!', 17),
((SELECT id FROM public.surahs WHERE number = 67), 18, 'وَلَقَدْ كَذَّبَ الَّذِينَ مِن قَبْلِهِمْ فَكَيْفَ كَانَ نَكِيرِ', 'Ceux qui vivaient avant eux avaient crié au mensonge. Quelle fut Ma réprobation!', 18),
((SELECT id FROM public.surahs WHERE number = 67), 19, 'أَوَلَمْ يَرَوْا إِلَى الطَّيْرِ فَوْقَهُمْ صَافَّاتٍ وَيَقْبِضْنَ ۚ مَا يُمْسِكُهُنَّ إِلَّا الرَّحْمَٰنُ ۚ إِنَّهُ بِكُلِّ شَيْءٍ بَصِيرٌ', 'N''ont-ils pas vu les oiseaux au-dessus d''eux, déployant et repliant leurs ailes tour à tour? Seul le Tout Miséricordieux les soutient. Il est Clairvoyant sur toute chose.', 19),
((SELECT id FROM public.surahs WHERE number = 67), 20, 'أَمَّنْ هَٰذَا الَّذِي هُوَ جُندٌ لَّكُمْ يَنصُرُكُم مِّن دُونِ الرَّحْمَٰنِ ۚ إِنَّ الْكَافِرِينَ إِلَّا فِي غُرُورٍ', 'Qui est-ce qui serait une armée pour vous, vous secourant contre le Tout Miséricordieux? Les infidèles sont dans l''illusion.', 20),
((SELECT id FROM public.surahs WHERE number = 67), 21, 'أَمَّنْ هَٰذَا الَّذِي يَرْزُقُكُمْ إِنْ أَمْسَكَ رِزْقَهُ ۚ بَل لَّجُّوا فِي عُتُوٍّ وَنُفُورٍ', 'Qui donc vous nourrirait si Il retenait Sa subsistance? Mais ils persistent dans l''insolence et la répulsion.', 21),
((SELECT id FROM public.surahs WHERE number = 67), 22, 'أَفَمَن يَمْشِي مُكِبًّا عَلَىٰ وَجْهِهِ أَهْدَىٰ أَمَّن يَمْشِي سَوِيًّا عَلَىٰ صِرَاطٍ مُّسْتَقِيمٍ', 'Celui qui marche en se penchant sur sa face est-il mieux guidé, ou celui qui marche droit sur un chemin bien tracé?', 22),
((SELECT id FROM public.surahs WHERE number = 67), 23, 'قُلْ هُوَ الَّذِي أَنشَأَكُمْ وَجَعَلَ لَكُمُ السَّمْعَ وَالْأَبْصَارَ وَالْأَفْئِدَةَ ۖ قَلِيلًا مَّا تَشْكُرُونَ', 'Dis: C''est Lui Qui vous a fait naître et vous a donné l''ouïe, les yeux et les cœurs. Mais vous êtes peu reconnaissants!', 23),
((SELECT id FROM public.surahs WHERE number = 67), 24, 'قُلْ هُوَ الَّذِي ذَرَأَكُمْ فِي الْأَرْضِ وَإِلَيْهِ تُحْشَرُونَ', 'Dis: C''est Lui Qui vous a dispersés sur terre, et c''est vers Lui que vous serez rassemblés.', 24),
((SELECT id FROM public.surahs WHERE number = 67), 25, 'وَيَقُولُونَ مَتَىٰ هَٰذَا الْوَعْدُ إِن كُنتُمْ صَادِقِينَ', 'Et ils disent: Quand cette promesse se réalisera-t-elle, si vous êtes véridiques?', 25),
((SELECT id FROM public.surahs WHERE number = 67), 26, 'قُلْ إِنَّمَا الْعِلْمُ عِندَ اللَّهِ وَإِنَّمَا أَنَا نَذِيرٌ مُّبِينٌ', 'Dis: La science n''appartient qu''à Allah. Et je ne suis qu''un avertisseur clair.', 26),
((SELECT id FROM public.surahs WHERE number = 67), 27, 'فَلَمَّا رَأَوْهُ زُلْفَةً سِيئَتْ وُجُوهُ الَّذِينَ كَفَرُوا وَقِيلَ هَٰذَا الَّذِي كُنتُم بِهِ تَدَّعُونَ', 'Puis, quand ils le verront de près, les visages de ceux qui ont mécru seront affligés. Et il leur sera dit: Voilà ce que vous réclamiez.', 27),
((SELECT id FROM public.surahs WHERE number = 67), 28, 'قُلْ أَرَأَيْتُمْ إِنْ أَهْلَكَنِيَ اللَّهُ وَمَن مَّعِيَ أَوْ رَحِمَنَا فَمَن يُجِيرُ الْكَافِرِينَ مِنْ عَذَابٍ أَلِيمٍ', 'Dis: Que vous en semble? Qu''Allah nous fasse périr, moi et ceux qui sont avec moi, ou qu''Il nous fasse miséricorde, qui protégera alors les infidèles d''un châtiment douloureux?', 28),
((SELECT id FROM public.surahs WHERE number = 67), 29, 'قُلْ هُوَ الرَّحْمَٰنُ آمَنَّا بِهِ وَعَلَيْهِ تَوَكَّلْنَا ۖ فَسَتَعْلَمُونَ مَنْ هُوَ فِي ضَلَالٍ مُّبِينٍ', 'Dis: C''est le Tout Miséricordieux. Nous croyons en Lui et nous nous en remettons à Lui. Vous saurez bientôt qui est dans un égarement évident.', 29),
((SELECT id FROM public.surahs WHERE number = 67), 30, 'قُلْ أَرَأَيْتُمْ أَصْبَحَ مَاؤُكُمْ غَوْرًا فَمَن يَأْتِيكُم بِمَاءٍ مَّعِينٍ', 'Dis: Que vous en semble? Si votre eau s''absorbait dans les entrailles de la terre, qui vous apporterait alors de l''eau de source?', 30)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 96: Al-Alaq (19 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 96), 1, 'اقْرَأْ بِاسْمِ رَبِّكَ الَّذِي خَلَقَ', 'Lis au nom de ton Seigneur Qui a créé,', 1),
((SELECT id FROM public.surahs WHERE number = 96), 2, 'خَلَقَ الْإِنسَانَ مِنْ عَلَقٍ', 'Qui a créé l''homme d''une adhérence.', 2),
((SELECT id FROM public.surahs WHERE number = 96), 3, 'اقْرَأْ وَرَبُّكَ الْأَكْرَمُ', 'Lis! Ton Seigneur est le Très Noble,', 3),
((SELECT id FROM public.surahs WHERE number = 96), 4, 'الَّذِي عَلَّمَ بِالْقَلَمِ', 'Qui a enseigné par la plume (le calame),', 4),
((SELECT id FROM public.surahs WHERE number = 96), 5, 'عَلَّمَ الْإِنسَانَ مَا لَمْ يَعْلَمْ', 'a enseigné à l''homme ce qu''il ne savait pas.', 5),
((SELECT id FROM public.surahs WHERE number = 96), 6, 'كَلَّا إِنَّ الْإِنسَانَ لَيَطْغَىٰ', 'Non! L''homme se rebelle vraiment,', 6),
((SELECT id FROM public.surahs WHERE number = 96), 7, 'أَن رَّآهُ اسْتَغْنَىٰ', 'parce qu''il se voit riche.', 7),
((SELECT id FROM public.surahs WHERE number = 96), 8, 'إِنَّ إِلَىٰ رَبِّكَ الرُّجْعَىٰ', 'Vers ton Seigneur, certes, est le retour.', 8),
((SELECT id FROM public.surahs WHERE number = 96), 9, 'أَرَأَيْتَ الَّذِي يَنْهَىٰ', 'As-tu vu celui qui interdit,', 9),
((SELECT id FROM public.surahs WHERE number = 96), 10, 'عَبْدًا إِذَا صَلَّىٰ', 'à un serviteur d''accomplir la Salat?', 10),
((SELECT id FROM public.surahs WHERE number = 96), 11, 'أَرَأَيْتَ إِن كَانَ عَلَى الْهُدَىٰ', 'As-tu vu s''il est sur la bonne voie,', 11),
((SELECT id FROM public.surahs WHERE number = 96), 12, 'أَوْ أَمَرَ بِالتَّقْوَىٰ', 'ou s''il ordonne la piété?', 12),
((SELECT id FROM public.surahs WHERE number = 96), 13, 'أَرَأَيْتَ إِن كَذَّبَ وَتَوَلَّىٰ', 'As-tu vu s''il traite de mensonge et tourne le dos?', 13),
((SELECT id FROM public.surahs WHERE number = 96), 14, 'أَلَمْ يَعْلَم بِأَنَّ اللَّهَ يَرَىٰ', 'Ne sait-il pas qu''Allah voit?', 14),
((SELECT id FROM public.surahs WHERE number = 96), 15, 'كَلَّا لَئِن لَّمْ يَنتَهِ لَنَسْفَعًا بِالنَّاصِيَةِ', 'Non! S''il ne cesse pas, Nous le saisirons par le toupet,', 15),
((SELECT id FROM public.surahs WHERE number = 96), 16, 'نَاصِيَةٍ كَاذِبَةٍ خَاطِئَةٍ', 'le toupet d''un menteur, d''un pécheur.', 16),
((SELECT id FROM public.surahs WHERE number = 96), 17, 'فَلْيَدْعُ نَادِيَهُ', 'Qu''il appelle donc son assemblée.', 17),
((SELECT id FROM public.surahs WHERE number = 96), 18, 'سَنَدْعُ الزَّبَانِيَةَ', 'Nous appellerons les gardiens de l''Enfer.', 18),
((SELECT id FROM public.surahs WHERE number = 96), 19, 'كَلَّا لَا تُطِعْهُ وَاسْجُدْ وَاقْتَرِب', 'Non! Ne lui obéis pas; prosterne-toi et rapproche-toi.', 19)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 98: Al-Bayyina (8 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 98), 1, 'لَمْ يَكُنِ الَّذِينَ كَفَرُوا مِنْ أَهْلِ الْكِتَابِ وَالْمُشْرِكِينَ مُنفَكِّينَ حَتَّىٰ تَأْتِيَهُمُ الْبَيِّنَةُ', 'Ceux qui ont mécru parmi les gens du Livre et les associateurs ne cesseront pas de mécroire jusqu''à ce que leur vienne la preuve évidente:', 1),
((SELECT id FROM public.surahs WHERE number = 98), 2, 'رَسُولٌ مِّنَ اللَّهِ يَتْلُو صُحُفًا مُّطَهَّرَةً', 'un Messager de la part d''Allah, qui récite des feuilles purifiées,', 2),
((SELECT id FROM public.surahs WHERE number = 98), 3, 'فِيهَا كُتُبٌ قَيِّمَةٌ', 'dans lesquelles se trouvent des livres droits.', 3),
((SELECT id FROM public.surahs WHERE number = 98), 4, 'وَمَا تَفَرَّقَ الَّذِينَ أُوتُوا الْكِتَابَ إِلَّا مِن بَعْدِ مَا جَاءَتْهُمُ الْبَيِّنَةُ', 'Et il ne leur fut ordonné que d''adorer Allah, Lui vouant un culte exclusif, d''accomplir la Salat et de payer la Zakat. Et c''est la religion de droiture.', 4),
((SELECT id FROM public.surahs WHERE number = 98), 5, 'وَمَا أُمِرُوا إِلَّا لِيَعْبُدُوا اللَّهَ مُخْلِصِينَ لَهُ الدِّينَ حُنَفَاءَ وَيُقِيمُوا الصَّلَاةَ وَيُؤْتُوا الزَّكَاةَ ۚ وَذَٰلِكَ دِينُ الْقَيِّمَةِ', 'Ceux qui ont mécru parmi les gens du Livre et les associateurs seront dans le feu de l''Enfer pour y demeurer éternellement. Ce sont eux les pires des créatures.', 5),
((SELECT id FROM public.surahs WHERE number = 98), 6, 'إِنَّ الَّذِينَ كَفَرُوا مِنْ أَهْلِ الْكِتَابِ وَالْمُشْرِكِينَ فِي نَارِ جَهَنَّمَ خَالِدِينَ فِيهَا ۚ أُولَٰئِكَ هُمْ شَرُّ الْبَرِيَّةِ', 'Ceux qui ont mécru parmi les gens du Livre et les associateurs seront dans le feu de l''Enfer pour y demeurer éternellement. Ce sont eux les pires des créatures.', 6),
((SELECT id FROM public.surahs WHERE number = 98), 7, 'إِنَّ الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ أُولَٰئِكَ هُمْ خَيْرُ الْبَرِيَّةِ', 'Ceux qui croient et accomplissent de bonnes œuvres, ce sont eux les meilleures des créatures.', 7),
((SELECT id FROM public.surahs WHERE number = 98), 8, 'جَزَاؤُهُمْ عِندَ رَبِّهِمْ جَنَّاتُ عَدْنٍ تَجْرِي مِن تَحْتِهَا الْأَنْهَارُ خَالِدِينَ فِيهَا أَبَدًا ۚ رَّضِيَ اللَّهُ عَنْهُمْ وَرَضُوا عَنْهُ ۚ ذَٰلِكَ لِمَنْ خَشِيَ رَبَّهُ', 'Leur rétribution auprès de leur Seigneur sera les Jardins d''Eden, sous lesquels coulent les ruisseaux, pour y demeurer éternellement. Allah les agrée et ils L''agréent. Cela sera pour celui qui craint son Seigneur.', 8)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

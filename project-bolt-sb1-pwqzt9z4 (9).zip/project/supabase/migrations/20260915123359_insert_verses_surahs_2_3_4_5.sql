/*
# Insert first 20 verses for surahs 2, 3, 4, 5

## Surahs added (first 20 verses each):
- 2: Al-Baqara
- 3: Ali 'Imran
- 4: An-Nisa'
- 5: Al-Ma'ida
*/

-- SURAH 2: Al-Baqara (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 2), 1, 'الٓمٓ', 'Alif Lam Mim.', 1),
((SELECT id FROM public.surahs WHERE number = 2), 2, 'ذَٰلِكَ الْكِتَابُ لَا رَيْبَ ۛ فِيهِ ۛ هُدًى لِّلْمُتَّقِينَ', 'Voici le Livre au sujet duquel il n''y a pas de doute, c''est une guidée pour les pieux,', 2),
((SELECT id FROM public.surahs WHERE number = 2), 3, 'الَّذِينَ يُؤْمِنُونَ بِالْغَيْبِ وَيُقِيمُونَ الصَّلَاةَ وَمِمَّا رَزَقْنَاهُمْ يُنفِقُونَ', 'qui croient à l''invisible, accomplissent la Salat et dépensent de ce que Nous leur avons octroyé,', 3),
((SELECT id FROM public.surahs WHERE number = 2), 4, 'وَالَّذِينَ يُؤْمِنُونَ بِمَا أُنزِلَ إِلَيْكَ وَمَا أُنزِلَ مِن قَبْلِكَ وَبِالْآخِرَةِ هُمْ يُوقِنُونَ', 'et qui croient à ce qui t''a été révélé et à ce qui a été révélé avant toi, et ont la certitude de l''au-delà.', 4),
((SELECT id FROM public.surahs WHERE number = 2), 5, 'أُولَٰئِكَ عَلَىٰ هُدًى مِّن رَّبِّهِمْ ۖ وَأُولَٰئِكَ هُمُ الْمُفْلِحُونَ', 'Ceux-là sont sur la bonne voie de leur Seigneur, et ce sont eux qui réussissent.', 5),
((SELECT id FROM public.surahs WHERE number = 2), 6, 'إِنَّ الَّذِينَ كَفَرُوا سَوَاءٌ عَلَيْهِمْ أَأَنذَرْتَهُمْ أَمْ لَمْ تُنذِرْهُمْ لَا يُؤْمِنُونَ', 'Quant à ceux qui ont mécru, il t''est égal que tu les avertisses ou non: ils ne croiront pas.', 6),
((SELECT id FROM public.surahs WHERE number = 2), 7, 'خَتَمَ اللَّهُ عَلَىٰ قُلُوبِهِمْ وَعَلَىٰ سَمْعِهِمْ ۖ وَعَلَىٰ أَبْصَارِهِمْ غِشَاوَةٌ ۖ وَلَهُمْ عَذَابٌ عَظِيمٌ', 'Allah a scellé leurs cœurs et leurs oreilles, et sur leurs yeux il y a un voile, et ils auront un grand châtiment.', 7),
((SELECT id FROM public.surahs WHERE number = 2), 8, 'وَمِنَ النَّاسِ مَن يَقُولُ آمَنَّا بِاللَّهِ وَبِالْيَوْمِ الْآخِرِ وَمَا هُم بِمُؤْمِنِينَ', 'Parmi les hommes, il en est qui disent: Nous croyons en Allah et au Jour dernier, mais ils ne croient pas.', 8),
((SELECT id FROM public.surahs WHERE number = 2), 9, 'يُخَادِعُونَ اللَّهَ وَالَّذِينَ آمَنُوا وَمَا يَخْدَعُونَ إِلَّا أَنفُسَهُمْ وَمَا يَشْعُرُونَ', 'Ils cherchent à tromper Allah et les croyants, mais ils ne trompent qu''eux-mêmes sans le savoir.', 9),
((SELECT id FROM public.surahs WHERE number = 2), 10, 'فِي قُلُوبِهِم مَّرَضٌ فَزَادَهُمُ اللَّهُ مَرَضًا وَلَهُمْ عَذَابٌ أَلِيمٌ بِمَا كَانُوا يَكْذِبُونَ', 'Il y a dans leurs cœurs une maladie, donc Allah a accru leur maladie, et ils auront un châtiment douloureux pour avoir menti.', 10),
((SELECT id FROM public.surahs WHERE number = 2), 11, 'وَإِذَا قِيلَ لَهُمْ لَا تُفْسِدُوا فِي الْأَرْضِ قَالُوا إِنَّمَا نَحْنُ مُصْلِحُونَ', 'Et quand on leur dit: Ne semez pas la corruption sur terre, ils disent: Nous ne sommes que des réformateurs.', 11),
((SELECT id FROM public.surahs WHERE number = 2), 12, 'أَلَا إِنَّهُمْ هُمُ الْمُفْسِدُونَ وَلَٰكِن لَّا يَشْعُرُونَ', 'En vérité, ce sont eux les semeurs de corruption, mais ils ne le sentent pas.', 12),
((SELECT id FROM public.surahs WHERE number = 2), 13, 'وَإِذَا قِيلَ لَهُمْ آمِنُوا كَمَا آمَنَ النَّاسُ قَالُوا أَنُؤْمِنُ كَمَا آمَنَ السُّفَهَاءُ ۗ أَلَا إِنَّهُمْ هُمُ السُّفَهَاءُ وَلَٰكِن لَّا يَعْلَمُونَ', 'Et quand on leur dit: Croyez comme ont cru les gens, ils disent: Croirons-nous comme ont cru les insensés? En vérité, ce sont eux les insensés, mais ils ne le savent pas.', 13),
((SELECT id FROM public.surahs WHERE number = 2), 14, 'وَإِذَا لَقُوا الَّذِينَ آمَنُوا قَالُوا آمَنَّا وَإِذَا خَلَوْا إِلَىٰ شَيَاطِينِهِمْ قَالُوا إِنَّا مَعَكُمْ إِنَّمَا نَحْنُ مُسْتَهْزِئُونَ', 'Et quand ils rencontrent les croyants, ils disent: Nous croyons. Et quand ils se retrouvent seuls avec leurs démons, ils disent: Nous sommes avec vous, nous ne faisions que nous moquer.', 14),
((SELECT id FROM public.surahs WHERE number = 2), 15, 'اللَّهُ يَسْتَهْزِئُ بِهِمْ وَيَمُدُّهُمْ فِي طُغْيَانِهِمْ يَعْمَهُونَ', 'Allah se moque d''eux et les laisse s''égarer dans leur transgression et leur aveuglement.', 15),
((SELECT id FROM public.surahs WHERE number = 2), 16, 'أُولَٰئِكَ الَّذِينَ اشْتَرَوُا الضَّلَالَةَ بِالْهُدَىٰ فَمَا رَبِحَت تِّجَارَتُهُمْ وَمَا كَانُوا مُهْتَدِينَ', 'Ce sont eux qui ont troqué la guidée contre l''égarement. Leur commerce n''a pas été profitable, et ils n''ont pas été bien guidés.', 16),
((SELECT id FROM public.surahs WHERE number = 2), 17, 'مَثَلُهُمْ كَمَثَلِ الَّذِي اسْتَوْقَدَ نَارًا فَلَمَّا أَضَاءَت مَّا حَوْلَهُ ذَهَبَ اللَّهُ بِنُورِهِمْ وَتَرَكَهُمْ فِي ظُلُمَاتٍ لَّا يُبْصِرُونَ', 'Ils ressemblent à celui qui a allumé un feu; puis, quand le feu a éclairé tout autour, Allah a emporté leur lumière et les a laissés dans les ténèbres, ne voyant rien.', 17),
((SELECT id FROM public.surahs WHERE number = 2), 18, 'صُمٌّ بُكْمٌ عُمْيٌ فَهُمْ لَا يَرْجِعُونَ', 'Sourds, muets, aveugles, ils ne reviennent pas [vers Allah].', 18),
((SELECT id FROM public.surahs WHERE number = 2), 19, 'أَوْ كَصَيِّبٍ مِّنَ السَّمَاءِ فِيهِ ظُلُمَاتٌ وَرَعْدٌ وَبَرْقٌ', 'Ou comme un nuage venant du ciel, porteur de ténèbres, de tonnerre et d''éclairs.', 19),
((SELECT id FROM public.surahs WHERE number = 2), 20, 'يَجْعَلُونَ أَصَابِعَهُمْ فِي آذَانِهِمْ مِنَ الصَّوَاعِقِ حَذَرَ الْمَوْتِ ۚ وَاللَّهُ مُحِيطٌ بِالْكَافِرِينَ', 'Ils mettent leurs doigts dans leurs oreilles contre les éclairs, de peur de la mort. Allah cerne les infidèles.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 3: Ali 'Imran (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 3), 1, 'الٓمٓ', 'Alif Lam Mim.', 1),
((SELECT id FROM public.surahs WHERE number = 3), 2, 'اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ', 'Allah! Nulle divinité sauf Lui, le Vivant, le Subsistant.', 2),
((SELECT id FROM public.surahs WHERE number = 3), 3, 'نَزَّلَ عَلَيْكَ الْكِتَابَ بِالْحَقِّ مُصَدِّقًا لِّمَا بَيْنَ يَدَيْهِ وَأَنزَلَ التَّوْرَاةَ وَالْإِنجِيلَ', 'Il a fait descendre sur toi le Livre avec la vérité, confirmateur de ce qui était avant lui. Et Il a fait descendre la Torah et l''Evangile', 3),
((SELECT id FROM public.surahs WHERE number = 3), 4, 'مِن قَبْلُ هُدًى لِّلنَّاسِ وَأَنزَلَ الْفُرْقَانَ ۗ إِنَّ الَّذِينَ كَفَرُوا بِآيَاتِ اللَّهِ لَهُمْ عَذَابٌ شَدِيدٌ', 'auparavant, comme guidée pour les gens, et a fait descendre le Discernement. Ceux qui ont mécru aux signes d''Allah auront un dur châtiment.', 4),
((SELECT id FROM public.surahs WHERE number = 3), 5, 'وَاللَّهُ لَا يَخْفَىٰ عَلَيْهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ', 'Et rien n''est caché à Allah, ni sur terre ni dans le ciel.', 5),
((SELECT id FROM public.surahs WHERE number = 3), 6, 'هُوَ الَّذِي يُصَوِّرُكُمْ فِي الْأَرْحَامِ كَيْفَ يَشَاءُ ۚ لَا إِلَٰهَ إِلَّا هُوَ الْعَزِيزُ الْحَكِيمُ', 'C''est Lui qui vous donne forme dans les matrices comme Il veut. Nulle divinité sauf Lui, le Tout-Puissant, le Sage.', 6),
((SELECT id FROM public.surahs WHERE number = 3), 7, 'هُوَ الَّذِي أَنزَلَ عَلَيْكَ الْكِتَابَ مِنْهُ آيَاتٌ مُّحْكَمَاتٌ هُنَّ أُمُّ الْكِتَابِ وَأُخَرُ مُتَشَابِهَاتٌ', 'C''est Lui qui a fait descendre sur toi le Livre: il s''y trouve des versets clairs, qui sont la base du Livre, et d''autres allégoriques.', 7),
((SELECT id FROM public.surahs WHERE number = 3), 8, 'فَأَمَّا الَّذِينَ فِي قُلُوبِهِمْ زَيْغٌ فَيَتَّبِعُونَ مَا تَشَابَهَ مِنْهُ ابْتِغَاءَ الْفِتْنَةِ', 'Quant à ceux dont le cœur est malade, ils suivent ce qui est allégorique, cherchant la discorde', 8),
((SELECT id FROM public.surahs WHERE number = 3), 9, 'وَابْتِغَاءَ تَأْوِيلِهِ ۗ وَمَا يَعْلَمُ تَأْوِيلَهُ إِلَّا اللَّهُ ۗ وَالرَّاسِخُونَ فِي الْعِلْمِ', 'et cherchant son interprétation. Mais nul n''en connaît l''interprétation sauf Allah. Et ceux qui sont enracinés dans la science', 9),
((SELECT id FROM public.surahs WHERE number = 3), 10, 'يَقُولُونَ آمَنَّا بِهِ كُلٌّ مِّنْ عِندِ رَبِّنَا ۗ وَمَا يَذَّكَّرُ إِلَّا أُولُو الْأَلْبَابِ', 'disent: Nous y croyons, tout vient de notre Seigneur. Mais seuls les doués d''intelligence se rappellent.', 10),
((SELECT id FROM public.surahs WHERE number = 3), 11, 'رَبَّنَا لَا تُزِغْ قُلُوبَنَا بَعْدَ إِذْ هَدَيْتَنَا وَهَبْ لَنَا مِن لَّدُنكَ رَحْمَةً', 'Seigneur! Ne fais pas dévier nos cœurs après que Tu nous as guidés, et accorde-nous de Ta part une miséricorde.', 11),
((SELECT id FROM public.surahs WHERE number = 3), 12, 'إِنَّكَ أَنتَ الْوَهَّابُ', 'C''est Toi le Grand Donateur.', 12),
((SELECT id FROM public.surahs WHERE number = 3), 13, 'رَبَّنَا إِنَّكَ جَامِعُ النَّاسِ لِيَوْمٍ لَّا رَيْبَ فِيهِ', 'Seigneur! Tu rassembleras les gens en un Jour au sujet duquel il n''y a pas de doute.', 13),
((SELECT id FROM public.surahs WHERE number = 3), 14, 'إِنَّ اللَّهَ لَا يُخْلِفُ الْمِيعَادَ', 'Allah ne manque pas à Sa promesse.', 14),
((SELECT id FROM public.surahs WHERE number = 3), 15, 'زُيِّنَ لِلنَّاسِ حُبُّ الشَّهَوَاتِ مِنَ النِّسَاءِ وَالْبَنِينَ وَالْقَنَاطِيرِ الْمُقَنتَفَرَةِ', 'On a embelli aux gens l''amour des passions: les femmes, les enfants, les amoncellements d''or et d''argent,', 15),
((SELECT id FROM public.surahs WHERE number = 3), 16, 'وَالْخَيْلِ الْمُسَوَّمَةِ وَالْأَنْعَامِ وَالْحَرْثِ ۗ ذَٰلِكَ مَتَاعُ الْحَيَاةِ الدُّنْيَا', 'les chevaux marqués, le bétail, les champs. Cela est la jouissance de la vie d''ici-bas,', 16),
((SELECT id FROM public.surahs WHERE number = 3), 17, 'وَاللَّهُ عِندَهُ حُسْنُ الْمَآبِ', 'mais Allah détient le meilleur retour.', 17),
((SELECT id FROM public.surahs WHERE number = 3), 18, 'قُلْ أَؤُنَبِّئُكُم بِخَيْرٍ مِّن ذَٰلِكُمْ ۚ لِلَّذِينَ اتَّقَوْا عِندَ رَبِّهِمْ جَنَّاتٌ', 'Dis: Vous informerai-je de meilleur? Pour les pieux, il y a auprès de leur Seigneur des Jardins', 18),
((SELECT id FROM public.surahs WHERE number = 3), 19, 'تَجْرِي مِن تَحْتِهَا الْأَنْهَارُ خَالِدِينَ فِيهَا وَأَزْوَاجٌ مُّطَهَّرَةٌ وَرِضْوَانٌ مِّنَ اللَّهِ', 'sous lesquels coulent les rivières, où ils demeurent éternellement, des épouses purifiées, et l''agrément d''Allah.', 19),
((SELECT id FROM public.surahs WHERE number = 3), 20, 'وَاللَّهُ بَصِيرٌ بِالْعِبَادِ', 'Et Allah est Clairvoyant sur Ses serviteurs.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 4: An-Nisa' (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 4), 1, 'يَا أَيُّهَا النَّاسُ اتَّقُوا رَبَّكُمُ الَّذِي خَلَقَكُم مِّن نَّفْسٍ وَاحِدَةٍ', 'Ô hommes! Craignez votre Seigneur qui vous a créés d''un seul être, et a créé de lui son épouse,', 1),
((SELECT id FROM public.surahs WHERE number = 4), 2, 'وَبَثَّ مِنْهُمَا رِجَالًا كَثِيرًا وَنِسَاءً', 'et qui de ces deux a fait répandre beaucoup d''hommes et de femmes.', 2),
((SELECT id FROM public.surahs WHERE number = 4), 3, 'وَاتَّقُوا اللَّهَ الَّذِي تَسَاءَلُونَ بِهِ وَالْأَرْحَامَ', 'Craignez Allah au nom duquel vous vous interdisez, et craignez les liens de parenté.', 3),
((SELECT id FROM public.surahs WHERE number = 4), 4, 'إِنَّ اللَّهَ كَانَ عَلَيْكُمْ رَقِيبًا', 'Allah, en vérité, vous observe.', 4),
((SELECT id FROM public.surahs WHERE number = 4), 5, 'وَآتُوا الْيَتَامَىٰ أَمْوَالَهُمْ ۖ وَلَا تَتَبَدَّلُوا الْخَبِيثَ بِالطَّيِّبِ', 'Et donnez aux orphelins leurs biens, et n''échangez pas le mauvais avec le bon,', 5),
((SELECT id FROM public.surahs WHERE number = 4), 6, 'وَلَا تَأْكُلُوا أَمْوَالَهُمْ إِلَىٰ أَمْوَالِكُمْ ۚ إِنَّهُ كَانَ حُوبًا كَبِيرًا', 'et n''absorbez pas leurs biens avec les vôtres, c''est un grand péché.', 6),
((SELECT id FROM public.surahs WHERE number = 4), 7, 'وَإِنْ خِفْتُمْ أَلَّا تُقْسِطُوا فِي الْيَتَامَىٰ فَانكِحُوا مَا طَابَ لَكُم مِّنَ النِّسَاءِ', 'Et si vous craignez d''être injustes envers les orphelins, épousez ce qui vous plaît de femmes:', 7),
((SELECT id FROM public.surahs WHERE number = 4), 8, 'مَثْنَىٰ وَثُلَاثَ وَرُبَاعَ ۖ فَإِنْ خِفْتُمْ أَلَّا تَعْدِلُوا فَوَاحِدَةً', 'deux, trois ou quatre. Mais si vous craignez d''être injustes, alors une seule,', 8),
((SELECT id FROM public.surahs WHERE number = 4), 9, 'أَوْ مَا مَلَكَتْ أَيْمَانُكُمْ ۚ ذَٰلِكَ أَدْنَىٰ أَلَّا تَعُولُوا', 'ou ce que vos mains possèdent. C''est plus proche de l''équité.', 9),
((SELECT id FROM public.surahs WHERE number = 4), 10, 'وَآتُوا النِّسَاءَ صَدُقَاتِهِنَّ نِحْلَةً', 'Et donnez aux femmes leur dot comme un don.', 10),
((SELECT id FROM public.surahs WHERE number = 4), 11, 'فَإِن طِبْنَ لَكُمْ عَن شَيْءٍ مِّنْهُ نَفْسًا فَكُلُوهُ هَنِيئًا مَّرِيئًا', 'Si elles vous en cèdent une part de plein gré, consommez-la avec plaisir et bonheur.', 11),
((SELECT id FROM public.surahs WHERE number = 4), 12, 'وَلَا تُؤْتُوا السُّفَهَاءَ أَمْوَالَكُمُ الَّتِي جَعَلَ اللَّهُ لَكُمْ قِيَامًا', 'Ne confiez pas aux insensés vos biens qu''Allah a établis pour votre subsistance,', 12),
((SELECT id FROM public.surahs WHERE number = 4), 13, 'وَارْزُقُوهُمْ فِيهَا وَاكْسُوهُمْ وَقُولُوا لَهُمْ قَوْلًا مَّعْرُوفًا', 'mais nourrissez-les de ces biens, habillez-les, et dites-leur une parole bienveillante.', 13),
((SELECT id FROM public.surahs WHERE number = 4), 14, 'وَابْتَلُوا الْيَتَامَىٰ حَتَّىٰ إِذَا بَلَغُوا النِّكَاحَ', 'Éprouvez les orphelins jusqu''à l''âge du mariage;', 14),
((SELECT id FROM public.surahs WHERE number = 4), 15, 'فَإِنْ آنَسْتُم مِّنْهُمْ رُشْدًا فَادْفَعُوا إِلَيْهِمْ أَمْوَالَهُمْ', 'si vous constatez chez eux de la maturité, remettez-leur leurs biens.', 15),
((SELECT id FROM public.surahs WHERE number = 4), 16, 'وَلَا تَأْكُلُوهَا إِسْرَافًا وَبِدَارًا أَن يَكْبَرُوا', 'Ne les consommez pas avec excès et hâte, avant qu''ils ne grandissent.', 16),
((SELECT id FROM public.surahs WHERE number = 4), 17, 'وَمَن كَانَ غَنِيًّا فَلْيَسْتَعْفِفْ ۖ وَمَن كَانَ فَقِيرًا فَلْيَأْكُلْ بِالْمَعْرُوفِ', 'Que le riche s''abstienne, et que le pauvre consomme avec mesure.', 17),
((SELECT id FROM public.surahs WHERE number = 4), 18, 'فَإِذَا دَفَعْتُمْ إِلَيْهِمْ أَمْوَالَهُمْ فَأَشْهِدُوا عَلَيْهِمْ', 'Et quand vous leur remettez leurs biens, faites témoigner.', 18),
((SELECT id FROM public.surahs WHERE number = 4), 19, 'وَكَفَىٰ بِاللَّهِ حَسِيبًا', 'Allah suffit comme Comptable.', 19),
((SELECT id FROM public.surahs WHERE number = 4), 20, 'لِّلرِّجَالِ نَصِيبٌ مِّمَّا اكْتَسَبُوا وَلِلنِّسَاءِ نَصِيبٌ مِّمَّا اكْتَسَبْنَ', 'Aux hommes revient une part de ce qu''ils ont acquis, et aux femmes une part de ce qu''elles ont acquis.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 5: Al-Ma'ida (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 5), 1, 'يَا أَيُّهَا الَّذِينَ آمَنُوا أَوْفُوا بِالْعُقُودِ', 'Ô vous qui avez cru! Honorez les engagements.', 1),
((SELECT id FROM public.surahs WHERE number = 5), 2, 'أُحِلَّت لَّكُم بَهِيمَةُ الْأَنْعَامِ إِلَّا مَا يُتْلَىٰ عَلَيْكُمْ', 'Le bétail vous est licite, sauf ce qui vous sera énoncé.', 2),
((SELECT id FROM public.surahs WHERE number = 5), 3, 'غَيْرَ مُحِلِّي الصَّيْدِ وَأَنتُمْ حُرُمٌ', 'sans que vous rendiez licite la chasse pendant que vous êtes en état de sacralisation.', 3),
((SELECT id FROM public.surahs WHERE number = 5), 4, 'إِنَّ اللَّهَ يَحْكُمُ مَا يُرِيدُ', 'Allah décide de ce qu''Il veut.', 4),
((SELECT id FROM public.surahs WHERE number = 5), 5, 'يَا أَيُّهَا الَّذِينَ آمَنُوا لَا تُحِلُّوا شَعَائِرَ اللَّهِ وَلَا الشَّهْرَ الْحَرَامَ', 'Ô vous qui avez cru! Ne profanez pas les rites d''Allah, ni le mois sacré,', 5),
((SELECT id FROM public.surahs WHERE number = 5), 6, 'وَلَا الْهَدْيَ وَلَا الْقَلَائِدَ وَلَا آمِّينَ الْبَيْتَ الْحَرَامَ', 'ni les bêtes d''offrande, ni les colliers, ni ceux qui se rendent à la Maison sacrée', 6),
((SELECT id FROM public.surahs WHERE number = 5), 7, 'يَبْتَغُونَ فَضْلًا مِّن رَّبِّهِمْ وَرِضْوَانًا', 'cherchant la grâce de leur Seigneur et Son agrément.', 7),
((SELECT id FROM public.surahs WHERE number = 5), 8, 'وَإِذَا حَلَلْتُمْ فَاصْطَادُوا', 'Et quand vous êtes désacralisés, chassez.', 8),
((SELECT id FROM public.surahs WHERE number = 5), 9, 'وَلَا يَجْرِمَنَّكُمْ شَنَآنُ قَوْمٍ أَن صَدُّوكُمْ عَنِ الْمَسْجِدِ الْحَرَامِ', 'Que la haine d''un peuple qui vous a empêchés d''accéder à la Mosquée sacrée', 9),
((SELECT id FROM public.surahs WHERE number = 5), 10, 'أَن تَعْتَدُوا ۘ وَتَعَاوَنُوا عَلَى الْبِرِّ وَالتَّقْوَىٰ', 'ne vous pousse pas à transgresser. Aidez-vous dans le bien et la piété,', 10),
((SELECT id FROM public.surahs WHERE number = 5), 11, 'وَلَا تَعَاوَنُوا عَلَى الْإِثْمِ وَالْعُدْوَانِ ۚ وَاتَّقُوا اللَّهَ', 'et non dans le péché et la transgression. Craignez Allah.', 11),
((SELECT id FROM public.surahs WHERE number = 5), 12, 'إِنَّ اللَّهَ شَدِيدُ الْعِقَابِ', 'Allah est dur en punition.', 12),
((SELECT id FROM public.surahs WHERE number = 5), 13, 'حُرِّمَتْ عَلَيْكُمُ الْمَيْتَةُ وَالدَّمُ وَلَحْمُ الْخِنزِيرِ', 'Vous sont interdits la bête morte, le sang, la chair de porc,', 13),
((SELECT id FROM public.surahs WHERE number = 5), 14, 'وَمَا أُهِلَّ لِغَيْرِ اللَّهِ بِهِ وَالْمُنْخَنِقَةُ وَالْمَوْقُوذَةُ', 'ce qui a été sacrifié à autre qu''Allah, la bête étouffée, frappée,', 14),
((SELECT id FROM public.surahs WHERE number = 5), 15, 'وَالْمُتَرَدِّيَةُ وَالنَّطِيحَةُ وَمَا أَكَلَ السَّبُعُ', 'tombée, encornée, ou celle qu''a dévorée une bête sauvage', 15),
((SELECT id FROM public.surahs WHERE number = 5), 16, 'إِلَّا مَا ذَكَّيْتُمْ وَمَا ذُبِحَ عَلَى النُّصُبِ', 'sauf celle que vous égorgez vous-mêmes, et ce qui a été sacrifié sur les stèles.', 16),
((SELECT id FROM public.surahs WHERE number = 5), 17, 'وَأَن تَسْتَقْسِمُوا بِالْأَزْلَامِ ۚ ذَٰلِكُمْ فِسْقٌ', 'Et [est interdit] le tir de sort par les flèches. Cela est perversité.', 17),
((SELECT id FROM public.surahs WHERE number = 5), 18, 'الْيَوْمَ يَئِسَ الَّذِينَ كَفَرُوا مِن دِينِكُمْ فَلَا تَخْشَوْهُمْ وَاخْشَوْنِ', 'Aujourd''hui, les infidèles désespèrent de votre religion. Ne les craignez donc pas, craignez-Moi.', 18),
((SELECT id FROM public.surahs WHERE number = 5), 19, 'الْيَوْمَ أُحِلَّ لَكُمُ الطَّيِّبَاتُ', 'Aujourd''hui, les bonnes choses vous sont permises.', 19),
((SELECT id FROM public.surahs WHERE number = 5), 20, 'وَطَعَامُ الَّذِينَ أُوتُوا الْكِتَابَ حِلٌّ لَّكُمْ وَطَعَامُكُمْ حِلٌّ لَّهُمْ', 'La nourriture des gens du Livre vous est licite, et votre nourriture leur est licite.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

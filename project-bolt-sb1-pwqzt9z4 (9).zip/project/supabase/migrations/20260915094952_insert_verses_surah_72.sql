/*
# Insert verses for surah 72: Al-Jinn (first 20 verses)
*/

INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 72), 1, 'قُلْ أُوحِيَ إِلَيَّ أَنَّهُ اسْتَمَعَ نَفَرٌ مِّنَ الْجِنِّ', 'Dis: Il m''a été révélé qu''un groupe de djinns ont écouté le Coran.', 1),
((SELECT id FROM public.surahs WHERE number = 72), 2, 'فَقَالُوا إِنَّا سَمِعْنَا قُرْآنًا عَجَبًا', 'Et dirent: Nous avons entendu un Coran merveilleux,', 2),
((SELECT id FROM public.surahs WHERE number = 72), 3, 'يَهْدِي إِلَى الرُّشْدِ فَآمَنَّا بِهِ', 'qui guide vers la droiture. Nous y croyons,', 3),
((SELECT id FROM public.surahs WHERE number = 72), 4, 'وَأَنَّهُ تَعَالَىٰ جَدُّ رَبِّنَا مَا اتَّخَذَ صَاحِبَةً وَلَا وَلَدًا', 'et nous n''associons personne à notre Seigneur.', 4),
((SELECT id FROM public.surahs WHERE number = 72), 5, 'وَأَنَّهُ كَانَ يَقُولُ سَفِيهُنَا عَلَى اللَّهِ شَطَطًا', 'Notre insensé disait des choses excessives sur Allah.', 5),
((SELECT id FROM public.surahs WHERE number = 72), 6, 'وَأَنَّا ظَنَنَّا أَن لَّن تَقُولَ الْإِنسُ وَالْجِنُّ عَلَى اللَّهِ كَذِبًا', 'Et nous pensions que ni humains ni djinns ne diraient de mensonge sur Allah.', 6),
((SELECT id FROM public.surahs WHERE number = 72), 7, 'وَأَنَّهُ كَانَ رِجَالٌ مِّنَ الْإِنسِ يَعُوذُونَ بِرِجَالٍ مِّنَ الْجِنِّ', 'Des humains cherchaient refuge auprès de certains djinns,', 7),
((SELECT id FROM public.surahs WHERE number = 72), 8, 'فَزَادُوهُمْ رَهَقًا', 'et cela accrut leur égarement.', 8),
((SELECT id FROM public.surahs WHERE number = 72), 9, 'وَأَنَّا لَمَسْنَا السَّمَاءَ فَوَجَدْنَاهَا مُلِئَتْ حَرَسًا شَدِيدًا وَشُهُبًا', 'Nous avons touché le ciel et l''avons trouvé rempli de gardiens redoutables et de météores.', 9),
((SELECT id FROM public.surahs WHERE number = 72), 10, 'وَأَنَّا كُنَّا نَقْعُدُ مِنْهَا مَقَاعِدَ لِلسَّمْعِ', 'Nous y prenions place pour écouter,', 10),
((SELECT id FROM public.surahs WHERE number = 72), 11, 'فَمَن يَسْتَمِعِ الْآنَ يَجِدْ لَهُ شِهَابًا رَّصَدًا', 'mais quiconque écoute maintenant trouve un météore à l''affût.', 11),
((SELECT id FROM public.surahs WHERE number = 72), 12, 'وَأَنَّا لَا نَدْرِي أَشَرٌّ أُرِيدَ بِمَن فِي الْأَرْضِ أَمْ أَرَادَ بِهِمْ رَبُّهُمْ رَشَدًا', 'Nous ne savons pas si le mal est voulu pour ceux qui sont sur la terre, ou si leur Seigneur veut leur droiture.', 12),
((SELECT id FROM public.surahs WHERE number = 72), 13, 'وَأَنَّا مِنَّا الصَّالِحُونَ وَمِنَّا دُونَ ذَٰلِكَ ۖ كُنَّا طَرَائِقَ قِدَدًا', 'Parmi nous, il en est de vertueux et d''autres qui ne le sont pas. Nous étions de divergentes voies.', 13),
((SELECT id FROM public.surahs WHERE number = 72), 14, 'وَأَنَّا ظَنَنَّا أَن لَّن نُّعْجِزَ اللَّهَ فِي الْأَرْضِ وَلَن نُّعْجِزَهُ هَرَبًا', 'Nous pensions que nous ne saurions réduire Allah sur terre, ni Lui échapper en fuyant.', 14),
((SELECT id FROM public.surahs WHERE number = 72), 15, 'وَأَنَّا لَمَّا سَمِعْنَا الْهُدَىٰ آمَنَّا بِهِ', 'Quand nous avons entendu la guidée, nous y avons cru.', 15),
((SELECT id FROM public.surahs WHERE number = 72), 16, 'وَأَنَّا مِنَّا الْمُسْلِمُونَ وَمِنَّا الْقَاسِطُونَ', 'Parmi nous, il en est de soumis, et d''autres de rebelles.', 16),
((SELECT id FROM public.surahs WHERE number = 72), 17, 'فَمَنْ أَسْلَمَ فَأُولَٰئِكَ تَحَرَّوْا رَشَدًا', 'Ceux qui se sont soumis ont choisi la droiture,', 17),
((SELECT id FROM public.surahs WHERE number = 72), 18, 'وَأَمَّا الْقَاسِطُونَ فَكَانُوا لِجَهَنَّمَ حَطَبًا', 'et quant aux rebelles, ils seront le combustible de l''Enfer.', 18),
((SELECT id FROM public.surahs WHERE number = 72), 19, 'وَأَنَّ الْمَسَاجِدَ لِلَّهِ فَلَا تَدْعُوا مَعَ اللَّهِ أَحَدًا', 'Et que les mosquées appartiennent à Allah. N''invoquez donc personne avec Allah.', 19),
((SELECT id FROM public.surahs WHERE number = 72), 20, 'وَأَنَّهُ لَمَّا قَامَ عَبْدُ اللَّهِ يَدْعُوهُ كَادُوا يَكُونُونَ عَلَيْهِ لِبَدًا', 'Et quand le serviteur d''Allah s''est levé pour L''invoquer, ils se sont presque jetés en masse sur lui.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

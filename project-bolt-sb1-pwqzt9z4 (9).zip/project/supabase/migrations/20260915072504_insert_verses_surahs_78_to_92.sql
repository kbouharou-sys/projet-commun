/*
# Insert verses for surahs 78-92

## Purpose
Adds verse data for surahs 78-92 (An-Naba through Al-Layl).
Arabic Uthmani text follows the standard Hafs reading. French translations
are well-established pre-translations.

## Surahs added:
- 78: An-Naba (40 verses)
- 79: An-Naziat (46 verses)
- 80: Abasa (42 verses)
- 81: At-Takwir (29 verses)
- 82: Al-Infitar (19 verses)
- 83: Al-Mutaffifin (36 verses)
- 84: Al-Inshiqaq (25 verses)
- 85: Al-Buruj (22 verses)
- 86: At-Tariq (17 verses)
- 87: Al-A'la (19 verses)
- 88: Al-Ghashiya (26 verses)
- 89: Al-Fajr (30 verses)
- 90: Al-Balad (20 verses)
- 91: Ash-Shams (15 verses)
- 92: Al-Layl (21 verses)
*/

-- =========================================================
-- SURAH 87: Al-A'la (19 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 87), 1, 'سَبِّحِ اسْمَ رَبِّكَ الْأَعْلَى', 'Glorifie le nom de ton Seigneur, le Très-Haut!', 1),
((SELECT id FROM public.surahs WHERE number = 87), 2, 'الَّذِي خَلَقَ فَسَوَّىٰ', 'Celui Qui a créé et agencé avec harmonie,', 2),
((SELECT id FROM public.surahs WHERE number = 87), 3, 'وَالَّذِي قَدَّرَ فَهَدَىٰ', 'Celui Qui a décrété et guidé,', 3),
((SELECT id FROM public.surahs WHERE number = 87), 4, 'وَالَّذِي أَخْرَجَ الْمَرْعَىٰ', 'et Celui Qui a fait pousser le pâturage,', 4),
((SELECT id FROM public.surahs WHERE number = 87), 5, 'فَجَعَلَهُ غُثَاءً أَحْوَىٰ', 'puis en a fait un foin sombre.', 5),
((SELECT id FROM public.surahs WHERE number = 87), 6, 'سَنُقْرِئُكَ فَلَا تَنسَىٰ', 'Nous allons te faire réciter (le Coran), de sorte que tu n''oublieras pas,', 6),
((SELECT id FROM public.surahs WHERE number = 87), 7, 'إِلَّا مَا شَاءَ اللَّهُ ۚ إِنَّهُ يَعْلَمُ الْجَهْرَ وَمَا يَخْفَىٰ', 'sauf ce qu''Allah voudra. Il connaît ce qui est manifeste et ce qui est caché.', 7),
((SELECT id FROM public.surahs WHERE number = 87), 8, 'وَنُيَسِّرُكَ لِلْيُسْرَىٰ', 'et Nous te faciliterons la voie facile.', 8),
((SELECT id FROM public.surahs WHERE number = 87), 9, 'فَذَكِّرْ إِن نَّفَعَتِ الذِّكْرَىٰ', 'Rappelle, donc, si le rappel est utile.', 9),
((SELECT id FROM public.surahs WHERE number = 87), 10, 'سَيَذَّكَّرُ مَن يَخْشَىٰ', 'Celui qui craint (Allah) s''en rappellera,', 10),
((SELECT id FROM public.surahs WHERE number = 87), 11, 'وَيَتَجَنَّبُهَا الْأَشْقَىٰ', 'et le très malheureux l''évitera,', 11),
((SELECT id FROM public.surahs WHERE number = 87), 12, 'الَّذِي يَصْلَى النَّارَ الْكُبْرَىٰ', 'lui qui brûlera dans le plus grand Feu,', 12),
((SELECT id FROM public.surahs WHERE number = 87), 13, 'ثُمَّ لَا يَمُوتُ فِيهَا وَلَا يَحْيَىٰ', 'où il ne mourra pas ni ne vivra.', 13),
((SELECT id FROM public.surahs WHERE number = 87), 14, 'قَدْ أَفْلَحَ مَن تَزَكَّىٰ', 'A réussi certes celui qui se purifie,', 14),
((SELECT id FROM public.surahs WHERE number = 87), 15, 'وَذَكَرَ اسْمَ رَبِّهِ فَصَلَّىٰ', 'et évoque le nom de son Seigneur, puis prie.', 15),
((SELECT id FROM public.surahs WHERE number = 87), 16, 'بَلْ تُؤْثِرُونَ الْحَيَاةَ الدُّنْيَا', 'Mais vous préférez la vie d''ici-bas,', 16),
((SELECT id FROM public.surahs WHERE number = 87), 17, 'وَالْآخِرَةُ خَيْرٌ وَأَبْقَىٰ', 'alors que l''au-delà est meilleur et plus durable.', 17),
((SELECT id FROM public.surahs WHERE number = 87), 18, 'إِنَّ هَٰذَا لَفِي الصُّحُفِ الْأُولَىٰ', 'Ceci se trouve dans les Feuilles anciennes,', 18),
((SELECT id FROM public.surahs WHERE number = 87), 19, 'صُحُفِ إِبْرَاهِيمَ وَمُوسَىٰ', 'les Feuilles d''Abraham et de Moïse.', 19)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 91: Ash-Shams (15 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 91), 1, 'وَالشَّمْسِ وَضُحَاهَا', 'Par le soleil et sa clarté matinale!', 1),
((SELECT id FROM public.surahs WHERE number = 91), 2, 'وَالْقَمَرِ إِذَا تَلَاهَا', 'Et par la lune quand elle le suit!', 2),
((SELECT id FROM public.surahs WHERE number = 91), 3, 'وَالنَّهَارِ إِذَا جَلَّاهَا', 'Et par le jour quand il l''éclaire!', 3),
((SELECT id FROM public.surahs WHERE number = 91), 4, 'وَاللَّيْلِ إِذَا يَغْشَاهَا', 'Et par la nuit quand elle l''enveloppe!', 4),
((SELECT id FROM public.surahs WHERE number = 91), 5, 'وَالسَّمَاءِ وَمَا بَنَاهَا', 'Et par le ciel et Celui Qui l''a construit!', 5),
((SELECT id FROM public.surahs WHERE number = 91), 6, 'وَالْأَرْضِ وَمَا طَحَاهَا', 'Et par la terre et Celui Qui l''a étendue!', 6),
((SELECT id FROM public.surahs WHERE number = 91), 7, 'وَنَفْسٍ وَمَا سَوَّاهَا', 'Et par l''âme et Celui Qui l''a harmonieusement façonnée,', 7),
((SELECT id FROM public.surahs WHERE number = 91), 8, 'فَأَلْهَمَهَا فُجُورَهَا وَتَقْوَاهَا', 'et Qui lui a inspiré son impie et sa piété.', 8),
((SELECT id FROM public.surahs WHERE number = 91), 9, 'قَدْ أَفْلَحَ مَن زَكَّاهَا', 'A réussi certes celui qui la purifie.', 9),
((SELECT id FROM public.surahs WHERE number = 91), 10, 'وَقَدْ خَابَ مَن دَسَّاهَا', 'Et est perdu certes celui qui la corrompt.', 10),
((SELECT id FROM public.surahs WHERE number = 91), 11, 'كَذَّبَتْ ثَمُودُ بِطَغْوَاهَا', 'Les Thamud, par leur transgression, ont crié au mensonge,', 11),
((SELECT id FROM public.surahs WHERE number = 91), 12, 'إِذِ انْبَعَثَ أَشْقَاهَا', 'quand le plus misérable d''entre eux se leva.', 12),
((SELECT id FROM public.surahs WHERE number = 91), 13, 'فَقَالَ لَهُمْ رَسُولُ اللَّهِ نَاقَةَ اللَّهِ وَسُقْيَاهَا', 'Le Messager d''Allah leur dit: (Laissez) la chamelle d''Allah et son abreuvage!', 13),
((SELECT id FROM public.surahs WHERE number = 91), 14, 'فَكَذَّبُوهُ فَعَقَرُوهَا فَدَمْدَمَ عَلَيْهِمْ رَبُّهُم بِذَنبِهِمْ فَسَوَّاهَا', 'Ils le traitèrent de menteux, l''étripèrent. Leur Seigneur les anéantit pour leur péché, et les mit tous sur le même pied.', 14),
((SELECT id FROM public.surahs WHERE number = 91), 15, 'وَلَا يَخَافُ عُقْبَاهَا', 'Et Il ne craint point l''issue.', 15)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 92: Al-Layl (21 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 92), 1, 'وَاللَّيْلِ إِذَا يَغْشَىٰ', 'Par la nuit quand elle couvre tout!', 1),
((SELECT id FROM public.surahs WHERE number = 92), 2, 'وَالنَّهَارِ إِذَا تَجَلَّىٰ', 'Et par le jour quand il éclaire!', 2),
((SELECT id FROM public.surahs WHERE number = 92), 3, 'وَمَا خَلَقَ الذَّكَرَ وَالْأُنثَىٰ', 'Et par Celui Qui a créé le mâle et la femelle!', 3),
((SELECT id FROM public.surahs WHERE number = 92), 4, 'إِنَّ سَعْيَكُمْ لَشَتَّىٰ', 'Vos efforts sont divergents.', 4),
((SELECT id FROM public.surahs WHERE number = 92), 5, 'فَأَمَّا مَنْ أَعْطَىٰ وَاتَّقَىٰ', 'Quant à celui qui donne et se prémunit,', 5),
((SELECT id FROM public.surahs WHERE number = 92), 6, 'وَصَدَّقَ بِالْحُسْنَىٰ', 'et croit en la plus belle (rétribution),', 6),
((SELECT id FROM public.surahs WHERE number = 92), 7, 'فَسَنُيَسِّرُهُ لِلْيُسْرَىٰ', 'Nous le guiderons vers la voie facile.', 7),
((SELECT id FROM public.surahs WHERE number = 92), 8, 'وَأَمَّا مَن بَخِلَ وَاسْتَغْنَىٰ', 'Et quant à celui qui est avare et se croit riche,', 8),
((SELECT id FROM public.surahs WHERE number = 92), 9, 'وَكَذَّبَ بِالْحُسْنَىٰ', 'et traite de mensonge la plus belle (rétribution),', 9),
((SELECT id FROM public.surahs WHERE number = 92), 10, 'فَسَنُيَسِّرُهُ لِلْعُسْرَىٰ', 'Nous le guiderons vers la voie difficile.', 10),
((SELECT id FROM public.surahs WHERE number = 92), 11, 'وَمَا يُغْنِي عَنْهُ مَالُهُ إِذَا تَرَدَّىٰ', 'Et sa fortune ne lui sera d''aucune utilité quand il tombera.', 11),
((SELECT id FROM public.surahs WHERE number = 92), 12, 'إِنَّ عَلَيْنَا لَلْهُدَىٰ', 'C''est à Nous, certes, de guider,', 12),
((SELECT id FROM public.surahs WHERE number = 92), 13, 'وَإِنَّ لَنَا لَلْآخِرَةَ وَالْأُولَىٰ', 'et à Nous appartient l''au-delà et ici-bas.', 13),
((SELECT id FROM public.surahs WHERE number = 92), 14, 'فَأَنذَرْتُكُمْ نَارًا تَلَظَّىٰ', 'Je vous ai donc avertis d''un Feu ardent,', 14),
((SELECT id FROM public.surahs WHERE number = 92), 15, 'لَا يَصْلَاهَا إِلَّا الْأَشْقَىٰ', 'que ne brûlera que le très malheureux,', 15),
((SELECT id FROM public.surahs WHERE number = 92), 16, 'الَّذِي كَذَّبَ وَتَوَلَّىٰ', 'qui traite de mensonge et se détourne.', 16),
((SELECT id FROM public.surahs WHERE number = 92), 17, 'وَسَيُجَنَّبُهَا الْأَتْقَىٰ', 'En sera écarté le très pieux,', 17),
((SELECT id FROM public.surahs WHERE number = 92), 18, 'الَّذِي يُؤْتِي مَالَهُ يَتَزَكَّىٰ', 'qui donne ses biens pour se purifier,', 18),
((SELECT id FROM public.surahs WHERE number = 92), 19, 'وَمَا لِأَحَدٍ عِندَهُ مِن نِّعْمَةٍ تُجْزَىٰ', 'et ne rend à personne un bienfait par complaisance,', 19),
((SELECT id FROM public.surahs WHERE number = 92), 20, 'إِلَّا ابْتِغَاءَ وَجْهِ رَبِّهِ الْأَعْلَىٰ', 'mais uniquement par désir de la Face de son Seigneur, le Très-Haut.', 20),
((SELECT id FROM public.surahs WHERE number = 92), 21, 'وَسَيَرْضَىٰ', 'Il sera certes satisfait.', 21)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 86: At-Tariq (17 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 86), 1, 'وَالسَّمَاءِ وَالطَّارِقِ', 'Par le ciel et par l''astre nocturne!', 1),
((SELECT id FROM public.surahs WHERE number = 86), 2, 'وَمَا أَدْرَاكَ مَا الطَّارِقِ', 'Et qui te dira ce qu''est l''astre nocturne?', 2),
((SELECT id FROM public.surahs WHERE number = 86), 3, 'النَّجْمُ الثَّاقِبُ', 'C''est l''étoile perçante.', 3),
((SELECT id FROM public.surahs WHERE number = 86), 4, 'إِن كُلُّ نَفْسٍ لَّمَّا عَلَيْهَا حَافِظٌ', 'Toute âme a, devant elle, un gardien.', 4),
((SELECT id FROM public.surahs WHERE number = 86), 5, 'فَلْيَنظُرِ الْإِنسَانُ مِمَّ خُلِقَ', 'Que l''homme regarde de quoi il a été créé.', 5),
((SELECT id FROM public.surahs WHERE number = 86), 6, 'خُلِقَ مِن مَّاءٍ دَافِقٍ', 'Il a été créé d''un liquide jailli,', 6),
((SELECT id FROM public.surahs WHERE number = 86), 7, 'يَخْرُجُ مِن بَيْنِ الصُّلْبِ وَالتَّرَائِبِ', 'sorti d''entre les lombes et les côtes.', 7),
((SELECT id FROM public.surahs WHERE number = 86), 8, 'إِنَّهُ عَلَىٰ رَجْعِهِ لَقَادِرٌ', 'Allah est certes capable de le ressusciter,', 8),
((SELECT id FROM public.surahs WHERE number = 86), 9, 'يَوْمَ تُبْلَى السَّرَائِرُ', 'le Jour où les secrets seront dévoilés,', 9),
((SELECT id FROM public.surahs WHERE number = 86), 10, 'فَمَا لَهُ مِن قُوَّةٍ وَلَا نَاصِرٍ', 'il n''aura ni force ni secoureur.', 10),
((SELECT id FROM public.surahs WHERE number = 86), 11, 'وَالسَّمَاءِ ذَاتِ الرَّجْعِ', 'Par le ciel qui fait revenir (la pluie),', 11),
((SELECT id FROM public.surahs WHERE number = 86), 12, 'وَالْأَرْضِ ذَاتِ الصَّدْعِ', 'et par la terre qui se fend!', 12),
((SELECT id FROM public.surahs WHERE number = 86), 13, 'إِنَّهُ لَقَوْلٌ فَصْلٌ', 'Ceci (le Coran) est certes une parole décisive,', 13),
((SELECT id FROM public.surahs WHERE number = 86), 14, 'وَمَا هُوَ بِالْهَزْلِ', 'et non point une plaisanterie frivole.', 14),
((SELECT id FROM public.surahs WHERE number = 86), 15, 'إِنَّهُمْ يَكِيدُونَ كَيْدًا', 'Ils trament certes une ruse,', 15),
((SELECT id FROM public.surahs WHERE number = 86), 16, 'وَأَكِيدُ كَيْدًا', 'et Moi Je trame une ruse.', 16),
((SELECT id FROM public.surahs WHERE number = 86), 17, 'فَمَهِّلِ الْكَافِرِينَ أَمْهِلْهُمْ رُوَيْدًا', 'Accorde donc un délai aux infidèles: accorde-leur un court délai.', 17)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 89: Al-Fajr (30 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 89), 1, 'وَالْفَجْرِ', 'Par l''aube!', 1),
((SELECT id FROM public.surahs WHERE number = 89), 2, 'وَلَيَالٍ عَشْرٍ', 'Et par les dix nuits!', 2),
((SELECT id FROM public.surahs WHERE number = 89), 3, 'وَالشَّفْعِ وَالْوَتْرِ', 'Et par le pair et l''impair!', 3),
((SELECT id FROM public.surahs WHERE number = 89), 4, 'وَاللَّيْلِ إِذَا يَسْرِ', 'Et par la nuit quand elle s''écoule!', 4),
((SELECT id FROM public.surahs WHERE number = 89), 5, 'هَلْ فِي ذَٰلِكَ قَسَمٌ لِّذِي حِجْرٍ', 'N''y a-t-il pas dans cela un serment suffisant pour l''homme doué d''intelligence?', 5),
((SELECT id FROM public.surahs WHERE number = 89), 6, 'أَلَمْ تَرَ كَيْفَ فَعَلَ رَبُّكَ بِعَادٍ', 'N''as-tu pas vu comment ton Seigneur a traité les Aad,', 6),
((SELECT id FROM public.surahs WHERE number = 89), 7, 'إِرَمَ ذَاتِ الْعِمَادِ', 'd''Iram, la cité aux colonnes,', 7),
((SELECT id FROM public.surahs WHERE number = 89), 8, 'الَّتِي لَمْ يُخْلَقْ مِثْلُهَا فِي الْبِلَادِ', 'dont les semblables n''ont jamais été créés dans le pays?', 8),
((SELECT id FROM public.surahs WHERE number = 89), 9, 'وَثَمُودَ الَّذِينَ جَابُوا الصَّخْرَ بِالْوَادِ', 'Et les Thamud qui taillaient le rocher dans la vallée?', 9),
((SELECT id FROM public.surahs WHERE number = 89), 10, 'وَفِرْعَوْنَ ذِي الْأَوْتَادِ', 'Et Pharaon, l''homme aux piquets (de tente)?', 10),
((SELECT id FROM public.surahs WHERE number = 89), 11, 'الَّذِينَ طَغَوْا فِي الْبِلَادِ', 'Tous se révoltèrent contre leurs Seigneurs dans le pays,', 11),
((SELECT id FROM public.surahs WHERE number = 89), 12, 'فَأَكْثَرُوا فِيهَا الْفَسَادَ', 'et y multiplièrent la corruption.', 12),
((SELECT id FROM public.surahs WHERE number = 89), 13, 'فَصَبَّ عَلَيْهِمْ رَبُّكَ سَوْطَ عَذَابٍ', 'Ton Seigneur déversa sur eux un fouet de châtiment.', 13),
((SELECT id FROM public.surahs WHERE number = 89), 14, 'إِنَّ رَبَّكَ لَبِالْمِرْصَادِ', 'Ton Seigneur est certes aux aguets.', 14),
((SELECT id FROM public.surahs WHERE number = 89), 15, 'فَأَمَّا الْإِنسَانُ إِذَا مَا ابْتَلَاهُ رَبُّهُ فَأَكْرَمَهُ وَنَعَّمَهُ', 'Quant à l''homme, quand son Seigneur l''éprouve en l''honorant et en le comblant de bienfaits, il dit: «Mon Seigneur m''honore.»', 15),
((SELECT id FROM public.surahs WHERE number = 89), 16, 'فَيَقُولُ رَبِّي أَكْرَمَنِ', 'Mais quand Il l''éprouve en restreignant sa subsistance, il dit: «Mon Seigneur m''avilit.»', 16),
((SELECT id FROM public.surahs WHERE number = 89), 17, 'وَأَمَّا إِذَا مَا ابْتَلَاهُ فَقَدَرَ عَلَيْهِ رِزْقَهُ فَيَقُولُ رَبِّي أَهَانَنِ', 'Mais non! C''est vous plutôt qui n''êtes pas généreux envers les orphelins,', 17),
((SELECT id FROM public.surahs WHERE number = 89), 18, 'كَلَّا ۖ بَل لَّا تُكْرِمُونَ الْيَتِيمَ', 'qui ne vous incitez pas à nourrir le pauvre,', 18),
((SELECT id FROM public.surahs WHERE number = 89), 19, 'وَلَا تَحَاضُّونَ عَلَىٰ طَعَامِ الْمِسْكِينِ', 'qui dévorez l''héritage avec une avidité vorace,', 19),
((SELECT id FROM public.surahs WHERE number = 89), 20, 'وَتَأْكُلُونَ التُّرَاثَ أَكْلًا لَّمًّا', 'et aimez les richesses d''un amour excessif.', 20),
((SELECT id FROM public.surahs WHERE number = 89), 21, 'وَتُحِبُّونَ الْمَالَ حُبًّا جَمًّا', 'Non! Quand la terre sera pulvérisée avec force,', 21),
((SELECT id FROM public.surahs WHERE number = 89), 22, 'كَلَّا ۖ إِذَا دُكَّتِ الْأَرْضُ دَكًّا دَكًّا', 'et que viendra ton Seigneur, ainsi que les Anges, rang par rang,', 22),
((SELECT id FROM public.surahs WHERE number = 89), 23, 'وَجَاءَ رَبُّكَ وَالْمَلَكُ صَفًّا صَفًّا', 'et ce Jour-là, on fera venir la Fournaise; ce Jour-là, l''homme se rappellera...', 23),
((SELECT id FROM public.surahs WHERE number = 89), 24, 'وَجِيءَ يَوْمَئِذٍ بِجَهَنَّمَ ۚ يَوْمَئِذٍ يَتَذَكَّرُ الْإِنسَانُ وَأَنَّىٰ لَهُ الذِّكْرَىٰ', 'mais à quoi lui servira de se rappeler alors?', 24),
((SELECT id FROM public.surahs WHERE number = 89), 25, 'يَقُولُ يَا لَيْتَنِي قَدَّمْتُ لِحَيَاتِي', 'Il dira: «Hélas! Que n''ai-je fait du bien pour ma vie future!»', 25),
((SELECT id FROM public.surahs WHERE number = 89), 26, 'فَيَوْمَئِذٍ لَّا يُعَذِّبُ عَذَابَهُ أَحَدٌ', 'Ce Jour-là, personne ne châtiera comme Il châtie,', 26),
((SELECT id FROM public.surahs WHERE number = 89), 27, 'وَلَا يُوثِقُ وَثَاقَهُ أَحَدٌ', 'et personne n''enchaînera comme Il enchaîne.', 27),
((SELECT id FROM public.surahs WHERE number = 89), 28, 'يَا أَيَّتُهَا النَّفْسُ الْمُطْمَئِنَّةُ', 'Ô toi, âme apaisée,', 28),
((SELECT id FROM public.surahs WHERE number = 89), 29, 'ارْجِعِي إِلَىٰ رَبِّكِ رَاضِيَةً مَّرْضِيَّةً', 'retourne vers ton Seigneur, satisfaite et agréée;', 29),
((SELECT id FROM public.surahs WHERE number = 89), 30, 'فَادْخُلِي فِي عِبَادِي', 'entre donc parmi Mes serviteurs,', 30)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

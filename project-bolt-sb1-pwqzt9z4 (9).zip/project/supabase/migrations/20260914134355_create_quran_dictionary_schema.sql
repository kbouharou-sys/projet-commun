/*
# Quran & Dictionary — Complete Database Schema (Step 1)

## Purpose
Creates the full persistent database architecture for an interactive Quran + dictionary application.
The Quran stores its own pre-translations and functions independently of the dictionary.
The dictionary will later enrich/correct those translations.

## 1. New Tables (creation order respects FK dependencies)

### `surahs` — Chapters of the Quran
- `id` (uuid, primary key)
- `number` (integer, unique — surah number 1–114)
- `name_fr` (text — French name)
- `name_ar` (text — Arabic name)
- `revelation_type` (text — 'meccan' or 'medinan')
- `verse_count` (integer — number of verses in this surah)
- `order_index` (integer — display order)
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

### `verses` — Individual verses
- `id` (uuid, primary key)
- `surah_id` (uuid, FK → surahs.id ON DELETE CASCADE)
- `verse_number` (integer — verse number within the surah)
- `arabic_uthmani` (text — Uthmani Arabic text)
- `french_pretranslation` (text — standalone French translation stored directly with the verse)
- `order_index` (integer — display order)
- `created_at` (timestamptz)
- `updated_at` (timestamptz)
- Unique constraint on (surah_id, verse_number)

### `roots` — Arabic roots and their translations
- `id` (uuid, primary key)
- `arabic_root` (text — the root, typically 3 letters, unique)
- `root_translation` (text — French translation of the root)
- `occurrence_count` (integer, default 0 — how many times this root appears in the Quran)
- `frequency_rank` (integer — rank from most frequent to least frequent)
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

### `verse_words` — Word-level decomposition of each verse
- `id` (uuid, primary key)
- `verse_id` (uuid, FK → verses.id ON DELETE CASCADE)
- `position` (integer — exact word order within the verse)
- `arabic_form` (text — the Arabic word as it appears)
- `root_id` (uuid, FK → roots.id ON DELETE SET NULL, nullable)
- `prefix` (text)
- `infix` (text)
- `suffix` (text)
- `created_at` (timestamptz)
- `updated_at` (timestamptz)
- Unique constraint on (verse_id, position)

### `variations` — Word forms derived from a root
- `id` (uuid, primary key)
- `root_id` (uuid, FK → roots.id ON DELETE CASCADE)
- `prefix` (text)
- `infix` (text)
- `suffix` (text)
- `arabic_form` (text — the derived Arabic word)
- `french_translation` (text — French translation of this specific form)
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

### `user_roles` — Application-level role assignment
- `id` (uuid, primary key)
- `user_id` (uuid, FK → auth.users.id ON DELETE CASCADE, unique)
- `role` (text — one of: 'admin_principal', 'admin_2', 'admin_3', 'lecteur')
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

### `change_log` — Audit trail for data modifications
- `id` (uuid, primary key)
- `user_id` (uuid, FK → auth.users.id ON DELETE SET NULL, nullable)
- `action` (text — 'insert', 'update', 'delete')
- `table_name` (text — which table was affected)
- `row_id` (uuid — which row was affected)
- `old_value` (jsonb — previous state)
- `new_value` (jsonb — new state)
- `created_at` (timestamptz)

## 2. Security — Row Level Security

All tables have RLS enabled.

### Public read (anon + authenticated):
- `surahs`, `verses`, `verse_words`, `roots`, `variations` — SELECT only

### Admin write (admin_principal, admin_2, admin_3):
- All content tables: INSERT, UPDATE, DELETE — only for users whose `user_roles.role` is an admin role.
- Enforced via `is_admin()` SECURITY DEFINER function.

### Reader role:
- SELECT only on all content tables. No writes allowed.

### user_roles:
- SELECT: users read their own role; admins read all roles.
- INSERT/UPDATE/DELETE: only admin_principal.

### change_log:
- SELECT: admin roles only.
- INSERT: any authenticated user (via triggers).
- No UPDATE or DELETE (append-only audit trail).

## 3. Constraints
- Maximum 3 admin users (enforced via trigger on user_roles).
- Unique constraints on surahs.number, (verses.surah_id, verse_number), roots.arabic_root, (verse_words.verse_id, position).

## 4. Triggers
- `set_updated_at()` on all content tables — auto-set updated_at on UPDATE.
- `log_change()` audit triggers on surahs, verses, verse_words, roots, variations.
- `enforce_max_admins()` on user_roles — prevents more than 3 admin accounts.

## 5. Important Notes
1. The Quran (surahs + verses) stores its own `french_pretranslation` and does NOT depend on the dictionary (roots + variations) to display translations.
2. `verse_words.root_id` is nullable so words can exist before being linked to a root.
3. The `change_log` table provides an audit trail for future admin features.
4. Role checks use `is_admin()` SECURITY DEFINER function — safe because it runs with server privileges.
*/

-- =========================================================
-- UTILITY: updated_at trigger function
-- =========================================================
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- =========================================================
-- UTILITY: is_admin() — SECURITY DEFINER function
-- Returns true if the current authenticated user has an admin role.
-- =========================================================
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_role text;
BEGIN
  SELECT role INTO v_role
  FROM public.user_roles
  WHERE user_id = auth.uid();

  IF v_role IN ('admin_principal', 'admin_2', 'admin_3') THEN
    RETURN true;
  END IF;

  RETURN false;
END;
$$;

-- =========================================================
-- TABLE: surahs
-- =========================================================
CREATE TABLE IF NOT EXISTS public.surahs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  number integer UNIQUE NOT NULL,
  name_fr text NOT NULL,
  name_ar text NOT NULL,
  revelation_type text CHECK (revelation_type IN ('meccan', 'medinan')),
  verse_count integer DEFAULT 0,
  order_index integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.surahs ENABLE ROW LEVEL SECURITY;

DROP TRIGGER IF EXISTS surahs_updated_at ON public.surahs;
CREATE TRIGGER surahs_updated_at
  BEFORE UPDATE ON public.surahs
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE INDEX IF NOT EXISTS idx_surahs_number ON public.surahs(number);
CREATE INDEX IF NOT EXISTS idx_surahs_order ON public.surahs(order_index);

DROP POLICY IF EXISTS "public_read_surahs" ON public.surahs;
CREATE POLICY "public_read_surahs"
  ON public.surahs FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_surahs" ON public.surahs;
CREATE POLICY "admin_insert_surahs"
  ON public.surahs FOR INSERT
  TO authenticated WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "admin_update_surahs" ON public.surahs;
CREATE POLICY "admin_update_surahs"
  ON public.surahs FOR UPDATE
  TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "admin_delete_surahs" ON public.surahs;
CREATE POLICY "admin_delete_surahs"
  ON public.surahs FOR DELETE
  TO authenticated USING (public.is_admin());

-- =========================================================
-- TABLE: verses
-- =========================================================
CREATE TABLE IF NOT EXISTS public.verses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  surah_id uuid NOT NULL REFERENCES public.surahs(id) ON DELETE CASCADE,
  verse_number integer NOT NULL,
  arabic_uthmani text NOT NULL,
  french_pretranslation text NOT NULL,
  order_index integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(surah_id, verse_number)
);

ALTER TABLE public.verses ENABLE ROW LEVEL SECURITY;

DROP TRIGGER IF EXISTS verses_updated_at ON public.verses;
CREATE TRIGGER verses_updated_at
  BEFORE UPDATE ON public.verses
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE INDEX IF NOT EXISTS idx_verses_surah_id ON public.verses(surah_id);

DROP POLICY IF EXISTS "public_read_verses" ON public.verses;
CREATE POLICY "public_read_verses"
  ON public.verses FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_verses" ON public.verses;
CREATE POLICY "admin_insert_verses"
  ON public.verses FOR INSERT
  TO authenticated WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "admin_update_verses" ON public.verses;
CREATE POLICY "admin_update_verses"
  ON public.verses FOR UPDATE
  TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "admin_delete_verses" ON public.verses;
CREATE POLICY "admin_delete_verses"
  ON public.verses FOR DELETE
  TO authenticated USING (public.is_admin());

-- =========================================================
-- TABLE: roots
-- =========================================================
CREATE TABLE IF NOT EXISTS public.roots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  arabic_root text UNIQUE NOT NULL,
  root_translation text,
  occurrence_count integer DEFAULT 0,
  frequency_rank integer,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.roots ENABLE ROW LEVEL SECURITY;

DROP TRIGGER IF EXISTS roots_updated_at ON public.roots;
CREATE TRIGGER roots_updated_at
  BEFORE UPDATE ON public.roots
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP POLICY IF EXISTS "public_read_roots" ON public.roots;
CREATE POLICY "public_read_roots"
  ON public.roots FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_roots" ON public.roots;
CREATE POLICY "admin_insert_roots"
  ON public.roots FOR INSERT
  TO authenticated WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "admin_update_roots" ON public.roots;
CREATE POLICY "admin_update_roots"
  ON public.roots FOR UPDATE
  TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "admin_delete_roots" ON public.roots;
CREATE POLICY "admin_delete_roots"
  ON public.roots FOR DELETE
  TO authenticated USING (public.is_admin());

-- =========================================================
-- TABLE: verse_words
-- =========================================================
CREATE TABLE IF NOT EXISTS public.verse_words (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  verse_id uuid NOT NULL REFERENCES public.verses(id) ON DELETE CASCADE,
  position integer NOT NULL,
  arabic_form text NOT NULL,
  root_id uuid REFERENCES public.roots(id) ON DELETE SET NULL,
  prefix text,
  infix text,
  suffix text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(verse_id, position)
);

ALTER TABLE public.verse_words ENABLE ROW LEVEL SECURITY;

DROP TRIGGER IF EXISTS verse_words_updated_at ON public.verse_words;
CREATE TRIGGER verse_words_updated_at
  BEFORE UPDATE ON public.verse_words
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE INDEX IF NOT EXISTS idx_verse_words_verse_id ON public.verse_words(verse_id);
CREATE INDEX IF NOT EXISTS idx_verse_words_root_id ON public.verse_words(root_id);

DROP POLICY IF EXISTS "public_read_verse_words" ON public.verse_words;
CREATE POLICY "public_read_verse_words"
  ON public.verse_words FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_verse_words" ON public.verse_words;
CREATE POLICY "admin_insert_verse_words"
  ON public.verse_words FOR INSERT
  TO authenticated WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "admin_update_verse_words" ON public.verse_words;
CREATE POLICY "admin_update_verse_words"
  ON public.verse_words FOR UPDATE
  TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "admin_delete_verse_words" ON public.verse_words;
CREATE POLICY "admin_delete_verse_words"
  ON public.verse_words FOR DELETE
  TO authenticated USING (public.is_admin());

-- =========================================================
-- TABLE: variations
-- =========================================================
CREATE TABLE IF NOT EXISTS public.variations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  root_id uuid NOT NULL REFERENCES public.roots(id) ON DELETE CASCADE,
  prefix text,
  infix text,
  suffix text,
  arabic_form text NOT NULL,
  french_translation text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.variations ENABLE ROW LEVEL SECURITY;

DROP TRIGGER IF EXISTS variations_updated_at ON public.variations;
CREATE TRIGGER variations_updated_at
  BEFORE UPDATE ON public.variations
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE INDEX IF NOT EXISTS idx_variations_root_id ON public.variations(root_id);

DROP POLICY IF EXISTS "public_read_variations" ON public.variations;
CREATE POLICY "public_read_variations"
  ON public.variations FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_variations" ON public.variations;
CREATE POLICY "admin_insert_variations"
  ON public.variations FOR INSERT
  TO authenticated WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "admin_update_variations" ON public.variations;
CREATE POLICY "admin_update_variations"
  ON public.variations FOR UPDATE
  TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "admin_delete_variations" ON public.variations;
CREATE POLICY "admin_delete_variations"
  ON public.variations FOR DELETE
  TO authenticated USING (public.is_admin());

-- =========================================================
-- TABLE: user_roles
-- =========================================================
CREATE TABLE IF NOT EXISTS public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('admin_principal', 'admin_2', 'admin_3', 'lecteur')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

DROP TRIGGER IF EXISTS user_roles_updated_at ON public.user_roles;
CREATE TRIGGER user_roles_updated_at
  BEFORE UPDATE ON public.user_roles
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE INDEX IF NOT EXISTS idx_user_roles_user_id ON public.user_roles(user_id);

DROP POLICY IF EXISTS "read_own_role" ON public.user_roles;
CREATE POLICY "read_own_role"
  ON public.user_roles FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "admin_read_all_roles" ON public.user_roles;
CREATE POLICY "admin_read_all_roles"
  ON public.user_roles FOR SELECT
  TO authenticated
  USING (public.is_admin());

DROP POLICY IF EXISTS "admin_principal_insert_role" ON public.user_roles;
CREATE POLICY "admin_principal_insert_role"
  ON public.user_roles FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.user_roles ur
      WHERE ur.user_id = auth.uid() AND ur.role = 'admin_principal'
    )
  );

DROP POLICY IF EXISTS "admin_principal_update_role" ON public.user_roles;
CREATE POLICY "admin_principal_update_role"
  ON public.user_roles FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.user_roles ur
      WHERE ur.user_id = auth.uid() AND ur.role = 'admin_principal'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.user_roles ur
      WHERE ur.user_id = auth.uid() AND ur.role = 'admin_principal'
    )
  );

DROP POLICY IF EXISTS "admin_principal_delete_role" ON public.user_roles;
CREATE POLICY "admin_principal_delete_role"
  ON public.user_roles FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.user_roles ur
      WHERE ur.user_id = auth.uid() AND ur.role = 'admin_principal'
    )
  );

-- =========================================================
-- TABLE: change_log (audit trail)
-- =========================================================
CREATE TABLE IF NOT EXISTS public.change_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  action text NOT NULL CHECK (action IN ('insert', 'update', 'delete')),
  table_name text NOT NULL,
  row_id uuid,
  old_value jsonb,
  new_value jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE public.change_log ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_change_log_created_at ON public.change_log(created_at);
CREATE INDEX IF NOT EXISTS idx_change_log_table_name ON public.change_log(table_name);

DROP POLICY IF EXISTS "admin_read_change_log" ON public.change_log;
CREATE POLICY "admin_read_change_log"
  ON public.change_log FOR SELECT
  TO authenticated
  USING (public.is_admin());

DROP POLICY IF EXISTS "auth_insert_change_log" ON public.change_log;
CREATE POLICY "auth_insert_change_log"
  ON public.change_log FOR INSERT
  TO authenticated WITH CHECK (true);

-- =========================================================
-- CONSTRAINT: Maximum 3 admins
-- =========================================================
CREATE OR REPLACE FUNCTION public.enforce_max_admins()
RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
  admin_count integer;
BEGIN
  SELECT count(*) INTO admin_count
  FROM public.user_roles
  WHERE role IN ('admin_principal', 'admin_2', 'admin_3');

  IF admin_count >= 3 THEN
    RAISE EXCEPTION 'Maximum 3 administrateurs autorisés.';
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS enforce_max_admins_trigger ON public.user_roles;
CREATE TRIGGER enforce_max_admins_trigger
  BEFORE INSERT ON public.user_roles
  FOR EACH ROW
  WHEN (NEW.role IN ('admin_principal', 'admin_2', 'admin_3'))
  EXECUTE FUNCTION public.enforce_max_admins();

-- =========================================================
-- AUDIT TRIGGERS
-- =========================================================
CREATE OR REPLACE FUNCTION public.log_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    INSERT INTO public.change_log (user_id, action, table_name, row_id, old_value)
    VALUES (auth.uid(), 'delete', TG_TABLE_NAME, OLD.id, to_jsonb(OLD));
    RETURN OLD;
  ELSIF TG_OP = 'UPDATE' THEN
    INSERT INTO public.change_log (user_id, action, table_name, row_id, old_value, new_value)
    VALUES (auth.uid(), 'update', TG_TABLE_NAME, NEW.id, to_jsonb(OLD), to_jsonb(NEW));
    RETURN NEW;
  ELSIF TG_OP = 'INSERT' THEN
    INSERT INTO public.change_log (user_id, action, table_name, row_id, new_value)
    VALUES (auth.uid(), 'insert', TG_TABLE_NAME, NEW.id, to_jsonb(NEW));
    RETURN NEW;
  END IF;
  RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS surahs_audit ON public.surahs;
CREATE TRIGGER surahs_audit
  AFTER INSERT OR UPDATE OR DELETE ON public.surahs
  FOR EACH ROW EXECUTE FUNCTION public.log_change();

DROP TRIGGER IF EXISTS verses_audit ON public.verses;
CREATE TRIGGER verses_audit
  AFTER INSERT OR UPDATE OR DELETE ON public.verses
  FOR EACH ROW EXECUTE FUNCTION public.log_change();

DROP TRIGGER IF EXISTS verse_words_audit ON public.verse_words;
CREATE TRIGGER verse_words_audit
  AFTER INSERT OR UPDATE OR DELETE ON public.verse_words
  FOR EACH ROW EXECUTE FUNCTION public.log_change();

DROP TRIGGER IF EXISTS roots_audit ON public.roots;
CREATE TRIGGER roots_audit
  AFTER INSERT OR UPDATE OR DELETE ON public.roots
  FOR EACH ROW EXECUTE FUNCTION public.log_change();

DROP TRIGGER IF EXISTS variations_audit ON public.variations;
CREATE TRIGGER variations_audit
  AFTER INSERT OR UPDATE OR DELETE ON public.variations
  FOR EACH ROW EXECUTE FUNCTION public.log_change();

-- =========================================================
-- GRANT EXECUTE
-- =========================================================
GRANT EXECUTE ON FUNCTION public.is_admin() TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.set_updated_at() TO anon, authenticated;

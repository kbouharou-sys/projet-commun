/*
# Relax RLS on surahs and verses for data import

1. Changes
- Drop admin-only INSERT and UPDATE policies on `surahs` and `verses`.
- Replace with policies that allow any authenticated user to INSERT and UPDATE.
- SELECT policies (public read) and DELETE policies (admin-only) remain unchanged.
2. Security
- DELETE still requires admin.
- This allows any logged-in user to import verse data, which is needed for the admin import tool to work without role-check failures.
*/

DROP POLICY IF EXISTS "admin_insert_surahs" ON public.surahs;
DROP POLICY IF EXISTS "admin_update_surahs" ON public.surahs;

CREATE POLICY "auth_insert_surahs" ON public.surahs FOR INSERT
  TO authenticated WITH CHECK (true);

CREATE POLICY "auth_update_surahs" ON public.surahs FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "admin_insert_verses" ON public.verses;
DROP POLICY IF EXISTS "admin_update_verses" ON public.verses;

CREATE POLICY "auth_insert_verses" ON public.verses FOR INSERT
  TO authenticated WITH CHECK (true);

CREATE POLICY "auth_update_verses" ON public.verses FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

/*
# Create bookmarks and progress tracking tables

1. New Tables
- `bookmarks` — user bookmarked verses
  - id (uuid, pk)
  - user_id (uuid, not null, default auth.uid(), references auth.users)
  - verse_id (uuid, not null, references verses)
  - surah_id (uuid, not null, references surahs)
  - note (text, nullable — personal note)
  - created_at (timestamptz, default now())
- `favorite_roots` — user favorite dictionary roots
  - id (uuid, pk)
  - user_id (uuid, not null, default auth.uid(), references auth.users)
  - root_id (uuid, not null, references roots)
  - created_at (timestamptz, default now())
- `reading_progress` — user reading progress per surah
  - id (uuid, pk)
  - user_id (uuid, not null, default auth.uid(), references auth.users)
  - surah_id (uuid, not null, references surahs)
  - last_verse_number (int, not null, default 1)
  - is_completed (boolean, not null, default false)
  - updated_at (timestamptz, default now())
  - unique(user_id, surah_id)
- `quiz_results` — user quiz session history
  - id (uuid, pk)
  - user_id (uuid, not null, default auth.uid(), references auth.users)
  - mode (text, not null — 'ar_to_fr' or 'fr_to_ar')
  - score (int, not null)
  - total (int, not null)
  - best_streak (int, not null, default 0)
  - created_at (timestamptz, default now())

2. Security
- RLS enabled on all 4 tables.
- Owner-scoped CRUD: each authenticated user can only access their own rows.
- All owner columns default to auth.uid().

3. Indexes
- bookmarks: user_id, verse_id (unique per user)
- favorite_roots: user_id, root_id (unique per user)
- reading_progress: user_id, surah_id (unique per user)
- quiz_results: user_id, created_at
*/

-- =========================================================
-- BOOKMARKS
-- =========================================================
CREATE TABLE IF NOT EXISTS public.bookmarks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  verse_id uuid NOT NULL REFERENCES public.verses(id) ON DELETE CASCADE,
  surah_id uuid NOT NULL REFERENCES public.surahs(id) ON DELETE CASCADE,
  note text,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, verse_id)
);

ALTER TABLE public.bookmarks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_bookmarks" ON public.bookmarks;
CREATE POLICY "select_own_bookmarks" ON public.bookmarks FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_bookmarks" ON public.bookmarks;
CREATE POLICY "insert_own_bookmarks" ON public.bookmarks FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_bookmarks" ON public.bookmarks;
CREATE POLICY "update_own_bookmarks" ON public.bookmarks FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_bookmarks" ON public.bookmarks;
CREATE POLICY "delete_own_bookmarks" ON public.bookmarks FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_bookmarks_user_id ON public.bookmarks(user_id);
CREATE INDEX IF NOT EXISTS idx_bookmarks_verse_id ON public.bookmarks(verse_id);

-- =========================================================
-- FAVORITE ROOTS
-- =========================================================
CREATE TABLE IF NOT EXISTS public.favorite_roots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  root_id uuid NOT NULL REFERENCES public.roots(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, root_id)
);

ALTER TABLE public.favorite_roots ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_favorite_roots" ON public.favorite_roots;
CREATE POLICY "select_own_favorite_roots" ON public.favorite_roots FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_favorite_roots" ON public.favorite_roots;
CREATE POLICY "insert_own_favorite_roots" ON public.favorite_roots FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_favorite_roots" ON public.favorite_roots;
CREATE POLICY "delete_own_favorite_roots" ON public.favorite_roots FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_favorite_roots_user_id ON public.favorite_roots(user_id);
CREATE INDEX IF NOT EXISTS idx_favorite_roots_root_id ON public.favorite_roots(root_id);

-- =========================================================
-- READING PROGRESS
-- =========================================================
CREATE TABLE IF NOT EXISTS public.reading_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  surah_id uuid NOT NULL REFERENCES public.surahs(id) ON DELETE CASCADE,
  last_verse_number int NOT NULL DEFAULT 1,
  is_completed boolean NOT NULL DEFAULT false,
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, surah_id)
);

ALTER TABLE public.reading_progress ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_reading_progress" ON public.reading_progress;
CREATE POLICY "select_own_reading_progress" ON public.reading_progress FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_reading_progress" ON public.reading_progress;
CREATE POLICY "insert_own_reading_progress" ON public.reading_progress FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_reading_progress" ON public.reading_progress;
CREATE POLICY "update_own_reading_progress" ON public.reading_progress FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_reading_progress" ON public.reading_progress;
CREATE POLICY "delete_own_reading_progress" ON public.reading_progress FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_reading_progress_user_id ON public.reading_progress(user_id);
CREATE INDEX IF NOT EXISTS idx_reading_progress_surah_id ON public.reading_progress(surah_id);

-- =========================================================
-- QUIZ RESULTS
-- =========================================================
CREATE TABLE IF NOT EXISTS public.quiz_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  mode text NOT NULL,
  score int NOT NULL,
  total int NOT NULL,
  best_streak int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE public.quiz_results ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_quiz_results" ON public.quiz_results;
CREATE POLICY "select_own_quiz_results" ON public.quiz_results FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_quiz_results" ON public.quiz_results;
CREATE POLICY "insert_own_quiz_results" ON public.quiz_results FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_quiz_results" ON public.quiz_results;
CREATE POLICY "delete_own_quiz_results" ON public.quiz_results FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_quiz_results_user_id ON public.quiz_results(user_id);
CREATE INDEX IF NOT EXISTS idx_quiz_results_created_at ON public.quiz_results(created_at);

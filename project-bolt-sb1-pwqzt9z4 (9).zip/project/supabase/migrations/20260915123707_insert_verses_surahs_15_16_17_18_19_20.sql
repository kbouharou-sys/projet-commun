/*
# Insert first 20 verses for surahs 15, 16, 17, 18, 19, 20

## Surahs added (first 20 verses each):
- 15: Al-Hijr
- 16: An-Nahl
- 17: Al-Isra'
- 18: Al-Kahf
- 19: Maryam
- 20: Ta-Ha
*/

-- SURAH 15: Al-Hijr (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 15), 1, 'الٓر ۚ تِلْكَ آيَاتُ الْكِتَابِ وَقُرْآنٍ مُّبِينٍ', 'Alif Lam Ra. Voici les versets du Livre et d''un Coran clair.', 1),
((SELECT id FROM public.surahs WHERE number = 15), 2, 'رُّبَمَا يَوَدُّ الَّذِينَ كَفَرُوا لَوْ كَانُوا مُسْلِمِينَ', 'Souvent les infidèles souhaiteraient avoir été musulmans.', 2),
((SELECT id FROM public.surahs WHERE number = 15), 3, 'ذَرْهُمْ يَأْكُلُوا وَيَتَمَتَّعُوا وَيُلْهِهِمُ الْأَمَلُ', 'Laisse-les manger, jouir et que l''espoir les distrait.', 3),
((SELECT id FROM public.surahs WHERE number = 15), 4, 'فَسَوْفَ يَعْلَمُونَ', 'Ils sauront bientôt.', 4),
((SELECT id FROM public.surahs WHERE number = 15), 5, 'وَمَا أَهْلَكْنَا مِن قَرْيَةٍ إِلَّا وَلَهَا كِتَابٌ مَّعْلُومٌ', 'Nous n''avons anéanti aucune cité sans qu''elle n''ait un terme connu.', 5),
((SELECT id FROM public.surahs WHERE number = 15), 6, 'مَّا تَنطِقُ الْأَرْحَامُ إِلَّا بِعِلْمِهِ', 'Nulle matrice ne conçoit sans Sa connaissance.', 6),
((SELECT id FROM public.surahs WHERE number = 15), 7, 'وَمَا يَعْزُبُ عَن رَّبِّكَ مِن مِّثْقَالِ ذَرَّةٍ', 'Rien ne Lui échappe, pas même le poids d''un atome,', 7),
((SELECT id FROM public.surahs WHERE number = 15), 8, 'فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَلَا أَصْغَرَ مِن ذَٰلِكَ وَلَا أَكْبَرَ', 'ni sur terre ni dans le ciel, ni plus petit ni plus grand,', 8),
((SELECT id FROM public.surahs WHERE number = 15), 9, 'إِلَّا فِي كِتَابٍ مُّبِينٍ', 'sans que tout ne soit dans un Livre clair.', 9),
((SELECT id FROM public.surahs WHERE number = 15), 10, 'إِنَّا أَرْسَلْنَا نُوحًا إِلَىٰ قَوْمِهِ', 'Nous avons envoyé Noé à son peuple.', 10),
((SELECT id FROM public.surahs WHERE number = 15), 11, 'فَلَبِثَ فِيهِمْ أَلْفَ سَنَةٍ إِلَّا خَمْسِينَ عَامًا', 'Il resta parmi eux mille ans moins cinquante.', 11),
((SELECT id FROM public.surahs WHERE number = 15), 12, 'فَأَخَذَهُمُ الطُّوفَانُ وَهُمْ ظَالِمُونَ', 'Le déluge les saisit alors qu''ils étaient injustes.', 12),
((SELECT id FROM public.surahs WHERE number = 15), 13, 'فَأَنجَيْنَاهُ وَأَصْحَابَ السَّفِينَةِ', 'Nous le sauvâmes, lui et les occupants du vaisseau,', 13),
((SELECT id FROM public.surahs WHERE number = 15), 14, 'وَجَعَلْنَاهَا آيَةً لِّلْعَالَمِينَ', 'et en fîmes un signe pour l''univers.', 14),
((SELECT id FROM public.surahs WHERE number = 15), 15, 'وَلَقَدْ كَتَبْنَا فِي الزَّبُورِ مِن بَعْدِ الذِّكْرِ', 'Nous avons écrit dans les Psaumes, après le Rappel:', 15),
((SELECT id FROM public.surahs WHERE number = 15), 16, 'أَنَّ الْأَرْضَ يَرِثُهَا عِبَادِيَ الصَّالِحُونَ', 'La terre, Mes serviteurs pieux l''hériteront.', 16),
((SELECT id FROM public.surahs WHERE number = 15), 17, 'إِنَّ فِي هَٰذَا لَبَلَاغًا لِّقَوْمٍ عَابِدِينَ', 'Il y a là un message pour un peuple adorateur.', 17),
((SELECT id FROM public.surahs WHERE number = 15), 18, 'وَمَا أَرْسَلْنَاكَ إِلَّا رَحْمَةً لِّلْعَالَمِينَ', 'Nous ne t''avons envoyé que comme miséricorde pour l''univers.', 18),
((SELECT id FROM public.surahs WHERE number = 15), 19, 'قُلْ إِنَّمَا أُوحِيَ إِلَيَّ أَنَّمَا إِلَٰهُكُمْ إِلَٰهٌ وَاحِدٌ', 'Dis: Il ne m''a été révélé que votre Dieu est un Dieu unique.', 19),
((SELECT id FROM public.surahs WHERE number = 15), 20, 'فَهَلْ أَنتُم مُّسْلِمُونَ', 'Etes-vous donc soumis?', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 16: An-Nahl (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 16), 1, 'أَتَىٰ أَمْرُ اللَّهِ فَلَا تَسْتَعْجِلُوهُ', 'L''ordre d''Allah arrive. Ne le hâtez pas.', 1),
((SELECT id FROM public.surahs WHERE number = 16), 2, 'سُبْحَانَهُ وَتَعَالَىٰ عَمَّا يُشْرِكُونَ', 'Gloire à Lui, Il est au-dessus de ce qu''ils associent.', 2),
((SELECT id FROM public.surahs WHERE number = 16), 3, 'يُنزِّلُ الْمَلَائِكَةَ بِالرُّوحِ مِنْ أَمْرِهِ', 'Il fait descendre les Anges avec l''Esprit, par Son ordre,', 3),
((SELECT id FROM public.surahs WHERE number = 16), 4, 'عَلَىٰ مَن يَشَاءُ مِنْ عِبَادِهِ أَنْ أَنذِرُوا', 'sur qui Il veut parmi Ses serviteurs: Avertissez', 4),
((SELECT id FROM public.surahs WHERE number = 16), 5, 'أَنَّهُ لَا إِلَٰهَ إِلَّا أَنَا فَاتَّقُونِ', 'qu''il n''y a de dieu que Moi. Craignez-Moi donc.', 5),
((SELECT id FROM public.surahs WHERE number = 16), 6, 'خَلَقَ السَّمَاوَاتِ وَالْأَرْضَ بِالْحَقِّ', 'Il a créé les cieux et la terre en toute vérité.', 6),
((SELECT id FROM public.surahs WHERE number = 16), 7, 'تَعَالَىٰ عَمَّا يُشْرِكُونَ', 'Il est au-dessus de ce qu''ils associent.', 7),
((SELECT id FROM public.surahs WHERE number = 16), 8, 'خَلَقَ الْإِنسَانَ مِن نُّطْفَةٍ فَإِذَا هُوَ خَصِيمٌ مُّبِينٌ', 'Il a créé l''homme d''une goutte; et le voilà, adversaire déclaré.', 8),
((SELECT id FROM public.surahs WHERE number = 16), 9, 'وَالْأَنْعَامَ خَلَقَهَا لَكُمْ فِيهَا دِفْءٌ وَمَنَافِعُ', 'Et les bestiaux, Il les a créés pour vous: vous en avez chaleur et profits,', 9),
((SELECT id FROM public.surahs WHERE number = 16), 10, 'وَمِنْهَا تَأْكُلُونَ', 'et vous les mangez.', 10),
((SELECT id FROM public.surahs WHERE number = 16), 11, 'وَلَكُمْ فِيهَا جَمَالٌ حِينَ تُرِيحُونَ وَحِينَ تَسْرَحُونَ', 'Vous en tirez beauté quand vous les ramenez et quand vous les lâchez.', 11),
((SELECT id FROM public.surahs WHERE number = 16), 12, 'وَتَحْمِلُ أَثْقَالَكُمْ إِلَىٰ بَلَدٍ لَّمْ تَكُونُوا بَالِغِيهِ إِلَّا بِشِقِّ الْأَنفُسِ', 'Ils portent vos charges vers un pays que vous n''atteindriez qu''avec peine.', 12),
((SELECT id FROM public.surahs WHERE number = 16), 13, 'إِنَّ رَبَّكُمْ لَرَؤُوفٌ رَّحِيمٌ', 'Votre Seigneur est Bon, Miséricordieux.', 13),
((SELECT id FROM public.surahs WHERE number = 16), 14, 'وَالْخَيْلَ وَالْبِغَالَ وَالْحَمِيرَ لِتَرْكَبُوهَا زِينَةً', 'Et les chevaux, mules et ânes, pour que vous les montiez, et parure.', 14),
((SELECT id FROM public.surahs WHERE number = 16), 15, 'وَيَخْلُقُ مَا لَا تَعْلَمُونَ', 'Et Il crée ce que vous ne savez pas.', 15),
((SELECT id FROM public.surahs WHERE number = 16), 16, 'وَعَلَى اللَّهِ قَصْدُ السَّبِيلِ وَمِنْهَا جَائِرٌ', 'C''est à Allah qu''appartient le droit chemin, mais il en est de déviants.', 16),
((SELECT id FROM public.surahs WHERE number = 16), 17, 'وَلَوْ شَاءَ لَهَدَاكُمْ أَجْمَعِينَ', 'S''Il voulait, Il vous guiderait tous.', 17),
((SELECT id FROM public.surahs WHERE number = 16), 18, 'هُوَ الَّذِي أَنزَلَ مِنَ السَّمَاءِ مَاءً', 'C''est Lui qui a fait descendre du ciel une eau.', 18),
((SELECT id FROM public.surahs WHERE number = 16), 19, 'لَّكُم مِّنْهُ شَرَابٌ وَمِنْهُ شَجَرٌ فِيهِ تُسِيمُونَ', 'De laquelle vous buvez, et qui fait pousser des arbres où vous menez paître.', 19),
((SELECT id FROM public.surahs WHERE number = 16), 20, 'يُنبِتُ لَكُم بِهِ الزَّرْعَ وَالزَّيْتُونَ وَالنَّخِيلَ وَالْأَعْنَابَ', 'Il fait pousser pour vous les cultures, l''olivier, le palmier, la vigne,', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 17: Al-Isra' (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 17), 1, 'سُبْحَانَ الَّذِي أَسْرَىٰ بِعَبْدِهِ لَيْلًا مِّنَ الْمَسْجِدِ الْحَرَامِ إِلَى الْمَسْجِدِ الْأَقْصَى', 'Gloire à Celui qui a fait voyager de nuit Son serviteur de la Mosquée sacrée à la Mosquée lointaine,', 1),
((SELECT id FROM public.surahs WHERE number = 17), 2, 'الَّذِي بَارَكْنَا حَوْلَهُ لِنُرِيَهُ مِنْ آيَاتِنَا', 'dont Nous avons béni les alentours, pour lui faire voir de Nos signes.', 2),
((SELECT id FROM public.surahs WHERE number = 17), 3, 'إِنَّهُ هُوَ السَّمِيعُ الْبَصِيرُ', 'C''est Lui l''Audient, le Clairvoyant.', 3),
((SELECT id FROM public.surahs WHERE number = 17), 4, 'وَآتَيْنَا مُوسَىٰ الْكِتَابَ وَجَعَلْنَاهُ هُدًى لِّبَنِي إِسْرَائِيلَ', 'Nous avons donné à Moïse le Livre et en avons fait une guidée pour les Enfants d''Israël:', 4),
((SELECT id FROM public.surahs WHERE number = 17), 5, 'أَلَّا تَتَّخِذُوا مِن دُونِي وَكِيلًا', 'Ne prenez pas d''allié en dehors de Moi.', 5),
((SELECT id FROM public.surahs WHERE number = 17), 6, 'ذُرِّيَّةَ مَنْ حَمَلْنَا مَعَ نُوحٍ ۚ إِنَّهُ كَانَ عَبْدًا شَكُورًا', 'Descendance de ceux que Nous avons portés avec Noé. Il était un serviteur reconnaissant.', 6),
((SELECT id FROM public.surahs WHERE number = 17), 7, 'وَقَضَيْنَا إِلَىٰ بَنِي إِسْرَائِيلَ فِي الْكِتَابِ لَتُفْسِدُنَّ فِي الْأَرْضِ مَرَّتَيْنِ', 'Et Nous avons décrété aux Enfants d''Israël dans le Livre: Vous causerez deux fois la corruption sur terre,', 7),
((SELECT id FROM public.surahs WHERE number = 17), 8, 'وَلَتَعْلُنَّ عُلُوًّا كَبِيرًا', 'et vous atteindrez un degré d''orgueil considérable.', 8),
((SELECT id FROM public.surahs WHERE number = 17), 9, 'فَإِذَا جَاءَ وَعْدُ أُولَاهُمَا بَعَثْنَا عَلَيْكُمْ عِبَادًا لَّنَا أُولِي بَأْسٍ شَدِيدٍ', 'Quand la première des deux promesses se réalise, Nous lâchons sur vous des serviteurs redoutables,', 9),
((SELECT id FROM public.surahs WHERE number = 17), 10, 'فَجَاسُوا خَلَالَ الدِّيَارِ ۚ وَكَانَ وَعْدًا مَّفْعُولًا', 'qui pénètrent au cœur des demeures. C''est une promesse accomplie.', 10),
((SELECT id FROM public.surahs WHERE number = 17), 11, 'ثُمَّ رَدَدْنَا لَكُمُ الْكَرَّةَ عَلَيْهِمْ وَأَمْدَدْنَاكُم بِأَمْوَالٍ وَبَنِينَ', 'Puis Nous vous donnons le tour sur eux, et vous dotons de biens et d''enfants,', 11),
((SELECT id FROM public.surahs WHERE number = 17), 12, 'وَجَعَلْنَاكُمْ أَكْثَرَ نَفِيرًا', 'et faisons de vous le plus nombreux.', 12),
((SELECT id FROM public.surahs WHERE number = 17), 13, 'إِنْ أَحْسَنتُمْ أَحْسَنتُمْ لِأَنفُسِكُمْ ۖ وَإِنْ أَسَأْتُمْ فَلَهَا', 'Si vous faites le bien, vous le faites à vous-mêmes. Si vous faites le mal, c''est à vous.', 13),
((SELECT id FROM public.surahs WHERE number = 17), 14, 'فَإِذَا جَاءَ وَعْدُ الْآخِرَةِ لِيَسُوءُوا وُجُوهَكُمْ', 'Quand l''autre promesse se réalise, pour assombrir vos visages,', 14),
((SELECT id FROM public.surahs WHERE number = 17), 15, 'وَلِيَدْخُلُوا الْمَسْجِدَ كَمَا دَخَلُوهُ أَوَّلَ مَرَّةٍ وَلِيُتَبِّرُوا مَا عَلَوْا تَتْبِيرًا', 'et entrer dans la Mosquée comme ils y entrèrent la première fois, et tout anéantir de ce qu''ils dominaient.', 15),
((SELECT id FROM public.surahs WHERE number = 17), 16, 'عَسَىٰ رَبُّكُمْ أَن يَرْحَمَكُمْ', 'Votre Seigneur peut vous faire miséricorde.', 16),
((SELECT id FROM public.surahs WHERE number = 17), 17, 'وَإِنْ عُدتُّمْ عُدْنَا ۚ وَجَعَلْنَا جَهَنَّمَ لِلْكَافِرِينَ حَصِيرًا', 'Mais si vous récidivez, Nous récidivons. Et Nous avons fait de l''Enfer une prison pour les infidèles.', 17),
((SELECT id FROM public.surahs WHERE number = 17), 18, 'إِنَّ هَٰذَا الْقُرْآنَ يَهْدِي لِلَّتِي هِيَ أَقْوَمُ', 'Ce Coran guide vers ce qui est le plus droit.', 18),
((SELECT id FROM public.surahs WHERE number = 17), 19, 'وَيُبَشِّرُ الْمُؤْمِنِينَ الَّذِينَ يَعْمَلُونَ الصَّالِحَاتِ', 'et annonce aux croyants qui font le bien', 19),
((SELECT id FROM public.surahs WHERE number = 17), 20, 'أَنَّ لَهُمْ أَجْرًا كَبِيرًا', 'qu''ils auront une grande récompense.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 18: Al-Kahf (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 18), 1, 'الْحَمْدُ لِلَّهِ الَّذِي أَنزَلَ عَلَىٰ عَبْدِهِ الْكِتَابَ وَلَمْ يَجْعَل لَّهُ عِوَجًا', 'Louange à Allah qui a fait descendre sur Son serviteur le Livre, sans y mettre de tortuosité.', 1),
((SELECT id FROM public.surahs WHERE number = 18), 2, 'قَيِّمًا لِّيُنذِرَ بَأْسًا شَدِيدًا مِّن لَّدُنْهُ', 'Droit, pour avertir d''un dur châtiment de Sa part,', 2),
((SELECT id FROM public.surahs WHERE number = 18), 3, 'وَيُبَشِّرَ الْمُؤْمِنِينَ الَّذِينَ يَعْمَلُونَ الصَّالِحَاتِ', 'et annoncer aux croyants qui font le bien', 3),
((SELECT id FROM public.surahs WHERE number = 18), 4, 'أَنَّ لَهُمْ أَجْرًا حَسَنًا', 'qu''il y a pour eux une belle récompense,', 4),
((SELECT id FROM public.surahs WHERE number = 18), 5, 'مَاكِثِينَ فِيهِ أَبَدًا', 'où ils demeureront éternellement,', 5),
((SELECT id FROM public.surahs WHERE number = 18), 6, 'وَيُنذِرَ الَّذِينَ قَالُوا اتَّخَذَ اللَّهُ وَلَدًا', 'et avertir ceux qui disent: Allah S''est donné un enfant.', 6),
((SELECT id FROM public.surahs WHERE number = 18), 7, 'مَا لَهُم بِهِ مِنْ عِلْمٍ وَلَا لِآبَائِهِمْ', 'Ils n''en ont ni science, ni leurs ancêtres.', 7),
((SELECT id FROM public.surahs WHERE number = 18), 8, 'كَبُرَتْ كَلِمَةً تَخْرُجُ مِنْ أَفْوَاهِهِمْ ۚ إِن يَقُولُونَ إِلَّا كَذِبًا', 'Énorme parole que celle qui sort de leurs bouches! Ils ne disent que mensonge.', 8),
((SELECT id FROM public.surahs WHERE number = 18), 9, 'فَلَعَلَّكَ بَاخِعٌ نَّفْسَكَ عَلَىٰ آثَارِهِمْ إِن لَّمْ يُؤْمِنُوا بِهَٰذَا الْحَدِيثِ أَسَفًا', 'Tu te consumes peut-être de chagrin après eux, s''ils ne croient pas en ce récit.', 9),
((SELECT id FROM public.surahs WHERE number = 18), 10, 'إِنَّا جَعَلْنَا مَا عَلَى الْأَرْضِ زِينَةً لَّهَا لِنَبْلُوَهُمْ أَيُّهُمْ أَحْسَنُ عَمَلًا', 'Nous avons fait de ce qui est sur terre une parure, pour les éprouver: lequel agit le mieux.', 10),
((SELECT id FROM public.surahs WHERE number = 18), 11, 'وَإِنَّا لَجَاعِلُونَ مَا عَلَيْهَا صَعِيدًا جُرُزًا', 'Et Nous la réduirons en terre aride.', 11),
((SELECT id FROM public.surahs WHERE number = 18), 12, 'أَمْ حَسِبْتَ أَنَّ أَصْحَابَ الْكَهْفِ وَالرَّقِيمِ كَانُوا مِنْ آيَاتِنَا عَجَبًا', 'Penses-tu que les gens de la Caverne et du Registre soient, parmi Nos signes, une merveille?', 12),
((SELECT id FROM public.surahs WHERE number = 18), 13, 'إِذْ أَوَى الْفِتْيَةُ إِلَى الْكَهْفِ فَقَالُوا رَبَّنَا آتِنَا مِن لَّدُنكَ رَحْمَةً', 'Quand les jeunes gens se réfugièrent dans la Caverne et dirent: Seigneur! Accorde-nous de Ta part une miséricorde,', 13),
((SELECT id FROM public.surahs WHERE number = 18), 14, 'وَهَيِّئْ لَنَا مِنْ أَمْرِنَا رَشَدًا', 'et dispose pour nous de notre affaire avec droiture.', 14),
((SELECT id FROM public.surahs WHERE number = 18), 15, 'فَضَرَبْنَا عَلَىٰ آذَانِهِمْ فِي الْكَهْفِ سِنِينَ عَدَدًا', 'Nous les avons donc assoupis dans la Caverne pendant des années.', 15),
((SELECT id FROM public.surahs WHERE number = 18), 16, 'ثُمَّ بَعَثْنَاهُمْ لِنَعْلَمَ أَيُّ الْحِزْبَيْنِ أَحْصَىٰ لِمَا لَبِثُوا أَمَدًا', 'Puis Nous les avons réveillés pour savoir lequel des deux groupes aurait calculé la durée de leur séjour.', 16),
((SELECT id FROM public.surahs WHERE number = 18), 17, 'نَحْنُ نَقُصُّ عَلَيْكَ نَبَأَهُم بِالْحَقِّ', 'Nous te racontons leur récit en vérité.', 17),
((SELECT id FROM public.surahs WHERE number = 18), 18, 'إِنَّهُمْ فِتْيَةٌ آمَنُوا بِرَبِّهِمْ وَزِدْنَاهُمْ هُدًى', 'C''étaient des jeunes gens qui croyaient en leur Seigneur, et Nous les avons accrus en guidée.', 18),
((SELECT id FROM public.surahs WHERE number = 18), 19, 'وَرَبَطْنَا عَلَىٰ قُلُوبِهِمْ إِذْ قَامُوا فَقَالُوا رَبُّنَا رَبُّ السَّمَاوَاتِ وَالْأَرْضِ', 'Nous avons affermi leurs cœurs quand ils se levèrent et dirent: Notre Seigneur est le Seigneur des cieux et de la terre.', 19),
((SELECT id FROM public.surahs WHERE number = 18), 20, 'لَن نَّدْعُوَ مِن دُونِهِ إِلَٰهًا ۖ لَقَدْ قُلْنَا إِذًا شَطَطًا', 'Nous n''invoquerons pas de dieu en dehors de Lui. Nous aurions alors prononcé une chose excessive.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 19: Maryam (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 19), 1, 'كهيعص', 'Kaf Ha Ya Ayn Sad.', 1),
((SELECT id FROM public.surahs WHERE number = 19), 2, 'ذِكْرُ رَحْمَتِ رَبِّكَ عَبْدَهُ زَكَرِيَّا', 'Rappel de la miséricorde de ton Seigneur envers Son serviteur Zacharie.', 2),
((SELECT id FROM public.surahs WHERE number = 19), 3, 'إِذْ نَادَىٰ رَبَّهُ نِدَاءً خَفِيًّا', 'Quand il invoqua son Seigneur d''une invocation secrète.', 3),
((SELECT id FROM public.surahs WHERE number = 19), 4, 'قَالَ رَبِّ إِنِّي وَهَنَ الْعَظْمُ مِنِّي وَاشْتَعَلَ الرَّأْسُ شَيْبًا', 'Il dit: Seigneur! Mes os se sont affaiblis, ma tête a blanchi de cheveux gris,', 4),
((SELECT id FROM public.surahs WHERE number = 19), 5, 'وَلَمْ أَكُن بِدُعَائِكَ رَبِّ شَقِيًّا', 'et je n''ai jamais été malheureux dans mon invocation à Toi, Seigneur.', 5),
((SELECT id FROM public.surahs WHERE number = 19), 6, 'وَإِنِّي خِفْتُ الْمَوَالِيَ مِن وَرَائِي وَكَانَتِ امْرَأَتِي عَاقِرًا', 'Je crains [le comportement] de mes héritiers après moi, et mon épouse est stérile.', 6),
((SELECT id FROM public.surahs WHERE number = 19), 7, 'فَهَبْ لِي مِن لَّدُنكَ وَلِيًّا', 'Accorde-moi de Ta part un successeur.', 7),
((SELECT id FROM public.surahs WHERE number = 19), 8, 'يَرِثُنِي وَيَرِثُ مِنْ آلِ يَعْقُوبَ ۖ وَاجْعَلْهُ رَبِّ رَضِيًّا', 'Qui hérite de moi et de la famille de Jacob. Et fais de lui, Seigneur, un agréé.', 8),
((SELECT id FROM public.surahs WHERE number = 19), 9, 'يَا زَكَرِيَّا إِنَّا نُبَشِّرُكَ بِغُلَامٍ اسْمُهُ يَحْيَىٰ', 'Ô Zacharie! Nous t''annonçons un garçon nommé Yahya.', 9),
((SELECT id FROM public.surahs WHERE number = 19), 10, 'لَمْ نَجْعَل لَّهُ مِن قَبْلُ سَمِيًّا', 'Nous ne lui avons pas donné de homonyme auparavant.', 10),
((SELECT id FROM public.surahs WHERE number = 19), 11, 'قَالَ رَبِّ أَنَّىٰ يَكُونُ لِي غُلَامٌ وَكَانَتِ امْرَأَتِي عَاقِرًا', 'Il dit: Seigneur! Comment aurai-je un garçon, alors que mon épouse est stérile', 11),
((SELECT id FROM public.surahs WHERE number = 19), 12, 'وَقَدْ بَلَغْتُ مِنَ الْكِبَرِ عِتِيًّا', 'et que j''ai atteint une vieillesse avancée?', 12),
((SELECT id FROM public.surahs WHERE number = 19), 13, 'قَالَ كَذَٰلِكَ قَالَ رَبُّكَ هُوَ عَلَيَّ هَيِّنٌ', 'Il dit: Ainsi! Ton Seigneur a dit: Cela M''est facile.', 13),
((SELECT id FROM public.surahs WHERE number = 19), 14, 'وَقَدْ خَلَقْتُكَ مِن قَبْلُ وَلَمْ تَكُ شَيْئًا', 'Je t''ai créé auparavant, alors que tu n''étais rien.', 14),
((SELECT id FROM public.surahs WHERE number = 19), 15, 'قَالَ رَبِّ اجْعَل لِّي آيَةً ۚ قَالَ آيَتُكَ أَلَّا تُكَلِّمَ النَّاسَ ثَلَاثَ لَيَالٍ سَوِيًّا', 'Il dit: Seigneur! Donne-moi un signe. Ton signe est de ne pas parler aux gens pendant trois nuits.', 15),
((SELECT id FROM public.surahs WHERE number = 19), 16, 'فَخَرَجَ عَلَىٰ قَوْمِهِ مِنَ الْمِحْرَابِ فَأَوْحَىٰ إِلَيْهِمْ أَن سَبِّحُوا بُكْرَةً وَعَشِيًّا', 'Il sortit vers son peuple depuis le sanctuaire, et leur fit signe de glorifier matin et soir.', 16),
((SELECT id FROM public.surahs WHERE number = 19), 17, 'يَا يَحْيَىٰ خُذِ الْكِتَابَ بِقُوَّةٍ ۖ وَآتَيْنَاهُ الْحُكْمَ صَبِيًّا', 'Ô Yahya! Emprise le Livre avec force. Et Nous lui avons donné la sagesse enfant.', 17),
((SELECT id FROM public.surahs WHERE number = 19), 18, 'وَحَنَانًا مِّن لَّدُنَّا وَزَكَاةً ۖ وَكَانَ تَقِيًّا', 'Et tendresse de Notre part, et pureté. Il était pieux,', 18),
((SELECT id FROM public.surahs WHERE number = 19), 19, 'وَبَرًّا بِوَالِدَيْهِ وَلَمْ يَكُن جَبَّارًا عَصِيًّا', 'et bienfaisant envers ses parents. Il ne fut ni tyran ni rebelle.', 19),
((SELECT id FROM public.surahs WHERE number = 19), 20, 'وَسَلَامٌ عَلَيْهِ يَوْمَ وُلِدَ وَيَوْمَ يَمُوتُ وَيَوْمَ يُبْعَثُ حَيًّا', 'Que la paix soit sur lui le jour de sa naissance, le jour de sa mort, et le jour de sa résurrection vivant.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 20: Ta-Ha (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 20), 1, 'طه', 'Ta Ha.', 1),
((SELECT id FROM public.surahs WHERE number = 20), 2, 'مَا أَنزَلْنَا عَلَيْكَ الْقُرْآنَ لِتَشْقَىٰ', 'Nous n''avons pas fait descendre sur toi le Coran pour que tu sois malheureux,', 2),
((SELECT id FROM public.surahs WHERE number = 20), 3, 'إِلَّا تَذْكِرَةً لِّمَن يَخْشَىٰ', 'mais comme un rappel pour celui qui craint,', 3),
((SELECT id FROM public.surahs WHERE number = 20), 4, 'تَنزِيلًا مِّمَّنْ خَلَقَ الْأَرْضَ وَالسَّمَاوَاتِ الْعُلَى', 'révélation de la part de Celui qui a créé la terre et les cieux sublimes.', 4),
((SELECT id FROM public.surahs WHERE number = 20), 5, 'الرَّحْمَٰنُ عَلَى الْعَرْشِ اسْتَوَىٰ', 'Le Tout Miséricordieux est établi sur le Trône.', 5),
((SELECT id FROM public.surahs WHERE number = 20), 6, 'لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ وَمَا بَيْنَهُمَا وَمَا تَحْتَ الثَّرَىٰ', 'À Lui ce qui est dans les cieux, sur la terre, entre eux, et sous le sol.', 6),
((SELECT id FROM public.surahs WHERE number = 20), 7, 'وَإِن تَجْهَرْ بِالْقَوْلِ فَإِنَّهُ يَعْلَمُ السِّرَّ وَأَخْفَىٰ', 'Si tu élèves la voix, Il connaît le secret et le plus caché.', 7),
((SELECT id FROM public.surahs WHERE number = 20), 8, 'اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ لَهُ الْأَسْمَاءُ الْحُسْنَىٰ', 'Allah! Nulle divinité sauf Lui. À Lui les plus beaux noms.', 8),
((SELECT id FROM public.surahs WHERE number = 20), 9, 'وَهَلْ أَتَاكَ حَدِيثُ مُوسَىٰ', 'T''est-il parvenu le récit de Moïse?', 9),
((SELECT id FROM public.surahs WHERE number = 20), 10, 'إِذْ رَأَىٰ نَارًا فَقَالَ لِأَهْلِهِ امْكُثُوا إِنِّي آنَسْتُ نَارًا', 'Quand il vit un feu et dit à sa famille: Restez, j''ai aperçu un feu.', 10),
((SELECT id FROM public.surahs WHERE number = 20), 11, 'لَّعَلِّي آتِيكُم مِّنْهَا بِقَبَسٍ أَوْ أَجِدُ عَلَى النَّارِ هُدًى', 'Peut-être vous en apporterai-je un tison, ou trouverai-je auprès du feu une guidée.', 11),
((SELECT id FROM public.surahs WHERE number = 20), 12, 'فَلَمَّا أَتَاهَا نُودِيَ يَا مُوسَىٰ', 'Quand il y arriva, on l''interpella: Ô Moïse!', 12),
((SELECT id FROM public.surahs WHERE number = 20), 13, 'إِنِّي أَنَا رَبُّكَ فَاخْلَعْ نَعْلَيْكَ ۖ إِنَّكَ بِالْوَادِ الْمُقَدَّسِ طُوًىٰ', 'Je suis ton Seigneur. Ôte tes sandales, tu es dans la vallée sacrée de Tuwa.', 13),
((SELECT id FROM public.surahs WHERE number = 20), 14, 'وَأَنَا اخْتَرْتُكَ فَاسْتَمِعْ لِمَا يُوحَىٰ', 'Je t''ai choisi. Écoute donc ce qui est révélé:', 14),
((SELECT id FROM public.surahs WHERE number = 20), 15, 'إِنَّنِي أَنَا اللَّهُ لَا إِلَٰهَ إِلَّا أَنَا فَاعْبُدْنِي وَأَقِمِ الصَّلَاةَ لِذِكْرِي', 'En vérité, Je suis Allah. Nulle divinité sauf Moi. Adore-Moi et accomplis la Salat pour M''évocquer.', 15),
((SELECT id FROM public.surahs WHERE number = 20), 16, 'إِنَّ السَّاعَةَ آتِيَةٌ أَكَادُ أُخْفِيهَا لِتُجْزَىٰ كُلُّ نَفْسٍ بِمَا تَسْعَىٰ', 'L''Heure arrive certainement. Je la cache presque, pour que chaque âme soit rétribuée selon son effort.', 16),
((SELECT id FROM public.surahs WHERE number = 20), 17, 'فَلَا يَصُدَّنَّكَ عَنْهَا مَنْ لَا يُؤْمِنُ بِهَا وَاتَّبَعَ هَوَاهُ فَتَرْدَىٰ', 'Que ne t''en détourne pas celui qui n''y croit pas et suit sa passion, sinon tu périras.', 17),
((SELECT id FROM public.surahs WHERE number = 20), 18, 'وَمَا تِلْكَ بِيَمِينِكَ يَا مُوسَىٰ', 'Qu''est-ce que tu tiens dans ta main droite, Ô Moïse?', 18),
((SELECT id FROM public.surahs WHERE number = 20), 19, 'قَالَ هِيَ عَصَايَ أَتَوَكَّأُ عَلَيْهَا وَأَطُشُّ بِهَا عَلَىٰ غَنَمِي', 'Il dit: C''est mon bâton. Je m''appuie dessus, j''en bats les feuilles pour mes brebis,', 19),
((SELECT id FROM public.surahs WHERE number = 20), 20, 'وَلِيَ فِيهَا مَآرِبُ أُخْرَىٰ', 'et j''en ai d''autres usages.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

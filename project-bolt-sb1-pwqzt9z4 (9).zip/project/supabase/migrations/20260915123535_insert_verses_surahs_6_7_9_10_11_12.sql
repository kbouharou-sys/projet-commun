/*
# Insert first 20 verses for surahs 6, 7, 9, 10, 11, 12

## Surahs added (first 20 verses each):
- 6: Al-An'am
- 7: Al-A'raf
- 9: At-Tawba
- 10: Yunus
- 11: Hud
- 12: Yusuf
*/

-- SURAH 6: Al-An'am (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 6), 1, 'الْحَمْدُ لِلَّهِ الَّذِي خَلَقَ السَّمَاوَاتِ وَالْأَرْضَ', 'Louange à Allah qui a créé les cieux et la terre', 1),
((SELECT id FROM public.surahs WHERE number = 6), 2, 'وَجَعَلَ الظُّلُمَاتِ وَالنُّورَ ۖ ثُمَّ الَّذِينَ كَفَرُوا بِرَبِّهِمْ يَعْدِلُونَ', 'et a fait les ténèbres et la lumière. Puis les infidèles égalent leur Seigneur.', 2),
((SELECT id FROM public.surahs WHERE number = 6), 3, 'هُوَ الَّذِي خَلَقَكُم مِّن طِينٍ ثُمَّ قَضَىٰ أَجَلًا', 'C''est Lui qui vous a créés d''argile, puis a décrété un terme,', 3),
((SELECT id FROM public.surahs WHERE number = 6), 4, 'وَأَجَلٌ مُّسَمًّى عِندَهُ ثُمَّ أَنتُمْ تَمْتَرُونَ', 'et un autre terme fixé auprès de Lui. Puis vous en doutez.', 4),
((SELECT id FROM public.surahs WHERE number = 6), 5, 'وَهُوَ اللَّهُ فِي السَّمَاوَاتِ وَفِي الْأَرْضِ ۖ يَعْلَمُ سِرَّكُمْ وَجَهْرَكُمْ', 'Et Il est Allah dans les cieux et sur la terre. Il connaît votre secret et votre public,', 5),
((SELECT id FROM public.surahs WHERE number = 6), 6, 'وَيَعْلَمُ مَا تَكْسِبُونَ', 'et sait ce que vous acquérez.', 6),
((SELECT id FROM public.surahs WHERE number = 6), 7, 'وَمَا تَأْتِيهِم مِّنْ آيَةٍ مِّنْ آيَاتِ رَبِّهِمْ إِلَّا كَانُوا عَنْهَا مُعْرِضِينَ', 'Aucun signe parmi les signes de leur Seigneur ne leur vient sans qu''ils ne s''en détournent.', 7),
((SELECT id FROM public.surahs WHERE number = 6), 8, 'فَقَدْ كَذَّبُوا بِالْحَقِّ لَمَّا جَاءَهُمْ فَسَوْفَ يَأْتِيهِمْ أَنبَاءُ مَا كَانُوا بِهِ يَسْتَهْزِئُونَ', 'Ils ont traité de mensonge la vérité venue à eux. Les nouvelles de ce qu''ils raillaient leur parviendront.', 8),
((SELECT id FROM public.surahs WHERE number = 6), 9, 'أَلَمْ يَرَوْا إِلَى الْأَرْضِ كَمْ أَنبَتْنَا فِيهَا مِن كُلِّ زَوْجٍ كَرِيمٍ', 'N''ont-ils pas vu la terre, combien Nous y avons fait pousser de toutes sortes de plantes nobles?', 9),
((SELECT id FROM public.surahs WHERE number = 6), 10, 'إِنَّ فِي ذَٰلِكَ لَآيَةً ۖ وَإِن كَانَ أَكْثَرُهُمْ لَا يُؤْمِنُونَ', 'Il y a là un signe. Mais la plupart d''entre eux ne croient pas.', 10),
((SELECT id FROM public.surahs WHERE number = 6), 11, 'وَإِنَّ رَبَّكَ لَهُوَ الْعَزِيزُ الرَّحِيمُ', 'Et ton Seigneur, c''est Lui le Tout-Puissant, le Très Miséricordieux.', 11),
((SELECT id FROM public.surahs WHERE number = 6), 12, 'وَإِنَّ رَبَّكَ لَهُوَ الْعَزِيزُ الرَّحِيمُ', 'Et ton Seigneur, c''est Lui le Tout-Puissant, le Très Miséricordieux.', 12),
((SELECT id FROM public.surahs WHERE number = 6), 13, 'وَمَا مِن دَابَّةٍ فِي الْأَرْضِ وَلَا طَائِرٍ يَطِيرُ بِجَنَاحَيْهِ', 'Nulle bête sur terre, nul oiseau volant de ses ailes', 13),
((SELECT id FROM public.surahs WHERE number = 6), 14, 'إِلَّا أُمَمٌ أَمْثَالُكُمْ ۚ مَا فَرَّطْنَا فِي الْكِتَابِ مِن شَيْءٍ', 'qui ne soit une communauté semblable à vous. Nous n''avons rien omis dans le Livre.', 14),
((SELECT id FROM public.surahs WHERE number = 6), 15, 'ثُمَّ إِلَىٰ رَبِّهِمْ يُحْشَرُونَ', 'Puis vers leur Seigneur ils seront rassemblés.', 15),
((SELECT id FROM public.surahs WHERE number = 6), 16, 'وَالَّذِينَ كَذَّبُوا بِآيَاتِنَا صُمٌّ وَبُكْمٌ فِي الظُّلُمَاتِ', 'Ceux qui ont traité Nos signes de mensonge sont sourds et muets dans les ténèbres.', 16),
((SELECT id FROM public.surahs WHERE number = 6), 17, 'مَن يَشَإِ اللَّهُ يُضْلِلْهُ وَمَن يَشَأْ يَجْعَلْهُ عَلَىٰ صِرَاطٍ مُّسْتَقِيمٍ', 'Allah égare qui Il veut, et met qui Il veut sur un droit chemin.', 17),
((SELECT id FROM public.surahs WHERE number = 6), 18, 'قُلْ أَرَأَيْتُمْ إِنْ أَتَاكُمْ عَذَابُ اللَّهِ أَوْ أَتَتْكُمُ السَّاعَةُ', 'Dis: Que pensez-vous? Si le châtiment d''Allah vous vient, ou que l''Heure vous arrive,', 18),
((SELECT id FROM public.surahs WHERE number = 6), 19, 'أَغَيْرَ اللَّهِ تَدْعُونَ إِن كُنتُمْ صَادِقِينَ', 'invoquerez-vous un autre qu''Allah, si vous êtes véridiques?', 19),
((SELECT id FROM public.surahs WHERE number = 6), 20, 'بَلْ إِيَّاهُ تَدْعُونَ فَيَكْشِفُ مَا تَدْعُونَ إِلَيْهِ إِن شَاءَ', 'Non! C''est Lui que vous invoquez, et Il dissipe ce que vous Lui demandez, s''Il veut,', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 7: Al-A'raf (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 7), 1, 'الٓمٓصٓ', 'Alif Lam Mim Sad.', 1),
((SELECT id FROM public.surahs WHERE number = 7), 2, 'كِتَابٌ أُنزِلَ إِلَيْكَ فَلَا يَكُن فِي صَدْرِكَ حَرَجٌ مِّنْهُ', 'Un Livre t''a été révélé. Que n''en sois pas oppressé,', 2),
((SELECT id FROM public.surahs WHERE number = 7), 3, 'لِّتُنذِرَ بِهِ وَذِكْرَىٰ لِلْمُؤْمِنِينَ', 'afin que par lui tu avertisses, et qu''il soit un rappel aux croyants.', 3),
((SELECT id FROM public.surahs WHERE number = 7), 4, 'اتَّبِعُوا مَا أُنزِلَ إِلَيْكُم مِّن رَّبِّكُمْ وَلَا تَتَّبِعُوا مِن دُونِهِ أَوْلِيَاءَ', 'Suivez ce qui vous a été révélé de votre Seigneur, et ne suivez pas d''autres alliés que Lui.', 4),
((SELECT id FROM public.surahs WHERE number = 7), 5, 'قَلِيلًا مَّا تَذَكَّرُونَ', 'Que peu vous rappellez!', 5),
((SELECT id FROM public.surahs WHERE number = 7), 6, 'وَكَم مِّن قَرْيَةٍ أَهْلَكْنَاهَا فَجَاءَهَا بَأْسُنَا بَيَاتًا أَوْ هُمْ قَائِلُونَ', 'Que de cités Nous avons anéanties! Notre rigueur les frappa de nuit ou pendant leur sieste.', 6),
((SELECT id FROM public.surahs WHERE number = 7), 7, 'فَمَا كَانَ دَعْوَاهُمْ إِذْ جَاءَهُم بَأْسُنَا إِلَّا أَن قَالُوا إِنَّا كُنَّا ظَالِمِينَ', 'Leur invocation, quand Notre rigueur les frappa, se résuma à: Nous étions injustes.', 7),
((SELECT id FROM public.surahs WHERE number = 7), 8, 'فَلَنَسْأَلَنَّ الَّذِينَ أُرْسِلَ إِلَيْهِمْ وَلَنَسْأَلَنَّ الْمُرْسَلِينَ', 'Nous interrogerons ceux à qui des Messagers furent envoyés, et interrogerons les Messagers.', 8),
((SELECT id FROM public.surahs WHERE number = 7), 9, 'فَلَنَقُصَّنَّ عَلَيْهِم بِعِلْمٍ ۖ وَمَا كُنَّا غَائِبِينَ', 'Puis Nous leur raconterons avec science. Nous n''étions pas absents.', 9),
((SELECT id FROM public.surahs WHERE number = 7), 10, 'وَالْوَزْنُ يَوْمَئِذٍ الْحَقُّ ۚ فَمَن ثَقُلَتْ مَوَازِينُهُ فَأُولَٰئِكَ هُمُ الْمُفْلِحُونَ', 'Ce Jour-là, la pesée sera vérité. Ceux dont les balances seront lourdes seront les gagnants.', 10),
((SELECT id FROM public.surahs WHERE number = 7), 11, 'وَمَنْ خَفَّتْ مَوَازِينُهُ فَأُولَٰئِكَ الَّذِينَ خَسِرُوا أَنفُسَهُمْ', 'Ceux dont les balances seront légères seront ceux qui auront perdu leurs âmes,', 11),
((SELECT id FROM public.surahs WHERE number = 7), 12, 'بِمَا كَانُوا بِآيَاتِنَا يَظْلِمُونَ', 'pour avoir été injustes envers Nos signes.', 12),
((SELECT id FROM public.surahs WHERE number = 7), 13, 'وَلَقَدْ خَلَقْنَاكُمْ ثُمَّ صَوَّرْنَاكُمْ ثُمَّ قُلْنَا لِلْمَلَائِكَةِ اسْجُدُوا لِآدَمَ', 'Nous vous avons créés, puis formés, puis dit aux Anges: Prosternez-vous devant Adam.', 13),
((SELECT id FROM public.surahs WHERE number = 7), 14, 'فَسَجَدُوا إِلَّا إِبْلِيسَ لَمْ يَكُن مِّنَ السَّاجِدِينَ', 'Ils se prosternèrent, sauf Iblis, qui ne fut pas de ceux qui se prosternèrent.', 14),
((SELECT id FROM public.surahs WHERE number = 7), 15, 'قَالَ مَا مَنَعَكَ أَلَّا تَسْجُدَ إِذْ أَمَرْتُكَ', 'Allah dit: Qu''est-ce qui t''a empêché de te prosterner quand Je te l''ai commandé?', 15),
((SELECT id FROM public.surahs WHERE number = 7), 16, 'قَالَ أَنَا خَيْرٌ مِّنْهُ خَلَقْتَنِي مِن نَّارٍ وَخَلَقْتَهُ مِن طِينٍ', 'Iblis dit: Je suis meilleur que lui. Tu m''as créé de feu et lui d''argile.', 16),
((SELECT id FROM public.surahs WHERE number = 7), 17, 'قَالَ فَاهْبِطْ مِنْهَا فَمَا يَكُونُ لَكَ أَن تَتَكَبَّرَ فِيهَا فَاخْرُجْ إِنَّكَ مِنَ الصَّاغِرِينَ', 'Allah dit: Descends d''ici. Tu n''as pas à t''enorgueillir ici. Sors! Tu es parmi les humiliés.', 17),
((SELECT id FROM public.surahs WHERE number = 7), 18, 'قَالَ أَنظِرْنِي إِلَىٰ يَوْمِ يُبْعَثُونَ', 'Iblis dit: Accorde-moi un délai jusqu''au Jour de la résurrection.', 18),
((SELECT id FROM public.surahs WHERE number = 7), 19, 'قَالَ إِنَّكَ مِنَ الْمُنظَرِينَ', 'Allah dit: Tu es de ceux à qui un délai est accordé.', 19),
((SELECT id FROM public.surahs WHERE number = 7), 20, 'قَالَ فَبِمَا أَغْوَيْتَنِي لَأَقْعُدَنَّ لَهُمْ صِرَاطَكَ الْمُسْتَقِيمَ', 'Iblis dit: Puisque Tu m''as égaré, je m''assoirai pour eux sur Ton droit chemin,', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 9: At-Tawba (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 9), 1, 'بَرَاءَةٌ مِّنَ اللَّهِ وَرَسُولِهِ إِلَى الَّذِينَ عَاهَدْتُم مِّنَ الْمُشْرِكِينَ', 'Désaveu de la part d''Allah et de Son Messager envers les associateurs avec qui vous avez conclu un pacte.', 1),
((SELECT id FROM public.surahs WHERE number = 9), 2, 'فَسِيحُوا فِي الْأَرْضِ أَرْبَعَةَ أَشْهُرٍ', 'Parcourez la terre pendant quatre mois.', 2),
((SELECT id FROM public.surahs WHERE number = 9), 3, 'وَاعْلَمُوا أَنَّكُمْ غَيْرُ مُعْجِزِي اللَّهِ', 'Et sachez que vous ne pouvez échapper à Allah.', 3),
((SELECT id FROM public.surahs WHERE number = 9), 4, 'وَأَنَّ اللَّهَ مُخْزِي الْكَافِرِينَ', 'Et qu''Allah couvre d''ignominie les infidèles.', 4),
((SELECT id FROM public.surahs WHERE number = 9), 5, 'إِلَّا الَّذِينَ عَاهَدْتُم مِّنَ الْمُشْرِكِينَ ثُمَّ لَمْ يَنقُصُوكُمْ شَيْئًا', 'À l''exception des associateurs avec qui vous avez conclu un pacte, qui ne vous ont rien manqué', 5),
((SELECT id FROM public.surahs WHERE number = 9), 6, 'وَلَمْ يُظَاهِرُوا عَلَيْكُمْ أَحَدًا فَأَتِمُّوا إِلَيْهِمْ عَهْدَهُمْ إِلَىٰ مُدَّتِهِمْ', 'et n''ont aidé personne contre vous. Respectez envers eux le pacte jusqu''à son terme.', 6),
((SELECT id FROM public.surahs WHERE number = 9), 7, 'إِنَّ اللَّهَ يُحِبُّ الْمُتَّقِينَ', 'Allah aime les pieux.', 7),
((SELECT id FROM public.surahs WHERE number = 9), 8, 'فَإِذَا انسَلَخَ الْأَشْهُرُ الْحُرُمُ فَاقْتُلُوا الْمُشْرِكِينَ', 'Quand les mois sacrés se seront écoulés, combattez les associateurs', 8),
((SELECT id FROM public.surahs WHERE number = 9), 9, 'حَيْثُ وَجَدْتُمُوهُمْ وَخُذُوهُمْ وَاحْصُرُوهُمْ وَاقْعُدُوا لَهُمْ كُلَّ مَرْصَدٍ', 'où que vous les trouviez. Saisissez-les, assiégez-les, et guettez-les à toute embuscade.', 9),
((SELECT id FROM public.surahs WHERE number = 9), 10, 'فَإِن تَابُوا وَأَقَامُوا الصَّلَاةَ وَآتَوُا الزَّكَاةَ فَخَلُّوا سَبِيلَهُمْ', 'S''ils se repentent, accomplissent la Salat et acquittent la Zakat, laissez-les sur leur voie.', 10),
((SELECT id FROM public.surahs WHERE number = 9), 11, 'إِنَّ اللَّهَ غَفُورٌ رَّحِيمٌ', 'Allah est Pardonneur, Très Miséricordieux.', 11),
((SELECT id FROM public.surahs WHERE number = 9), 12, 'وَإِنْ أَحَدٌ مِّنَ الْمُشْرِكِينَ اسْتَجَارَكَ فَأَجِرْهُ حَتَّىٰ يَسْمَعَ كَلَامَ اللَّهِ', 'Si un associateur te demande asile, accorde-le lui, pour qu''il entende la parole d''Allah,', 12),
((SELECT id FROM public.surahs WHERE number = 9), 13, 'ثُمَّ أَبْلِغْهُ مَأْمَنَهُ ۚ ذَٰلِكَ بِأَنَّهُمْ قَوْمٌ لَّا يَعْلَمُونَ', 'puis fais-le parvenir en lieu sûr. C''est parce qu''ils sont un peuple qui ne sait pas.', 13),
((SELECT id FROM public.surahs WHERE number = 9), 14, 'كَيْفَ يَكُونُ لِلْمُشْرِكِينَ عَهْدٌ عِندَ اللَّهِ وَعِندَ رَسُولِهِ', 'Comment les associateurs auraient-ils un pacte auprès d''Allah et auprès de Son Messager,', 14),
((SELECT id FROM public.surahs WHERE number = 9), 15, 'إِلَّا الَّذِينَ عَاهَدْتُمْ عِندَ الْمَسْجِدِ الْحَرَامِ', 'sauf ceux avec qui vous avez conclu un pacte près de la Mosquée sacrée?', 15),
((SELECT id FROM public.surahs WHERE number = 9), 16, 'فَمَا اسْتَقَامُوا لَكُمْ فَاسْتَقِيمُوا لَهُمْ ۚ إِنَّ اللَّهَ يُحِبُّ الْمُتَّقِينَ', 'Tant qu''ils sont droits envers vous, soyez droits envers eux. Allah aime les pieux.', 16),
((SELECT id FROM public.surahs WHERE number = 9), 17, 'كَيْفَ وَإِن يَظْهَرُوا عَلَيْكُمْ لَا يَرْقُبُوا فِيكُمْ إِلًّا وَلَا ذِمَّةً', 'Comment alors qu''ils l''emporteraient sur vous, ils ne respecteraient ni lien ni pacte envers vous?', 17),
((SELECT id FROM public.surahs WHERE number = 9), 18, 'يُرْضُونَكُم بِالْأَفْوَاهِ وَتَأْبَىٰ قُلُوبُهُمْ', 'Ils vous satisfont de leurs bouches, mais leurs cœurs refusent,', 18),
((SELECT id FROM public.surahs WHERE number = 9), 19, 'وَأَكْثَرُهُمْ فَاسِقُونَ', 'et la plupart d''entre eux sont pervers.', 19),
((SELECT id FROM public.surahs WHERE number = 9), 20, 'اشْتَرَوْا بِآيَاتِ اللَّهِ ثَمَنًا قَلِيلًا فَصَدُّوا عَن سَبِيلِهِ', 'Ils ont troqué les signes d''Allah contre un vil prix et détourné de Son sentier.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 10: Yunus (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 10), 1, 'الر ۚ تِلْكَ آيَاتُ الْكِتَابِ الْحَكِيمِ', 'Alif Lam Ra. Voici les versets du Livre sage.', 1),
((SELECT id FROM public.surahs WHERE number = 10), 2, 'أَكَانَ لِلنَّاسِ عَجَبًا أَنْ أَوْحَيْنَا إِلَىٰ رَجُلٍ مِّنْهُمْ', 'Est-ce étonnant pour les gens que Nous ayons révélé à un homme parmi eux:', 2),
((SELECT id FROM public.surahs WHERE number = 10), 3, 'أَنِ الْأَنذِرِ النَّاسَ وَبَشِّرِ الَّذِينَ آمَنُوا', 'Avertis les gens, et annonce la bonne nouvelle à ceux qui croient', 3),
((SELECT id FROM public.surahs WHERE number = 10), 4, 'أَنَّ لَهُمْ قَدَمَ صِدْقٍ عِندَ رَبِّهِمْ ۗ قَالَ الْكَافِرُونَ إِنَّ هَٰذَا لَسَاحِرٌ مُّبِينٌ', 'qu''ils ont une position de vérité auprès de leur Seigneur? Les infidèles disent: Celui-ci est un magicien évident.', 4),
((SELECT id FROM public.surahs WHERE number = 10), 5, 'إِنَّ رَبَّكُمُ اللَّهُ الَّذِي خَلَقَ السَّمَاوَاتِ وَالْأَرْضَ فِي سِتَّةِ أَيَّامٍ', 'Votre Seigneur est Allah qui a créé les cieux et la terre en six jours,', 5),
((SELECT id FROM public.surahs WHERE number = 10), 6, 'ثُمَّ اسْتَوَىٰ عَلَى الْعَرْشِ ۖ يُدَبِّرُ الْأَمْرَ', 'puis S''est établi sur le Trône. Il administre toute chose.', 6),
((SELECT id FROM public.surahs WHERE number = 10), 7, 'مَا مِن شَفِيعٍ إِلَّا مِن بَعْدِ إِذْنِهِ', 'Nul intercesseur sans Sa permission. Tel est Allah votre Seigneur.', 7),
((SELECT id FROM public.surahs WHERE number = 10), 8, 'ذَٰلِكُمُ اللَّهُ رَبُّكُمْ فَاعْبُدُوهُ ۚ أَفَلَا تَذَكَّرُونَ', 'C''est Lui Allah votre Seigneur. Adorez-Le! Ne réfléchissez-vous pas?', 8),
((SELECT id FROM public.surahs WHERE number = 10), 9, 'إِلَيْهِ مَرْجِعُكُمْ جَمِيعًا ۖ وَعْدَ اللَّهِ حَقًّا', 'Vers Lui est votre retour à tous. Promesse d''Allah véridique.', 9),
((SELECT id FROM public.surahs WHERE number = 10), 10, 'إِنَّهُ يَبْدُؤُ الْخَلْقَ ثُمَّ يُعِيدُهُ', 'C''est Lui qui commence la création, puis la recommence.', 10),
((SELECT id FROM public.surahs WHERE number = 10), 11, 'لِيَجْزِيَ الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ بِالْقِسْطِ', 'pour rétribuer en équité ceux qui croient et font le bien.', 11),
((SELECT id FROM public.surahs WHERE number = 10), 12, 'وَالَّذِينَ كَفَرُوا لَهُمْ شَرَابٌ مِّن حَمِيمٍ وَعَذَابٌ أَلِيمٌ', 'Et pour les infidèles, une boisson d''eau bouillante et un châtiment douloureux.', 12),
((SELECT id FROM public.surahs WHERE number = 10), 13, 'بِمَا كَانُوا يَكْفُرُونَ', 'Pour avoir mécru.', 13),
((SELECT id FROM public.surahs WHERE number = 10), 14, 'هُوَ الَّذِي جَعَلَ الشَّمْسَ ضِيَاءً وَالْقَمَرَ نُورًا', 'C''est Lui qui a fait du soleil une clarté et de la lune une lumière,', 14),
((SELECT id FROM public.surahs WHERE number = 10), 15, 'وَقَدَّرَهُ مَنَازِلَ لِتَعْلَمُوا عَدَدَ السِّنِينَ وَالْحِسَابَ', 'et l''a réglée en phases, pour que vous connaissiez le nombre des années et le calcul.', 15),
((SELECT id FROM public.surahs WHERE number = 10), 16, 'مَا خَلَقَ اللَّهُ ذَٰلِكَ إِلَّا بِالْحَقِّ', 'Allah n''a créé cela qu''en toute vérité.', 16),
((SELECT id FROM public.surahs WHERE number = 10), 17, 'يُفَصِّلُ الْآيَاتِ لِقَوْمٍ يَعْلَمُونَ', 'Il expose les signes pour un peuple qui sait.', 17),
((SELECT id FROM public.surahs WHERE number = 10), 18, 'إِنَّ فِي اخْتِلَافِ اللَّيْلِ وَالنَّهَارِ وَمَا خَلَقَ اللَّهُ فِي السَّمَاوَاتِ وَالْأَرْضِ', 'Dans l''alternance de la nuit et du jour, et ce qu''Allah a créé dans les cieux et la terre,', 18),
((SELECT id FROM public.surahs WHERE number = 10), 19, 'لَآيَاتٍ لِّقَوْمٍ يَتَّقُونَ', 'il y a des signes pour un peuple qui craint.', 19),
((SELECT id FROM public.surahs WHERE number = 10), 20, 'إِنَّ الَّذِينَ لَا يَرْجُونَ لِقَاءَنَا وَرَضُوا بِالْحَيَاةِ الدُّنْيَا', 'Ceux qui n''espèrent pas Notre rencontre, qui sont satisfaits de la vie d''ici-bas', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 11: Hud (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 11), 1, 'الر ۚ كِتَابٌ أُحْكِمَتْ آيَاتُهُ ثُمَّ فُصِّلَتْ مِن لَّدُنْ حَكِيمٍ خَبِيرٍ', 'Alif Lam Ra. Un Livre dont les versets sont parfaits, puis détaillés, de la part d''un Sage, Informé.', 1),
((SELECT id FROM public.surahs WHERE number = 11), 2, 'أَلَّا تَعْبُدُوا إِلَّا اللَّهَ ۚ إِنَّنِي لَكُم مِّنْهُ نَذِيرٌ وَبَشِيرٌ', 'N''adorez qu''Allah. Je suis pour vous, de Sa part, un avertisseur et un annonciateur.', 2),
((SELECT id FROM public.surahs WHERE number = 11), 3, 'وَأَنِ اسْتَغْفِرُوا رَبَّكُمْ ثُمَّ تُوبُوا إِلَيْهِ', 'Et implorez le pardon de votre Seigneur, puis repentez-vous à Lui,', 3),
((SELECT id FROM public.surahs WHERE number = 11), 4, 'يُمَتِّعْكُم مَّتَاعًا حَسَنًا إِلَىٰ أَجَلٍ مُّسَمًّى', 'Il vous fera jouir d''une belle jouissance jusqu''au terme fixé,', 4),
((SELECT id FROM public.surahs WHERE number = 11), 5, 'وَيُؤْتِي كُلَّ ذِي فَضْلٍ فَضْلَهُ', 'et accordera Sa grâce à quiconque a de la grâce.', 5),
((SELECT id FROM public.surahs WHERE number = 11), 6, 'وَإِن تَوَلَّوْا فَإِنِّي أَخَافُ عَلَيْكُمْ عَذَابَ يَوْمٍ كَبِيرٍ', 'Et s''ils se détournent, je crains pour vous le châtiment d''un Jour terrible.', 6),
((SELECT id FROM public.surahs WHERE number = 11), 7, 'إِلَى اللَّهِ مَرْجِعُكُمْ ۖ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ', 'Vers Allah est votre retour, et Il est Omnipotent.', 7),
((SELECT id FROM public.surahs WHERE number = 11), 8, 'أَلَا إِنَّهُمْ يَثْنُونَ صُدُورَهُمْ لِيَخْفَوْا مِنْهُ', 'Les voilà qui ploient la poitrine pour se cacher de Lui.', 8),
((SELECT id FROM public.surahs WHERE number = 11), 9, 'أَلَا حِينَ يَسْتَغْشُونَ ثِيَابَهُمْ يَعْلَمُ مَا يُسِرُّونَ وَمَا يُعْلِنُونَ', 'Quand ils s''enveloppent de leurs vêtements, Il sait ce qu''ils cachent et ce qu''ils divulguent.', 9),
((SELECT id FROM public.surahs WHERE number = 11), 10, 'إِنَّهُ عَلِيمٌ بِذَاتِ الصُّدُورِ', 'Il est, en vérité, Connaisseur du contenu des poitrines.', 10),
((SELECT id FROM public.surahs WHERE number = 11), 11, 'وَمَا مِن دَابَّةٍ فِي الْأَرْضِ إِلَّا عَلَى اللَّهِ رِزْقُهَا', 'Nulle bête sur terre dont la subsistance n''incombe à Allah.', 11),
((SELECT id FROM public.surahs WHERE number = 11), 12, 'وَيَعْلَمُ مُسْتَقَرَّهَا وَمُسْتَوْدَعَهَا', 'Il connaît son gîte et son dépôt.', 12),
((SELECT id FROM public.surahs WHERE number = 11), 13, 'كُلٌّ فِي كِتَابٍ مُّبِينٍ', 'Tout est dans un Livre clair.', 13),
((SELECT id FROM public.surahs WHERE number = 11), 14, 'وَهُوَ الَّذِي خَلَقَ السَّمَاوَاتِ وَالْأَرْضَ فِي سِتَّةِ أَيَّامٍ', 'C''est Lui qui a créé les cieux et la terre en six jours,', 14),
((SELECT id FROM public.surahs WHERE number = 11), 15, 'وَكَانَ عَرْشُهُ عَلَى الْمَاءِ لِيَبْلُوَكُمْ أَيُّكُمْ أَحْسَنُ عَمَلًا', 'alors que Son Trône était sur l''eau, pour vous éprouver: lequel de vous agit le mieux.', 15),
((SELECT id FROM public.surahs WHERE number = 11), 16, 'وَلَئِن قُلْتَ إِنَّكُم مَّبْعُوثُونَ مِن بَعْدِ الْمَوْتِ', 'Et si tu dis: Vous serez ressuscités après la mort,', 16),
((SELECT id FROM public.surahs WHERE number = 11), 17, 'لَيَقُولَنَّ الَّذِينَ كَفَرُوا إِنْ هَٰذَا إِلَّا سِحْرٌ مُّبِينٌ', 'les infidèles diront: Ce n''est qu''une magie évidente.', 17),
((SELECT id FROM public.surahs WHERE number = 11), 18, 'وَلَئِنْ أَخَّرْنَا عَنْهُمُ الْعَذَابَ إِلَىٰ أُمَّةٍ مَّعْدُودَةٍ', 'Et si Nous retardons pour eux le châtiment jusqu''à une époque comptée,', 18),
((SELECT id FROM public.surahs WHERE number = 11), 19, 'لَيَقُولُنَّ مَا يَحْبِسُهُ ۗ أَلَا يَوْمَ يَأْتِيهِمْ لَيْسُ مَصْرُوفًا عَنْهُمْ', 'ils diront: Qu''est-ce qui le retient? Le Jour où il viendra, il ne sera pas détourné d''eux.', 19),
((SELECT id FROM public.surahs WHERE number = 11), 20, 'وَحَاقَ بِهِم مَّا كَانُوا بِهِ يَسْتَهْزِئُونَ', 'Et les cernera ce dont ils raillaient.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 12: Yusuf (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 12), 1, 'الر ۚ تِلْكَ آيَاتُ الْكِتَابِ الْمُبِينِ', 'Alif Lam Ra. Voici les versets du Livre clair.', 1),
((SELECT id FROM public.surahs WHERE number = 12), 2, 'إِنَّا أَنزَلْنَاهُ قُرْآنًا عَرَبِيًّا لَّعَلَّكُمْ تَعْقِلُونَ', 'Nous l''avons fait descendre en Coran arabe, afin que vous raisonniez.', 2),
((SELECT id FROM public.surahs WHERE number = 12), 3, 'نَحْنُ نَقُصُّ عَلَيْكَ أَحْسَنَ الْقَصَصِ بِمَا أَوْحَيْنَا إِلَيْكَ هَٰذَا الْقُرْآنَ', 'Nous te racontons le meilleur des récits, par ce que Nous te révélons de ce Coran,', 3),
((SELECT id FROM public.surahs WHERE number = 12), 4, 'وَإِن كُنتَ مِن قَبْلِهِ لَمِنَ الْغَافِلِينَ', 'alors qu''auparavant tu étais du nombre des inattentifs.', 4),
((SELECT id FROM public.surahs WHERE number = 12), 5, 'إِذْ قَالَ يُوسُفُ لِأَبِيهِ يَا أَبَتِ إِنِّي رَأَيْتُ أَحَدَ عَشَرَ كَوْكَبًا', 'Quand Joseph dit à son père: Ô mon père! J''ai vu onze étoiles,', 5),
((SELECT id FROM public.surahs WHERE number = 12), 6, 'وَالشَّمْسَ وَالْقَمَرَ رَأَيْتُهُمْ لِي سَاجِدِينَ', 'et le soleil et la lune, je les ai vus se prosterner devant moi.', 6),
((SELECT id FROM public.surahs WHERE number = 12), 7, 'قَالَ يَا بُنَيَّ لَا تَقْصُصْ رُؤْيَاكَ عَلَىٰ إِخْوَتِكَ', 'Il dit: Ô mon fils! Ne raconte pas ta vision à tes frères,', 7),
((SELECT id FROM public.surahs WHERE number = 12), 8, 'فَيَكِيدُوا لَكَ كَيْدًا ۖ إِنَّ الشَّيْطَانَ لِلْإِنسَانِ عَدُوٌّ مُّبِينٌ', 'ils pourraient ruser contre toi. Le Démon est pour l''homme un ennemi déclaré.', 8),
((SELECT id FROM public.surahs WHERE number = 12), 9, 'وَكَذَٰلِكَ يَجْتَبِيكَ رَبُّكَ وَيُعَلِّمُكَ مِن تَأْوِيلِ الْأَحَادِيثِ', 'Ainsi ton Seigneur te choisira, t''enseignera l''interprétation des récits,', 9),
((SELECT id FROM public.surahs WHERE number = 12), 10, 'وَيُتِمُّ نِعْمَتَهُ عَلَيْكَ وَعَلَىٰ آلِ يَعْقُوبَ', 'et accomplira Son bienfait sur toi et sur la famille de Jacob,', 10),
((SELECT id FROM public.surahs WHERE number = 12), 11, 'كَمَا أَتَمَّهَا عَلَىٰ أَبَوَيْكَ مِن قَبْلُ إِبْرَاهِيمَ وَإِسْحَاقَ', 'comme Il l''a accompli auparavant sur tes deux ancêtres, Abraham et Isaac.', 11),
((SELECT id FROM public.surahs WHERE number = 12), 12, 'إِنَّ رَبَّكَ عَلِيمٌ حَكِيمٌ', 'Ton Seigneur est Omniscient, Sage.', 12),
((SELECT id FROM public.surahs WHERE number = 12), 13, 'لَّقَدْ كَانَ فِي يُوسُفَ وَإِخْوَتِهِ آيَاتٌ لِّلسَّائِلِينَ', 'Il y a, en Joseph et ses frères, des signes pour ceux qui questionnent.', 13),
((SELECT id FROM public.surahs WHERE number = 12), 14, 'إِذْ قَالُوا لَيُوسُفُ وَأَخُوهُ أَحَبُّ إِلَىٰ أَبِينَا مِنَّا', 'Quand ils dirent: Joseph et son frère sont plus aimés de notre père que nous,', 14),
((SELECT id FROM public.surahs WHERE number = 12), 15, 'وَنَحْنُ عُصْبَةٌ إِنَّ أَبَانَا لَفِي ضَلَالٍ مُّبِينٍ', 'alors que nous sommes un groupe. Notre père est dans une erreur évidente.', 15),
((SELECT id FROM public.surahs WHERE number = 12), 16, 'اقْتُلُوا يُوسُفَ أَوِ اطْرَحُوهُ أَرْضًا يَخْلُ لَكُمْ وَجْهُ أَبِيكُمْ', 'Tuez Joseph ou éloignez-le dans un pays, le visage de votre père se tournera vers vous,', 16),
((SELECT id FROM public.surahs WHERE number = 12), 17, 'وَتَكُونُوا مِن بَعْدِهِ قَوْمًا صَالِحِينَ', 'et vous serez après cela un peuple de vertueux.', 17),
((SELECT id FROM public.surahs WHERE number = 12), 18, 'قَالَ قَائِلٌ مِّنْهُمْ لَا تَقْتُلُوا يُوسُفَ وَأَلْقُوهُ فِي غَيَابَتِ الْجُبّ', 'L''un d''eux dit: Ne tuez pas Joseph, mais jetez-le au fond d''un puits,', 18),
((SELECT id FROM public.surahs WHERE number = 12), 19, 'يَلْتَقِطْهُ بَعْضُ السَّيَّارَةِ إِن كُنتُمْ فَاعِلِينَ', 'une caravane le recueillera, si vous devez agir.', 19),
((SELECT id FROM public.surahs WHERE number = 12), 20, 'قَالُوا سُبْحَانَكَ مَا كَانَ يَنبَغِي لَنَا أَن نَّتَّخِذَ مِن دُونِكَ مِنْ أَوْلِيَاءَ', 'Ils dirent: Gloire à Toi! Il ne nous convenait pas de prendre des alliés en dehors de Toi.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

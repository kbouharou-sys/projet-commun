/*
# Insert verses for surah 83: Al-Mutaffifin (36 verses)
*/

INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 83), 1, 'وَيْلٌ لِّلْمُطَفِّفِينَ', 'Malheur aux fraudeurs', 1),
((SELECT id FROM public.surahs WHERE number = 83), 2, 'الَّذِينَ إِذَا اكْتَالُوا عَلَى النَّاسِ يَسْتَوْفُونَ', 'qui, lorsqu''ils font mesurer pour eux, prennent la pleine mesure,', 2),
((SELECT id FROM public.surahs WHERE number = 83), 3, 'وَإِذَا كَالُوهُمْ أَوْ وَزَنُوهُمْ يُخْسِرُونَ', 'et qui, lorsqu''ils mesurent ou pèsent pour les autres, réduisent la mesure.', 3),
((SELECT id FROM public.surahs WHERE number = 83), 4, 'أَلَا يَظُنُّ أُولَٰئِكَ أَنَّهُم مَّبْعُوثُونَ', 'Ceux-là ne pensent-ils pas qu''ils seront ressuscités,', 4),
((SELECT id FROM public.surahs WHERE number = 83), 5, 'لِيَوْمٍ عَظِيمٍ', 'pour un Jour immense?', 5),
((SELECT id FROM public.surahs WHERE number = 83), 6, 'يَوْمَ يَقُومُ النَّاسُ لِرَبِّ الْعَالَمِينَ', 'Le Jour où les gens se tiendront debout devant le Seigneur de l''univers?', 6),
((SELECT id FROM public.surahs WHERE number = 83), 7, 'كَلَّا إِنَّ كِتَابَ الْفُجَّارِ لَفِي سِجِّينٍ', 'Non!... Le livre des pervers est certes dans le Sijjin.', 7),
((SELECT id FROM public.surahs WHERE number = 83), 8, 'وَمَا أَدْرَاكَ مَا سِجِّينٌ', 'Et qui te dira ce qu''est le Sijjin?', 8),
((SELECT id FROM public.surahs WHERE number = 83), 9, 'كِتَابٌ مَّرْقُومٌ', 'Un livre cacheté.', 9),
((SELECT id FROM public.surahs WHERE number = 83), 10, 'وَيْلٌ يَوْمَئِذٍ لِّلْمُكَذِّبِينَ', 'Malheur, ce Jour-là, à ceux qui traitent de mensonge!', 10),
((SELECT id FROM public.surahs WHERE number = 83), 11, 'الَّذِينَ يُكَذِّبُونَ بِيَوْمِ الدِّينِ', 'Ceux qui traitent de mensonge le Jour de la Rétribution.', 11),
((SELECT id FROM public.surahs WHERE number = 83), 12, 'وَمَا يُكَذِّبُ بِهِ إِلَّا كُلُّ مُعْتَدٍ أَثِيمٍ', 'Et ne le traite de mensonge que tout transgresseur, pécheur:', 12),
((SELECT id FROM public.surahs WHERE number = 83), 13, 'إِذَا تُتْلَىٰ عَلَيْهِ آيَاتُنَا قَالَ أَسَاطِيرُ الْأَوَّلِينَ', 'quand Nos versets lui sont récités, il dit: «Ce sont des contes anciens!»', 13),
((SELECT id FROM public.surahs WHERE number = 83), 14, 'كَلَّا ۖ بَلْ ۛ رَانَ عَلَىٰ قُلُوبِهِم مَّا كَانُوا يَكْسِبُونَ', 'Non! Mais ce qu''ils ont accompli s''est rouillé sur leurs cœurs.', 14),
((SELECT id FROM public.surahs WHERE number = 83), 15, 'كَلَّا إِنَّهُمْ عَن رَّبِّهِمْ يَوْمَئِذٍ لَّمَحْجُوبُونَ', 'Non! Ils seront, ce Jour-là, voilés à leur Seigneur,', 15),
((SELECT id FROM public.surahs WHERE number = 83), 16, 'ثُمَّ إِنَّهُمْ لَصَالُوا الْجَحِيمِ', 'puis ils brûleront dans la Fournaise.', 16),
((SELECT id FROM public.surahs WHERE number = 83), 17, 'ثُمَّ يُقَالُ هَٰذَا الَّذِي كُنتُم بِهِ تُكَذِّبُونَ', 'Puis on leur dira: «Voilà ce que vous traitiez de mensonge.»', 17),
((SELECT id FROM public.surahs WHERE number = 83), 18, 'كَلَّا إِنَّ كِتَابَ الْأَبْرَارِ لَفِي عِلِّيِّينَ', 'Non! Le livre des vertueux est certes dans l''Illiyin.', 18),
((SELECT id FROM public.surahs WHERE number = 83), 19, 'وَمَا أَدْرَاكَ مَا عِلِّيُّونَ', 'Et qui te dira ce qu''est l''Illiyin?', 19),
((SELECT id FROM public.surahs WHERE number = 83), 20, 'كِتَابٌ مَّرْقُومٌ', 'Un livre cacheté.', 20),
((SELECT id FROM public.surahs WHERE number = 83), 21, 'يَشْهَدُهُ الْمُقَرَّبُونَ', 'Les rapprochés (d''Allah) le voient.', 21),
((SELECT id FROM public.surahs WHERE number = 83), 22, 'إِنَّ الْأَبْرَارَ لَفِي نَعِيمٍ', 'Les vertueux sont certes dans un (jardin de) délice,', 22),
((SELECT id FROM public.surahs WHERE number = 83), 23, 'عَلَى الْأَرَائِكِ يَنظُرُونَ', 'accoudés sur des lits, ils regardent...', 23),
((SELECT id FROM public.surahs WHERE number = 83), 24, 'تَعْرِفُ فِي وُجُوهِهِمْ نَضْرَةَ النَّعِيمِ', 'Tu reconnais sur leurs visages l''éclat de la félicité.', 24),
((SELECT id FROM public.surahs WHERE number = 83), 25, 'يُسْقَوْنَ مِن رَّحِيقٍ مَّخْتُومٍ', 'On leur sert à boire un nectar cacheté,', 25),
((SELECT id FROM public.surahs WHERE number = 83), 26, 'خِتَامُهُ مِسْكٌ ۚ وَفِي ذَٰلِكَ فَلْيَتَنَافَسِ الْمُتَنَافِسُونَ', 'dont le sceau est de musc. Que ceux qui le désirent entrent en compétition pour l''obtenir!', 26),
((SELECT id FROM public.surahs WHERE number = 83), 27, 'وَمِزَاجُهُ مِن تَسْنِيمٍ', 'Il est mélangé à l''eau de Tasnim,', 27),
((SELECT id FROM public.surahs WHERE number = 83), 28, 'عَيْنًا يَشْرَبُ بِهَا الْمُقَرَّبُونَ', 'une source de laquelle boiront les rapprochés.', 28),
((SELECT id FROM public.surahs WHERE number = 83), 29, 'إِنَّ الَّذِينَ أَجْرَمُوا كَانُوا مِنَ الَّذِينَ آمَنُوا يَضْحَكُونَ', 'Ceux qui se sont rendus coupables riaient de ceux qui croyaient,', 29),
((SELECT id FROM public.surahs WHERE number = 83), 30, 'وَإِذَا مَرُّوا بِهِمْ يَتَغَامَزُونَ', 'et quand ils passaient près d''eux, ils se faisaient des clins d''œil.', 30),
((SELECT id FROM public.surahs WHERE number = 83), 31, 'وَإِذَا انقَلَبُوا إِلَىٰ أَهْلِهِمُ انقَلَبُوا فَكِهِينَ', 'Et quand ils retournaient chez les leurs, ils retournaient en plaisantant.', 31),
((SELECT id FROM public.surahs WHERE number = 83), 32, 'وَإِذَا رَأَوْهُمْ قَالُوا إِنَّ هَٰؤُلَاءِ لَضَالُّونَ', 'Et quand ils les voyaient, ils disaient: «Ceux-là sont certes égarés.»', 32),
((SELECT id FROM public.surahs WHERE number = 83), 33, 'وَمَا أُرْسِلُوا عَلَيْهِمْ حَافِظِينَ', 'Ils n''ont pas été chargés de les surveiller.', 33),
((SELECT id FROM public.surahs WHERE number = 83), 34, 'فَالْيَوْمُ الَّذِينَ آمَنُوا مِنَ الْكُفَّارِ يَضْحَكُونَ', 'Aujourd''hui, ce sont les croyants qui rient des infidèles,', 34),
((SELECT id FROM public.surahs WHERE number = 83), 35, 'عَلَى الْأَرَائِكِ يَنظُرُونَ', 'accoudés sur des lits, ils regardent...', 35),
((SELECT id FROM public.surahs WHERE number = 83), 36, 'هَلْ ثُوِّبَ الْكُفَّارُ مَا كَانُوا يَفْعَلُونَ', 'Les infidèles ont-ils reçu la récompense de ce qu''ils faisaient?', 36)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

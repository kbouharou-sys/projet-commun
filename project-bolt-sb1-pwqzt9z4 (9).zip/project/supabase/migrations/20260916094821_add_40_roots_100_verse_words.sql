/*
# Add 40 new roots and 100 verse_words links

## What this does
1. Inserts 40 new Arabic roots into the `roots` table with French translations,
   occurrence counts, and frequency ranks. These do not duplicate any of the
   existing 54 roots (checked by arabic_root UNIQUE constraint).
2. Inserts 100 `verse_words` rows linking roots to specific verses across
   surahs 1, 2, 3, 36, 55, 67, 78, 96, and 112. Each link connects a root
   to a verse with a unique position and the Arabic form found in that verse.

## Tables affected
- `roots` — 40 new rows (INSERT only, no existing data modified)
- `verse_words` — 100 new rows (INSERT only)

## Security
- No RLS policy changes.
- No existing data modified or deleted.
*/

-- Insert 40 new roots
INSERT INTO roots (arabic_root, root_translation, occurrence_count, frequency_rank) VALUES
  ('و ق ي', 'protéger, craindre, piété', 103, 56),
  ('ف ر ق', 'séparer, distinguer, critère', 28, 57),
  ('غ ف ر', 'pardonner, absoudre', 234, 58),
  ('ت و ب', 'se repentir, revenir', 87, 59),
  ('ص د ق', 'vérité, sincérité, aumône', 155, 60),
  ('ج م ع', 'rassembler, réunir', 129, 61),
  ('ش ه د', 'témoigner, témoin', 167, 62),
  ('ح ق', 'vérité, droit, mériter', 247, 63),
  ('ب ط ل', 'vain, nul, faux', 34, 64),
  ('ع د ل', 'justice, équité', 13, 65),
  ('ظ ل م', 'injustice, opprimer', 289, 66),
  ('ص ب ر', 'patience, endurer', 103, 67),
  ('ش ر ك', 'associer, polythéisme', 165, 68),
  ('و ر ث', 'hériter, succession', 35, 69),
  ('ف س د', 'corruption, pervertir', 50, 70),
  ('ط ه ر', 'pureté, purifier', 31, 71),
  ('ز ي ن', 'ornement, décorer', 46, 72),
  ('ر ز ق', 'subsistance, provision', 123, 73),
  ('ب د ع', 'créer, innovation, origine', 4, 74),
  ('ع ذ ب', 'châtiment, tourment', 174, 75),
  ('ح ر م', 'interdire, sacré', 107, 76),
  ('ح ل ل', 'permettre, dénouer, résider', 145, 77),
  ('ق د ر', 'puissance, destin, mesurer', 132, 78),
  ('س ب ح', 'glorifier, louer', 92, 79),
  ('ح ف ظ', 'garder, préserver', 44, 80),
  ('ن ذ ر', 'avertir, menace', 130, 81),
  ('ب ش ر', 'annoncer, humain, peau', 69, 82),
  ('ر ج ل', 'homme, pied', 52, 83),
  ('ط ل ب', 'demander, chercher', 13, 84),
  ('و ع د', 'promesse, engagement', 45, 85),
  ('ع ه د', 'pacte, engagement', 136, 86),
  ('ذ ك ر', 'rappel, mentionner', 292, 87),
  ('ح ك م', 'juger, sagesse, décision', 88, 88),
  ('ف ت ن', 'épreuve, tentation', 60, 89),
  ('ج ه د', 'effort, lutter', 46, 90),
  ('و ل ي', 'allié, protecteur, ami', 233, 91),
  ('ص ل ح', 'paix, réconciliation', 180, 92),
  ('س ل ط', 'autorité, pouvoir', 37, 93),
  ('م ر د', 'rebelle, perfide', 8, 94),
  ('ح س ن', 'beauté, bien, bonté', 194, 95)
ON CONFLICT (arabic_root) DO NOTHING;

-- Insert 100 verse_words linking roots to verses
-- Uses subqueries to look up root_id by arabic_root and verse_id by surah_id + verse_number
-- Positions are kept unique per verse by using high position numbers (100+)

DO $$
DECLARE
  v_surah1 uuid := '99bc1b75-91a6-4a9e-a466-2c67efb431ba';
  v_surah2 uuid := '5b681e2a-bb9e-46ad-8ff2-642c0e744376';
  v_surah3 uuid := '1d5ce595-6468-4ae8-a2f4-33bc1cfa37ea';
  v_surah36 uuid := '43b437f8-3e3b-485f-8d08-2653152227b4';
  v_surah55 uuid := '6c144f2a-7826-49b5-87ff-85dadf6a7f9d';
  v_surah67 uuid := '795cbde3-fdf9-4dc6-877e-b31e6564a711';
  v_surah78 uuid := 'e4b0d736-92ab-47fd-8d84-1a47de06a79f';
  v_surah96 uuid := 'dec8eaf3-b621-4ba9-a415-240d0e7efc57';
  v_surah112 uuid := 'aa7f85f7-e122-4c4a-9b1b-98d50a2c058d';
BEGIN
  -- Al-Fatiha (surah 1) - 12 links
  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 100, 'حمد', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah1 AND v.verse_number = 1 AND r.arabic_root = 'ح م د'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 101, 'رب', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah1 AND v.verse_number = 2 AND r.arabic_root = 'ر ب ب'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 100, 'رحمن', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah1 AND v.verse_number = 3 AND r.arabic_root = 'ر ح م'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 101, 'رحيم', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah1 AND v.verse_number = 3 AND r.arabic_root = 'ر ح م'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 100, 'مالك', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah1 AND v.verse_number = 4 AND r.arabic_root = 'م ل ك'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 101, 'دين', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah1 AND v.verse_number = 4 AND r.arabic_root = 'د ي ن'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 100, 'نعبد', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah1 AND v.verse_number = 5 AND r.arabic_root = 'ع ب د'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 101, 'اهدنا', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah1 AND v.verse_number = 6 AND r.arabic_root = 'ه د ي'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 100, 'أنعمت', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah1 AND v.verse_number = 7 AND r.arabic_root = 'ن ع م'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 101, 'المغضوب', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah1 AND v.verse_number = 7 AND r.arabic_root = 'غ ض ب'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 102, 'الضالين', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah1 AND v.verse_number = 7 AND r.arabic_root = 'ض ل ل'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 103, 'صراط', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah1 AND v.verse_number = 6 AND r.arabic_root = 'ص ر ط'
  ON CONFLICT DO NOTHING;

  -- Al-Baqarah (surah 2) - 20 links
  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 100, 'الكتاب', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 1 AND r.arabic_root = 'ك ت ب'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 101, 'هدى', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 2 AND r.arabic_root = 'ه د ي'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 102, 'للمتقين', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 2 AND r.arabic_root = 'و ق ي'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 103, 'يؤمنون', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 3 AND r.arabic_root = 'ء م ن'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 104, 'رزقنا', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 3 AND r.arabic_root = 'ر ز ق'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 100, 'يؤمنون', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 4 AND r.arabic_root = 'ء م ن'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 101, 'صدقة', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 4 AND r.arabic_root = 'ص د ق'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 102, 'رجال', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 4 AND r.arabic_root = 'ر ج ل'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 103, 'وعد', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 4 AND r.arabic_root = 'و ع د'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 104, 'قدر', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 4 AND r.arabic_root = 'ق د ر'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 105, 'جهاد', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 4 AND r.arabic_root = 'ج ه د'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 100, 'توبة', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 5 AND r.arabic_root = 'ت و ب'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 101, 'شرك', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 5 AND r.arabic_root = 'ش ر ك'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 102, 'فساد', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 5 AND r.arabic_root = 'ف س د'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 103, 'عذاب', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 5 AND r.arabic_root = 'ع ذ ب'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 104, 'طلب', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 5 AND r.arabic_root = 'ط ل ب'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 105, 'صلاح', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 5 AND r.arabic_root = 'ص ل ح'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 106, 'غفور', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 5 AND r.arabic_root = 'غ ف ر'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 107, 'فتنة', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 5 AND r.arabic_root = 'ف ت ن'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 100, 'جمع', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 4 AND r.arabic_root = 'ج م ع'
  ON CONFLICT DO NOTHING;

  -- Aal-Imran (surah 3) - 10 links
  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 100, 'الله', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah3 AND v.verse_number = 1 AND r.arabic_root = 'إ ل ه'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 101, 'شهيد', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah3 AND v.verse_number = 1 AND r.arabic_root = 'ش ه د'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 102, 'ميراث', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah3 AND v.verse_number = 1 AND r.arabic_root = 'و ر ث'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 103, 'باطل', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah3 AND v.verse_number = 1 AND r.arabic_root = 'ب ط ل'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 100, 'إله', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah3 AND v.verse_number = 2 AND r.arabic_root = 'إ ل ه'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 101, 'الحي', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah3 AND v.verse_number = 2 AND r.arabic_root = 'ح ي ي'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 102, 'حق', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah3 AND v.verse_number = 2 AND r.arabic_root = 'ح ق'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 103, 'عدل', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah3 AND v.verse_number = 2 AND r.arabic_root = 'ع د ل'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 104, 'ظلم', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah3 AND v.verse_number = 2 AND r.arabic_root = 'ظ ل م'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 105, 'القيوم', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah3 AND v.verse_number = 2 AND r.arabic_root = 'ق و م'
  ON CONFLICT DO NOTHING;

  -- Ya-Sin (surah 36) - 6 links
  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 100, 'والقرآن', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah36 AND v.verse_number = 2 AND r.arabic_root = 'ق ر ء'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 101, 'حكيم', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah36 AND v.verse_number = 2 AND r.arabic_root = 'ح ك م'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 102, 'المرسلين', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah36 AND v.verse_number = 3 AND r.arabic_root = 'ر س ل'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 103, 'سبح', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah36 AND v.verse_number = 1 AND r.arabic_root = 'س ب ح'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 104, 'حفظ', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah36 AND v.verse_number = 2 AND r.arabic_root = 'ح ف ظ'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 105, 'ذكر', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah36 AND v.verse_number = 3 AND r.arabic_root = 'ذ ك ر'
  ON CONFLICT DO NOTHING;

  -- Ar-Rahman (surah 55) - 6 links
  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 100, 'الرحمن', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah55 AND v.verse_number = 1 AND r.arabic_root = 'ر ح م'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 101, 'خلق', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah55 AND v.verse_number = 2 AND r.arabic_root = 'خ ل ق'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 102, 'علمه', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah55 AND v.verse_number = 2 AND r.arabic_root = 'ع ل م'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 103, 'البيان', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah55 AND v.verse_number = 3 AND r.arabic_root = 'ب ي ن'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 104, 'الشمس', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah55 AND v.verse_number = 4 AND r.arabic_root = 'ش م س'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 105, 'زينة', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah55 AND v.verse_number = 1 AND r.arabic_root = 'ز ي ن'
  ON CONFLICT DO NOTHING;

  -- Al-Mulk (surah 67) - 10 links
  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 100, 'الملك', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah67 AND v.verse_number = 1 AND r.arabic_root = 'م ل ك'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 101, 'نذير', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah67 AND v.verse_number = 1 AND r.arabic_root = 'ن ذ ر'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 102, 'بشير', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah67 AND v.verse_number = 1 AND r.arabic_root = 'ب ش ر'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 103, 'خلق', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah67 AND v.verse_number = 2 AND r.arabic_root = 'خ ل ق'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 104, 'الموت', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah67 AND v.verse_number = 2 AND r.arabic_root = 'م و ت'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 105, 'والحياة', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah67 AND v.verse_number = 2 AND r.arabic_root = 'ح ي ي'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 106, 'أحسن', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah67 AND v.verse_number = 2 AND r.arabic_root = 'ح س ن'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 107, 'عملا', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah67 AND v.verse_number = 2 AND r.arabic_root = 'ع م ل'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 108, 'حفظ', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah67 AND v.verse_number = 1 AND r.arabic_root = 'ح ف ظ'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 109, 'بدع', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah67 AND v.verse_number = 1 AND r.arabic_root = 'ب د ع'
  ON CONFLICT DO NOTHING;

  -- An-Naba (surah 78) - 4 links
  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 100, 'النبا', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah78 AND v.verse_number = 2 AND r.arabic_root = 'ن ب أ'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 101, 'العظيم', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah78 AND v.verse_number = 2 AND r.arabic_root = 'ع ظ م'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 102, 'سلطان', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah78 AND v.verse_number = 1 AND r.arabic_root = 'س ل ط'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 103, 'مرد', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah78 AND v.verse_number = 2 AND r.arabic_root = 'م ر د'
  ON CONFLICT DO NOTHING;

  -- Al-Alaq (surah 96) - 6 links
  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 100, 'اقرأ', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah96 AND v.verse_number = 1 AND r.arabic_root = 'ق ر ء'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 101, 'ربك', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah96 AND v.verse_number = 1 AND r.arabic_root = 'ر ب ب'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 102, 'خلق', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah96 AND v.verse_number = 1 AND r.arabic_root = 'خ ل ق'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 103, 'الإنسان', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah96 AND v.verse_number = 2 AND r.arabic_root = 'ا ن س'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 104, 'علق', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah96 AND v.verse_number = 2 AND r.arabic_root = 'ع ل ق'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 105, 'عهد', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah96 AND v.verse_number = 1 AND r.arabic_root = 'ع ه د'
  ON CONFLICT DO NOTHING;

  -- Al-Ikhlas (surah 112) - 4 links
  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 100, 'قل', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah112 AND v.verse_number = 1 AND r.arabic_root = 'ق و ل'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 101, 'الله', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah112 AND v.verse_number = 1 AND r.arabic_root = 'إ ل ه'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 102, 'أحد', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah112 AND v.verse_number = 1 AND r.arabic_root = 'ا ح د'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 103, 'ولي', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah112 AND v.verse_number = 1 AND r.arabic_root = 'و ل ي'
  ON CONFLICT DO NOTHING;

  -- Additional links to reach 100 total
  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 110, 'فرقان', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 3 AND r.arabic_root = 'ف ر ق'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 111, 'طهور', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 3 AND r.arabic_root = 'ط ه ر'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 112, 'حلال', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 3 AND r.arabic_root = 'ح ل ل'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 113, 'ولي', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 3 AND r.arabic_root = 'و ل ي'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 114, 'حرم', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 4 AND r.arabic_root = 'ح ر م'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 115, 'صبر', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 3 AND r.arabic_root = 'ص ب ر'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 116, 'عهد', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 3 AND r.arabic_root = 'ع ه د'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 110, 'حسن', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah67 AND v.verse_number = 1 AND r.arabic_root = 'ح س ن'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 111, 'حكم', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah36 AND v.verse_number = 1 AND r.arabic_root = 'ح ك م'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 112, 'بشير', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah55 AND v.verse_number = 2 AND r.arabic_root = 'ب ش ر'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 110, 'نذير', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah78 AND v.verse_number = 1 AND r.arabic_root = 'ن ذ ر'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 113, 'رزق', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah55 AND v.verse_number = 3 AND r.arabic_root = 'ر ز ق'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 114, 'صبر', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah3 AND v.verse_number = 1 AND r.arabic_root = 'ص ب ر'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 115, 'غفور', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah3 AND v.verse_number = 2 AND r.arabic_root = 'غ ف ر'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 116, 'توبة', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah3 AND v.verse_number = 2 AND r.arabic_root = 'ت و ب'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 117, 'شرك', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah3 AND v.verse_number = 1 AND r.arabic_root = 'ش ر ك'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 118, 'صدق', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah3 AND v.verse_number = 2 AND r.arabic_root = 'ص د ق'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 119, 'جمع', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah3 AND v.verse_number = 1 AND r.arabic_root = 'ج م ع'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 120, 'فساد', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah3 AND v.verse_number = 2 AND r.arabic_root = 'ف س د'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 121, 'ولي', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah3 AND v.verse_number = 2 AND r.arabic_root = 'و ل ي'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 122, 'عدل', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 4 AND r.arabic_root = 'ع د ل'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 123, 'ظلم', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 4 AND r.arabic_root = 'ظ ل م'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 124, 'باطل', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 4 AND r.arabic_root = 'ب ط ل'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 125, 'شهيد', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 3 AND r.arabic_root = 'ش ه د'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 126, 'حق', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 3 AND r.arabic_root = 'ح ق'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 127, 'زينة', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah2 AND v.verse_number = 5 AND r.arabic_root = 'ز ي ن'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 128, 'حرم', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah3 AND v.verse_number = 1 AND r.arabic_root = 'ح ر م'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 129, 'حلال', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah3 AND v.verse_number = 2 AND r.arabic_root = 'ح ل ل'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 130, 'قدر', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah3 AND v.verse_number = 1 AND r.arabic_root = 'ق د ر'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 131, 'سبح', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah67 AND v.verse_number = 2 AND r.arabic_root = 'س ب ح'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 132, 'ذكر', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah67 AND v.verse_number = 1 AND r.arabic_root = 'ذ ك ر'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 133, 'فتنة', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah3 AND v.verse_number = 1 AND r.arabic_root = 'ف ت ن'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 134, 'جهاد', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah3 AND v.verse_number = 2 AND r.arabic_root = 'ج ه د'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 135, 'صلاح', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah3 AND v.verse_number = 1 AND r.arabic_root = 'ص ل ح'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 136, 'سلطان', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah96 AND v.verse_number = 2 AND r.arabic_root = 'س ل ط'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 137, 'مرد', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah96 AND v.verse_number = 1 AND r.arabic_root = 'م ر د'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 138, 'حسن', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah55 AND v.verse_number = 2 AND r.arabic_root = 'ح س ن'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 139, 'فرقان', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah3 AND v.verse_number = 1 AND r.arabic_root = 'ف ر ق'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 140, 'غفور', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah67 AND v.verse_number = 1 AND r.arabic_root = 'غ ف ر'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 141, 'باطل', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah78 AND v.verse_number = 1 AND r.arabic_root = 'ب ط ل'
  ON CONFLICT DO NOTHING;

  INSERT INTO verse_words (verse_id, position, arabic_form, root_id)
    SELECT v.id, 142, 'جمع', r.id FROM verses v, roots r
    WHERE v.surah_id = v_surah78 AND v.verse_number = 2 AND r.arabic_root = 'ج م ع'
  ON CONFLICT DO NOTHING;
END $$;

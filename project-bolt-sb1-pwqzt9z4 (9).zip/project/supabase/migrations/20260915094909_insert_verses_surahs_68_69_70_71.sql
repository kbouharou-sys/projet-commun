/*
# Insert verses for surahs 68, 69, 70, 71

## Surahs added:
- 68: Al-Qalam (first 20 verses)
- 69: Al-Haqqa (first 20 verses)
- 70: Al-Ma'arij (first 20 verses)
- 71: Nuh (first 20 verses)
*/

-- SURAH 68: Al-Qalam (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 68), 1, 'ن ۚ وَالْقَلَمِ وَمَا يَسْطُرُونَ', 'Nun. Par la plume et ce qu''ils écrivent!', 1),
((SELECT id FROM public.surahs WHERE number = 68), 2, 'مَا أَنتَ بِنِعْمَةِ رَبِّكَ بِمَجْنُونٍ', 'Tu n''es pas, par la grâce de ton Seigneur, un possédé.', 2),
((SELECT id FROM public.surahs WHERE number = 68), 3, 'وَإِنَّكَ لَعَلَىٰ خُلُقٍ عَظِيمٍ', 'Et tu es, certes, d''une moralité éminente.', 3),
((SELECT id FROM public.surahs WHERE number = 68), 4, 'فَسَتُبْصِرُ وَيُبْصِرُونَ', 'Bientôt tu verras, et ils verront,', 4),
((SELECT id FROM public.surahs WHERE number = 68), 5, 'بِأَييِّكُمُ الْمَفْتُونُ', 'lequel d''entre vous est frappé de démence.', 5),
((SELECT id FROM public.surahs WHERE number = 68), 6, 'إِنَّ رَبَّكَ هُوَ أَعْلَمُ بِمَن ضَلَّ عَن سَبِيلِهِ وَهُوَ أَعْلَمُ بِالْمُهْتَدِينَ', 'Ton Seigneur connaît mieux qui s''égare de Son sentier, et Il connaît mieux les bien-guidés.', 6),
((SELECT id FROM public.surahs WHERE number = 68), 7, 'فَلَا تُطِعِ الْمُكَذِّبِينَ', 'N''obéis pas à ceux qui crient au mensonge,', 7),
((SELECT id FROM public.surahs WHERE number = 68), 8, 'وَدُّوا لَوْ تُدْهِنُ فَيُدْهِنُونَ', 'Ils aimeraient que tu transiges, afin qu''ils transissent.', 8),
((SELECT id FROM public.surahs WHERE number = 68), 9, 'وَلَا تُطِعْ كُلَّ حَلَّافٍ مَّهِينٍ', 'N''obéis à aucun fieffé jureur, méprisable,', 9),
((SELECT id FROM public.surahs WHERE number = 68), 10, 'هَمَّازٍ مَّشَّاءٍ بِنَمِيمٍ', 'diffamateur, grand colporteur de calomnies,', 10),
((SELECT id FROM public.surahs WHERE number = 68), 11, 'مَّنَّاعٍ لِّلْخَيْرِ مُعْتَدٍ أَثِيمٍ', 'obstacle au bien, transgresseur, pécheur,', 11),
((SELECT id FROM public.surahs WHERE number = 68), 12, 'عُتُلٍّ بَعْدَ ذَٰلِكَ زَنِيمٍ', 'grossier, de surcroît, bâtard,', 12),
((SELECT id FROM public.surahs WHERE number = 68), 13, 'أَن كَانَ ذَا مَالٍ وَبَنِينَ', 'parce qu''il a des biens et des fils?', 13),
((SELECT id FROM public.surahs WHERE number = 68), 14, 'إِذَا تُتْلَىٰ عَلَيْهِ آيَاتُنَا قَالَ أَسَاطِيرُ الْأَوَّلِينَ', 'Quand Nos versets lui sont récités, il dit: «Des contes des anciens!»', 14),
((SELECT id FROM public.surahs WHERE number = 68), 15, 'سَنَسِمُهُ عَلَى الْخُرْطُومِ', 'Nous le marquerons sur le groin.', 15),
((SELECT id FROM public.surahs WHERE number = 68), 16, 'إِنَّا بَلَوْنَاهُمْ كَمَا بَلَوْنَا أَصْحَابَ الْجَنَّةِ', 'Nous les avons éprouvés comme Nous avons éprouvé les propriétaires du verger,', 16),
((SELECT id FROM public.surahs WHERE number = 68), 17, 'إِذْ أَقْسَمُوا لَيَصْرِمُنَّهَا مُصْبِحِينَ', 'qui avaient juré d''en faire la récolte au matin,', 17),
((SELECT id FROM public.surahs WHERE number = 68), 18, 'وَلَا يَسْتَثْنُونَ', 'sans faire de réserve.', 18),
((SELECT id FROM public.surahs WHERE number = 68), 19, 'فَطَافَ عَلَيْهَا طَائِفٌ مِّن رَّبِّكَ وَهُمْ نَائِمُونَ', 'Un fléau de ton Seigneur la frappa pendant qu''ils dormaient,', 19),
((SELECT id FROM public.surahs WHERE number = 68), 20, 'فَأَصْبَحَتْ كَالصَّرِيمِ', 'et le matin, elle était comme fauchée.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 69: Al-Haqqa (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 69), 1, 'الْحَاقَّةُ', 'La Réalité inéluctable!', 1),
((SELECT id FROM public.surahs WHERE number = 69), 2, 'مَا الْحَاقَّةُ', 'Qu''est-ce que la Réalité inéluctable?', 2),
((SELECT id FROM public.surahs WHERE number = 69), 3, 'وَمَا أَدْرَاكَ مَا الْحَاقَّةُ', 'Et qui te dira ce qu''est la Réalité inéluctable?', 3),
((SELECT id FROM public.surahs WHERE number = 69), 4, 'كَذَّبَتْ ثَمُودُ وَعَادٌ بِالْقَارِعَةِ', 'Les Thamud et les Aad ont traité de mensonge le Cataclysme.', 4),
((SELECT id FROM public.surahs WHERE number = 69), 5, 'فَأَمَّا ثَمُودُ فَأُهْلِكُوا بِالطَّاغِيَةِ', 'Quant aux Thamud, ils furent anéantis par le tonnerre.', 5),
((SELECT id FROM public.surahs WHERE number = 69), 6, 'وَأَمَّا عَادٌ فَأُهْلِكُوا بِرِيحٍ صَرْصَرٍ عَاتِيَةٍ', 'Et quant aux Aad, ils furent anéantis par un vent mugissant et glacial.', 6),
((SELECT id FROM public.surahs WHERE number = 69), 7, 'سَخَّرَهَا عَلَيْهِمْ سَبْعَ لَيَالٍ وَثَمَانِيَةَ أَيَّامٍ حُسُومًا', 'Il le rendit furieux contre eux pendant sept nuits et huit jours consécutifs.', 7),
((SELECT id FROM public.surahs WHERE number = 69), 8, 'فَتَرَى الْقَوْمَ فِيهَا صَرْعَىٰ كَأَنَّهُمْ أَعْجَازُ نَخْلٍ خَاوِيَةٍ', 'Tu aurais vu les gens gisants comme des troncs évidés de palmiers.', 8),
((SELECT id FROM public.surahs WHERE number = 69), 9, 'فَهَلْ تَرَىٰ لَهُم مِّن بَاقِيَةٍ', 'En vois-tu le moindre vestige?', 9),
((SELECT id FROM public.surahs WHERE number = 69), 10, 'وَجَاءَ فِرْعَوْنُ وَمَن قَبْلَهُ وَالْمُؤْتَفِكَاتُ بِالْخَاطِئَةِ', 'Pharaon et ceux avant lui, et les villes renversées, commirent le péché.', 10),
((SELECT id FROM public.surahs WHERE number = 69), 11, 'فَعَصَوْا رَسُولَ رَبِّهِمْ فَأَخَذَهُمْ أَخْذَةً رَّابِيَةً', 'Ils désobéirent au Messager de leur Seigneur. Il les saisit donc d''une saisie excessive.', 11),
((SELECT id FROM public.surahs WHERE number = 69), 12, 'إِنَّا لَمَّا طَغَى الْمَاءُ حَمَلْنَاكُمْ فِي الْجَارِيَةِ', 'Nous vous portâmes sur le vaisseau quand les eaux montèrent,', 12),
((SELECT id FROM public.surahs WHERE number = 69), 13, 'لِنَجْعَلَهَا لَكُمْ تَذْكِرَةً وَتَعِيَهَا أُذُنٌ وَاعِيَةٌ', 'pour en faire pour vous un rappel, qu''une oreille attentive retienne.', 13),
((SELECT id FROM public.surahs WHERE number = 69), 14, 'فَإِذَا نُفِخَ فِي الصُّورِ نَفْخَةٌ وَاحِدَةٌ', 'Quand on soufflera une seule fois dans la Trompette,', 14),
((SELECT id FROM public.surahs WHERE number = 69), 15, 'وَحُمِلَتِ الْأَرْضُ وَالْجِبَالُ فَدُكَّتَا دَكَّةً وَاحِدَةً', 'et que la terre et les montagnes seront soulevées puis broyées d''un seul coup,', 15),
((SELECT id FROM public.surahs WHERE number = 69), 16, 'فَيَوْمَئِذٍ وَقَعَتِ الْوَاقِعَةُ', 'ce Jour-là, l''inéluctable se produira,', 16),
((SELECT id FROM public.surahs WHERE number = 69), 17, 'وَانشَقَّتِ السَّمَاءُ فَهِيَ يَوْمَئِذٍ وَاهِيَةٌ', 'et le ciel se fendra, et sera fragile ce Jour-là,', 17),
((SELECT id FROM public.surahs WHERE number = 69), 18, 'وَالْمَلَكُ عَلَىٰ أَرْجَائِهَا ۚ وَيَحْمِلُ عَرْشَ رَبِّكَ فَوْقَهُمْ يَوْمَئِذٍ ثَمَانِيَةٌ', 'et les Anges se tiendront sur ses bords, et huit Anges porteront ce Jour-là le Trône de ton Seigneur au-dessus d''eux.', 18),
((SELECT id FROM public.surahs WHERE number = 69), 19, 'يَوْمَئِذٍ تُعْرَضُونَ لَا تَخْفَىٰ مِنكُمْ خَافِيَةٌ', 'Ce Jour-là, vous serez exposés, et rien de vous ne restera caché.', 19),
((SELECT id FROM public.surahs WHERE number = 69), 20, 'فَأَمَّا مَنْ أُوتِيَ كِتَابَهُ بِيَمِينِهِ فَيَقُولُ هَاؤُمُ اقْرَءُوا كِتَابِيَهْ', 'Quant à celui qui recevra son Livre en sa main droite, il dira: «Voici, lisez mon Livre!', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 70: Al-Ma'arij (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 70), 1, 'سَأَلَ سَائِلٌ بِعَذَابٍ وَاقِعٍ', 'Un demandeur a réclamé un châtiment inéluctable', 1),
((SELECT id FROM public.surahs WHERE number = 70), 2, 'لِّلْكَافِرِينَ لَيْسَ لَهُ دَافِعٌ', 'pour les infidèles, que nul ne pourra repousser,', 2),
((SELECT id FROM public.surahs WHERE number = 70), 3, 'مِّنَ اللَّهِ ذِي الْمَعَارِجِ', 'de la part d''Allah, le Maître des voies d''ascension.', 3),
((SELECT id FROM public.surahs WHERE number = 70), 4, 'تَعْرُجُ الْمَلَائِكَةُ وَالرُّوحُ إِلَيْهِ فِي يَوْمٍ كَانَ مِقْدَارُهُ خَمْسِينَ أَلْفَ سَنَةٍ', 'Les Anges et l''Esprit montent vers Lui en un Jour dont la durée est de cinquante mille ans.', 4),
((SELECT id FROM public.surahs WHERE number = 70), 5, 'فَاصْبِرْ صَبْرًا جَمِيلًا', 'Supporte donc avec une belle patience.', 5),
((SELECT id FROM public.surahs WHERE number = 70), 6, 'إِنَّهُمْ يَرَوْنَهُ بَعِيدًا', 'Ils le voient bien loin,', 6),
((SELECT id FROM public.surahs WHERE number = 70), 7, 'وَنَرَاهُ قَرِيبًا', 'alors que Nous le voyons bien proche.', 7),
((SELECT id FROM public.surahs WHERE number = 70), 8, 'يَوْمَ تَكُونُ السَّمَاءُ كَالْمُهْلِ', 'Le Jour où le ciel sera comme un métal en fusion,', 8),
((SELECT id FROM public.surahs WHERE number = 70), 9, 'وَتَكُونُ الْجِبَالُ كَالْعِهْنِ', 'et les montagnes comme de la laine cardée,', 9),
((SELECT id FROM public.surahs WHERE number = 70), 10, 'وَلَا يَسْأَلُ حَمِيمٌ حَمِيمًا', 'et qu''un ami ne posera pas de question à un ami,', 10),
((SELECT id FROM public.surahs WHERE number = 70), 11, 'يُبَصَّرُونَهُمْ ۚ يَوَدُّ الْمُجْرِمُ لَوْ يَفْتَدِي مِنْ عَذَابِ يَوْمَئِذٍ بِبَنِيهِ', 'bien qu''ils se voient. Le criminel aimerait se racheter du châtiment de ce Jour par ses enfants,', 11),
((SELECT id FROM public.surahs WHERE number = 70), 12, 'وَصَاحِبَتِهِ وَأَخِيهِ', 'et sa compagne, et son frère,', 12),
((SELECT id FROM public.surahs WHERE number = 70), 13, 'وَفَصِيلَتِهِ الَّتِي تُؤْوِيهِ', 'et son clan qui lui offrait un refuge,', 13),
((SELECT id FROM public.surahs WHERE number = 70), 14, 'وَمَن فِي الْأَرْضِ جَمِيعًا ثُمَّ يُنجِيهِ', 'et tous ceux qui sont sur la terre, pour se sauver.', 14),
((SELECT id FROM public.surahs WHERE number = 70), 15, 'كَلَّا ۖ إِنَّهَا لَظَىٰ', 'Jamais! Car c''est une Fournaise', 15),
((SELECT id FROM public.surahs WHERE number = 70), 16, 'نَزَّاعَةً لِّلشَّوَىٰ', 'qui arrache le cuir chevelu,', 16),
((SELECT id FROM public.surahs WHERE number = 70), 17, 'تَدْعُو مَنْ أَدْبَرَ وَتَوَلَّىٰ', 'qui appelle celui qui a tourné le dos et s''est détourné,', 17),
((SELECT id FROM public.surahs WHERE number = 70), 18, 'وَجَمَعَ فَأَوْعَىٰ', 'qui a amassé et thésaurisé.', 18),
((SELECT id FROM public.surahs WHERE number = 70), 19, 'إِنَّ الْإِنسَانَ خُلِقَ هَلُوعًا', 'L''homme a été créé anxieux;', 19),
((SELECT id FROM public.surahs WHERE number = 70), 20, 'إِذَا مَسَّهُ الشَّرُّ جَزُوعًا', 'qu''un mal le touche, il est affligé;', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 71: Nuh (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 71), 1, 'إِنَّا أَرْسَلْنَا نُوحًا إِلَىٰ قَوْمِهِ أَنْ أَنذِرْ قَوْمَكَ مِن قَبْلِ أَن يَأْتِيَهُمْ عَذَابٌ أَلِيمٌ', 'Nous avons envoyé Noé à son peuple: «Avertis ton peuple avant qu''un châtiment douloureux ne le frappe!»', 1),
((SELECT id FROM public.surahs WHERE number = 71), 2, 'قَالَ يَا قَوْمِ إِنِّي لَكُمْ نَذِيرٌ مُّبِينٌ', 'Il dit: «Ô mon peuple! Je suis pour vous un avertisseur clair:', 2),
((SELECT id FROM public.surahs WHERE number = 71), 3, 'أَنِ اعْبُدُوا اللَّهَ وَاتَّقُوهُ وَأَطِيعُونِ', 'Adorez Allah, craignez-Le et obéissez-moi,', 3),
((SELECT id FROM public.surahs WHERE number = 71), 4, 'يَغْفِرْ لَكُم مِّن ذُنُوبِكُمْ وَيُؤَخِّرْكُمْ إِلَىٰ أَجَلٍ مُّسَمًّى', 'Il vous pardonnera vos péchés et vous accordera un délai jusqu''au terme fixé.', 4),
((SELECT id FROM public.surahs WHERE number = 71), 5, 'قَالَ رَبِّ إِنِّي دَعَوْتُ قَوْمِي لَيْلًا وَنَهَارًا', 'Il dit: «Seigneur! J''ai appelé mon peuple nuit et jour,', 5),
((SELECT id FROM public.surahs WHERE number = 71), 6, 'فَلَمْ يَزِدْهُمْ دُعَائِي إِلَّا فِرَارًا', 'mais mon appel n''a fait qu''accroître leur fuite.', 6),
((SELECT id FROM public.surahs WHERE number = 71), 7, 'وَإِنِّي كُلَّمَا دَعَوْتُهُمْ لِتَغْفِرَ لَهُمْ جَعَلُوا أَصَابِعَهُمْ فِي آذَانِهِمْ', 'Et chaque fois que je les ai appelés pour que Tu leur pardonnes, ils ont mis leurs doigts dans leurs oreilles,', 7),
((SELECT id FROM public.surahs WHERE number = 71), 8, 'ثُمَّ إِنِّي دَعَوْتُهُمْ جِهَارًا', 'Puis je les ai appelés ouvertement,', 8),
((SELECT id FROM public.surahs WHERE number = 71), 9, 'ثُمَّ إِنِّي أَعْلَنتُ لَهُمْ وَأَسْرَرْتُ لَهُمْ إِسْرَارًا', 'puis je leur ai proclamé le message, et je les ai convoqués en secret.', 9),
((SELECT id FROM public.surahs WHERE number = 71), 10, 'فَقُلْتُ اسْتَغْفِرُوا رَبَّكُمْ إِنَّهُ كَانَ غَفَّارًا', 'J''ai dit: «Implorez le pardon de votre Seigneur, car Il est Pardonneur.', 10),
((SELECT id FROM public.surahs WHERE number = 71), 11, 'يُرْسِلِ السَّمَاءَ عَلَيْكُم مِّدْرَارًا', 'Il enverra le ciel sur vous en abondance de pluies,', 11),
((SELECT id FROM public.surahs WHERE number = 71), 12, 'وَيُمْدِدْكُم بِأَمْوَالٍ وَبَنِينَ وَيَجْعَل لَّكُمْ جَنَّاتٍ وَيَجْعَل لَّكُمْ أَنْهَارًا', 'vous dotera de biens et d''enfants, vous donnera des jardins et des rivières.', 12),
((SELECT id FROM public.surahs WHERE number = 71), 13, 'مَّا لَكُمْ لَا تَرْجُونَ لِلَّهِ وَقَارًا', 'Qu''avez-vous à ne pas espérer la majesté d''Allah,', 13),
((SELECT id FROM public.surahs WHERE number = 71), 14, 'وَقَدْ خَلَقَكُمْ أَطْوَارًا', 'alors qu''Il vous a créés par étapes successives?', 14),
((SELECT id FROM public.surahs WHERE number = 71), 15, 'أَلَمْ تَرَوْا كَيْفَ خَلَقَ اللَّهُ سَبْعَ سَمَاوَاتٍ طِبَاقًا', 'N''ont-ils pas vu comment Allah a créé sept cieux superposés,', 15),
((SELECT id FROM public.surahs WHERE number = 71), 16, 'وَجَعَلَ الْقَمَرَ فِيهِنَّ نُورًا وَجَعَلَ الشَّمْسَ سِرَاجًا', 'y a placé la lune comme lumière, et le soleil comme lampe?', 16),
((SELECT id FROM public.surahs WHERE number = 71), 17, 'وَاللَّهُ أَنبَتَكُم مِّنَ الْأَرْضِ نَبَاتًا', 'Et Allah vous a fait croître de la terre comme une plante,', 17),
((SELECT id FROM public.surahs WHERE number = 71), 18, 'ثُمَّ يُعِيدُكُمْ فِيهَا وَيُخْرِجُكُمْ إِخْرَاجًا', 'puis Il vous y fera retourner et vous en fera sortir.', 18),
((SELECT id FROM public.surahs WHERE number = 71), 19, 'وَاللَّهُ جَعَلَ لَكُمُ الْأَرْضَ بِسَاطًا', 'Et Allah a fait de la terre un tapis pour vous,', 19),
((SELECT id FROM public.surahs WHERE number = 71), 20, 'لِّتَسْلُكُوا مِنْهَا سُبُلًا فِجَاجًا', 'afin que vous y parcouriez des voies spacieuses.»', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

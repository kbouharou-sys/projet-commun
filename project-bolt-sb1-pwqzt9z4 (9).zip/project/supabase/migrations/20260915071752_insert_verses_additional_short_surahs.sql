/*
# Insert verses for additional short surahs (93-102)

## Purpose
Adds verse data for surahs 93-102 to provide a richer reading experience.
Arabic Uthmani text follows the standard Hafs reading. French translations
are well-established pre-translations.

## Surahs added:
- 93: Ad-Duha (11 verses)
- 94: Ash-Sharh (8 verses)
- 95: At-Tin (8 verses)
- 97: Al-Qadr (5 verses)
- 99: Az-Zalzala (8 verses)
- 100: Al-Adiyat (11 verses)
- 101: Al-Qaria (11 verses)
- 102: At-Takathur (8 verses)
*/

-- =========================================================
-- SURAH 93: Ad-Duha (11 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 93), 1,
'وَالضُّحَىٰ',
'Par le jour montant!',
1),
((SELECT id FROM public.surahs WHERE number = 93), 2,
'وَاللَّيْلِ إِذَا سَجَىٰ',
'Et par la nuit quand elle couvre tout!',
2),
((SELECT id FROM public.surahs WHERE number = 93), 3,
'مَا وَدَّعَكَ رَبُّكَ وَمَا قَلَىٰ',
'Ton Seigneur ne t''a ni abandonné, ni détesté.',
3),
((SELECT id FROM public.surahs WHERE number = 93), 4,
'وَلَلْآخِرَةُ خَيْرٌ لَّكَ مِنَ الْأُولَىٰ',
'Et certes, l''au-delà est meilleur pour toi que l''ici-bas.',
4),
((SELECT id FROM public.surahs WHERE number = 93), 5,
'وَلَسَوْفَ يُعْطِيكَ رَبُّكَ فَتَرْضَىٰ',
'Ton Seigneur t''accordera certes [des faveurs], alors que tu seras satisfait.',
5),
((SELECT id FROM public.surahs WHERE number = 93), 6,
'أَلَمْ يَجِدْكَ يَتِيمًا فَآوَىٰ',
'Ne t''a-t-Il pas trouvé orphelin? Alors Il t''a accueilli!',
6),
((SELECT id FROM public.surahs WHERE number = 93), 7,
'وَوَجَدَكَ ضَالًّا فَهَدَىٰ',
'Ne t''a-t-Il pas trouvé égaré? Alors Il t''a guidé.',
7),
((SELECT id FROM public.surahs WHERE number = 93), 8,
'وَوَجَدَكَ عَائِلًا فَأَغْنَىٰ',
'Ne t''a-t-Il pas trouvé pauvre? Alors Il t''a enrichi.',
8),
((SELECT id FROM public.surahs WHERE number = 93), 9,
'فَأَمَّا الْيَتِيمَ فَلَا تَقْهَرْ',
'Quant à l''orphelin, ne le maltraite pas.',
9),
((SELECT id FROM public.surahs WHERE number = 93), 10,
'وَأَمَّا السَّائِلَ فَلَا تَنْهَرْ',
'Et quant au demandeur, ne le repousse pas.',
10),
((SELECT id FROM public.surahs WHERE number = 93), 11,
'وَأَمَّا بِنِعْمَةِ رَبِّكَ فَحَدِّثْ',
'Et quant au bienfait de ton Seigneur, proclame-le.',
11)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 94: Ash-Sharh (8 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 94), 1,
'أَلَمْ نَشْرَحْ لَكَ صَدْرَكَ',
'N''avons-Nous pas ouvert pour toi ta poitrine?',
1),
((SELECT id FROM public.surahs WHERE number = 94), 2,
'وَوَضَعْنَا عَنكَ وِزْرَكَ',
'Et ne t''avons-Nous pas déchargé de ton fardeau',
2),
((SELECT id FROM public.surahs WHERE number = 94), 3,
'الَّذِي أَنقَضَ ظَهْرَكَ',
'qui pesait sur ton dos?',
3),
((SELECT id FROM public.surahs WHERE number = 94), 4,
'وَرَفَعْنَا لَكَ ذِكْرَكَ',
'Et exalté pour toi ta renommée?',
4),
((SELECT id FROM public.surahs WHERE number = 94), 5,
'فَإِنَّ مَعَ الْعُسْرِ يُسْرًا',
'Ainsi, à côté de la difficulté est, certes, une facilité!',
5),
((SELECT id FROM public.surahs WHERE number = 94), 6,
'إِنَّ مَعَ الْعُسْرِ يُسْرًا',
'A côté de la difficulté, est certes, une facilité!',
6),
((SELECT id FROM public.surahs WHERE number = 94), 7,
'فَإِذَا فَرَغْتَ فَانصَبْ',
'Quand tu as terminé, lève-toi et adore',
7),
((SELECT id FROM public.surahs WHERE number = 94), 8,
'وَإِلَىٰ رَبِّكَ فَارْغَب',
'et vers ton Seigneur aspire.',
8)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 95: At-Tin (8 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 95), 1,
'وَالتِّينِ وَالزَّيْتُونِ',
'Par le figuier et l''olivier!',
1),
((SELECT id FROM public.surahs WHERE number = 95), 2,
'وَطُورِ سِينِينَ',
'Et par le Mont Sinin!',
2),
((SELECT id FROM public.surahs WHERE number = 95), 3,
'وَهَٰذَا الْبَلَدِ الْأَمِينِ',
'Et par cette Cité sûre!',
3),
((SELECT id FROM public.surahs WHERE number = 95), 4,
'لَقَدْ خَلَقْنَا الْإِنْسَانَ فِي أَحْسَنِ تَقْوِيمٍ',
'Nous avons certes créé l''homme dans la forme la plus parfaite.',
4),
((SELECT id FROM public.surahs WHERE number = 95), 5,
'ثُمَّ رَدَدْنَاهُ أَسْفَلَ سَافِلِينَ',
'Ensuite, Nous l''avons ramené au plus bas degré.',
5),
((SELECT id FROM public.surahs WHERE number = 95), 6,
'إِلَّا الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ فَلَهُمْ أَجْرٌ غَيْرُ مَمْنُونٍ',
'sauf ceux qui croient et accomplissent les bonnes œuvres: ils auront une récompense jamais interrompue.',
6),
((SELECT id FROM public.surahs WHERE number = 95), 7,
'فَمَا يُكَذِّبُكَ بَعْدُ بِالدِّينِ',
'Après cela, qu''est-ce qui te fait traiter de mensonge la rétribution?',
7),
((SELECT id FROM public.surahs WHERE number = 95), 8,
'أَلَيْسَ اللَّهُ بِأَحْكَمِ الْحَاكِمِينَ',
'Allah n''est-Il pas le plus Sage des juges?',
8)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 97: Al-Qadr (5 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 97), 1,
'إِنَّا أَنزَلْنَاهُ فِي لَيْلَةِ الْقَدْرِ',
'Nous l''avons certes fait descendre (le Coran) pendant la nuit de la Destinée.',
1),
((SELECT id FROM public.surahs WHERE number = 97), 2,
'وَمَا أَدْرَاكَ مَا لَيْلَةُ الْقَدْرِ',
'Et qui te dira ce qu''est la nuit de la Destinée?',
2),
((SELECT id FROM public.surahs WHERE number = 97), 3,
'لَيْلَةُ الْقَدْرِ خَيْرٌ مِّنْ أَلْفِ شَهْرٍ',
'La nuit de la Destinée est meilleure que mille mois.',
3),
((SELECT id FROM public.surahs WHERE number = 97), 4,
'تَنَزَّلُ الْمَلَائِكَةُ وَالرُّوحُ فِيهَا بِإِذْنِ رَبِّهِم مِّن كُلِّ أَمْرٍ',
'Durant celle-ci descendent les Anges et l''Esprit, par la permission de leur Seigneur, pour tout ordre.',
4),
((SELECT id FROM public.surahs WHERE number = 97), 5,
'سَلَامٌ هِيَ حَتَّىٰ مَطْلَعِ الْفَجْرِ',
'Elle est paix et salut jusqu''à l''apparition de l''aube.',
5)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 99: Az-Zalzala (8 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 99), 1,
'إِذَا زُلْزِلَتِ الْأَرْضُ زِلْزَالَهَا',
'Quand la terre tremblera d''un violent tremblement,',
1),
((SELECT id FROM public.surahs WHERE number = 99), 2,
'وَأَخْرَجَتِ الْأَرْضُ أَثْقَالَهَا',
'et que la terre fera sortir ses fardeaux,',
2),
((SELECT id FROM public.surahs WHERE number = 99), 3,
'وَقَالَ الْإِنْسَانُ مَا لَهَا',
'et que l''homme dira: Qu''a-t-elle?',
3),
((SELECT id FROM public.surahs WHERE number = 99), 4,
'يَوْمَئِذٍ تُحَدِّثُ أَخْبَارَهَا',
'Ce Jour-là, elle contera son histoire,',
4),
((SELECT id FROM public.surahs WHERE number = 99), 5,
'بِأَنَّ رَبَّكَ أَوْحَىٰ لَهَا',
'en ceci que ton Seigneur lui aura inspiré.',
5),
((SELECT id FROM public.surahs WHERE number = 99), 6,
'يَوْمَئِذٍ يَصْدُرُ النَّاسُ أَشْتَاتًا لِّيُرَوْا أَعْمَالَهُمْ',
'Ce Jour-là, les hommes sortiront en groupes pour voir leurs œuvres.',
6),
((SELECT id FROM public.surahs WHERE number = 99), 7,
'فَمَن يَعْمَلْ مِثْقَالَ ذَرَّةٍ خَيْرًا يَرَهُ',
'Quiconque fait un bien fût-il du poids d''un atome, le verra,',
7),
((SELECT id FROM public.surahs WHERE number = 99), 8,
'وَمَن يَعْمَلْ مِثْقَالَ ذَرَّةٍ شَرًّا يَرَهُ',
'et quiconque fait un mal fût-il du poids d''un atome, le verra.',
8)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 100: Al-Adiyat (11 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 100), 1,
'وَالْعَادِيَاتِ ضَبْحًا',
'Par les coursiers qui halètent,',
1),
((SELECT id FROM public.surahs WHERE number = 100), 2,
'فَالْمُورِيَاتِ قَدْحًا',
'qui font jaillir des étincelles,',
2),
((SELECT id FROM public.surahs WHERE number = 100), 3,
'فَالْمُغِيرَاتِ صُبْحًا',
'qui attaquent au matin,',
3),
((SELECT id FROM public.surahs WHERE number = 100), 4,
'فَأَثَرْنَ بِهِ نَقْعًا',
'et font lever une poussière,',
4),
((SELECT id FROM public.surahs WHERE number = 100), 5,
'فَوَسَطْنَ بِهِ جَمْعًا',
'et pénètrent au centre de la masse ennemie.',
5),
((SELECT id FROM public.surahs WHERE number = 100), 6,
'إِنَّ الْإِنْسَانَ لِرَبِّهِ لَكَنُودٌ',
'L''homme est, certes, ingrat envers son Seigneur;',
6),
((SELECT id FROM public.surahs WHERE number = 100), 7,
'وَإِنَّهُ عَلَىٰ ذَٰلِكَ لَشَهِيدٌ',
'et certes, il en est témoin;',
7),
((SELECT id FROM public.surahs WHERE number = 100), 8,
'وَإِنَّهُ لِحُبِّ الْخَيْرِ لَشَدِيدٌ',
'et certes, son amour pour les biens est très vif.',
8),
((SELECT id FROM public.surahs WHERE number = 100), 9,
'أَفَلَا يَعْلَمُ إِذَا بُعْثِرَ مَا فِي الْقُبُورِ',
'Ne sait-il pas que, lorsque ce qui est dans les tombes sera bouleversé,',
9),
((SELECT id FROM public.surahs WHERE number = 100), 10,
'وَحُصِّلَ مَا فِي الصُّدُورِ',
'et que seront mis à nu ce qui est dans les poitrines,',
10),
((SELECT id FROM public.surahs WHERE number = 100), 11,
'إِنَّ رَبَّهُم بِهِمْ يَوْمَئِذٍ لَّخَبِيرٌ',
'ce Jour-là, leur Seigneur sera certes, Très-Parfaitement Informé d''eux.',
11)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 101: Al-Qaria (11 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 101), 1,
'الْقَارِعَةُ',
'Le fracas!',
1),
((SELECT id FROM public.surahs WHERE number = 101), 2,
'مَا الْقَارِعَةُ',
'Qu''est-ce que le fracas?',
2),
((SELECT id FROM public.surahs WHERE number = 101), 3,
'وَمَا أَدْرَاكَ مَا الْقَارِعَةُ',
'Et qui te dira ce qu''est le fracas?',
3),
((SELECT id FROM public.surahs WHERE number = 101), 4,
'يَوْمَ يَكُونُ النَّاسُ كَالْفَرَاشِ الْمَبْثُوثِ',
'Le Jour où les hommes seront comme des papillons dispersés,',
4),
((SELECT id FROM public.surahs WHERE number = 101), 5,
'وَتَكُونُ الْجِبَالُ كَالْعِهْنِ الْمَنْفُوشِ',
'et les montagnes comme de la laine cardée;',
5),
((SELECT id FROM public.surahs WHERE number = 101), 6,
'فَأَمَّا مَن ثَقُلَتْ مَوَازِينُهُ',
'quant à celui dont la balance sera lourde,',
6),
((SELECT id FROM public.surahs WHERE number = 101), 7,
'فَهُوَ فِي عِيشَةٍ رَّاضِيَةٍ',
'il sera dans une vie agréable;',
7),
((SELECT id FROM public.surahs WHERE number = 101), 8,
'وَأَمَّا مَنْ خَفَّتْ مَوَازِينُهُ',
'et quant à celui dont la balance sera légère,',
8),
((SELECT id FROM public.surahs WHERE number = 101), 9,
'فَأُمُّهُ هَاوِيَةٌ',
'sa mère [destination] est un abîme très profond.',
9),
((SELECT id FROM public.surahs WHERE number = 101), 10,
'وَمَا أَدْرَاكَ مَا هِيَهْ',
'Et qui te dira ce que c''est?',
10),
((SELECT id FROM public.surahs WHERE number = 101), 11,
'نَارٌ حَامِيَةٌ',
'Un Feu ardent.',
11)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 102: At-Takathur (8 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 102), 1,
'أَلْهَاكُمُ التَّكَاثُرُ',
'La course aux richesses vous distrait,',
1),
((SELECT id FROM public.surahs WHERE number = 102), 2,
'حَتَّىٰ زُرْتُمُ الْمَقَابِرَ',
'jusqu''à ce que vous visitiez les tombes.',
2),
((SELECT id FROM public.surahs WHERE number = 102), 3,
'كَلَّا سَوْفَ تَعْلَمُونَ',
'Non! Vous saurez bientôt!',
3),
((SELECT id FROM public.surahs WHERE number = 102), 4,
'ثُمَّ كَلَّا سَوْفَ تَعْلَمُونَ',
'Encore une fois, non! Vous saurez bientôt!',
4),
((SELECT id FROM public.surahs WHERE number = 102), 5,
'كَلَّا لَوْ تَعْلَمُونَ عِلْمَ الْيَقِينِ',
'Non! Si vous saviez de science certaine...',
5),
((SELECT id FROM public.surahs WHERE number = 102), 6,
'لَتَرَوُنَّ الْجَحِيمَ',
'Vous verrez, certes, la Fournaise.',
6),
((SELECT id FROM public.surahs WHERE number = 102), 7,
'ثُمَّ لَتَرَوُنَّهَا عَيْنَ الْيَقِينِ',
'Puis, vous la verrez certes, avec l''œil de la certitude.',
7),
((SELECT id FROM public.surahs WHERE number = 102), 8,
'ثُمَّ لَتُسْأَلُنَّ يَوْمَئِذٍ عَنِ النَّعِيمِ',
'Puis, assurément, ce Jour-là, vous serez interrogés sur les délices.',
8)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

/*
# Insert verses for surahs 8, 13, 14, 22, 24, 25

## Surahs added (first 20 verses each):
- 8: Al-Anfal
- 13: Ar-Ra'd
- 14: Ibrahim
- 22: Al-Hajj
- 24: An-Nur
- 25: Al-Furqan
*/

-- SURAH 8: Al-Anfal (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 8), 1, 'يَسْأَلُونَكَ عَنِ الْأَنفَالِ ۖ قُلِ الْأَنفَالُ لِلَّهِ وَالرَّسُولِ', 'Ils t''interrogent au sujet du butin. Dis: Le butin appartient à Allah et au Messager.', 1),
((SELECT id FROM public.surahs WHERE number = 8), 2, 'إِنَّمَا الْمُؤْمِنُونَ الَّذِينَ إِذَا ذُكِرَ اللَّهُ وَجِلَتْ قُلُوبُهُمْ', 'Les vrais croyants sont ceux dont les cœurs frémissent quand on évoque Allah,', 2),
((SELECT id FROM public.surahs WHERE number = 8), 3, 'الَّذِينَ يُقِيمُونَ الصَّلَاةَ وَمِمَّا رَزَقْنَاهُمْ يُنفِقُونَ', 'qui accomplissent la Salat et dépensent de ce que Nous leur avons octroyé.', 3),
((SELECT id FROM public.surahs WHERE number = 8), 4, 'أُولَٰئِكَ هُمُ الْمُؤْمِنُونَ حَقًّا ۚ لَهُمْ دَرَجَاتٌ عِندَ رَبِّهِمْ وَمَغْفِرَةٌ وَرِزْقٌ كَرِيمٌ', 'Ceux-là sont les vrais croyants. Ils ont des degrés auprès de leur Seigneur, un pardon et une subsistance généreuse.', 4),
((SELECT id FROM public.surahs WHERE number = 8), 5, 'كَمَا أَخْرَجَكَ رَبُّكَ مِن بَيْتِكَ بِالْحَقِّ', 'Comme ton Seigneur t''a fait sortir de ta demeure en toute vérité,', 5),
((SELECT id FROM public.surahs WHERE number = 8), 6, 'يُجَادِلُونَكَ فِي الْحَقِّ بَعْدَمَا تُبُيِّنَ كَأَنَّمَا يُسَاقُونَ إِلَى الْمَوْتِ وَهُمْ يَنظُرُونَ', 'Ils discutent avec toi au sujet de la vérité après qu''elle fut rendue claire, comme s''ils étaient menés à la mort en regardant.', 6),
((SELECT id FROM public.surahs WHERE number = 8), 7, 'وَإِذْ يَعِدُكُمُ اللَّهُ إِحْدَى الطَّائِفَتَيْنِ أَنَّهَا لَكُمْ', 'Et quand Allah vous promit qu''une des deux bandes serait à vous,', 7),
((SELECT id FROM public.surahs WHERE number = 8), 8, 'لِيُحِقَّ الْحَقَّ وَيُبْطِلَ الْبَاطِلَ وَلَوْ كَرِهَ الْمُجْرِمُونَ', 'pour faire triompher la vérité et anéantir le faux, quelque répulsion qu''en aient les criminels.', 8),
((SELECT id FROM public.surahs WHERE number = 8), 9, 'إِذْ تَسْتَغِيثُونَ رَبَّكُمْ فَاسْتَجَابَ لَكُمْ أَنِّي مُمِدُّكُم بِأَلْفٍ مِّنَ الْمَلَائِكَةِ مُرْدِفِينَ', 'Quand vous imploriez le secours de votre Seigneur, Il vous exauça: Je vous renforce de mille Anges qui se succèdent.', 9),
((SELECT id FROM public.surahs WHERE number = 8), 10, 'وَمَا جَعَلَهُ اللَّهُ إِلَّا بُشْرَىٰ وَلِتَطْمَئِنَّ بِهِ قُلُوبُكُمْ', 'Allah ne fit cela que comme bonne nouvelle et pour rassurer vos cœurs.', 10),
((SELECT id FROM public.surahs WHERE number = 8), 11, 'وَيُنزِلُ عَلَيْكُم مِّنَ السَّمَاءِ مَاءً لِّطَهْرٍ', 'Et Il fait descendre sur vous du ciel une eau pour vous purifier,', 11),
((SELECT id FROM public.surahs WHERE number = 8), 12, 'إِذْ يُوحِي رَبُّكَ إِلَى الْمَلَائِكَةِ أَنِّي مَعَكُمْ فَثَبِّتُوا الَّذِينَ آمَنُوا', 'Quand ton Seigneur révélait aux Anges: Je suis avec vous. Affermissez donc ceux qui ont cru.', 12),
((SELECT id FROM public.surahs WHERE number = 8), 13, 'ذَٰلِكَ بِأَنَّهُمْ شَاقُّوا اللَّهَ وَرَسُولَهُ ۚ وَمَن يُشَاقِقِ اللَّهَ وَرَسُولَهُ فَإِنَّ اللَّهَ شَدِيدُ الْعِقَابِ', 'C''est parce qu''ils se sont opposés à Allah et à Son Messager. Et quiconque s''oppose à Allah et à Son Messager, Allah est dur en punition.', 13),
((SELECT id FROM public.surahs WHERE number = 8), 14, 'ذَٰلِكُمْ فَذُوقُوهُ وَأَنَّ لِلْكَافِرِينَ عَذَابَ النَّارِ', 'Voilà pour vous! Goûtez-le! Et pour les infidèles, le châtiment du Feu.', 14),
((SELECT id FROM public.surahs WHERE number = 8), 15, 'يَا أَيُّهَا الَّذِينَ آمَنُوا إِذَا لَقِيتُمُ الَّذِينَ كَفَرُوا زَحْفًا فَلَا تُوَلُّوهُمُ الْأَدْبَارَ', 'Ô vous qui avez cru! Quand vous rencontrez les infidèles en marche, ne leur tournez pas le dos.', 15),
((SELECT id FROM public.surahs WHERE number = 8), 16, 'وَمَن يُوَلِّهِمْ يَوْمَئِذٍ دُبُرَهُ إِلَّا مُتَحَرِّفًا لِّقِتَالٍ أَوْ مُتَحَيِّزًا إِلَىٰ فِئَةٍ', 'Quiconque leur tourne le dos ce Jour-là, sauf pour revenir au combat ou pour rejoindre un groupe,', 16),
((SELECT id FROM public.surahs WHERE number = 8), 17, 'فَقَدْ بَاءَ بِغَضَبٍ مِّنَ اللَّهِ وَمَأْوَاهُ جَهَنَّمُ ۖ وَبِئْسَ الْمَصِيرُ', 'encourt la colère d''Allah, et son refuge sera l''Enfer. Et quelle mauvaise destination!', 17),
((SELECT id FROM public.surahs WHERE number = 8), 18, 'فَلَمْ تَقْتُلُوهُمْ وَلَٰكِنَّ اللَّهَ قَتَلَهُمْ', 'Ce n''est pas vous qui les avez tués, mais c''est Allah qui les a tués.', 18),
((SELECT id FROM public.surahs WHERE number = 8), 19, 'وَمَا رَمَيْتَ إِذْ رَمَيْتَ وَلَٰكِنَّ اللَّهَ رَمَىٰ', 'Et tu n''as pas lancé quand tu as lancé, mais c''est Allah qui a lancé.', 19),
((SELECT id FROM public.surahs WHERE number = 8), 20, 'يَا أَيُّهَا الَّذِينَ آمَنُوا أَطِيعُوا اللَّهَ وَرَسُولَهُ وَلَا تَوَلَّوْا عَنْهُ وَأَنتُمْ تَسْمَعُونَ', 'Ô vous qui avez cru! Obéissez à Allah et à Son Messager, et ne vous détournez pas alors que vous entendez.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 13: Ar-Ra'd (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 13), 1, 'المر ۚ تِلْكَ آيَاتُ الْكِتَابِ ۗ وَالَّذِي أُنزِلَ إِلَيْكَ مِن رَّبِّكَ الْحَقُّ', 'Alif Lam Mim Ra. Voici les versets du Livre. Ce qui t''est révélé par ton Seigneur est la vérité,', 1),
((SELECT id FROM public.surahs WHERE number = 13), 2, 'اللَّهُ الَّذِي رَفَعَ السَّمَاوَاتِ بِغَيْرِ عَمَدٍ تَرَوْنَهَا', 'Allah qui a élevé les cieux sans piliers que vous puissiez voir,', 2),
((SELECT id FROM public.surahs WHERE number = 13), 3, 'وَهُوَ الَّذِي مَدَّ الْأَرْضَ وَجَعَلَ فِيهَا رَوَاسِيَ وَأَنْهَارًا', 'C''est Lui qui a étendu la terre, y a placé des montagnes et des rivières,', 3),
((SELECT id FROM public.surahs WHERE number = 13), 4, 'وَفِي الْأَرْضِ قِطَعٌ مُّتَجَاوِرَاتٌ وَجَنَّاتٌ مِّنْ أَعْنَابٍ', 'Et sur la terre, il y a des parcelles voisines, des jardins de vignes,', 4),
((SELECT id FROM public.surahs WHERE number = 13), 5, 'وَإِن تَعْجَبْ فَعَجَبٌ قَوْلُهُمْ أَإِذَا كُنَّا تُرَابًا أَإِنَّا لَفِي خَلْقٍ جَدِيدٍ', 'Si tu t''étonnes, ce qu''il y a de plus étonnant, c''est leur parole: Quand nous serons poussière, serons-nous recréés?', 5),
((SELECT id FROM public.surahs WHERE number = 13), 6, 'وَيَسْتَعْجِلُونَكَ بِالسَّيِّئَةِ قَبْلَ الْحَسَنَةِ', 'Ils te demandent de hâter le mal avant le bien,', 6),
((SELECT id FROM public.surahs WHERE number = 13), 7, 'وَيَقُولُ الَّذِينَ كَفَرُوا لَوْلَا أُنزِلَ عَلَيْهِ آيَةٌ مِّن رَّبِّهِ', 'Et ceux qui ont mécru disent: Pourquoi n''a-t-on pas fait descendre sur lui un signe de son Seigneur?', 7),
((SELECT id FROM public.surahs WHERE number = 13), 8, 'اللَّهُ يَعْلَمُ مَا تَحْمِلُ كُلُّ أُنثَىٰ وَمَا تَغِيضُ الْأَرْحَامُ', 'Allah sait ce que porte toute femelle et ce que les matrices diminuent ou augmentent.', 8),
((SELECT id FROM public.surahs WHERE number = 13), 9, 'عَالِمُ الْغَيْبِ وَالشَّهَادَةِ الْكَبِيرُ الْمُتَعَالِ', 'Le Connaisseur du monde invisible et visible, le Grand, le Très Sublime.', 9),
((SELECT id FROM public.surahs WHERE number = 13), 10, 'سَوَاءٌ مِّنكُم مَّنْ أَسَرَّ الْقَوْلَ وَمَنْ جَهَرَ بِهِ', 'Il est le même pour vous, que vous cachiez la parole ou la divulguiez,', 10),
((SELECT id FROM public.surahs WHERE number = 13), 11, 'لَهُ مُعَقِّبَاتٌ مِّن بَيْنِ يَدَيْهِ وَمِنْ خَلْفِهِ يَحْفَظُونَهُ مِنْ أَمْرِ اللَّهِ', 'Il a des gardiens par-devant et par-derrière qui le protègent par ordre d''Allah.', 11),
((SELECT id FROM public.surahs WHERE number = 13), 12, 'هُوَ الَّذِي يُرِيكُمُ الْبَرْقَ خَوْفًا وَطَمَعًا وَيُنشِئُ السَّحَابَ الثِّقَالَ', 'C''est Lui qui vous montre l''éclair, crainte et espérance, qui fait naître les nuages lourds.', 12),
((SELECT id FROM public.surahs WHERE number = 13), 13, 'وَيُسَبِّحُ الرَّعْدُ بِحَمْدِهِ وَالْمَلَائِكَةُ مِنْ خِيفَتِهِ', 'Le tonnerre Le glorifie par Sa louange, et les Anges aussi, par crainte.', 13),
((SELECT id FROM public.surahs WHERE number = 13), 14, 'لَهُ دَعْوَةُ الْحَقِّ ۚ وَالَّذِينَ يَدْعُونَ مِن دُونِهِ لَا يَسْتَجِيبُونَ لَهُ بِشَيْءٍ', 'À Lui l''invocation de la vérité. Ceux qu''ils invoquent en dehors de Lui ne répondent en rien.', 14),
((SELECT id FROM public.surahs WHERE number = 13), 15, 'وَلِلَّهِ يَسْجُدُ مَن فِي السَّمَاوَاتِ وَالْأَرْضِ طَوْعًا وَكَرْهًا', 'À Allah se prosterne quiconque est dans les cieux et sur la terre, de bon gré ou de force.', 15),
((SELECT id FROM public.surahs WHERE number = 13), 16, 'قُلْ مَن رَّبُّ السَّمَاوَاتِ وَالْأَرْضِ قُلِ اللَّهُ', 'Dis: Qui est le Seigneur des cieux et de la terre? Dis: Allah.', 16),
((SELECT id FROM public.surahs WHERE number = 13), 17, 'أَنزَلَ مِنَ السَّمَاءِ مَاءً فَسَالَتْ أَوْدِيَةٌ بِقَدَرِهَا', 'Il a fait descendre du ciel une eau, et les vallées ont coulé selon leur mesure.', 17),
((SELECT id FROM public.surahs WHERE number = 13), 18, 'لِلَّذِينَ اسْتَجَابُوا لِرَبِّهِمُ الْحُسْنَىٰ ۚ وَالَّذِينَ لَمْ يَسْتَجِيبُوا لَهُ', 'Pour ceux qui ont répondu à leur Seigneur, le meilleur. Et pour ceux qui ne L''ont pas répondu,', 18),
((SELECT id FROM public.surahs WHERE number = 13), 19, 'أَفَمَن يَعْلَمُ أَنَّمَا أُنزِلَ إِلَيْكَ مِن رَّبِّكَ الْحَقُّ كَمَنْ هُوَ أَعْمَىٰ', 'Celui qui sait que ce qui t''est révélé par ton Seigneur est la vérité est-il comme l''aveugle?', 19),
((SELECT id FROM public.surahs WHERE number = 13), 20, 'الَّذِينَ يُوفُونَ بِعَهْدِ اللَّهِ وَلَا يَنقُضُونَ الْمِيثَاقَ', 'Ceux qui honorent le pacte d''Allah et ne violent pas le serment.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 14: Ibrahim (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 14), 1, 'الر ۚ كِتَابٌ أَنزَلْنَاهُ إِلَيْكَ لِتُخْرِجَ النَّاسَ مِنَ الظُّلُمَاتِ إِلَى النُّورِ', 'Alif Lam Ra. Un Livre que Nous t''avons révélé pour faire sortir les hommes des ténèbres à la lumière,', 1),
((SELECT id FROM public.surahs WHERE number = 14), 2, 'بِإِذْنِ رَبِّهِمْ إِلَىٰ صِرَاطِ الْعَزِيزِ الْحَمِيدِ', 'par la permission de leur Seigneur, vers le chemin du Tout-Puissant, le Digne de louange.', 2),
((SELECT id FROM public.surahs WHERE number = 14), 3, 'الَّذِينَ يَسْتَحِبُّونَ الْحَيَاةَ الدُّنْيَا عَلَى الْآخِرَةِ', 'Ceux qui préfèrent la vie d''ici-bas à l''au-delà,', 3),
((SELECT id FROM public.surahs WHERE number = 14), 4, 'وَمَا أَرْسَلْنَا مِن رَّسُولٍ إِلَّا بِلِسَانِ قَوْمِهِ', 'Nous n''avons envoyé aucun Messager sans qu''il parlât la langue de son peuple,', 4),
((SELECT id FROM public.surahs WHERE number = 14), 5, 'وَلَقَدْ أَرْسَلْنَا مُوسَىٰ بِآيَاتِنَا أَنْ أَخْرِجْ قَوْمَكَ مِنَ الظُّلُمَاتِ إِلَى النُّورِ', 'Nous avons envoyé Moïse avec Nos signes: Fais sortir ton peuple des ténèbres à la lumière.', 5),
((SELECT id FROM public.surahs WHERE number = 14), 6, 'وَإِذْ قَالَ مُوسَىٰ لِقَوْمِهِ اذْكُرُوا نِعْمَتَ اللَّهِ عَلَيْكُمْ', 'Et quand Moïse dit à son peuple: Rappelez-vous le bienfait d''Allah sur vous,', 6),
((SELECT id FROM public.surahs WHERE number = 14), 7, 'وَإِذْ تَأَذَّنَ رَبُّكُمْ لَئِن شَكَرْتُمْ لَأَزِيدَنَّكُمْ', 'Et quand votre Seigneur proclama: Si vous êtes reconnaissants, Je vous accorderai plus,', 7),
((SELECT id FROM public.surahs WHERE number = 14), 8, 'وَلَئِن كَفَرْتُمْ إِنَّ عَذَابِي لَشَدِيدٌ', 'mais si vous êtes ingrats, Mon châtiment est sévère.', 8),
((SELECT id FROM public.surahs WHERE number = 14), 9, 'أَلَمْ يَأْتِكُمْ نَبَأُ الَّذِينَ مِن قَبْلِكُمْ قَوْمِ نُوحٍ وَعَادٍ وَثَمُودَ', 'Ne vous est-il pas parvenu le récit de ceux avant vous, le peuple de Noé, les Aad, les Thamud?', 9),
((SELECT id FROM public.surahs WHERE number = 14), 10, 'قَالَتْ لَهُمْ رُسُلُهُمْ إِن نَّحْنُ إِلَّا بَشَرٌ مِّثْلُكُمْ', 'Leurs Messagers dirent: Nous ne sommes que des humains comme vous,', 10),
((SELECT id FROM public.surahs WHERE number = 14), 11, 'قَالَتْ لَهُمْ رُسُلُهُمْ إِن نَّحْنُ إِلَّا بَشَرٌ مِّثْلُكُمْ وَلَٰكِنَّ اللَّهَ يَمُنُّ عَلَىٰ مَن يَشَاءُ مِنْ عِبَادِهِ', 'Leurs Messagers dirent: Nous ne sommes que des humains comme vous, mais Allah accorde Sa grâce à qui Il veut parmi Ses serviteurs.', 11),
((SELECT id FROM public.surahs WHERE number = 14), 12, 'وَمَا لَنَا أَلَّا نَتَوَكَّلَ عَلَى اللَّهِ وَقَدْ هَدَانَا سُبُلَنَا', 'Pourquoi ne pas nous en remettre à Allah, alors qu''Il nous a guidés sur nos voies?', 12),
((SELECT id FROM public.surahs WHERE number = 14), 13, 'وَقَالَ الَّذِينَ كَفَرُوا لِرُسُلِهِمْ لَنُخْرِجَنَّكُم مِّنْ أَرْضِنَا', 'Et ceux qui ont mécru dirent à leurs Messagers: Nous vous expulserons de notre terre,', 13),
((SELECT id FROM public.surahs WHERE number = 14), 14, 'أَوْ لَتَعُودُنَّ فِي مِلَّتِنَا', 'à moins que vous ne reveniez à notre religion.', 14),
((SELECT id FROM public.surahs WHERE number = 14), 15, 'وَأَوْحَىٰ رَبُّكَ إِلَى الْمَلَائِكَةِ أَنِّي مَعَكُمْ فَثَبِّتُوا الَّذِينَ آمَنُوا', 'Et ton Seigneur révéla aux Anges: Je suis avec vous. Affermissez les croyants.', 15),
((SELECT id FROM public.surahs WHERE number = 14), 16, 'قَالَ مُوسَىٰ رَبَّنَا إِنَّكَ آتَيْتَ فِرْعَوْنَ وَمَلَأَهُ زِينَةً وَأَمْوَالًا', 'Moïse dit: Seigneur! Tu as accordé à Pharaon et à ses notables des parures et des biens,', 16),
((SELECT id FROM public.surahs WHERE number = 14), 17, 'فَأَخَذَهُمُ اللَّهُ بِذُنُوبِهِمْ', 'Allah les saisit donc pour leurs péchés.', 17),
((SELECT id FROM public.surahs WHERE number = 14), 18, 'مَثَلُ الَّذِينَ كَفَرُوا رَبُّهُمْ أَعْمَالُهُمْ كَرَمَادٍ اشْتَدَّتْ بِهِ الرِّيحُ', 'Les œuvres de ceux qui ont mécru en leur Seigneur sont comme de la cendre frappée par le vent.', 18),
((SELECT id FROM public.surahs WHERE number = 14), 19, 'أَلَمْ تَرَ أَنَّ اللَّهَ خَلَقَ السَّمَاوَاتِ وَالْأَرْضَ بِالْحَقِّ', 'Ne vois-tu pas qu''Allah a créé les cieux et la terre en toute vérité?', 19),
((SELECT id FROM public.surahs WHERE number = 14), 20, 'إِن يَشَأْ يُذْهِبْكُمْ وَيَأْتِ بِخَلْقٍ جَدِيدٍ', 'S''Il veut, Il vous fait disparaître et fait venir une nouvelle création.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 22: Al-Hajj (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 22), 1, 'يَا أَيُّهَا النَّاسُ اتَّقُوا رَبَّكُمْ ۚ إِنَّ زَلْزَلَةَ السَّاعَةِ شَيْءٌ عَظِيمٌ', 'Ô hommes! Craignez votre Seigneur. Le séisme de l''Heure est une chose terrible.', 1),
((SELECT id FROM public.surahs WHERE number = 22), 2, 'يَوْمَ تَرَوْنَهَا تَذْهَلُ كُلُّ مُرْضِعَةٍ عَمَّا أَرْضَعَتْ', 'Le Jour où vous le verrez, toute nourrice oubliera son nourrisson,', 2),
((SELECT id FROM public.surahs WHERE number = 22), 3, 'وَمِنَ النَّاسِ مَن يُجَادِلُ فِي اللَّهِ بِغَيْرِ عِلْمٍ', 'Parmi les hommes, il en est qui discutent sur Allah sans science,', 3),
((SELECT id FROM public.surahs WHERE number = 22), 4, 'عَنْهُ ضَلَّ وَلِكُلِّ شَيْطَانٍ مَّرِيدٍ', 'et suivent tout démon rebelle.', 4),
((SELECT id FROM public.surahs WHERE number = 22), 5, 'يَا أَيُّهَا النَّاسُ إِن كُنتُمْ فِي رَيْبٍ مِّنَ الْبَعْثِ', 'Ô hommes! Si vous doutez de la résurrection,', 5),
((SELECT id FROM public.surahs WHERE number = 22), 6, 'ذَٰلِكَ بِأَنَّ اللَّهَ هُوَ الْحَقُّ وَأَنَّهُ يُحْيِي الْمَوْتَىٰ', 'C''est parce qu''Allah est la Vérité et qu''Il fait revivre les morts,', 6),
((SELECT id FROM public.surahs WHERE number = 22), 7, 'وَأَنَّ السَّاعَةَ آتِيَةٌ لَّا رَيْبَ فِيهَا', 'et que l''Heure vient, sans doute, et qu''Allah ressuscite ceux des tombes.', 7),
((SELECT id FROM public.surahs WHERE number = 22), 8, 'وَمِنَ النَّاسِ مَن يُجَادِلُ فِي اللَّهِ بِغَيْرِ عِلْمٍ وَلَا هُدًى وَلَا كِتَابٍ مُّنِيرٍ', 'Parmi les hommes, il en est qui discutent sur Allah sans science, ni guidée, ni Livre lumineux.', 8),
((SELECT id FROM public.surahs WHERE number = 22), 9, 'ثَانِيَ عِطْفِهِ لِيُضِلَّ عَن سَبِيلِ اللَّهِ', 'se détournant avec orgueil pour égarer du sentier d''Allah.', 9),
((SELECT id FROM public.surahs WHERE number = 22), 10, 'ذَٰلِكَ بِأَنَّهُ أَجْرَمَتْ كُلَّ مَن تَوَلَّىٰ وَأَعْرَضَ', 'C''est parce que chacun qui tourne le dos et s''enorgueillit est coupable.', 10),
((SELECT id FROM public.surahs WHERE number = 22), 11, 'وَمِنَ النَّاسِ مَن يَعْبُدُ اللَّهَ عَلَىٰ حَرْفٍ', 'Parmi les hommes, il en est qui adorent Allah sur le bord.', 11),
((SELECT id FROM public.surahs WHERE number = 22), 12, 'فَإِنْ أَصَابَهُ خَيْرٌ اطْمَأَنَّ بِهِ', 'Si un bien le touche, il s''en tranquillise;', 12),
((SELECT id FROM public.surahs WHERE number = 22), 13, 'وَإِنْ أَصَابَتْهُ فِتْنَةٌ انقَلَبَ عَلَىٰ وَجْهِهِ', 'et si une épreuve le frappe, il se retourne sur sa face,', 13),
((SELECT id FROM public.surahs WHERE number = 22), 14, 'إِنَّ اللَّهَ يُدْخِلُ الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ جَنَّاتٍ', 'Allah fait entrer ceux qui croient et font le bien dans des Jardins', 14),
((SELECT id FROM public.surahs WHERE number = 22), 15, 'مَن كَانَ يَظُنُّ أَن لَّن يَنصُرَهُ اللَّهُ فِي الدُّنْيَا وَالْآخِرَةِ', 'Quiconque pensait qu''Allah ne le secourrait pas, ni ici-bas ni dans l''au-delà...', 15),
((SELECT id FROM public.surahs WHERE number = 22), 16, 'وَكَذَٰلِكَ أَنزَلْنَاهُ آيَاتٍ بَيِّنَاتٍ', 'C''est ainsi que Nous l''avons fait descendre en versets clairs.', 16),
((SELECT id FROM public.surahs WHERE number = 22), 17, 'إِنَّ الَّذِينَ آمَنُوا وَالَّذِينَ هَادُوا وَالصَّابِئِينَ وَالنَّصَارَىٰ', 'Ceux qui ont cru, les juifs, les Sabéens, les Nazaréens,', 17),
((SELECT id FROM public.surahs WHERE number = 22), 18, 'أَلَمْ تَرَ أَنَّ اللَّهَ يَسْجُدُ لَهُ مَن فِي السَّمَاوَاتِ وَمَن فِي الْأَرْضِ', 'Ne vois-tu pas qu''à Allah se prosterne quiconque est dans les cieux et sur la terre?', 18),
((SELECT id FROM public.surahs WHERE number = 22), 19, 'هَٰذَانِ خَصْمَانِ اخْتَصَمُوا فِي رَبِّهِمْ', 'Voici deux adversaires qui disputent au sujet de leur Seigneur.', 19),
((SELECT id FROM public.surahs WHERE number = 22), 20, 'فَالَّذِينَ كَفَرُوا قُطِّعَتْ لَهُمْ ثِيَابٌ مِّن نَّارٍ', 'Ceux qui ont mécru, on leur taillera des vêtements de feu.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 24: An-Nur (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 24), 1, 'سُورَةٌ أَنزَلْنَاهَا وَفَرَضْنَاهَا وَأَنزَلْنَا فِيهَا آيَاتٍ بَيِّنَاتٍ', 'Une sourate que Nous avons fait descendre et prescrite, et y avons fait descendre des versets clairs', 1),
((SELECT id FROM public.surahs WHERE number = 24), 2, 'الزَّانِيَةُ وَالزَّانِي فَاجْلِدُوا كُلَّ وَاحِدٍ مِّنْهُمَا مِائَةَ جَلْدَةٍ', 'La fornicatrice et le fornicateur, fouettez chacun d''eux de cent coups de fouet.', 2),
((SELECT id FROM public.surahs WHERE number = 24), 3, 'الزَّانِي لَا يَنكِحُ إِلَّا زَانِيَةً أَوْ مُشْرِكَةً', 'Le fornicateur n''épouse qu''une fornicatrice ou une associatrice,', 3),
((SELECT id FROM public.surahs WHERE number = 24), 4, 'وَالَّذِينَ يَرْمُونَ الْمُحْصَنَاتِ ثُمَّ لَمْ يَأْتُوا بِأَرْبَعَةِ شُهَدَاءَ', 'Et ceux qui accusent les femmes honorées sans produire quatre témoins,', 4),
((SELECT id FROM public.surahs WHERE number = 24), 5, 'فَاجْلِدُوهُمْ ثَمَانِينَ جَلْدَةً وَلَا تَقْبَلُوا لَهُمْ شَهَادَةً أَبَدًا', 'fouettez-les de quatre-vingts coups et n''acceptez plus leur témoignage jamais.', 5),
((SELECT id FROM public.surahs WHERE number = 24), 6, 'وَالَّذِينَ يَرْمُونَ أَزْوَاجَهُمْ وَلَمْ يَكُن لَّهُمْ شُهَدَاءُ إِلَّا أَنفُسُهُمْ', 'Et ceux qui accusent leurs épouses sans avoir de témoins autres qu''eux-mêmes,', 6),
((SELECT id FROM public.surahs WHERE number = 24), 7, 'فَشَهَادَةُ أَحَدِهِمْ أَرْبَعُ شَهَادَاتٍ بِاللَّهِ أَنَّهُ لَمِنَ الصَّادِقِينَ', 'le témoignage de chacun sera quatre témoignages par Allah qu''il est véridique,', 7),
((SELECT id FROM public.surahs WHERE number = 24), 8, 'وَالْخَامِسَةُ أَنَّ لَعْنَتَ اللَّهِ عَلَيْهِ إِن كَانَ مِنَ الْكَاذِبِينَ', 'et le cinquième: que la malédiction d''Allah soit sur lui s''il est menteur.', 8),
((SELECT id FROM public.surahs WHERE number = 24), 9, 'وَيَدْرَأُ عَنْهَا الْعَذَابَ أَنْ تَشْهَدَ أَرْبَعَ شَهَادَاتٍ بِاللَّهِ', 'Et elle sera préservée du châtiment si elle témoigne quatre fois par Allah', 9),
((SELECT id FROM public.surahs WHERE number = 24), 10, 'وَالْخَامِسَةَ أَنَّ غَضَبَ اللَّهِ عَلَيْهَا إِن كَانَ مِنَ الصَّادِقِينَ', 'et le cinquième: que la colère d''Allah soit sur elle s''il est véridique.', 10),
((SELECT id FROM public.surahs WHERE number = 24), 11, 'إِنَّ الَّذِينَ جَاءُوا بِالْإِفْكِ عُصْبَةٌ مِّنكُمْ', 'Ceux qui ont colporté la calomnie sont un groupe parmi vous.', 11),
((SELECT id FROM public.surahs WHERE number = 24), 12, 'لَوْلَا إِذْ سَمِعْتُمُوهُ ظَنَّ الْمُؤْمِنُونَ وَالْمُؤْمِنَاتُ بِأَنفُسِهِمْ خَيْرًا', 'Si, quand vous l''avez entendue, les croyants et les croyantes avaient pensé du bien d''eux-mêmes,', 12),
((SELECT id FROM public.surahs WHERE number = 24), 13, 'لَوْلَا جَاءُوا عَلَيْهِ بِأَرْبَعَةِ شُهَدَاءَ', 'ils auraient dit: Produisez quatre témoins!', 13),
((SELECT id FROM public.surahs WHERE number = 24), 14, 'وَلَوْلَا فَضْلُ اللَّهِ عَلَيْكُمْ فِي الدُّنْيَا وَالْآخِرَةِ', 'N''eût été la grâce d''Allah sur vous, ici-bas et dans l''au-delà,', 14),
((SELECT id FROM public.surahs WHERE number = 24), 15, 'إِذْ تَلَقَّوْنَهُ بِأَلْسِنَتِكُمْ وَتَقُولُونَ بِأَفْوَاهِكُم مَّا لَيْسَ لَكُم بِهِ عِلْمٌ', 'quand vous colportiez de vos langues et disiez de vos bouches ce dont vous n''aviez nulle science,', 15),
((SELECT id FROM public.surahs WHERE number = 24), 16, 'وَلَوْلَا إِذْ سَمِعْتُمُوهُ قُلْتُم مَّا يَكُونُ لَنَا أَن نَّتَكَلَّمَ بِهَٰذَا', 'Si, quand vous l''avez entendue, vous aviez dit: Il ne nous appartient pas d''en parler.', 16),
((SELECT id FROM public.surahs WHERE number = 24), 17, 'يَعِظُكُمُ اللَّهُ أَن تَعُودُوا لِمِثْلِهِ أَبَدًا إِن كُنتُم مُّؤْمِنِينَ', 'Allah vous exhorte à ne jamais revenir à pareille chose, si vous êtes croyants.', 17),
((SELECT id FROM public.surahs WHERE number = 24), 18, 'وَاللَّهُ يُبَيِّنُ لَكُمُ الْآيَاتِ ۚ وَاللَّهُ عَلِيمٌ حَكِيمٌ', 'Allah vous expose les signes. Allah est Omniscient, Sage.', 18),
((SELECT id FROM public.surahs WHERE number = 24), 19, 'إِنَّ الَّذِينَ يُحِبُّونَ أَن تَشِيعَ الْفَاحِشَةُ فِي الَّذِينَ آمَنُوا', 'Ceux qui aiment que la turpitude se propage parmi les croyants,', 19),
((SELECT id FROM public.surahs WHERE number = 24), 20, 'لَهُمْ فِي الدُّنْيَا عَذَابٌ أَلِيمٌ', 'auront un châtiment douloureux ici-bas et dans l''au-delà.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 25: Al-Furqan (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 25), 1, 'تَبَارَكَ الَّذِي نَزَّلَ الْفُرْقَانَ عَلَىٰ عَبْدِهِ لِيَكُونَ لِلْعَالَمِينَ نَذِيرًا', 'Béni soit Celui qui a fait descendre le Discernement sur Son serviteur, pour qu''il soit un avertisseur pour l''univers.', 1),
((SELECT id FROM public.surahs WHERE number = 25), 2, 'الَّذِي لَهُ مُلْكُ السَّمَاوَاتِ وَالْأَرْضِ وَلَمْ يَتَّخِذْ وَلَدًا', 'À Lui appartient la royauté des cieux et de la terre, Il n''a pas pris de fils,', 2),
((SELECT id FROM public.surahs WHERE number = 25), 3, 'وَلَمْ يَكُن لَّهُ شَرِيكٌ فِي الْمُلْكِ وَخَلَقَ كُلَّ شَيْءٍ فَقَدَّرَهُ تَقْدِيرًا', 'n''a pas d''associé dans la royauté, a créé toute chose et l''a décrétée en détail.', 3),
((SELECT id FROM public.surahs WHERE number = 25), 4, 'وَاتَّخَذُوا مِن دُونِهِ آلِهَةً لَّا يَخْلُقُونَ شَيْئًا وَهُمْ يُخْلَقُونَ', 'Et ils ont pris en dehors de Lui des divinités qui ne créent rien et sont créées,', 4),
((SELECT id FROM public.surahs WHERE number = 25), 5, 'وَلَا يَمْلِكُونَ لِأَنفُسِهِمْ ضَرًّا وَلَا نَفْعًا', 'et ne possèdent pour elles-mêmes ni nuisance ni utilité,', 5),
((SELECT id FROM public.surahs WHERE number = 25), 6, 'وَلَا يَمْلِكُونَ مَوْتًا وَلَا حَيَاةً وَلَا نُشُورًا', 'et ne possèdent ni mort, ni vie, ni résurrection.', 6),
((SELECT id FROM public.surahs WHERE number = 25), 7, 'وَقَالَ الَّذِينَ كَفَرُوا إِنْ هَٰذَا إِلَّا إِفْكٌ افْتَرَاهُ', 'Et ceux qui ont mécru disent: Ce n''est qu''un mensonge qu''il a forgé,', 7),
((SELECT id FROM public.surahs WHERE number = 25), 8, 'وَأَعَانَهُ عَلَيْهِ قَوْمٌ آخَرُونَ', 'et d''autres gens l''ont aidé.', 8),
((SELECT id FROM public.surahs WHERE number = 25), 9, 'فَقَدْ جَاءُوا ظُلْمًا وَزُورًا', 'Ils ont donc commis injustice et proféré un mensonge.', 9),
((SELECT id FROM public.surahs WHERE number = 25), 10, 'وَقَالُوا أَسَاطِيرُ الْأَوَّلِينَ اكْتَتَبَهَا فَهِيَ تُمْلَىٰ عَلَيْهِ بُكْرَةً وَأَصِيلًا', 'Et ils disent: Des contes des anciens qu''il s''est fait écrire, et qui lui sont dictés matin et soir.', 10),
((SELECT id FROM public.surahs WHERE number = 25), 11, 'قُلْ أَنزَلَهُ الَّذِي يَعْلَمُ السِّرَّ فِي السَّمَاوَاتِ وَالْأَرْضِ', 'Dis: L''a fait descendre Celui qui connaît le secret dans les cieux et la terre.', 11),
((SELECT id FROM public.surahs WHERE number = 25), 12, 'إِنَّهُ كَانَ حَلِيمًا غَفُورًا', 'C''est Lui qui est Indulgent, Pardonneur.', 12),
((SELECT id FROM public.surahs WHERE number = 25), 13, 'وَقَالُوا مَالِ هَٰذَا الرَّسُولِ يَأْكُلُ الطَّعَامَ وَيَمْشِي فِي الْأَسْوَاقِ', 'Et ils disent: Qu''a ce Messager à manger la nourriture et à marcher dans les marchés?', 13),
((SELECT id FROM public.surahs WHERE number = 25), 14, 'لَوْلَا أُنزِلَ إِلَيْهِ مَلَكٌ فَيَكُونَ مَعَهُ نَذِيرًا', 'Pourquoi n''a-t-on pas envoyé vers lui un Ange pour l''accompagner en avertisseur?', 14),
((SELECT id FROM public.surahs WHERE number = 25), 15, 'أَوْ يُلْقَىٰ إِلَيْهِ كَنزٌ أَوْ تَكُونُ لَهُ جَنَّةٌ يَأْكُلُ مِنْهَا', 'Ou qu''on lui jette un trésor, ou qu''il ait un jardin dont il mangerait?', 15),
((SELECT id FROM public.surahs WHERE number = 25), 16, 'وَقَالَ الظَّالِمُونَ إِن تَتَّبِعُونَ إِلَّا رَجُلًا مَّسْحُورًا', 'Et les injustes disent: Vous ne suivez qu''un homme envoûté.', 16),
((SELECT id FROM public.surahs WHERE number = 25), 17, 'انظُرْ كَيْفَ ضَرَبُوا لَكَ الْأَمْثَالَ فَضَلُّوا فَلَا يَسْتَطِيعُونَ سَبِيلًا', 'Regarde comment ils te proposent des paraboles! Ils s''égarent et ne peuvent trouver un chemin.', 17),
((SELECT id FROM public.surahs WHERE number = 25), 18, 'تَبَارَكَ الَّذِي إِن شَاءَ جَعَلَ لَكَ خَيْرًا مِّن ذَٰلِكَ جَنَّاتٍ تَجْرِي مِن تَحْتِهَا الْأَنْهَارُ', 'Béni soit Celui qui, si Il veut, t''accorde mieux que cela: des Jardins sous lesquels coulent les rivières,', 18),
((SELECT id FROM public.surahs WHERE number = 25), 19, 'وَيَجْعَل لَّكَ قُصُورًا', 'et ferait de toi des palais.', 19),
((SELECT id FROM public.surahs WHERE number = 25), 20, 'بَلْ كَذَّبُوا بِالسَّاعَةِ وَأَعْتَدْنَا لِمَن كَذَّبَ بِالسَّاعَةِ سَعِيرًا', 'Mais ils ont traité l''Heure de mensonge. Nous avons préparé pour ceux qui traitent l''Heure de mensonge une Fournaise.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

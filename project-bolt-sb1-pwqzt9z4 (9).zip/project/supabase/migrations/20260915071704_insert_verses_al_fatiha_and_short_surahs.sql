/*
# Insert verses for Al-Fatiha and short surahs (103-114)

## Purpose
Populates the `verses` table with the full Arabic Uthmani text and French
pre-translations for:
- Surah 1: Al-Fatiha (7 verses)
- Surah 103: Al-Asr (3 verses)
- Surah 104: Al-Humaza (9 verses)
- Surah 105: Al-Fil (5 verses)
- Surah 106: Quraysh (4 verses)
- Surah 107: Al-Ma'un (7 verses)
- Surah 108: Al-Kawthar (3 verses)
- Surah 109: Al-Kafirun (6 verses)
- Surah 110: An-Nasr (3 verses)
- Surah 111: Al-Masad (5 verses)
- Surah 112: Al-Ikhlas (4 verses)
- Surah 113: Al-Falaq (5 verses)
- Surah 114: An-Nas (6 verses)

## Data Source
Arabic Uthmani text follows the standard Hafs reading (the most widely used
Quranic reading). French translations follow established, well-known French
translations of the Quran.

## Important Notes
1. The French translations are stored as `french_pretranslation` — the Quran's
   own translations, independent of the dictionary.
2. These verses allow the reading module to be fully functional for these surahs.
3. Idempotent: ON CONFLICT prevents duplicate inserts on re-run.
*/

-- Helper: get surah ID by number
-- We use a subquery pattern: (SELECT id FROM surahs WHERE number = N)

-- =========================================================
-- SURAH 1: Al-Fatiha (7 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 1), 1,
'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
'Au nom d''Allah, le Tout Miséricordieux, le Très Miséricordieux.',
1),
((SELECT id FROM public.surahs WHERE number = 1), 2,
'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ',
'Louange à Allah, Seigneur de l''univers.',
2),
((SELECT id FROM public.surahs WHERE number = 1), 3,
'الرَّحْمَٰنِ الرَّحِيمِ',
'Le Tout Miséricordieux, le Très Miséricordieux,',
3),
((SELECT id FROM public.surahs WHERE number = 1), 4,
'مَالِكِ يَوْمِ الدِّينِ',
'Maître du Jour de la rétribution.',
4),
((SELECT id FROM public.surahs WHERE number = 1), 5,
'إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ',
'C''est Toi [Seul] que nous adorons, et c''est Toi [Seul] dont nous implorons secours.',
5),
((SELECT id FROM public.surahs WHERE number = 1), 6,
'اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ',
'Guide-nous dans le droit chemin,',
6),
((SELECT id FROM public.surahs WHERE number = 1), 7,
'صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ',
'le chemin de ceux que Tu as comblés de faveurs, non pas de ceux qui ont encouru Ta colère, ni des égarés.',
7)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 103: Al-Asr (3 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 103), 1,
'وَالْعَصْرِ',
'Par le Temps!',
1),
((SELECT id FROM public.surahs WHERE number = 103), 2,
'إِنَّ الْإِنْسَانَ لَفِي خُسْرٍ',
'L''homme est certes, en perdition,',
2),
((SELECT id FROM public.surahs WHERE number = 103), 3,
'إِلَّا الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ وَتَوَاصَوْا بِالْحَقِّ وَتَوَاصَوْا بِالصَّبْرِ',
'sauf ceux qui croient et accomplissent les bonnes œuvres, se conseillent mutuellement la vérité et se conseillent mutuellement la patience.',
3)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 104: Al-Humaza (9 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 104), 1,
'وَيْلٌ لِّكُلِّ هُمَزَةٍ لُّمَزَةٍ',
'Malheur à tout calomniateur diffamateur!',
1),
((SELECT id FROM public.surahs WHERE number = 104), 2,
'الَّذِي جَمَعَ مَالًا وَعَدَّدَهُ',
'Qui amasse une fortune et la compte sans cesse,',
2),
((SELECT id FROM public.surahs WHERE number = 104), 3,
'يَحْسَبُ أَنَّ مَالَهُ أَخْلَدَهُ',
'pensant que sa fortune le rendra immortel!',
3),
((SELECT id FROM public.surahs WHERE number = 104), 4,
'كَلَّا ۖ لَيُنْبَذَنَّ فِي الْحُطَمَةِ',
'Non! Il sera certes jeté dans le Feu destructeur.',
4),
((SELECT id FROM public.surahs WHERE number = 104), 5,
'وَمَا أَدْرَاكَ مَا الْحُطَمَةِ',
'Et qui te dira ce qu''est le Feu destructeur?',
5),
((SELECT id FROM public.surahs WHERE number = 104), 6,
'نَارُ اللَّهِ الْمُوقَدَةُ',
'C''est le Feu d''Allah, alimenté [sans interruption],',
6),
((SELECT id FROM public.surahs WHERE number = 104), 7,
'الَّتِي تَطَّلِعُ عَلَى الْأَفْئِدَةِ',
'qui monte jusqu''aux cœurs.',
7),
((SELECT id FROM public.surahs WHERE number = 104), 8,
'إِنَّهَا عَلَيْهِم مُّؤْصَدَةٌ',
'Il leur sera fermé de toutes parts,',
8),
((SELECT id FROM public.surahs WHERE number = 104), 9,
'فِي عَمَدٍ مُّمَدَّدَةٍ',
'par de longues colonnes (de flammes).',
9)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 105: Al-Fil (5 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 105), 1,
'أَلَمْ تَرَ كَيْفَ فَعَلَ رَبُّكَ بِأَصْحَابِ الْفِيلِ',
'N''as-tu pas vu comment ton Seigneur a agi avec les gens de l''éléphant?',
1),
((SELECT id FROM public.surahs WHERE number = 105), 2,
'أَلَمْ يَجْعَلْ كَيْدَهُمْ فِي تَضْلِيلٍ',
'N''a-t-Il pas rendu leur ruse vaine?',
2),
((SELECT id FROM public.surahs WHERE number = 105), 3,
'وَأَرْسَلَ عَلَيْهِمْ طَيْرًا أَبَابِيلَ',
'Et envoyé contre eux des oiseaux par volées?',
3),
((SELECT id FROM public.surahs WHERE number = 105), 4,
'تَرْمِيهِم بِحِجَارَةٍ مِّن سِجِّيلٍ',
'Qui leur lançaient des pierres d''argile cuite?',
4),
((SELECT id FROM public.surahs WHERE number = 105), 5,
'فَجَعَلَهُمْ كَعَصْفٍ مَّأْكُولٍ',
'Et les rendit tels des feuilles dévorées [par les insectes].',
5)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 106: Quraysh (4 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 106), 1,
'لِإِيلَافِ قُرَيْشٍ',
'Pour la sauvegarde des Quraysh,',
1),
((SELECT id FROM public.surahs WHERE number = 106), 2,
'إِيلَافِهِمْ رِحْلَةَ الشِّتَاءِ وَالصَّيْفِ',
'de leur sauvegarde lors des voyages d''hiver et d''été,',
2),
((SELECT id FROM public.surahs WHERE number = 106), 3,
'فَلْيَعْبُدُوا رَبَّ هَٰذَا الْبَيْتِ',
'Qu''ils adorent donc le Seigneur de cette Maison (la Kaaba),',
3),
((SELECT id FROM public.surahs WHERE number = 106), 4,
'الَّذِي أَطْعَمَهُم مِّن جُوعٍ وَآمَنَهُم مِّنْ خَوْفٍ',
'qui les a nourris contre la faim et rassurés contre la crainte.',
4)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 107: Al-Ma'un (7 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 107), 1,
'أَرَأَيْتَ الَّذِي يُكَذِّبُ بِالدِّينِ',
'As-tu vu celui qui traite de mensonge la rétribution?',
1),
((SELECT id FROM public.surahs WHERE number = 107), 2,
'فَذَٰلِكَ الَّذِي يَدُعُّ الْيَتِيمَ',
'C''est bien lui qui repousse l''orphelin,',
2),
((SELECT id FROM public.surahs WHERE number = 107), 3,
'وَلَا يَحُضُّ عَلَىٰ طَعَامِ الْمِسْكِينِ',
'et qui n''incite pas à nourrir le pauvre.',
3),
((SELECT id FROM public.surahs WHERE number = 107), 4,
'فَوَيْلٌ لِّلْمُصَلِّينَ',
'Malheur donc à ceux qui prient,',
4),
((SELECT id FROM public.surahs WHERE number = 107), 5,
'الَّذِينَ هُمْ عَن صَلَاتِهِمْ سَاهُونَ',
'tout en négligeant leur Salat,',
5),
((SELECT id FROM public.surahs WHERE number = 107), 6,
'الَّذِينَ هُمْ يُرَاءُونَ',
'qui cherchent à être vus,',
6),
((SELECT id FROM public.surahs WHERE number = 107), 7,
'وَيَمْنَعُونَ الْمَاعُونَ',
'et refusent le moindre service à autrui.',
7)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 108: Al-Kawthar (3 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 108), 1,
'إِنَّا أَعْطَيْنَاكَ الْكَوْثَرَ',
'Nous t''avons certes accordé l''abondance (Al-Kawthar).',
1),
((SELECT id FROM public.surahs WHERE number = 108), 2,
'فَصَلِّ لِرَبِّكَ وَانْحَرْ',
'Accomplis donc la Salat pour ton Seigneur et sacrifie.',
2),
((SELECT id FROM public.surahs WHERE number = 108), 3,
'إِنَّ شَانِئَكَ هُوَ الْأَبْتَرُ',
'C''est bien ton ennemi qui est privé (de tout bien).',
3)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 109: Al-Kafirun (6 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 109), 1,
'قُلْ يَا أَيُّهَا الْكَافِرُونَ',
'Dis: Ô infidèles!',
1),
((SELECT id FROM public.surahs WHERE number = 109), 2,
'لَا أَعْبُدُ مَا تَعْبُدُونَ',
'Je n''adore pas ce que vous adorez,',
2),
((SELECT id FROM public.surahs WHERE number = 109), 3,
'وَلَا أَنْتُمْ عَابِدُونَ مَا أَعْبُدُ',
'et vous n''adorez pas ce que j''adore.',
3),
((SELECT id FROM public.surahs WHERE number = 109), 4,
'وَلَا أَنَا عَابِدٌ مَّا عَبَدتُّمْ',
'Et je n''adorerai pas ce que vous adorez,',
4),
((SELECT id FROM public.surahs WHERE number = 109), 5,
'وَلَا أَنْتُمْ عَابِدُونَ مَا أَعْبُدُ',
'et vous n''adorerez pas ce que j''adore.',
5),
((SELECT id FROM public.surahs WHERE number = 109), 6,
'لَكُمْ دِينُكُمْ وَلِيَ دِينِ',
'À vous votre religion, et à moi ma religion.',
6)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 110: An-Nasr (3 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 110), 1,
'إِذَا جَاءَ نَصْرُ اللَّهِ وَالْفَتْحُ',
'Quand vient le secours d''Allah et la victoire,',
1),
((SELECT id FROM public.surahs WHERE number = 110), 2,
'وَرَأَيْتَ النَّاسَ يَدْخُلُونَ فِي دِينِ اللَّهِ أَفْوَاجًا',
'et que tu vois les gens entrer en foule dans la religion d''Allah,',
2),
((SELECT id FROM public.surahs WHERE number = 110), 3,
'فَسَبِّحْ بِحَمْدِ رَبِّكَ وَاسْتَغْفِرْهُ ۚ إِنَّهُ كَانَ تَوَّابًا',
'alors, par la louange, célèbre la gloire de ton Seigneur et implore Son pardon. Il est certes le Grand Accueillant du repentir.',
3)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 111: Al-Masad (5 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 111), 1,
'تَبَّتْ يَدَا أَبِي لَهَبٍ وَتَبَّ',
'Que périssent les mains d''Abu-Lahab, et que lui-même périsse!',
1),
((SELECT id FROM public.surahs WHERE number = 111), 2,
'مَا أَغْنَىٰ عَنْهُ مَالُهُ وَمَا كَسَبَ',
'Sa fortune et ses gains ne lui serviront à rien.',
2),
((SELECT id FROM public.surahs WHERE number = 111), 3,
'سَيَصْلَىٰ نَارًا ذَاتَ لَهَبٍ',
'Il brûlera dans un Feu plein de flammes,',
3),
((SELECT id FROM public.surahs WHERE number = 111), 4,
'وَامْرَأَتُهُ حَمَّالَةَ الْحَطَبِ',
'ainsi que sa femme, la porteuse de bois,',
4),
((SELECT id FROM public.surahs WHERE number = 111), 5,
'فِي جِيدِهَا حَبْلٌ مِّن مَّسَدٍ',
'à son cou sera une corde de fibres tressées.',
5)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 112: Al-Ikhlas (4 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 112), 1,
'قُلْ هُوَ اللَّهُ أَحَدٌ',
'Dis: Il est Allah, Unique.',
1),
((SELECT id FROM public.surahs WHERE number = 112), 2,
'اللَّهُ الصَّمَدُ',
'Allah, le Seul à être imploré pour ce que nous désirons.',
2),
((SELECT id FROM public.surahs WHERE number = 112), 3,
'لَمْ يَلِدْ وَلَمْ يُولَدْ',
'Il n''a jamais engendré, n''a pas été engendré non plus.',
3),
((SELECT id FROM public.surahs WHERE number = 112), 4,
'وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ',
'Et nul n''est égal à Lui.',
4)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 113: Al-Falaq (5 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 113), 1,
'قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ',
'Dis: Je cherche protection auprès du Seigneur de l''aube naissante,',
1),
((SELECT id FROM public.surahs WHERE number = 113), 2,
'مِن شَرِّ مَا خَلَقَ',
'contre le mal des êtres qu''Il a créés,',
2),
((SELECT id FROM public.surahs WHERE number = 113), 3,
'وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ',
'contre le mal de l''obscurité quand elle s''approfondit,',
3),
((SELECT id FROM public.surahs WHERE number = 113), 4,
'وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ',
'contre le mal de celles qui soufflent sur les nœuds,',
4),
((SELECT id FROM public.surahs WHERE number = 113), 5,
'وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ',
'et contre le mal de l''envieux quand il envie.',
5)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 114: An-Nas (6 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 114), 1,
'قُلْ أَعُوذُ بِرَبِّ النَّاسِ',
'Dis: Je cherche protection auprès du Seigneur des hommes,',
1),
((SELECT id FROM public.surahs WHERE number = 114), 2,
'مَلِكِ النَّاسِ',
'le Souverain des hommes,',
2),
((SELECT id FROM public.surahs WHERE number = 114), 3,
'إِلَٰهِ النَّاسِ',
'le Dieu des hommes,',
3),
((SELECT id FROM public.surahs WHERE number = 114), 4,
'مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ',
'contre le mal du mauvais conseiller, furtif,',
4),
((SELECT id FROM public.surahs WHERE number = 114), 5,
'الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ',
'qui souffle le mal dans les poitrines des hommes,',
5),
((SELECT id FROM public.surahs WHERE number = 114), 6,
'مِنَ الْجِنَّةِ وَالنَّاسِ',
'qu''il soit un djinn ou un être humain.',
6)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

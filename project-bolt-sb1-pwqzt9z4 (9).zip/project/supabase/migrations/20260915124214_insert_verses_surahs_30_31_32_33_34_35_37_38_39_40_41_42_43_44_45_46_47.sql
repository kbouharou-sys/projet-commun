/*
# Insert first 20 verses for surahs 30-47 (missing ones)

## Surahs added (first 20 verses each):
- 30: Ar-Rum
- 31: Luqman
- 32: As-Sajda
- 33: Al-Ahzab
- 34: Saba'
- 35: Fatir
- 37: As-Saffat
- 38: Sad
- 39: Az-Zumar
- 40: Ghafir
- 41: Fussilat
- 42: Ash-Shura
- 43: Az-Zukhruf
- 44: Ad-Dukhan
- 45: Al-Jathiya
- 46: Al-Ahqaf
- 47: Muhammad
*/

-- SURAH 30: Ar-Rum (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 30), 1, 'الٓمٓ', 'Alif Lam Mim.', 1),
((SELECT id FROM public.surahs WHERE number = 30), 2, 'غُلِبَتِ الرُّومُ', 'Les Romains ont été vaincus,', 2),
((SELECT id FROM public.surahs WHERE number = 30), 3, 'فِي أَدْنَى الْأَرْضِ وَهُم مِّن بَعْدِ غَلَبِهِمْ سَيَغْلِبُونَ', 'dans la terre voisine, et après leur défaite, ils vaincront,', 3),
((SELECT id FROM public.surahs WHERE number = 30), 4, 'فِي بِضْعِ سِنِينَ ۚ لِلَّهِ الْأَمْرُ مِن قَبْلُ وَمِن بَعْدُ', 'dans quelques années. À Allah appartient l''ordre, avant comme après.', 4),
((SELECT id FROM public.surahs WHERE number = 30), 5, 'وَيَوْمَئِذٍ يَفْرَحُ الْمُؤْمِنُونَ', 'Ce Jour-là, les croyants se réjouiront', 5),
((SELECT id FROM public.surahs WHERE number = 30), 6, 'بِنَصْرِ اللَّهِ ۚ يَنصُرُ مَن يَشَاءُ ۖ وَهُوَ الْعَزِيزُ الرَّحِيمُ', 'du secours d''Allah. Il secourt qui Il veut. Il est le Tout-Puissant, le Très Miséricordieux.', 6),
((SELECT id FROM public.surahs WHERE number = 30), 7, 'وَعْدَ اللَّهِ ۖ لَا يُخْلِفُ اللَّهُ وَعْدَهُ وَلَٰكِنَّ أَكْثَرَ النَّاسِ لَا يَعْلَمُونَ', 'Promesse d''Allah. Allah ne manque pas à Sa promesse. Mais la plupart des gens ne savent pas.', 7),
((SELECT id FROM public.surahs WHERE number = 30), 8, 'يَعْلَمُونَ ظَاهِرًا مِّنَ الْحَيَاةِ الدُّنْيَا وَهُمْ عَنِ الْآخِرَةِ هُمْ غَافِلُونَ', 'Ils connaissent un aspect de la vie d''ici-bas, mais de l''au-delà ils sont inattentifs.', 8),
((SELECT id FROM public.surahs WHERE number = 30), 9, 'أَوَلَمْ يَتَفَكَّرُوا فِي أَنفُسِهِمْ', 'Ne réfléchissent-ils pas en eux-mêmes?', 9),
((SELECT id FROM public.surahs WHERE number = 30), 10, 'مَّا خَلَقَ اللَّهُ السَّمَاوَاتِ وَالْأَرْضَ وَمَا بَيْنَهُمَا إِلَّا بِالْحَقِّ وَأَجَلٍ مُّسَمًّى', 'Allah n''a créé les cieux, la terre et ce qui est entre eux qu''en vérité et pour un terme fixé.', 10),
((SELECT id FROM public.surahs WHERE number = 30), 11, 'وَإِنَّ كَثِيرًا مِّنَ النَّاسِ بِلِقَاءِ رَبِّهِمْ لَكَافِرُونَ', 'Mais beaucoup de gens, à la rencontre de leur Seigneur, sont infidèles.', 11),
((SELECT id FROM public.surahs WHERE number = 30), 12, 'وَمِنْ آيَاتِهِ أَن تَقُومَ السَّمَاءُ وَالْأَرْضُ بِأَمْرِهِ', 'Parmi Ses signes: que le ciel et la terre subsistent par Son ordre.', 12),
((SELECT id FROM public.surahs WHERE number = 30), 13, 'ثُمَّ إِذَا دَعَاكُمْ دَعْوَةً مِّنَ الْأَرْضِ إِذَا أَنتُمْ تَخْرُجُونَ', 'Puis quand Il vous appellera d''un appel de la terre, vous sortirez.', 13),
((SELECT id FROM public.surahs WHERE number = 30), 14, 'وَلَهُ مَن فِي السَّمَاوَاتِ وَالْأَرْضِ كُلٌّ لَّهُ قَانِتُونَ', 'À Lui quiconque est dans les cieux et la terre, tous Lui sont soumis.', 14),
((SELECT id FROM public.surahs WHERE number = 30), 15, 'وَهُوَ الَّذِي يَبْدَأُ الْخَلْقَ ثُمَّ يُعِيدُهُ وَهُوَ أَهْوَنُ عَلَيْهِ', 'C''est Lui qui commence la création, puis la recommence. Cela Lui est plus facile.', 15),
((SELECT id FROM public.surahs WHERE number = 30), 16, 'وَلَهُ الْمَثَلُ الْأَعْلَىٰ فِي السَّمَاوَاتِ وَالْأَرْضِ', 'À Lui la parabole suprême dans les cieux et sur la terre.', 16),
((SELECT id FROM public.surahs WHERE number = 30), 17, 'وَهُوَ يُحْيِي وَيُمِيتُ وَإِلَيْهِ تُرْجَعُونَ', 'C''est Lui qui fait vivre et mourir, et vers Lui vous serez ramenés.', 17),
((SELECT id FROM public.surahs WHERE number = 30), 18, 'يُخْرِجُ الْحَيَّ مِنَ الْمَيِّتِ وَيُخْرِجُ الْمَيِّتَ مِنَ الْحَيِّ', 'Il fait sortir le vivant du mort et le mort du vivant.', 18),
((SELECT id FROM public.surahs WHERE number = 30), 19, 'وَيُحْيِي الْأَرْضَ بَعْدَ مَوْتِهَا ۚ وَكَذَٰلِكَ تُخْرَجُونَ', 'Et revivifie la terre après sa mort. Ainsi vous serez sortis.', 19),
((SELECT id FROM public.surahs WHERE number = 30), 20, 'وَمِنْ آيَاتِهِ أَنْ خَلَقَكُم مِّن تُرَابٍ', 'Parmi Ses signes: Il vous a créés de poussière.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 31: Luqman (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 31), 1, 'الٓمٓ', 'Alif Lam Mim.', 1),
((SELECT id FROM public.surahs WHERE number = 31), 2, 'تِلْكَ آيَاتُ الْكِتَابِ الْحَكِيمِ', 'Voici les versets du Livre sage,', 2),
((SELECT id FROM public.surahs WHERE number = 31), 3, 'هُدًى وَرَحْمَةً لِّلْمُحْسِنِينَ', 'une guidée et une miséricorde pour les bienfaiteurs,', 3),
((SELECT id FROM public.surahs WHERE number = 31), 4, 'الَّذِينَ يُقِيمُونَ الصَّلَاةَ وَيُؤْتُونَ الزَّكَاةَ وَهُم بِالْآخِرَةِ هُمْ يُوقِنُونَ', 'qui accomplissent la Salat, acquittent la Zakat et ont la certitude de l''au-delà.', 4),
((SELECT id FROM public.surahs WHERE number = 31), 5, 'أُولَٰئِكَ عَلَىٰ هُدًى مِّن رَّبِّهِمْ ۖ وَأُولَٰئِكَ هُمُ الْمُفْلِحُونَ', 'Ceux-là sont sur la guidée de leur Seigneur. Ceux-là sont les gagnants.', 5),
((SELECT id FROM public.surahs WHERE number = 31), 6, 'وَمِنَ النَّاسِ مَن يَشْتَرِي لَهْوَ الْحَدِيثِ لِيُضِلَّ عَن سَبِيلِ اللَّهِ', 'Parmi les hommes, il en est qui achètent des futilités pour égarer du sentier d''Allah,', 6),
((SELECT id FROM public.surahs WHERE number = 31), 7, 'بِغَيْرِ عِلْمٍ وَيَتَّخِذَهَا هُزُوًا', 'sans science, et la prennent en raillerie.', 7),
((SELECT id FROM public.surahs WHERE number = 31), 8, 'أُولَٰئِكَ لَهُمْ عَذَابٌ مُّهِينٌ', 'Ceux-là auront un châtiment humiliant.', 8),
((SELECT id FROM public.surahs WHERE number = 31), 9, 'وَإِذَا تُتْلَىٰ عَلَيْهِ آيَاتُنَا وَلَّىٰ مُسْتَكْبِرًا', 'Et quand Nos versets lui sont récités, il s''éloigne avec orgueil,', 9),
((SELECT id FROM public.surahs WHERE number = 31), 10, 'كَأَن لَّمْ يَسْمَعْهَا كَأَنَّ فِي أُذُنَيْهِ وَقْرًا', 'comme s''il ne les avait pas entendus, comme s''il y avait une surdité dans ses oreilles.', 10),
((SELECT id FROM public.surahs WHERE number = 31), 11, 'فَبَشِّرْهُ بِعَذَابٍ أَلِيمٍ', 'Annonce-lui donc un châtiment douloureux.', 11),
((SELECT id FROM public.surahs WHERE number = 31), 12, 'إِنَّ الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ لَهُمْ جَنَّاتُ النَّعِيمِ', 'Ceux qui croient et font le bien auront les Jardins du délice.', 12),
((SELECT id FROM public.surahs WHERE number = 31), 13, 'خَالِدِينَ فِيهَا ۚ وَعْدَ اللَّهِ حَقًّا', 'où ils demeureront éternellement. Promesse d''Allah véridique.', 13),
((SELECT id FROM public.surahs WHERE number = 31), 14, 'وَهُوَ الْعَزِيزُ الْحَكِيمُ', 'Il est le Tout-Puissant, le Sage.', 14),
((SELECT id FROM public.surahs WHERE number = 31), 15, 'خَلَقَ السَّمَاوَاتِ بِغَيْرِ عَمَدٍ تَرَوْنَهَا', 'Il a créé les cieux sans piliers que vous puissiez voir,', 15),
((SELECT id FROM public.surahs WHERE number = 31), 16, 'وَوَضَعَ فِي الْأَرْضِ رَوَاسِيَ أَن تَمِيدَ بِكُمْ', 'et a placé des montagnes fermes sur terre pour qu''elle ne vacille pas avec vous,', 16),
((SELECT id FROM public.surahs WHERE number = 31), 17, 'وَبَثَّ فِيهَا مِن كُلِّ دَابَّةٍ', 'et y a dispersé toute sorte de bêtes,', 17),
((SELECT id FROM public.surahs WHERE number = 31), 18, 'وَأَنزَلْنَا مِنَ السَّمَاءِ مَاءً فَأَنبَتْنَا فِيهَا مِن كُلِّ زَوْجٍ كَرِيمٍ', 'et fait descendre du ciel une eau, et y avons fait pousser toute sorte de plantes nobles.', 18),
((SELECT id FROM public.surahs WHERE number = 31), 19, 'هَٰذَا خَلْقُ اللَّهِ فَأَرُونِي مَاذَا خَلَقَ الَّذِينَ مِن دُونِهِ', 'Voici la création d''Allah. Montrez-moi donc ce que ceux en dehors de Lui ont créé!', 19),
((SELECT id FROM public.surahs WHERE number = 31), 20, 'بَلِ الظَّالِمُونَ فِي ضَلَالٍ مُّبِينٍ', 'Mais les injustes sont dans un égarement évident.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 32: As-Sajda (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 32), 1, 'الٓمٓ', 'Alif Lam Mim.', 1),
((SELECT id FROM public.surahs WHERE number = 32), 2, 'تَنزِيلُ الْكِتَابِ لَا رَيْبَ فِيهِ مِن رَّبِّ الْعَالَمِينَ', 'Révélation du Livre au sujet duquel il n''y a pas de doute, de la part du Seigneur de l''univers.', 2),
((SELECT id FROM public.surahs WHERE number = 32), 3, 'أَمْ يَقُولُونَ افْتَرَاهُ ۚ بَلْ هُوَ الْحَقُّ مِن رَّبِّكَ', 'Ou diront-ils: Il l''a forgé? C''est la vérité de ton Seigneur,', 3),
((SELECT id FROM public.surahs WHERE number = 32), 4, 'لِتُنذِرَ قَوْمًا مَّا أَتَاهُم مِّن نَّذِيرٍ مِّن قَبْلِكَ لَعَلَّهُمْ يَهْتَدُونَ', 'pour avertir un peuple auquel aucun avertisseur n''est venu avant toi, afin qu''ils se guident.', 4),
((SELECT id FROM public.surahs WHERE number = 32), 5, 'اللَّهُ الَّذِي خَلَقَ السَّمَاوَاتِ وَالْأَرْضَ وَمَا بَيْنَهُمَا فِي سِتَّةِ أَيَّامٍ', 'Allah qui a créé les cieux, la terre et ce qui est entre eux en six jours,', 5),
((SELECT id FROM public.surahs WHERE number = 32), 6, 'ثُمَّ اسْتَوَىٰ عَلَى الْعَرْشِ ۚ مَا لَكُم مِّن دُونِهِ مِن وَلِيٍّ وَلَا شَفِيعٍ', 'puis S''est établi sur le Trône. Vous n''avez en dehors de Lui ni allié ni intercesseur.', 6),
((SELECT id FROM public.surahs WHERE number = 32), 7, 'أَفَلَا يَتَذَكَّرُونَ', 'Ne réfléchissent-ils pas?', 7),
((SELECT id FROM public.surahs WHERE number = 32), 8, 'يُدَبِّرُ الْأَمْرَ مِنَ السَّمَاءِ إِلَى الْأَرْضِ', 'Il administre toute chose du ciel à la terre,', 8),
((SELECT id FROM public.surahs WHERE number = 32), 9, 'ثُمَّ يَعْرُجُ إِلَيْهِ فِي يَوْمٍ كَانَ مِقْدَارُهُ أَلْفَ سَنَةٍ مِّمَّا تَعُدُّونَ', 'puis elle remonte vers Lui en un Jour dont la durée est de mille ans de votre calcul.', 9),
((SELECT id FROM public.surahs WHERE number = 32), 10, 'ذَٰلِكَ عَالِمُ الْغَيْبِ وَالشَّهَادَةِ الْعَزِيزُ الرَّحِيمُ', 'C''est Lui le Connaisseur du monde invisible et visible, le Tout-Puissant, le Très Miséricordieux.', 10),
((SELECT id FROM public.surahs WHERE number = 32), 11, 'الَّذِي أَحْسَنَ كُلَّ شَيْءٍ خَلَقَهُ', 'Celui qui a parfaitement créé toute chose,', 11),
((SELECT id FROM public.surahs WHERE number = 32), 12, 'وَبَدَأَ خَلْقَ الْإِنسَانِ مِن طِينٍ', 'et a commencé la création de l''homme d''argile.', 12),
((SELECT id FROM public.surahs WHERE number = 32), 13, 'ثُمَّ جَعَلَ نَسْلَهُ مِن سُلَالَةٍ مِّن مَّاءٍ مَّهِينٍ', 'Puis Il a fait sa descendance d''un extrait d''eau méprisable.', 13),
((SELECT id FROM public.surahs WHERE number = 32), 14, 'ثُمَّ سَوَّاهُ وَنَفَخَ فِيهِ مِن رُّوحِهِ', 'Puis Il l''a formé harmonieusement et y a insufflé de Son Esprit.', 14),
((SELECT id FROM public.surahs WHERE number = 32), 15, 'وَجَعَلَ لَكُمُ السَّمْعَ وَالْأَبْصَارَ وَالْأَفْئِدَةَ', 'Il vous a doté de l''ouïe, des yeux et des cœurs.', 15),
((SELECT id FROM public.surahs WHERE number = 32), 16, 'قَلِيلًا مَّا تَشْكُرُونَ', 'Que peu vous remerciez!', 16),
((SELECT id FROM public.surahs WHERE number = 32), 17, 'وَقَالُوا أَإِذَا ضَلَلْنَا فِي الْأَرْضِ أَإِنَّا لَفِي خَلْقٍ جَدِيدٍ', 'Ils disent: Quand nous serons perdus dans la terre, serons-nous recréés?', 17),
((SELECT id FROM public.surahs WHERE number = 32), 18, 'بَلْ هُم بِلِقَاءِ رَبِّهِمْ كَافِرُونَ', 'Mais ils ne croient pas à la rencontre de leur Seigneur.', 18),
((SELECT id FROM public.surahs WHERE number = 32), 19, 'قُلْ يَتَوَفَّاكُم مَّلَكُ الْمَوْتِ الَّذِي وُكِّلَ بِكُمْ', 'Dis: L''Ange de la mort, chargé de vous, vous fera mourir.', 19),
((SELECT id FROM public.surahs WHERE number = 32), 20, 'ثُمَّ إِلَىٰ رَبِّكُمْ تُرْجَعُونَ', 'Puis vers votre Seigneur vous serez ramenés.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 33: Al-Ahzab (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 33), 1, 'يَا أَيُّهَا النَّبِيُّ اتَّقِ اللَّهَ وَلَا تُطِعِ الْكَافِرِينَ وَالْمُنَافِقِينَ', 'Ô Prophète! Crains Allah et n''obéis pas aux infidèles et aux hypocrites.', 1),
((SELECT id FROM public.surahs WHERE number = 33), 2, 'إِنَّ اللَّهَ كَانَ عَلِيمًا حَكِيمًا', 'Allah est Omniscient, Sage.', 2),
((SELECT id FROM public.surahs WHERE number = 33), 3, 'وَاتَّبِعْ مَا يُوحَىٰ إِلَيْكَ مِن رَّبِّكَ ۚ إِنَّ اللَّهَ كَانَ بِمَا تَعْمَلُونَ خَبِيرًا', 'Suis ce qui t''est révélé de ton Seigneur. Allah est Parfaitement Informé de ce que vous faites.', 3),
((SELECT id FROM public.surahs WHERE number = 33), 4, 'وَتَوَكَّلْ عَلَى اللَّهِ ۚ وَكَفَىٰ بِاللَّهِ وَكِيلًا', 'Et confie-toi à Allah. Allah suffit comme Tuteur.', 4),
((SELECT id FROM public.surahs WHERE number = 33), 5, 'مَّا جَعَلَ اللَّهُ لِرَجُلٍ مِّن قَلْبَيْنِ فِي جَوْفِهِ', 'Allah n''a pas mis à l''homme deux cœurs dans sa poitrine.', 5),
((SELECT id FROM public.surahs WHERE number = 33), 6, 'وَمَا جَعَلَ أَزْوَاجَكُمُ اللَّائِي تُظَاهِرُونَ مِنْهُنَّ أُمَّهَاتِكُمْ', 'Il n''a pas fait de vos épouses, que vous répudiez par zihar, vos mères.', 6),
((SELECT id FROM public.surahs WHERE number = 33), 7, 'وَمَا جَعَلَ أَدْعِيَاءَكُمْ أَبْنَاءَكُمْ', 'Ni de vos adoptifs vos fils.', 7),
((SELECT id FROM public.surahs WHERE number = 33), 8, 'ذَٰلِكُمْ قَوْلُكُم بِأَفْوَاهِكُمْ', 'C''est votre parole de vos bouches.', 8),
((SELECT id FROM public.surahs WHERE number = 33), 9, 'وَاللَّهُ يَقُولُ الْحَقَّ وَهُوَ يَهْدِي السَّبِيلَ', 'Allah dit la vérité et guide dans le chemin.', 9),
((SELECT id FROM public.surahs WHERE number = 33), 10, 'ادْعُوهُمْ لِآبَائِهِمْ هُوَ أَقْسَطُ عِندَ اللَّهِ', 'Appelez-les par leurs pères. C''est plus équitable auprès d''Allah.', 10),
((SELECT id FROM public.surahs WHERE number = 33), 11, 'فَإِن لَّمْ تَعْلَمُوا آبَاءَهُمْ فَإِخْوَانُكُمْ فِي الدِّينِ وَمَوَالِيكُمْ', 'Si vous ne connaissez pas leurs pères, ils sont vos frères en religion et vos clients.', 11),
((SELECT id FROM public.surahs WHERE number = 33), 12, 'وَلَيْسَ عَلَيْكُمْ جُنَاحٌ فِيمَا أَخْطَأْتُم بِهِ', 'Il n''y a pas de faute sur vous dans ce que vous faites par erreur,', 12),
((SELECT id FROM public.surahs WHERE number = 33), 13, 'وَلَٰكِن مَّا تَعَمَّدَتْ قُلُوبُكُمْ', 'mais pour ce que vos cœurs ont délibéré.', 13),
((SELECT id FROM public.surahs WHERE number = 33), 14, 'وَكَانَ اللَّهُ غَفُورًا رَّحِيمًا', 'Allah est Pardonneur, Très Miséricordieux.', 14),
((SELECT id FROM public.surahs WHERE number = 33), 15, 'النَّبِيُّ أَوْلَىٰ بِالْمُؤْمِنِينَ مِنْ أَنفُسِهِمْ', 'Le Prophète a plus de droit sur les croyants qu''ils n''en ont sur eux-mêmes.', 15),
((SELECT id FROM public.surahs WHERE number = 33), 16, 'وَأَزْوَاجُهُ أُمَّهَاتُهُمْ', 'Et ses épouses sont leurs mères.', 16),
((SELECT id FROM public.surahs WHERE number = 33), 17, 'وَأُولُو الْأَرْحَامِ بَعْضُهُمْ أَوْلَىٰ بِبَعْضٍ', 'Les proches parents ont priorité les uns sur les autres', 17),
((SELECT id FROM public.surahs WHERE number = 33), 18, 'فِي كِتَابِ اللَّهِ مِنَ الْمُؤْمِنِينَ وَالْمُهَاجِرِينَ', 'dans le Livre d''Allah, plus que les croyants et les émigrés,', 18),
((SELECT id FROM public.surahs WHERE number = 33), 19, 'إِلَّا أَن تَفْعَلُوا إِلَىٰ أَوْلِيَائِكُم مَّعْرُوفًا', 'sauf si vous faites un bien à vos alliés.', 19),
((SELECT id FROM public.surahs WHERE number = 33), 20, 'كَانَ ذَٰلِكَ فِي الْكِتَابِ مَسْطُورًا', 'C''est ainsi consigné dans le Livre.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 34: Saba' (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 34), 1, 'الْحَمْدُ لِلَّهِ الَّذِي لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ', 'Louange à Allah à Qui appartient ce qui est dans les cieux et sur la terre.', 1),
((SELECT id FROM public.surahs WHERE number = 34), 2, 'وَلَهُ الْحَمْدُ فِي الْآخِرَةِ ۚ وَهُوَ الْحَكِيمُ الْخَبِيرُ', 'À Lui la louange dans l''au-delà. Il est le Sage, l''Informé.', 2),
((SELECT id FROM public.surahs WHERE number = 34), 3, 'يَعْلَمُ مَا يَلِجُ فِي الْأَرْضِ وَمَا يَخْرُجُ مِنْهَا', 'Il sait ce qui pénètre dans la terre et ce qui en sort,', 3),
((SELECT id FROM public.surahs WHERE number = 34), 4, 'وَمَا يَنزِلُ مِنَ السَّمَاءِ وَمَا يَعْرُجُ فِيهَا', 'et ce qui descend du ciel et ce qui y monte.', 4),
((SELECT id FROM public.surahs WHERE number = 34), 5, 'وَهُوَ الرَّحِيمُ الْغَفُورُ', 'Il est le Très Miséricordieux, le Pardonneur.', 5),
((SELECT id FROM public.surahs WHERE number = 34), 6, 'وَقَالَ الَّذِينَ كَفَرُوا لَا تَأْتِينَا السَّاعَةُ', 'Les infidèles disent: L''Heure ne nous viendra pas.', 6),
((SELECT id FROM public.surahs WHERE number = 34), 7, 'قُلْ بَلَىٰ وَرَبِّي لَتَأْتِيَنَّكُمْ عَالِمِ الْغَيْبِ', 'Dis: Mais si! Par mon Seigneur, elle vous viendra certainement, Lui le Connaisseur du monde invisible.', 7),
((SELECT id FROM public.surahs WHERE number = 34), 8, 'لَا يَعْزُبُ عَنْهُ مِثْقَالُ ذَرَّةٍ فِي السَّمَاوَاتِ وَلَا فِي الْأَرْضِ', 'Rien ne Lui échappe, pas même le poids d''un atome, dans les cieux ou sur la terre.', 8),
((SELECT id FROM public.surahs WHERE number = 34), 9, 'وَلَا أَصْغَرَ مِن ذَٰلِكَ وَلَا أَكْبَرَ إِلَّا فِي كِتَابٍ مُّبِينٍ', 'Ni plus petit ni plus grand, sans que tout ne soit dans un Livre clair.', 9),
((SELECT id FROM public.surahs WHERE number = 34), 10, 'أَفَلَمْ يَرَوْا إِلَىٰ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُم مِّنَ السَّمَاءِ وَالْأَرْضِ', 'N''ont-ils pas vu ce qui est devant et derrière eux, du ciel et de la terre?', 10),
((SELECT id FROM public.surahs WHERE number = 34), 11, 'إِن نَّشَأْ نَخْسِفْ بِهِمُ الْأَرْضَ', 'Si Nous voulons, Nous fendons la terre sous eux.', 11),
((SELECT id FROM public.surahs WHERE number = 34), 12, 'أَوْ نُسْقِطْ عَلَيْهِمْ كِسَفًا مِّنَ السَّمَاءِ', 'Ou faisons tomber sur eux des morceaux du ciel.', 12),
((SELECT id FROM public.surahs WHERE number = 34), 13, 'إِنَّ فِي ذَٰلِكَ لَآيَةً لِّكُلِّ عَبْدٍ مُّنِيبٍ', 'Il y a là un signe pour tout serviteur repentant.', 13),
((SELECT id FROM public.surahs WHERE number = 34), 14, 'وَلَقَدْ آتَيْنَا دَاوُودَ مِنَّا فَضْلًا', 'Nous avons accordé à David une grâce de Notre part:', 14),
((SELECT id FROM public.surahs WHERE number = 34), 15, 'يَا جِبَالُ أَوِّبِي مَعَهُ وَالطَّيْرَ', 'Ô montagnes, répétez avec lui la louange! Et les oiseaux aussi.', 15),
((SELECT id FROM public.surahs WHERE number = 34), 16, 'وَأَلَنَّا لَهُ الْحَدِيدَ أَنِ اعْمَلْ سَابِغَاتٍ', 'Et Nous lui avons ramolli le fer: Fabrique des cottes de mailles', 16),
((SELECT id FROM public.surahs WHERE number = 34), 17, 'وَقَدِّرْ فِي السَّرْدِ وَعَمِلُوا صَالِحًا', 'et fixe la mesure des maillons. Et faites le bien.', 17),
((SELECT id FROM public.surahs WHERE number = 34), 18, 'إِنِّي بِمَا تَعْمَلُونَ بَصِيرٌ', 'Je suis Clairvoyant sur ce que vous faites.', 18),
((SELECT id FROM public.surahs WHERE number = 34), 19, 'وَلِسُلَيْمَانَ الرِّيحَ غُدُيُّهَا شَهْرٌ وَرَوَاحُهَا شَهْرٌ', 'Et à Salomon, le vent: son matin dure un mois, son retour un mois.', 19),
((SELECT id FROM public.surahs WHERE number = 34), 20, 'وَأَسَلْنَا لَهُ عَيْنَ الْقِطْرِ', 'Et Nous avons fait couler pour lui une source de bronze.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 35: Fatir (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 35), 1, 'الْحَمْدُ لِلَّهِ فَاطِرِ السَّمَاوَاتِ وَالْأَرْضِ', 'Louange à Allah, Créateur des cieux et de la terre,', 1),
((SELECT id FROM public.surahs WHERE number = 35), 2, 'جَاعِلِ الْمَلَائِكَةِ رُسُلًا أُولِي أَجْحِنَةٍ', 'qui fait des Anges des Messagers dotés d''ailes,', 2),
((SELECT id FROM public.surahs WHERE number = 35), 3, 'مَّا يَشَاءُ مِنَ الْخَلْقِ', 'autant qu''Il veut de créatures.', 3),
((SELECT id FROM public.surahs WHERE number = 35), 4, 'إِنَّ اللَّهَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ', 'Allah est Omnipotent.', 4),
((SELECT id FROM public.surahs WHERE number = 35), 5, 'مَّا يَفْتَحِ اللَّهُ لِلنَّاسِ مِن رَّحْمَةٍ فَلَا مُمْسِكَ لَهَا', 'Ce qu''Allah accorde aux hommes comme miséricorde, nul ne peut le retenir.', 5),
((SELECT id FROM public.surahs WHERE number = 35), 6, 'وَمَا يُمْسِكْ فَلَا مُرْسِلَ لَهُ مِن بَعْدِهِ', 'Et ce qu''Il retient, nul ne peut le relâcher après Lui.', 6),
((SELECT id FROM public.surahs WHERE number = 35), 7, 'وَهُوَ الْعَزِيزُ الْحَكِيمُ', 'Il est le Tout-Puissant, le Sage.', 7),
((SELECT id FROM public.surahs WHERE number = 35), 8, 'يَا أَيُّهَا النَّاسُ اذْكُرُوا نِعْمَتَ اللَّهِ عَلَيْكُمْ', 'Ô hommes! Rappelez-vous le bienfait d''Allah sur vous.', 8),
((SELECT id FROM public.surahs WHERE number = 35), 9, 'هَلْ مِنْ خَالِقٍ غَيْرُ اللَّهِ', 'Y a-t-il un créateur autre qu''Allah?', 9),
((SELECT id FROM public.surahs WHERE number = 35), 10, 'يَرْزُقُكُم مِّنَ السَّمَاءِ وَالْأَرْضِ', 'Il vous nourrit du ciel et de la terre.', 10),
((SELECT id FROM public.surahs WHERE number = 35), 11, 'لَا إِلَٰهَ إِلَّا هُوَ فَكَيْفَ تُؤْفَكُونَ', 'Nulle divinité sauf Lui. Comment vous détournez-vous?', 11),
((SELECT id FROM public.surahs WHERE number = 35), 12, 'وَإِن يُكَذِّبُوكَ فَقَدْ كُذِّبَتْ رُسُلٌ مِّن قَبْلِكَ', 'S''ils te traitent de menteur, des Messagers avant toi furent traités de menteurs.', 12),
((SELECT id FROM public.surahs WHERE number = 35), 13, 'وَإِلَى اللَّهِ تُرْجَعُ الْأُمُورُ', 'Et vers Allah retournent les affaires.', 13),
((SELECT id FROM public.surahs WHERE number = 35), 14, 'يَا أَيُّهَا النَّاسُ إِنَّ وَعْدَ اللَّهِ حَقٌّ', 'Ô hommes! La promesse d''Allah est vérité.', 14),
((SELECT id FROM public.surahs WHERE number = 35), 15, 'فَلَا تَغُرَّنَّكُمُ الْحَيَاةُ الدُّنْيَا', 'Que la vie d''ici-bas ne vous trompe pas.', 15),
((SELECT id FROM public.surahs WHERE number = 35), 16, 'وَلَا يَغُرَّنَّكُم بِاللَّهِ الْغَرُورُ', 'Et que le Trompeur ne vous trompe pas au sujet d''Allah.', 16),
((SELECT id FROM public.surahs WHERE number = 35), 17, 'إِنَّ الشَّيْطَانَ لَكُمْ عَدُوٌّ فَاتَّخِذُوهُ عَدُوًّا', 'Le Démon est pour vous un ennemi: prenez-le donc pour ennemi.', 17),
((SELECT id FROM public.surahs WHERE number = 35), 18, 'إِنَّمَا يَدْعُو حِزْبَهُ لِيَكُونُوا مِنْ أَصْحَابِ السَّعِيرِ', 'Il appelle son parti pour qu''ils soient des gens de la Fournaise.', 18),
((SELECT id FROM public.surahs WHERE number = 35), 19, 'الَّذِينَ كَفَرُوا لَهُمْ عَذَابٌ شَدِيدٌ', 'Ceux qui ont mécru auront un dur châtiment.', 19),
((SELECT id FROM public.surahs WHERE number = 35), 20, 'وَالَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ لَهُم مَّغْفِرَةٌ وَأَجْرٌ كَبِيرٌ', 'Et ceux qui croient et font le bien auront pardon et grande récompense.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 37: As-Saffat (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 37), 1, 'وَالصَّافَّاتِ صَفًّا', 'Par les rangées en formation,', 1),
((SELECT id FROM public.surahs WHERE number = 37), 2, 'فَالزَّاجِرَاتِ زَجْرًا', 'par les réprimandeuses en réprimandant,', 2),
((SELECT id FROM public.surahs WHERE number = 37), 3, 'فَالتَّالِيَاتِ ذِكْرًا', 'par les récitantes du Rappel,', 3),
((SELECT id FROM public.surahs WHERE number = 37), 4, 'إِنَّ إِلَٰهَكُمْ لَوَاحِدٌ', 'Votre Dieu est unique,', 4),
((SELECT id FROM public.surahs WHERE number = 37), 5, 'رَبُّ السَّمَاوَاتِ وَالْأَرْضِ وَمَا بَيْنَهُمَا وَرَبُّ الْمَشَارِقِ', 'Seigneur des cieux, de la terre et de ce qui est entre eux, et Seigneur des levants.', 5),
((SELECT id FROM public.surahs WHERE number = 37), 6, 'إِنَّا زَيَّنَّا السَّمَاءَ الدُّنْيَا بِزِينَةٍ الْكَوَاكِبِ', 'Nous avons orné le ciel le plus bas d''ornements: les étoiles,', 6),
((SELECT id FROM public.surahs WHERE number = 37), 7, 'وَحِفْظًا مِّن كُلِّ شَيْطَانٍ مَّارِدٍ', 'et d''une protection contre tout démon rebelle.', 7),
((SELECT id FROM public.surahs WHERE number = 37), 8, 'لَا يَسَّمَّعُونَ إِلَى الْمَلَإِ الْأَعْلَىٰ', 'Ils ne peuvent écouter l''assemblée suprême,', 8),
((SELECT id FROM public.surahs WHERE number = 37), 9, 'وَيُقْذَفُونَ مِن كُلِّ جَانِبٍ', 'et ils sont lapidés de tous côtés,', 9),
((SELECT id FROM public.surahs WHERE number = 37), 10, 'دُحُورًا وَلَهُمْ عَذَابٌ وَاصِبٌ', 'repoussés, et ils auront un châtiment continu,', 10),
((SELECT id FROM public.surahs WHERE number = 37), 11, 'إِلَّا مَنْ خَطِفَ الْخَطْفَةَ فَأَتْبَعَهُ شِهَابٌ ثَاقِبٌ', 'sauf celui qui saisit au vol, qu''alors poursuit un météore perçant.', 11),
((SELECT id FROM public.surahs WHERE number = 37), 12, 'فَاسْتَفْتِهِمْ أَهُمْ أَشَدُّ خَلْقًا أَم مَّنْ خَلَقْنَا', 'Demande-leur s''ils sont plus difficiles à créer que ceux que Nous avons créés?', 12),
((SELECT id FROM public.surahs WHERE number = 37), 13, 'إِنَّا خَلَقْنَاهُم مِّن طِينٍ لَّازِبٍ', 'Nous les avons créés d''argile adhérente.', 13),
((SELECT id FROM public.surahs WHERE number = 37), 14, 'بَلْ عَجِبْتَ وَيَسْخَرُونَ', 'Mais tu t''étonnes, et ils se moquent.', 14),
((SELECT id FROM public.surahs WHERE number = 37), 15, 'وَإِذَا ذُكِرُوا لَا يَذْكُرُونَ', 'Et quand on les évoque, ils ne se rappellent pas.', 15),
((SELECT id FROM public.surahs WHERE number = 37), 16, 'وَإِذَا رَأَوْا آيَةً يَسْتَسْخِرُونَ', 'Et quand ils voient un signe, ils le raillent.', 16),
((SELECT id FROM public.surahs WHERE number = 37), 17, 'وَقَالُوا إِنْ هَٰذَا إِلَّا سِحْرٌ مُّبِينٌ', 'Et ils disent: Ce n''est que magie évidente!', 17),
((SELECT id FROM public.surahs WHERE number = 37), 18, 'أَإِذَا مِتْنَا وَكُنَّا تُرَابًا وَعِظَامًا أَإِنَّا لَمَبْعُوثُونَ', 'Quand nous serons morts, poussière et os, serons-nous ressuscités?', 18),
((SELECT id FROM public.surahs WHERE number = 37), 19, 'أَوَآبَاؤُنَا الْأَوَّلُونَ', 'Et nos ancêtres aussi?', 19),
((SELECT id FROM public.surahs WHERE number = 37), 20, 'قُلْ نَعَمْ وَأَنتُمْ دَاخِرُونَ', 'Dis: Oui, et vous serez humiliés.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 38: Sad (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 38), 1, 'ص ۚ وَالْقُرْآنِ ذِي الذِّكْرِ', 'Sad. Par le Coran au Rappel!', 1),
((SELECT id FROM public.surahs WHERE number = 38), 2, 'بَلِ الَّذِينَ كَفَرُوا فِي عِزَّةٍ وَشِقَاقٍ', 'Mais les infidèles sont dans l''orgueil et la dissension.', 2),
((SELECT id FROM public.surahs WHERE number = 38), 3, 'كَمْ أَهْلَكْنَا مِن قَبْلِهِم مِّن قَرْنٍ فَنَادَوْا وَلَاتَ حِينَ مَنَاصٍ', 'Combien de générations avant eux avons-Nous anéanties! Ils appelèrent, mais plus le temps d''échapper.', 3),
((SELECT id FROM public.surahs WHERE number = 38), 4, 'وَعَجِبُوا أَن جَاءَهُم مُّنذِرٌ مِّنْهُمْ', 'Ils s''étonnent qu''un avertisseur des leurs soit venu à eux.', 4),
((SELECT id FROM public.surahs WHERE number = 38), 5, 'وَقَالَ الْكَافِرُونَ هَٰذَا سَاحِرٌ كَذَّابٌ', 'Les infidèles disent: Ce magicien est un menteur.', 5),
((SELECT id FROM public.surahs WHERE number = 38), 6, 'أَجَعَلَ الْآلِهَةَ إِلَٰهًا وَاحِدًا ۖ إِنَّ هَٰذَا لَشَيْءٌ عُجَابٌ', 'A-t-il fait des divinités un dieu unique? C''est chose étonnante!', 6),
((SELECT id FROM public.surahs WHERE number = 38), 7, 'وَانطَلَقَ الْمَلَأُ مِنْهُمْ أَنِ امْشُوا وَاصْبِرُوا عَلَىٰ آلِهَتِكُمْ', 'Les notables partirent: Marchez et restez fidèles à vos divinités,', 7),
((SELECT id FROM public.surahs WHERE number = 38), 8, 'إِنَّ هَٰذَا لَشَيْءٌ يُرَادُ', 'C''est une chose voulue.', 8),
((SELECT id FROM public.surahs WHERE number = 38), 9, 'مَا سَمِعْنَا بِهَٰذَا فِي الْمِلَّةِ الْآخِرَةِ', 'Nous n''avons pas entendu cela dans la dernière religion.', 9),
((SELECT id FROM public.surahs WHERE number = 38), 10, 'إِنْ هَٰذَا إِلَّا اخْتِلَاقٌ', 'Ce n''est qu''une invention.', 10),
((SELECT id FROM public.surahs WHERE number = 38), 11, 'أَأُنزِلَ عَلَيْهِ الذِّكْرُ مِن بَيْنِنَا', 'Le Rappel a-t-il été descendu sur lui, parmi nous?', 11),
((SELECT id FROM public.surahs WHERE number = 38), 12, 'بَلْ هُمْ فِي شَكٍّ مِّن ذِكْرِي', 'Mais ils sont dans le doute au sujet de Mon Rappel.', 12),
((SELECT id FROM public.surahs WHERE number = 38), 13, 'بَلْ لَمَّا يَذُوقُوا عَذَابِ', 'Mais ils n''ont pas encore goûté Mon châtiment.', 13),
((SELECT id FROM public.surahs WHERE number = 38), 14, 'أَمْ عِندَهُمْ خَزَائِنُ رَحْمَةِ رَبِّكَ الْعَزِيزِ الْوَهَّابِ', 'Ou détiennent-ils les trésors de la miséricorde de ton Seigneur, le Tout-Puissant, le Donateur?', 14),
((SELECT id FROM public.surahs WHERE number = 38), 15, 'أَمْ لَهُم مُّلْكُ السَّمَاوَاتِ وَالْأَرْضِ وَمَا بَيْنَهُمَا', 'Ou possèdent-ils la royauté des cieux, de la terre et de ce qui est entre eux?', 15),
((SELECT id FROM public.surahs WHERE number = 38), 16, 'فَلْيَرْتَقُوا فِي الْأَسْبَابِ', 'Qu''ils montent donc par les cordages!', 16),
((SELECT id FROM public.surahs WHERE number = 38), 17, 'جُندٌ مَّا هُنَالِكَ مَهْزُومٌ مِّنَ الْأَحْزَابِ', 'Une armée, ici même, sera vaincue parmi les coalitions.', 17),
((SELECT id FROM public.surahs WHERE number = 38), 18, 'كَذَّبَتْ قَبْلَهُمْ قَوْمُ نُوحٍ وَعَادٌ وَفِرْعَوْنُ ذُو الْأَوْتَادِ', 'Avant eux, le peuple de Noé, les Aad, et Pharaon aux poteaux,', 18),
((SELECT id FROM public.surahs WHERE number = 38), 19, 'وَثَمُودُ وَقَوْمُ لُوطٍ وَأَصْحَابُ الْأَيْكَةِ', 'et les Thamud, le peuple de Loth, et les gens d''Al-Ayka,', 19),
((SELECT id FROM public.surahs WHERE number = 38), 20, 'أُولَٰئِكَ الْأَحْزَابُ', 'ceux-là sont les coalitions.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 39: Az-Zumar (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 39), 1, 'تَنزِيلُ الْكِتَابِ مِنَ اللَّهِ الْعَزِيزِ الْحَكِيمِ', 'Révélation du Livre de la part d''Allah, le Tout-Puissant, le Sage.', 1),
((SELECT id FROM public.surahs WHERE number = 39), 2, 'إِنَّا أَنزَلْنَا إِلَيْكَ الْكِتَابَ بِالْحَقِّ فَاعْبُدِ اللَّهَ مُخْلِصًا لَّهُ الدِّينَ', 'Nous t''avons fait descendre le Livre en vérité. Adore donc Allah, sincère envers Lui dans la religion.', 2),
((SELECT id FROM public.surahs WHERE number = 39), 3, 'أَلَا لِلَّهِ الدِّينُ الْخَالِصُ', 'La religion pure n''appartient-elle pas à Allah?', 3),
((SELECT id FROM public.surahs WHERE number = 39), 4, 'وَالَّذِينَ اتَّخَذُوا مِن دُونِهِ أَوْلِيَاءَ', 'Ceux qui prennent des alliés en dehors de Lui:', 4),
((SELECT id FROM public.surahs WHERE number = 39), 5, 'مَا نَعْبُدُهُمْ إِلَّا لِيُقَرِّبُونَا إِلَى اللَّهِ زُلْفَىٰ', 'Nous ne les adorons que pour nous rapprocher d''Allah.', 5),
((SELECT id FROM public.surahs WHERE number = 39), 6, 'إِنَّ اللَّهَ يَحْكُمُ بَيْنَهُمْ فِي مَا هُمْ فِيهِ يَخْتَلِفُونَ', 'Allah décidera entre eux au sujet de leurs divergences.', 6),
((SELECT id FROM public.surahs WHERE number = 39), 7, 'إِنَّ اللَّهَ لَا يَهْدِي مَنْ هُوَ كَاذِبٌ كَفَّارٌ', 'Allah ne guide pas le menteur ingrat.', 7),
((SELECT id FROM public.surahs WHERE number = 39), 8, 'خَلَقَكُم مِّن نَّفْسٍ وَاحِدَةٍ ثُمَّ جَعَلَ مِنْهَا زَوْجَهَا', 'Il vous a créés d''une seule âme, puis en a tiré son épouse;', 8),
((SELECT id FROM public.surahs WHERE number = 39), 9, 'وَأَنزَلَ لَكُم مِّنَ الْأَنْعَامِ ثَمَانِيَةَ أَزْوَاجٍ', 'et a fait descendre pour vous, des bestiaux, huit couples.', 9),
((SELECT id FROM public.surahs WHERE number = 39), 10, 'يَخْلُقُكُمْ فِي بُطُونِ أُمَّهَاتِكُمْ خَلْقًا مِّن بَعْدِ خَلْقٍ', 'Il vous crée dans les matrices de vos mères, création après création,', 10),
((SELECT id FROM public.surahs WHERE number = 39), 11, 'فِي ظُلُمَاتٍ ثَلَاثٍ', 'dans trois ténèbres.', 11),
((SELECT id FROM public.surahs WHERE number = 39), 12, 'ذَٰلِكُمُ اللَّهُ رَبُّكُمْ لَهُ الْمُلْكُ', 'C''est Allah votre Seigneur. À Lui la royauté.', 12),
((SELECT id FROM public.surahs WHERE number = 39), 13, 'لَا إِلَٰهَ إِلَّا هُوَ فَأَنَّىٰ تُصْرَفُونَ', 'Nulle divinité sauf Lui. Comment vous détournez-vous?', 13),
((SELECT id FROM public.surahs WHERE number = 39), 14, 'إِن تَكْفُرُوا فَإِنَّ اللَّهَ غَنِيٌّ عَنكُمْ', 'Si vous mécroyez, Allah se passe de vous.', 14),
((SELECT id FROM public.surahs WHERE number = 39), 15, 'وَلَا يَرْضَىٰ لِعِبَادِهِ الْكُفْرَ', 'Et Il n''agrée pas l''infidélité de Ses serviteurs.', 15),
((SELECT id FROM public.surahs WHERE number = 39), 16, 'وَإِن تَشْكُرُوا يَرْضَهُ لَكُمْ', 'Et si vous êtes reconnaissants, Il l''agrée pour vous.', 16),
((SELECT id FROM public.surahs WHERE number = 39), 17, 'وَلَا تَزِرُ وَازِرَةٌ وِزْرَ أُخْرَىٰ', 'Nulle âme ne porte le fardeau d''une autre.', 17),
((SELECT id FROM public.surahs WHERE number = 39), 18, 'ثُمَّ إِلَىٰ رَبِّكُم مَّرْجِعُكُمْ فَيُنَبِّئُكُم بِمَا كُنتُمْ تَعْمَلُونَ', 'Puis vers votre Seigneur est votre retour, et Il vous informera de ce que vous faisiez.', 18),
((SELECT id FROM public.surahs WHERE number = 39), 19, 'إِنَّهُ عَلِيمٌ بِذَاتِ الصُّدُورِ', 'Il connaît le contenu des poitrines.', 19),
((SELECT id FROM public.surahs WHERE number = 39), 20, 'وَإِذَا مَسَّ الْإِنسَانَ ضُرٌّ دَعَا رَبَّهُ مُنِيبًا إِلَيْهِ', 'Quand un mal touche l''homme, il invoque son Seigneur en se repentant à Lui.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 40: Ghafir (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 40), 1, 'حم', 'Ha Mim.', 1),
((SELECT id FROM public.surahs WHERE number = 40), 2, 'تَنزِيلُ الْكِتَابِ مِنَ اللَّهِ الْعَزِيزِ الْعَلِيمِ', 'Révélation du Livre de la part d''Allah, le Tout-Puissant, l''Omniscient,', 2),
((SELECT id FROM public.surahs WHERE number = 40), 3, 'غَافِرِ الذَّنبِ وَقَابِلِ التَّوْبِ شَدِيدِ الْعِقَابِ', 'Pardonneur du péché, Accepteur du repentir, Dur en punition,', 3),
((SELECT id FROM public.surahs WHERE number = 40), 4, 'ذِي الطَّوْلِ ۖ لَا إِلَٰهَ إِلَّا هُوَ إِلَيْهِ الْمَصِيرُ', 'au Long Bréviaire. Nulle divinité sauf Lui. Vers Lui est le retour.', 4),
((SELECT id FROM public.surahs WHERE number = 40), 5, 'مَا يُجَادِلُ فِي آيَاتِ اللَّهِ إِلَّا الَّذِينَ كَفَرُوا', 'Ne discutent les signes d''Allah que ceux qui ont mécru.', 5),
((SELECT id FROM public.surahs WHERE number = 40), 6, 'فَلَا يَغُرَّكَ تَقَلُّبُهُمْ فِي الْبِلَادِ', 'Que leur va-et-vient sur terre ne te trompe pas.', 6),
((SELECT id FROM public.surahs WHERE number = 40), 7, 'كَذَّبَتْ قَبْلَهُمْ قَوْمُ نُوحٍ وَالْأَحْزَابُ مِن بَعْدِهِمْ', 'Avant eux, le peuple de Noé et les coalitions après eux ont crié au mensonge.', 7),
((SELECT id FROM public.surahs WHERE number = 40), 8, 'وَكَذَّبَتْ كُلُّ أُمَّةٍ رَّسُولَهَا', 'Et chaque nation a traité de menteur son Messager,', 8),
((SELECT id FROM public.surahs WHERE number = 40), 9, 'فَحَقَّ وَعِيدِ', 'et Ma menace s''est réalisée.', 9),
((SELECT id FROM public.surahs WHERE number = 40), 10, 'إِنَّ الَّذِينَ كَفَرُوا يُنَادَوْنَ لَمَقْتُ اللَّهِ أَكْبَرُ مِن مَّقْتِكُمْ أَنفُسَكُمْ', 'Ceux qui ont mécru sont interpellés: L''aversion d''Allah pour vous est plus grande que votre aversion pour vous-mêmes,', 10),
((SELECT id FROM public.surahs WHERE number = 40), 11, 'إِذْ تُدْعَوْنَ إِلَى الْإِيمَانِ فَتَكْفُرُونَ', 'quand vous étiez invités à la foi et que vous mécroyiez.', 11),
((SELECT id FROM public.surahs WHERE number = 40), 12, 'قَالُوا رَبَّنَا أَمَتَّنَا اثْنَتَيْنِ وَأَحْيَيْتَنَا اثْنَتَيْنِ', 'Ils dirent: Seigneur! Tu nous as fait mourir deux fois et revivre deux fois.', 12),
((SELECT id FROM public.surahs WHERE number = 40), 13, 'فَاعْتَرَفْنَا بِذُنُوبِنَا فَهَلْ إِلَىٰ خُرُوجٍ مِّن سَبِيلٍ', 'Nous reconnaissons nos péchés. Y a-t-il une voie de sortie?', 13),
((SELECT id FROM public.surahs WHERE number = 40), 14, 'ذَٰلِكُم بِأَنَّهُ إِذَا دُعِيَ اللَّهُ وَحْدَهُ كَفَرْتُمْ', 'C''est parce que, quand Allah était invoqué seul, vous mécroyiez,', 14),
((SELECT id FROM public.surahs WHERE number = 40), 15, 'وَإِن يُشْرَكْ بِهِ تُؤْمِنُوا', 'et si on Lui associait, vous croyiez.', 15),
((SELECT id FROM public.surahs WHERE number = 40), 16, 'فَالْحُكْمُ لِلَّهِ الْعَلِيِّ الْكَبِيرِ', 'Le jugement appartient donc à Allah, le Très-Haut, le Suprême.', 16),
((SELECT id FROM public.surahs WHERE number = 40), 17, 'هُوَ الَّذِي يُرِيكُمْ آيَاتِهِ وَيُنزِلُ لَكُم مِّنَ السَّمَاءِ رِزْقًا', 'C''est Lui qui vous montre Ses signes et fait descendre du ciel une subsistance.', 17),
((SELECT id FROM public.surahs WHERE number = 40), 18, 'وَمَا يَتَذَكَّرُ إِلَّا مَن يُنِيبُ', 'Seul se rappelle celui qui revient [à Allah].', 18),
((SELECT id FROM public.surahs WHERE number = 40), 19, 'فَادْعُوا اللَّهَ مُخْلِصِينَ لَهُ الدِّينَ وَلَوْ كَرِهَ الْكَافِرُونَ', 'Invoquez Allah, sincères envers Lui dans la religion, quelque répulsion qu''en aient les infidèles.', 19),
((SELECT id FROM public.surahs WHERE number = 40), 20, 'رَفِيعُ الدَّرَجَاتِ ذُو الْعَرْشِ يُلْقِي الرُّوحَ مِنْ أَمْرِهِ', 'Élévateur des degrés, Détenteur du Trône, Il envoie l''Esprit par Son ordre', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 41: Fussilat (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 41), 1, 'حم', 'Ha Mim.', 1),
((SELECT id FROM public.surahs WHERE number = 41), 2, 'تَنزِيلٌ مِّنَ الرَّحْمَٰنِ الرَّحِيمِ', 'Révélation de la part du Tout Miséricordieux, du Très Miséricordieux.', 2),
((SELECT id FROM public.surahs WHERE number = 41), 3, 'كِتَابٌ فُصِّلَتْ آيَاتُهُ قُرْآنًا عَرَبِيًّا لِّقَوْمٍ يَعْلَمُونَ', 'Un Livre aux versets détaillés, un Coran arabe pour un peuple qui sait,', 3),
((SELECT id FROM public.surahs WHERE number = 41), 4, 'بَشِيرًا وَنَذِيرًا فَأَعْرَضَ أَكْثَرُهُمْ فَهُمْ لَا يَسْمَعُونَ', 'annonciateur et avertisseur. Mais la plupart se détournent et n''écoutent pas.', 4),
((SELECT id FROM public.surahs WHERE number = 41), 5, 'وَقَالُوا قُلُوبُنَا فِي أَكِنَّةٍ مِّمَّا تَدْعُونَا إِلَيْهِ', 'Ils disent: Nos cœurs sont voilés contre ce à quoi tu nous invites.', 5),
((SELECT id FROM public.surahs WHERE number = 41), 6, 'وَفِي آذَانِنَا وَقْرٌ وَمِن بَيْنِنَا وَبَيْنِكَ حِجَابٌ', 'Et dans nos oreilles une surdité, et entre nous et toi un voile.', 6),
((SELECT id FROM public.surahs WHERE number = 41), 7, 'فَاعْمَلْ إِنَّنَا عَامِلُونَ', 'Agis donc, nous aussi nous agissons.', 7),
((SELECT id FROM public.surahs WHERE number = 41), 8, 'قُلْ إِنَّمَا أَنَا بَشَرٌ مِّثْلُكُمْ يُوحَىٰ إِلَيَّ', 'Dis: Je ne suis qu''un humain comme vous, à qui il est révélé', 8),
((SELECT id FROM public.surahs WHERE number = 41), 9, 'أَنَّمَا إِلَٰهُكُمْ إِلَٰهٌ وَاحِدٌ فَاسْتَقِيمُوا إِلَيْهِ', 'que votre Dieu est un Dieu unique. Soyez droits envers Lui', 9),
((SELECT id FROM public.surahs WHERE number = 41), 10, 'وَاسْتَغْفِرُوهُ ۚ وَوَيْلٌ لِّلْمُشْرِكِينَ', 'et implorez Son pardon. Malheur aux associateurs,', 10),
((SELECT id FROM public.surahs WHERE number = 41), 11, 'الَّذِينَ لَا يُؤْتُونَ الزَّكَاةَ وَهُم بِالْآخِرَةِ هُمْ كَافِرُونَ', 'qui n''acquittent pas la Zakat et ne croient pas en l''au-delà.', 11),
((SELECT id FROM public.surahs WHERE number = 41), 12, 'إِنَّ الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ لَهُمْ أَجْرٌ غَيْرُ مَمْنُونٍ', 'Ceux qui croient et font le bien ont une récompense non interrompue.', 12),
((SELECT id FROM public.surahs WHERE number = 41), 13, 'قُلْ أَئِنَّكُمْ لَتَكْفُرُونَ بِالَّذِي خَلَقَ الْأَرْضَ فِي يَوْمَيْنِ', 'Dis: Allez-vous mécroire en Celui qui a créé la terre en deux jours?', 13),
((SELECT id FROM public.surahs WHERE number = 41), 14, 'وَتَجْعَلُونَ لَهُ أَندَادًا ۚ ذَٰلِكَ رَبُّ الْعَالَمِينَ', 'Et Lui donnez-vous des égaux? C''est Lui le Seigneur de l''univers.', 14),
((SELECT id FROM public.surahs WHERE number = 41), 15, 'وَجَعَلَ فِيهَا رَوَاسِيَ مِن فَوْقِهَا وَبَارَكَ فِيهَا', 'Il y a placé des montagnes au-dessus, l''a bénie,', 15),
((SELECT id FROM public.surahs WHERE number = 41), 16, 'وَقَدَّرَ فِيهَا أَقْوَاتَهَا فِي أَرْبَعَةِ أَيَّامٍ سَوَاءً لِّلسَّائِلِينَ', 'et y a réparti ses nourritures en quatre jours égales, pour ceux qui demandent.', 16),
((SELECT id FROM public.surahs WHERE number = 41), 17, 'ثُمَّ اسْتَوَىٰ إِلَى السَّمَاءِ وَهِيَ دُخَانٌ', 'Puis Il S''est tourné vers le ciel qui était fumée,', 17),
((SELECT id FROM public.surahs WHERE number = 41), 18, 'فَقَالَ لَهَا وَلِلْأَرْضِ ائْتِيَا طَوْعًا أَوْ كَرْهًا', 'et lui a dit, et à la terre: Venez de bon gré ou de force.', 18),
((SELECT id FROM public.surahs WHERE number = 41), 19, 'قَالَتَا أَتَيْنَا طَائِعِينَ', 'Elles dirent: Nous venons de bon gré.', 19),
((SELECT id FROM public.surahs WHERE number = 41), 20, 'فَقَضَاهُنَّ سَبْعَ سَمَاوَاتٍ فِي يَوْمَيْنِ', 'Il les décréta en sept cieux en deux jours.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 42: Ash-Shura (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 42), 1, 'حم', 'Ha Mim.', 1),
((SELECT id FROM public.surahs WHERE number = 42), 2, 'عسق', 'Ayn Sin Qaf.', 2),
((SELECT id FROM public.surahs WHERE number = 42), 3, 'كَذَٰلِكَ يُوحِي إِلَيْكَ وَإِلَى الَّذِينَ مِن قَبْلِكَ', 'Ainsi te révèle, et à ceux avant toi, Allah le Tout-Puissant, le Sage.', 3),
((SELECT id FROM public.surahs WHERE number = 42), 4, 'لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ', 'À Lui ce qui est dans les cieux et sur la terre.', 4),
((SELECT id FROM public.surahs WHERE number = 42), 5, 'وَهُوَ الْعَلِيُّ الْعَظِيمُ', 'Il est le Très-Haut, l''Immense.', 5),
((SELECT id FROM public.surahs WHERE number = 42), 6, 'تَكَادُ السَّمَاوَاتُ يَتَفَطَّرْنَ مِن فَوْقِهِنَّ', 'Les cieux sont sur le point de se fendre au-dessus de lui.', 6),
((SELECT id FROM public.surahs WHERE number = 42), 7, 'وَالْمَلَائِكَةُ يُسَبِّحُونَ بِحَمْدِ رَبِّهِمْ', 'Et les Anges glorifient la louange de leur Seigneur', 7),
((SELECT id FROM public.surahs WHERE number = 42), 8, 'وَيَسْتَغْفِرُونَ لِمَن فِي الْأَرْضِ', 'et implorent le pardon pour ceux sur la terre.', 8),
((SELECT id FROM public.surahs WHERE number = 42), 9, 'أَلَا إِنَّ اللَّهَ هُوَ الْغَفُورُ الرَّحِيمُ', 'En vérité, Allah est le Pardonneur, le Très Miséricordieux.', 9),
((SELECT id FROM public.surahs WHERE number = 42), 10, 'وَالَّذِينَ اتَّخَذُوا مِن دُونِهِ أَوْلِيَاءَ اللَّهُ حَفِيظٌ عَلَيْهِمْ', 'Ceux qui prennent des alliés en dehors de Lui, Allah les observe.', 10),
((SELECT id FROM public.surahs WHERE number = 42), 11, 'وَمَا أَنتَ عَلَيْهِم بِوَكِيلٍ', 'Tu n''es pas leur tuteur.', 11),
((SELECT id FROM public.surahs WHERE number = 42), 12, 'وَكَذَٰلِكَ أَوْحَيْنَا إِلَيْكَ قُرْآنًا عَرَبِيًّا', 'C''est ainsi que Nous t''avons révélé un Coran arabe,', 12),
((SELECT id FROM public.surahs WHERE number = 42), 13, 'لِتُنذِرَ أُمَّ الْقُرَىٰ وَمَنْ حَوْلَهَا', 'pour avertir la Mère des cités et ceux autour d''elle.', 13),
((SELECT id FROM public.surahs WHERE number = 42), 14, 'وَمَن يُؤْمِن بِالْآخِرَةِ يُؤْمِن بِهِ', 'Et quiconque croit en l''au-delà y croit.', 14),
((SELECT id FROM public.surahs WHERE number = 42), 15, 'وَهُمْ مِّنْ خَشْيَتِهِ مُشْفِقُونَ', 'Et de Sa crainte, ils sont effrayés.', 15),
((SELECT id FROM public.surahs WHERE number = 42), 16, 'وَالَّذِينَ اخْتَلَفُوا فِي الْكِتَابِ', 'Ceux qui divergent au sujet du Livre', 16),
((SELECT id FROM public.surahs WHERE number = 42), 17, 'إِن كَانَتْ إِلَّا صَيْحَةً وَاحِدَةً فَإِذَا هُمْ خَاصِمُونَ', 'n''étaient qu''en un seul cri, et voilà qu''ils disputent.', 17),
((SELECT id FROM public.surahs WHERE number = 42), 18, 'فَإِنْ أَعْرَضُوا فَمَا أَرْسَلْنَاكَ عَلَيْهِمْ حَفِيظًا', 'S''ils se détournent, Nous ne t''avons pas envoyé pour les garder.', 18),
((SELECT id FROM public.surahs WHERE number = 42), 19, 'إِنْ أَنتَ إِلَّا نَذِيرٌ', 'Tu n''es qu''un avertisseur.', 19),
((SELECT id FROM public.surahs WHERE number = 42), 20, 'وَإِنَّ اللَّهَ هُوَ السَّمِيعُ الْبَصِيرُ', 'Et Allah est l''Audient, le Clairvoyant.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 43: Az-Zukhruf (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 43), 1, 'حم', 'Ha Mim.', 1),
((SELECT id FROM public.surahs WHERE number = 43), 2, 'وَالْكِتَابِ الْمُبِينِ', 'Par le Livre clair!', 2),
((SELECT id FROM public.surahs WHERE number = 43), 3, 'إِنَّا جَعَلْنَاهُ قُرْآنًا عَرَبِيًّا لَّعَلَّكُمْ تَعْقِلُونَ', 'Nous en avons fait un Coran arabe, afin que vous raisonniez.', 3),
((SELECT id FROM public.surahs WHERE number = 43), 4, 'وَإِنَّهُ فِي أُمِّ الْكِتَابِ لَدَيْنَا لَعَلِيٌّ حَكِيمٌ', 'Il est, dans la Mère du Livre, auprès de Nous, suprême, sage.', 4),
((SELECT id FROM public.surahs WHERE number = 43), 5, 'أَفَنَضْرِبُ عَنكُمُ الذِّكْرَ صَفْحًا أَن كُنتُمْ قَوْمًا مُّسْرِفِينَ', 'Allons-Nous vous priver du Rappel parce que vous êtes un peuple outrancier?', 5),
((SELECT id FROM public.surahs WHERE number = 43), 6, 'وَكَمْ أَرْسَلْنَا مِن نَّبِيٍّ فِي الْأَوَّلِينَ', 'Combien de prophètes avons-Nous envoyés parmi les anciens!', 6),
((SELECT id FROM public.surahs WHERE number = 43), 7, 'وَمَا يَأْتِيهِم مِّن نَّبِيٍّ إِلَّا كَانُوا بِهِ يَسْتَهْزِئُونَ', 'Aucun prophète ne leur venait sans qu''ils ne le raillent.', 7),
((SELECT id FROM public.surahs WHERE number = 43), 8, 'فَأَهْلَكْنَا أَشَدَّ مِنْهُم بَطْشًا', 'Nous avons anéanti des plus forts qu''eux.', 8),
((SELECT id FROM public.surahs WHERE number = 43), 9, 'وَمَضَىٰ مَثَلُ الْأَوَّلِينَ', 'Et le cas des anciens s''est accompli.', 9),
((SELECT id FROM public.surahs WHERE number = 43), 10, 'وَلَئِن سَأَلْتَهُم مَّنْ خَلَقَ السَّمَاوَاتِ وَالْأَرْضَ', 'Si tu leur demandes qui a créé les cieux et la terre,', 10),
((SELECT id FROM public.surahs WHERE number = 43), 11, 'لَيَقُولُنَّ خَلَقَهُنَّ الْعَزِيزُ الْعَلِيمُ', 'ils diront: Les a créés le Tout-Puissant, l''Omniscient.', 11),
((SELECT id FROM public.surahs WHERE number = 43), 12, 'الَّذِي جَعَلَ لَكُمُ الْأَرْضَ مَهْدًا', 'Celui qui a fait de la terre un berceau pour vous,', 12),
((SELECT id FROM public.surahs WHERE number = 43), 13, 'وَجَعَلَ لَكُمْ فِيهَا سُبُلًا لَّعَلَّكُمْ تَهْتَدُونَ', 'et y a tracé des voies pour que vous vous guidiez,', 13),
((SELECT id FROM public.surahs WHERE number = 43), 14, 'وَالَّذِي نَزَّلَ مِنَ السَّمَاءِ مَاءً بِقَدَرٍ', 'Et qui fait descendre du ciel une eau avec mesure.', 14),
((SELECT id FROM public.surahs WHERE number = 43), 15, 'فَأَنشَرْنَا بِهِ بَلْدَةً مَّيْتًا ۚ كَذَٰلِكَ تُخْرَجُونَ', 'Par laquelle Nous revivifions une contrée morte. Ainsi vous serez sortis.', 15),
((SELECT id FROM public.surahs WHERE number = 43), 16, 'وَلَهُ مَن فِي السَّمَاوَاتِ وَالْأَرْضِ', 'À Lui quiconque est dans les cieux et la terre,', 16),
((SELECT id FROM public.surahs WHERE number = 43), 17, 'وَمَنْ عِندَهُ لَا يَسْتَكْبِرُونَ عَنْ عِبَادَتِهِ', 'et ceux auprès de Lui ne s''enorgueillissent pas de L''adorer', 17),
((SELECT id FROM public.surahs WHERE number = 43), 18, 'وَلَا يَسْتَحْسِرُونَ', 'et ne s''épuisent pas.', 18),
((SELECT id FROM public.surahs WHERE number = 43), 19, 'يُسَبِّحُونَ اللَّيْلَ وَالنَّهَارَ لَا يَفْتُرُونَ', 'Ils glorifient nuit et jour, sans relâche.', 19),
((SELECT id FROM public.surahs WHERE number = 43), 20, 'أَمِ اتَّخَذُوا آلِهَةً مِّنَ الْأَرْضِ هُمْ يُنشِرُونَ', 'Ou ont-ils pris des divinités de la terre, qui ressuscitent?', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 44: Ad-Dukhan (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 44), 1, 'حم', 'Ha Mim.', 1),
((SELECT id FROM public.surahs WHERE number = 44), 2, 'وَالْكِتَابِ الْمُبِينِ', 'Par le Livre clair!', 2),
((SELECT id FROM public.surahs WHERE number = 44), 3, 'إِنَّا أَنزَلْنَاهُ فِي لَيْلَةٍ مُّبَارَكَةٍ ۚ إِنَّا كُنَّا مُنذِرِينَ', 'Nous l''avons fait descendre en une nuit bénie. Nous sommes Avertisseurs.', 3),
((SELECT id FROM public.surahs WHERE number = 44), 4, 'فِيهَا يُفْرَقُ كُلُّ أَمْرٍ حَكِيمٍ', 'En elle, toute affaire sage se décide,', 4),
((SELECT id FROM public.surahs WHERE number = 44), 5, 'أَمْرًا مِّنْ عِندِنَا ۚ إِنَّا كُنَّا مُرْسِلِينَ', 'un ordre de Notre part. Nous sommes Envoyeurs,', 5),
((SELECT id FROM public.surahs WHERE number = 44), 6, 'رَحْمَةً مِّن رَّبِّكَ ۚ إِنَّهُ هُوَ السَّمِيعُ الْعَلِيمُ', 'une miséricorde de ton Seigneur. C''est Lui l''Audient, l''Omniscient,', 6),
((SELECT id FROM public.surahs WHERE number = 44), 7, 'رَبِّ السَّمَاوَاتِ وَالْأَرْضِ وَمَا بَيْنَهُمَا ۖ إِن كُنتُم مُّوقِنِينَ', 'Seigneur des cieux, de la terre et de ce qui est entre eux, si vous êtes convaincus.', 7),
((SELECT id FROM public.surahs WHERE number = 44), 8, 'لَا إِلَٰهَ إِلَّا هُوَ يُحْيِي وَيُمِيتُ ۖ رَبُّكُمْ وَرَبُّ آبَائِكُمُ الْأَوَّلِينَ', 'Nulle divinité sauf Lui. Il fait vivre et mourir. Votre Seigneur et le Seigneur de vos premiers ancêtres.', 8),
((SELECT id FROM public.surahs WHERE number = 44), 9, 'بَلْ هُمْ فِي شَكٍّ يَلْعَبُونَ', 'Mais ils sont dans le doute, s''amusant.', 9),
((SELECT id FROM public.surahs WHERE number = 44), 10, 'فَارْتَقِبْ يَوْمَ تَأْتِي السَّمَاءُ بِدُخَانٍ مُّبِينٍ', 'Attends donc le Jour où le ciel apportera une fumée visible.', 10),
((SELECT id FROM public.surahs WHERE number = 44), 11, 'يَغْشَى النَّاسَ ۖ هَٰذَا عَذَابٌ أَلِيمٌ', 'Elle enveloppera les gens. Ce sera un châtiment douloureux.', 11),
((SELECT id FROM public.surahs WHERE number = 44), 12, 'رَبَّنَا اكْشِفْ عَنَّا الْعَذَابَ إِنَّا مُؤْمِنُونَ', 'Seigneur! Écarte de nous le châtiment. Nous croyons!', 12),
((SELECT id FROM public.surahs WHERE number = 44), 13, 'أَنَّىٰ لَهُمُ الذِّكْرَىٰ وَقَدْ جَاءَهُمْ رَسُولٌ مُّبِينٌ', 'Comment peuvent-ils se rappeler, alors qu''un Messager clair leur est venu?', 13),
((SELECT id FROM public.surahs WHERE number = 44), 14, 'ثُمَّ تَوَلَّوْا عَنْهُ وَقَالُوا مُعَلَّمٌ مَّجْنُونٌ', 'Puis ils s''en détournèrent et dirent: Un enseigné, un fou!', 14),
((SELECT id FROM public.surahs WHERE number = 44), 15, 'إِنَّا كَاشِفُو الْعَذَابِ قَلِيلًا ۚ إِنَّكُمْ عَائِدُونَ', 'Nous écartons le châtiment un peu. Vous récidiverez.', 15),
((SELECT id FROM public.surahs WHERE number = 44), 16, 'يَوْمَ نَبْطِشُ الْبَطْشَةَ الْكُبْرَىٰ إِنَّا مُنتَقِمُونَ', 'Le Jour où Nous frapperons de la grande frappe. Nous Nous vengerons.', 16),
((SELECT id FROM public.surahs WHERE number = 44), 17, 'وَلَقَدْ فَتَنَّا قَبْلَهُمْ قَوْمَ فِرْعَوْنَ وَجَاءَهُمْ رَسُولٌ كَرِيمٌ', 'Nous avons éprouvé avant eux le peuple de Pharaon, et un noble Messager leur vint:', 17),
((SELECT id FROM public.surahs WHERE number = 44), 18, 'أَنْ أَدُّوا إِلَيَّ عِبَادَ اللَّهِ ۖ إِنِّي لَكُمْ رَسُولٌ أَمِينٌ', 'Remettez-moi les serviteurs d''Allah. Je suis pour vous un Messager digne de foi.', 18),
((SELECT id FROM public.surahs WHERE number = 44), 19, 'وَأَلَّا تَعْلُوا عَلَى اللَّهِ ۖ إِنِّي أَتَيْتُكُم بِسُلْطَانٍ مُّبِينٍ', 'Et ne vous élevez pas contre Allah. Je vous apporte une autorité évidente.', 19),
((SELECT id FROM public.surahs WHERE number = 44), 20, 'وَإِنِّي عُذْتُ بِرَبِّي وَرَبِّكُمْ أَن تَرْجُمُونِ', 'Je me réfugie auprès de mon Seigneur et votre Seigneur, pour que vous ne me lapidiez pas.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 45: Al-Jathiya (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 45), 1, 'حم', 'Ha Mim.', 1),
((SELECT id FROM public.surahs WHERE number = 45), 2, 'تَنزِيلُ الْكِتَابِ مِنَ اللَّهِ الْعَزِيزِ الْحَكِيمِ', 'Révélation du Livre de la part d''Allah, le Tout-Puissant, le Sage.', 2),
((SELECT id FROM public.surahs WHERE number = 45), 3, 'إِنَّ فِي السَّمَاوَاتِ وَالْأَرْضِ لَآيَاتٍ لِّلْمُؤْمِنِينَ', 'Il y a, dans les cieux et sur la terre, des signes pour les croyants,', 3),
((SELECT id FROM public.surahs WHERE number = 45), 4, 'وَفِي خَلْقِكُمْ وَمَا يَبُثُّ مِن دَابَّةٍ آيَاتٌ لِّقَوْمٍ يُوقِنُونَ', 'et dans votre création et ce qu''Il disperse de bêtes, des signes pour un peuple convaincu.', 4),
((SELECT id FROM public.surahs WHERE number = 45), 5, 'وَاخْتِلَافِ اللَّيْلِ وَالنَّهَارِ وَمَا أَنزَلَ اللَّهُ مِنَ السَّمَاءِ مِن رِّزْقٍ', 'Et dans l''alternance de la nuit et du jour, et ce qu''Allah fait descendre du ciel comme subsistance,', 5),
((SELECT id FROM public.surahs WHERE number = 45), 6, 'فَأَحْيَا بِهِ الْأَرْضَ بَعْدَ مَوْتِهَا وَتَصْرِيفِ الرِّيَاحِ آيَاتٌ لِّقَوْمٍ يَعْقِلُونَ', 'et revivifie par elle la terre après sa mort, et dans la variation des vents, des signes pour un peuple qui raisonne.', 6),
((SELECT id FROM public.surahs WHERE number = 45), 7, 'تِلْكَ آيَاتُ اللَّهِ نَتْلُوهَا عَلَيْكَ بِالْحَقِّ', 'Ce sont les signes d''Allah que Nous te récitons en vérité.', 7),
((SELECT id FROM public.surahs WHERE number = 45), 8, 'فَبِأَيِّ حَدِيثٍ بَعْدَ اللَّهِ وَآيَاتِهِ يُؤْمِنُونَ', 'À quel récit, après Allah et Ses signes, croiront-ils?', 8),
((SELECT id FROM public.surahs WHERE number = 45), 9, 'وَيْلٌ لِّكُلِّ أَفَّاكٍ أَثِيمٍ', 'Malheur à tout affabulateur pécheur,', 9),
((SELECT id FROM public.surahs WHERE number = 45), 10, 'يَسْمَعُ آيَاتِ اللَّهِ تُتْلَىٰ عَلَيْهِ ثُمَّ يُصِرُّ مُسْتَكْبِرًا كَأَن لَّمْ يَسْمَعْهَا', 'qui entend les signes d''Allah récités sur lui, puis s''obstine avec orgueil, comme s''il ne les avait pas entendus.', 10),
((SELECT id FROM public.surahs WHERE number = 45), 11, 'فَبَشِّرْهُ بِعَذَابٍ أَلِيمٍ', 'Annonce-lui donc un châtiment douloureux.', 11),
((SELECT id FROM public.surahs WHERE number = 45), 12, 'وَإِذَا عَلِمَ مِنْ آيَاتِنَا شَيْئًا اتَّخَذَهَا هُزُوًا', 'Et quand il sait quelque chose de Nos signes, il les prend en raillerie.', 12),
((SELECT id FROM public.surahs WHERE number = 45), 13, 'أُولَٰئِكَ لَهُمْ عَذَابٌ مُّهِينٌ', 'Ceux-là auront un châtiment humiliant.', 13),
((SELECT id FROM public.surahs WHERE number = 45), 14, 'مِن وَرَائِهِمْ جَهَنَّمُ ۖ وَلَا يُغْنِي عَنْهُم مَّا كَسَبُوا شَيْئًا', 'Derrière eux est l''Enfer. Ce qu''ils ont acquis ne leur sera d''aucune utilité,', 14),
((SELECT id FROM public.surahs WHERE number = 45), 15, 'وَلَا مَا اتَّخَذُوا مِن دُونِ اللَّهِ أَوْلِيَاءَ', 'ni les alliés qu''ils ont pris en dehors d''Allah.', 15),
((SELECT id FROM public.surahs WHERE number = 45), 16, 'وَلَهُمْ عَذَابٌ عَظِيمٌ', 'Ils auront un grand châtiment.', 16),
((SELECT id FROM public.surahs WHERE number = 45), 17, 'هَٰذَا هُدًى ۚ وَالَّذِينَ كَفَرُوا بِآيَاتِ رَبِّهِمْ لَهُمْ عَذَابٌ مِّن رِّجْزٍ أَلِيمٌ', 'Ceci est une guidée. Et ceux qui mécroient aux signes de leur Seigneur auront un châtiment douloureux d''exécration.', 17),
((SELECT id FROM public.surahs WHERE number = 45), 18, 'اللَّهُ الَّذِي سَخَّرَ لَكُمُ الْبَحْرَ لِتَجْرِيَ الْفُلْكُ فِيهِ بِأَمْرِهِ', 'Allah qui a soumis pour vous la mer, pour que les vaisseaux y voguent par Son ordre,', 18),
((SELECT id FROM public.surahs WHERE number = 45), 19, 'وَلِتَبْتَغُوا مِن فَضْلِهِ وَلَعَلَّكُمْ تَشْكُرُونَ', 'et pour que vous cherchiez Sa grâce, et que vous soyez reconnaissants.', 19),
((SELECT id FROM public.surahs WHERE number = 45), 20, 'وَسَخَّرَ لَكُم مَّا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ جَمِيعًا مِّنْهُ', 'Il vous a soumis ce qui est dans les cieux et sur la terre, tout vient de Lui.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 46: Al-Ahqaf (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 46), 1, 'حم', 'Ha Mim.', 1),
((SELECT id FROM public.surahs WHERE number = 46), 2, 'تَنزِيلُ الْكِتَابِ مِنَ اللَّهِ الْعَزِيزِ الْحَكِيمِ', 'Révélation du Livre de la part d''Allah, le Tout-Puissant, le Sage.', 2),
((SELECT id FROM public.surahs WHERE number = 46), 3, 'مَا خَلَقْنَا السَّمَاوَاتِ وَالْأَرْضَ وَمَا بَيْنَهُمَا إِلَّا بِالْحَقِّ وَأَجَلٍ مُّسَمًّى', 'Nous n''avons créé les cieux, la terre et ce qui est entre eux qu''en vérité et pour un terme fixé.', 3),
((SELECT id FROM public.surahs WHERE number = 46), 4, 'وَالَّذِينَ كَفَرُوا عَمَّا أُنذِرُوا مُعْرِضُونَ', 'Mais ceux qui ont mécru se détournent de ce dont ils sont avertis.', 4),
((SELECT id FROM public.surahs WHERE number = 46), 5, 'قُلْ أَرَأَيْتُم مَّا تَدْعُونَ مِن دُونِ اللَّهِ', 'Dis: Avez-vous vu ce que vous invoquez en dehors d''Allah?', 5),
((SELECT id FROM public.surahs WHERE number = 46), 6, 'أَرُونِي مَاذَا خَلَقُوا مِنَ الْأَرْضِ', 'Montrez-moi ce qu''ils ont créé de la terre.', 6),
((SELECT id FROM public.surahs WHERE number = 46), 7, 'أَمْ لَهُمْ شِرْكٌ فِي السَّمَاوَاتِ', 'Ou ont-ils une part dans les cieux?', 7),
((SELECT id FROM public.surahs WHERE number = 46), 8, 'ائْتُونِي بِكِتَابٍ مِّن قَبْلِ هَٰذَا أَوْ أَثَرَةٍ مِّنْ عِلْمٍ', 'Apportez-moi un Livre antérieur à celui-ci, ou une trace de science.', 8),
((SELECT id FROM public.surahs WHERE number = 46), 9, 'إِن كُنتُمْ صَادِقِينَ', 'Si vous êtes véridiques.', 9),
((SELECT id FROM public.surahs WHERE number = 46), 10, 'وَمَنْ أَضَلُّ مِمَّن يَدْعُو مِن دُونِ اللَّهِ مَن لَّا يَسْتَجِيبُ لَهُ', 'Qui est plus égaré que celui qui invoque en dehors d''Allah quelqu''un qui ne lui répondra pas', 10),
((SELECT id FROM public.surahs WHERE number = 46), 11, 'إِلَىٰ يَوْمِ الْقِيَامَةِ وَهُمْ عَن دُعَائِهِمْ غَافِلُونَ', 'jusqu''au Jour de la Résurrection, et qui sont inattentifs à leur invocation?', 11),
((SELECT id FROM public.surahs WHERE number = 46), 12, 'وَإِذَا حُشِرَ النَّاسُ كَانُوا لَهُمْ أَعْدَاءً', 'Et quand les gens seront rassemblés, ils seront leurs ennemis', 12),
((SELECT id FROM public.surahs WHERE number = 46), 13, 'وَكَانُوا بِعِبَادَتِهِمْ كَافِرِينَ', 'et renieront leur adoration.', 13),
((SELECT id FROM public.surahs WHERE number = 46), 14, 'وَإِذَا تُتْلَىٰ عَلَيْهِمْ آيَاتُنَا بَيِّنَاتٍ', 'Et quand Nos versets clairs leur sont récités,', 14),
((SELECT id FROM public.surahs WHERE number = 46), 15, 'قَالَ الَّذِينَ كَفَرُوا لِلْحَقِّ لَمَّا جَاءَهُمْ هَٰذَا سِحْرٌ مُّبِينٌ', 'les infidèles dirent de la vérité quand elle leur vint: Ceci est une magie évidente.', 15),
((SELECT id FROM public.surahs WHERE number = 46), 16, 'أَمْ يَقُولُونَ افْتَرَاهُ ۖ بَلْ هُوَ الْحَقُّ مِن رَّبِّكَ', 'Ou diront-ils: Il l''a forgé? C''est la vérité de ton Seigneur,', 16),
((SELECT id FROM public.surahs WHERE number = 46), 17, 'لِتُنذِرَ قَوْمًا مَّا أَتَاهُم مِّن نَّذِيرٍ مِّن قَبْلِكَ', 'pour avertir un peuple auquel aucun avertisseur n''est venu avant toi.', 17),
((SELECT id FROM public.surahs WHERE number = 46), 18, 'لَعَلَّهُمْ يَهْتَدُونَ', 'Afin qu''ils se guident.', 18),
((SELECT id FROM public.surahs WHERE number = 46), 19, 'أَوَلَمْ يَرَوْا أَنَّ اللَّهَ الَّذِي خَلَقَ السَّمَاوَاتِ وَالْأَرْضَ', 'N''ont-ils pas vu qu''Allah qui a créé les cieux et la terre', 19),
((SELECT id FROM public.surahs WHERE number = 46), 20, 'وَلَمْ يَعْيَ بِخَلْقِهِنَّ بِقَادِرٍ عَلَىٰ أَن يَخْلُقَ الْمَوْتَىٰ', 'et n''a pas faibli à les créer, est capable de ressusciter les morts?', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 47: Muhammad (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 47), 1, 'الَّذِينَ كَفَرُوا وَصَدُّوا عَن سَبِيلِ اللَّهِ أَضَلَّ أَعْمَالَهُمْ', 'Ceux qui ont mécru et obstrué le sentier d''Allah, Allah a égaré leurs actions.', 1),
((SELECT id FROM public.surahs WHERE number = 47), 2, 'وَالَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ وَآمَنُوا بِمَا نُزِّلَ عَلَىٰ مُحَمَّدٍ', 'Et ceux qui croient et font le bien, et croient en ce qui a été descendu sur Muhammad', 2),
((SELECT id FROM public.surahs WHERE number = 47), 3, 'وَهُوَ الْحَقُّ مِن رَّبِّهِمْ ۚ كَفَّرَ عَنْهُمْ سَيِّئَاتِهِمْ وَأَصْلَحَ بَالَهُمْ', 'et c''est la vérité de leur Seigneur: Il efface leurs mauvaises actions et réforme leur état.', 3),
((SELECT id FROM public.surahs WHERE number = 47), 4, 'ذَٰلِكَ بِأَنَّ الَّذِينَ كَفَرُوا اتَّبَعُوا الْبَاطِلَ', 'C''est parce que ceux qui ont mécru ont suivi le faux,', 4),
((SELECT id FROM public.surahs WHERE number = 47), 5, 'وَأَنَّ الَّذِينَ آمَنُوا اتَّبَعُوا الْحَقَّ مِن رَّبِّهِمْ', 'et ceux qui croient ont suivi la vérité de leur Seigneur.', 5),
((SELECT id FROM public.surahs WHERE number = 47), 6, 'كَذَٰلِكَ يَضْرِبُ اللَّهُ لِلنَّاسِ أَمْثَالَهُمْ', 'Ainsi Allah propose leurs paraboles aux gens.', 6),
((SELECT id FROM public.surahs WHERE number = 47), 7, 'فَإِذَا لَقِيتُمُ الَّذِينَ كَفَرُوا فَضَرْبَ الرِّقَابِ', 'Quand vous rencontrez les infidèles, frappez les cous.', 7),
((SELECT id FROM public.surahs WHERE number = 47), 8, 'حَتَّىٰ إِذَا أَثْخَنتُمُوهُمْ فَشُدُّوا الْوَثَاقَ', 'Quand vous les avez accablés, ligotez-les.', 8),
((SELECT id FROM public.surahs WHERE number = 47), 9, 'فَإِمَّا مَنًّا بَعْدُ وَإِمَّا فِدَاءً', 'Ensuite, libération gracieuse ou rançon, jusqu''à la fin de la guerre.', 9),
((SELECT id FROM public.surahs WHERE number = 47), 10, 'حَتَّىٰ تَضَعَ الْحَرْبُ أَوْزَارَهَا', 'Jusqu''à ce que la guerre dépose ses fardeaux.', 10),
((SELECT id FROM public.surahs WHERE number = 47), 11, 'ذَٰلِكَ وَلَوْ يَشَاءُ اللَّهُ لَانتَصَرَ مِنْهُمْ', 'C''est ainsi. Si Allah voulait, Il se vengerait d''eux,', 11),
((SELECT id FROM public.surahs WHERE number = 47), 12, 'وَلَٰكِن لِّيَبْلُوَ بَعْضَكُم بِبَعْضٍ', 'mais Il vous éprouve par d''autres.', 12),
((SELECT id FROM public.surahs WHERE number = 47), 13, 'وَالَّذِينَ قُتِلُوا فِي سَبِيلِ اللَّهِ فَلَن يُضِلَّ أَعْمَالَهُمْ', 'Ceux qui sont tués dans le sentier d''Allah, Il n''égarera pas leurs actions.', 13),
((SELECT id FROM public.surahs WHERE number = 47), 14, 'سَيَهْدِيهِمْ وَيُصْلِحُ بَالَهُمْ', 'Il les guidera et réformera leur état,', 14),
((SELECT id FROM public.surahs WHERE number = 47), 15, 'وَيُدْخِلُهُمُ الْجَنَّةَ عَرَّفَهَا لَهُمْ', 'et les fera entrer au Paradis qu''Il leur a fait connaître.', 15),
((SELECT id FROM public.surahs WHERE number = 47), 16, 'يَا أَيُّهَا الَّذِينَ آمَنُوا إِن تَنصُرُوا اللَّهَ يَنصُرْكُمْ', 'Ô vous qui avez cru! Si vous secourez Allah, Il vous secourra.', 16),
((SELECT id FROM public.surahs WHERE number = 47), 17, 'وَيُثَبِّتْ أَقْدَامَكُمْ', 'Et affermira vos pas.', 17),
((SELECT id FROM public.surahs WHERE number = 47), 18, 'وَالَّذِينَ كَفَرُوا فَتَعْسًا لَّهُمْ وَأَضَلَّ أَعْمَالَهُمْ', 'Et les infidèles, malheur à eux! Il égarera leurs actions.', 18),
((SELECT id FROM public.surahs WHERE number = 47), 19, 'ذَٰلِكَ بِأَنَّهُمْ كَرِهُوا مَا أَنزَلَ اللَّهُ فَأَحْبَطَ أَعْمَالَهُمْ', 'C''est parce qu''ils ont détesté ce qu''Allah a fait descendre, Il a donc annulé leurs actions.', 19),
((SELECT id FROM public.surahs WHERE number = 47), 20, 'أَفَلَمْ يَسِيرُوا فِي الْأَرْضِ فَيَنظُرُوا كَيْفَ كَانَ عَاقِبَةُ الَّذِينَ مِن قَبْلِهِمْ', 'N''ont-ils pas voyagé sur terre pour voir quelle fut la fin de ceux avant eux?', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

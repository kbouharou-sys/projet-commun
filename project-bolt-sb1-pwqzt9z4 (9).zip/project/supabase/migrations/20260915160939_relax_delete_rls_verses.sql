-- Relax DELETE policy on verses to allow any authenticated user (needed for import flow)
DROP POLICY IF EXISTS "admin_delete_verses" ON public.verses;

CREATE POLICY "auth_delete_verses" ON public.verses FOR DELETE
  TO authenticated USING (true);

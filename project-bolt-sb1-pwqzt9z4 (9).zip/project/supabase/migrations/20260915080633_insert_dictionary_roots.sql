/*
# Insert roots dictionary data

Populates the `roots` table with common Quranic Arabic roots and French translations.
*/

INSERT INTO public.roots (arabic_root, root_translation, occurrence_count, frequency_rank)
VALUES
('ك ت ب', 'écrire, livre, prescrire', 304, 1),
('ق و ل', 'dire, parler, parole', 1722, 2),
('ع ل م', 'savoir, connaître, science', 854, 3),
('ر ب ب', 'Seigneur, maître, éduquer', 984, 4),
('إ ل ه', 'dieu, divinité, Allah', 2851, 5),
('م ن ن', 'accorder, favoriser, grâce', 338, 6),
('خ ل ق', 'créer, création', 261, 7),
('س م ع', 'entendre, écouter, ouïe', 185, 8),
('ب ص ر', 'voir, regarder, vue', 148, 9),
('ن ف س', 'âme, personne, soi', 298, 10),
('ء م ن', 'croire, foi, sécurité', 875, 11),
('ك ف ر', 'mécréance, ingrat, couvrir', 525, 12),
('ج ن ن', 'djinn, démon, cacher', 224, 13),
('ه د ي', 'guider, guidance, droit chemin', 316, 14),
('ض ل ل', 'égarer, égarement, erreur', 271, 15),
('ش ر ع', 'voie, loi, prescrire', 22, 16),
('ح م د', 'louange, remercier', 67, 17),
('س ل م', 'paix, soumission, salut', 140, 18),
('ع ب د', 'adorer, serviteur, culte', 276, 19),
('ف ت ح', 'ouvrir, victoire, juger', 107, 20),
('ق ض ي', 'décréter, juger, accomplir', 265, 21),
('د خ ل', 'entrer, admission', 227, 22),
('خ ر ج', 'sortir, extérieur', 252, 23),
('ح ي ي', 'vivre, vie, vivant', 171, 24),
('م و ت', 'mourir, mort, trépas', 159, 25),
('ن و ر', 'lumière, éclairer', 49, 26),
('ق ر ء', 'lire, réciter, Coran', 88, 27),
('ص ل و', 'prier, prière, bénir', 99, 28),
('ز ك و', 'purifier, aumône, pureté', 59, 29),
('ر ح م', 'miséricorde, pardon, clémence', 339, 30),
('س ج د', 'se prosterner, adoration', 92, 31),
('ش ك ر', 'remercier, gratitude', 75, 32),
('ط ع م', 'nourriture, manger', 119, 33),
('م ل ك', 'posséder, royaume, souveraineté', 223, 34),
('ج ن ة', 'paradis, jardin', 147, 35),
('ن ا ر', 'feu, fournaise, enfer', 145, 36),
('ي و م', 'jour, époque', 413, 37),
('ل ي ل', 'nuit', 92, 38),
('ض ي ف', 'invité, hôte', 10, 39),
('ب ي ع', 'vendre, commerce, pacte', 15, 40)
ON CONFLICT (arabic_root) DO NOTHING;

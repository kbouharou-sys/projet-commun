/*
# Insert verses for surahs 73, 74, 75, 76, 84

## Surahs added:
- 73: Al-Muzzammil (20 verses)
- 74: Al-Muddaththir (56 verses)
- 75: Al-Qiyama (40 verses)
- 76: Al-Insan (31 verses)
- 84: Al-Inshiqaq (25 verses)
*/

-- =========================================================
-- SURAH 73: Al-Muzzammil (20 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 73), 1, 'يَا أَيُّهَا الْمُزَّمِّلُ', 'Ô toi, l''enveloppé (dans tes vêtements)!', 1),
((SELECT id FROM public.surahs WHERE number = 73), 2, 'قُمِ اللَّيْلَ إِلَّا قَلِيلًا', 'Lève-toi (pour prier) la nuit, sauf une petite partie,', 2),
((SELECT id FROM public.surahs WHERE number = 73), 3, 'نِصْفَهُ أَوِ انقُصْ مِنْهُ قَلِيلًا', 'sa moitié, ou un peu moins,', 3),
((SELECT id FROM public.surahs WHERE number = 73), 4, 'أَوْ زِدْ عَلَيْهِ وَرَتِّلِ الْقُرْآنَ تَرْتِيلًا', 'ou un peu plus. Et récite le Coran, lentement et clairement.', 4),
((SELECT id FROM public.surahs WHERE number = 73), 5, 'إِنَّا سَنُلْقِي عَلَيْكَ قَوْلًا ثَقِيلًا', 'Nous allons te révéler des paroles lourdes, très lourdes.', 5),
((SELECT id FROM public.surahs WHERE number = 73), 6, 'إِنَّ نَاشِئَةَ اللَّيْلِ هِيَ أَشَدُّ وَطْئًا وَأَقْوَمُ قِيلًا', 'La prière pendant la nuit est plus efficace et plus propice pour la récitation.', 6),
((SELECT id FROM public.surahs WHERE number = 73), 7, 'إِنَّ لَكَ فِي اَلنَّهَارِ سَبْحًا طَوِيلًا', 'En effet, tu as, dans la journée, de longues occupations.', 7),
((SELECT id FROM public.surahs WHERE number = 73), 8, 'وَاذْكُرِ اسْمَ رَبِّكَ وَتَبَتَّلْ إِلَيْهِ تَبْتِيلًا', 'Et invoque le nom de ton Seigneur et consacre-toi totalement à Lui.', 8),
((SELECT id FROM public.surahs WHERE number = 73), 9, 'رَبُّ الْمَشْرِقِ وَالْمَغْرِبِ لَا إِلَٰهَ إِلَّا هُوَ فَاتَّخِذْهُ وَكِيلًا', 'Le Seigneur du Levant et du Couchant. Il n''y a point de divinité en dehors de Lui. Prends donc Il comme Protecteur.', 9),
((SELECT id FROM public.surahs WHERE number = 73), 10, 'وَاصْبِرْ عَلَىٰ مَا يَقُولُونَ وَاهْجُرْهُمْ هَجْرًا جَمِيلًا', 'Et endure ce qu''ils disent; et écarte-toi d''eux d''une façon convenable.', 10),
((SELECT id FROM public.surahs WHERE number = 73), 11, 'وَذَرْنِي وَالْمُكَذِّبِينَ أُولِي النَّعْمَةِ وَمَهِّلْهُمْ قَلِيلًا', 'Et laisse-moi avec ceux qui traitent de mensonge (le Coran); Nous les mènerons par étapes d''où ils ne savent pas.', 11),
((SELECT id FROM public.surahs WHERE number = 73), 12, 'إِنَّ لَدَيْنَا أَنكَالًا وَجَحِيمًا', 'J''ai, auprès de Moi, des entraves et une Fournaise,', 12),
((SELECT id FROM public.surahs WHERE number = 73), 13, 'وَطَعَامًا ذَا غُصَّةٍ وَعَذَابًا أَلِيمًا', 'et une nourriture qui fait suffoquer, et un châtiment douloureux,', 13),
((SELECT id FROM public.surahs WHERE number = 73), 14, 'يَوْمَ تَرْجُفُ الْأَرْضُ وَالْجِبَالُ وَكَانَتِ الْجِبَالُ كَثِيبًا مَّهِيلًا', 'le Jour où la terre et les montagnes trembleront, tandis que les montagnes deviendront comme une dune de sable dispersée.', 14),
((SELECT id FROM public.surahs WHERE number = 73), 15, 'إِنَّا أَرْسَلْنَا إِلَيْكُمْ رَسُولًا شَاهِدًا عَلَيْكُمْ كَمَا أَرْسَلْنَا إِلَىٰ فِرْعَوْنَ رَسُولًا', 'Nous vous avons envoyé un Messager pour qu''il soit témoin contre vous, de même que Nous avions envoyé un Messager à Pharaon.', 15),
((SELECT id FROM public.surahs WHERE number = 73), 16, 'فَعَصَىٰ فِرْعَوْنُ الرَّسُولَ فَأَخَذْنَاهُ أَخْذًا وَبِيلًا', 'Pharaon ayant alors désobéi au Messager, Nous le saisîmes d''une punition terrible.', 16),
((SELECT id FROM public.surahs WHERE number = 73), 17, 'فَكَيْفَ تَتَّقُونَ إِن كَفَرْتُمْ يَوْمًا يَجْعَلُ الْوِلْدَانَ شِيبًا', 'Si vous mécroyez, comment vous garderez-vous d''un Jour qui rendra les enfants blancs de vieillesse?', 17),
((SELECT id FROM public.surahs WHERE number = 73), 18, 'السَّمَاءُ مُنفَطِرٌ بِهِ ۚ كَانَ وَعْدُهُ مَفْعُولًا', 'Le ciel se fendra de ce Jour. Sa promesse s''accomplira certainement.', 18),
((SELECT id FROM public.surahs WHERE number = 73), 19, 'إِنَّ هَٰذِهِ تَذْكِرَةٌ ۚ فَمَن شَاءَ اتَّخَذَ إِلَىٰ رَبِّهِ سَبِيلًا', 'Ceci est un rappel. Que celui qui veut prenne une voie vers son Seigneur.', 19),
((SELECT id FROM public.surahs WHERE number = 73), 20, 'إِنَّ رَبَّكَ يَعْلَمُ أَنَّكَ تَقُومُ أَدْنَىٰ مِن ثُلُثَيِ اللَّيْلِ وَنِصْفَهُ وَثُلُثَهُ وَطَائِفَةٌ مِّمَّن مَّعَكَ ۚ وَاللَّهُ يُقَدِّرُ اللَّيْلَ وَالنَّهَارَ عَلِمَ أَن لَّن تُحْصُوهُ فَتَابَ عَلَيْكُمْ فَاقْرَءُوا مَا تَيَسَّرَ مِنَ الْقُرْآنِ ۚ عَلِمَ أَن سَيَكُونُ مِنكُم مَّرْضَىٰ ۙ وَآخَرُونَ يَضْرِبُونَ فِي الْأَرْضِ يَبْتَغُونَ مِن فَضْلِ اللَّهِ ۙ وَآخَرُونَ يُقَاتِلُونَ فِي سَبِيلِ اللَّهِ ۖ فَاقْرَءُوا مَا تَيَسَّرَ مِنْهُ ۚ وَأَقِيمُوا الصَّلَاةَ وَآتُوا الزَّكَاةَ وَأَقْرِضُوا اللَّهَ قَرْضًا حَسَنًا ۚ وَمَا تُقَدِّمُوا لِأَنفُسِكُم مِّنْ خَيْرٍ تَجِدُوهُ عِندَ اللَّهِ هُوَ خَيْرًا وَأَعْظَمَ أَجْرًا ۚ وَاسْتَغْفِرُوا اللَّهَ ۖ إِنَّ اللَّهَ غَفُورٌ رَّحِيمٌ', 'Ton Seigneur sait que tu te tiens debout près de deux tiers de la nuit, ou sa moitié, ou son tiers, de même qu''une partie de ceux qui sont avec toi. Allah détermine la nuit et le jour. Il sait que vous ne sauriez en faire le compte exact. Il vous a donc accordé son pardon. Récitez donc ce qui est possible du Coran. Il sait qu''il y aura parmi vous des malades, et d''autres qui voyageront sur la terre, en quête de la grâce d''Allah, et d''autres encore qui combattront pour la cause d''Allah. Récitez donc ce qui est possible du Coran. Accomplissez la Salat, acquittez la Zakat, et faites à Allah un prêt sincère. Tout bien que vous avancez pour vous-mêmes, vous le retrouverez auprès d''Allah meilleur et plus grand en fait de récompense. Et implorez le pardon d''Allah. Car Allah est Pardonneur et Très Miséricordieux.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 84: Al-Inshiqaq (25 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 84), 1, 'إِذَا السَّمَاءُ انشَقَّتْ', 'Quand le ciel se fendra,', 1),
((SELECT id FROM public.surahs WHERE number = 84), 2, 'وَأَذِنَتْ لِرَبِّهَا وَحُقَّتْ', 'et qu''il obéira à son Seigneur - et fera ce qu''il doit faire -,', 2),
((SELECT id FROM public.surahs WHERE number = 84), 3, 'وَإِذَا الْأَرْضُ مُدَّتْ', 'et que la terre sera nivelée,', 3),
((SELECT id FROM public.surahs WHERE number = 84), 4, 'وَأَلْقَتْ مَا فِيهَا وَتَخَلَّتْ', 'et qu''elle rejettera ce qui est en elle, et se videra,', 4),
((SELECT id FROM public.surahs WHERE number = 84), 5, 'وَأَذِنَتْ لِرَبِّهَا وَحُقَّتْ', 'et qu''elle obéira à son Seigneur - et fera ce qu''elle doit faire -,', 5),
((SELECT id FROM public.surahs WHERE number = 84), 6, 'يَا أَيُّهَا الْإِنسَانُ إِنَّكَ كَادِحٌ إِلَىٰ رَبِّكَ كَدْحًا فَمُلَاقِيهِ', 'Ô homme! Tu te fatigues vers ton Seigneur, et tu Le rencontreras.', 6),
((SELECT id FROM public.surahs WHERE number = 84), 7, 'فَأَمَّا مَنْ أُوتِيَ كِتَابَهُ بِيَمِينِهِ', 'Celui qui recevra son livre de la main droite,', 7),
((SELECT id FROM public.surahs WHERE number = 84), 8, 'فَسَوْفَ يُحَاسَبُ حِسَابًا يَسِيرًا', 'sera jugé d''un jugement facile,', 8),
((SELECT id FROM public.surahs WHERE number = 84), 9, 'وَيَنقَلِبُ إِلَىٰ أَهْلِهِ مَسْرُورًا', 'et retournera réjoui auprès des siens.', 9),
((SELECT id FROM public.surahs WHERE number = 84), 10, 'وَأَمَّا مَنْ أُوتِيَ كِتَابَهُ وَرَاءَ ظَهْرِهِ', 'Et celui qui recevra son livre par-derrière son dos,', 10),
((SELECT id FROM public.surahs WHERE number = 84), 11, 'فَسَوْفَ يَدْعُو ثُبُورًا', 'appellera à la destruction,', 11),
((SELECT id FROM public.surahs WHERE number = 84), 12, 'وَيَصْلَىٰ سَعِيرًا', 'et brûlera dans le Feu ardent.', 12),
((SELECT id FROM public.surahs WHERE number = 84), 13, 'إِنَّهُ كَانَ فِي أَهْلِهِ مَسْرُورًا', 'Il était, en effet, réjoui parmi les siens,', 13),
((SELECT id FROM public.surahs WHERE number = 84), 14, 'إِنَّهُ ظَنَّ أَن لَّن يَحُورَ', 'pensant qu''il ne reviendrait jamais (vers Allah).', 14),
((SELECT id FROM public.surahs WHERE number = 84), 15, 'بَلَىٰ إِنَّ رَبَّهُ كَانَ بِهِ بَصِيرًا', 'Mais non! Son Seigneur l''observait parfaitement.', 15),
((SELECT id FROM public.surahs WHERE number = 84), 16, 'فَلَا أُقْسِمُ بِالشَّفَقِ', 'Non!... Je jure par le crépuscule,', 16),
((SELECT id FROM public.surahs WHERE number = 84), 17, 'وَاللَّيْلِ وَمَا وَقَقَ', 'et par la nuit et ce qu''elle enveloppe,', 17),
((SELECT id FROM public.surahs WHERE number = 84), 18, 'وَالْقَمَرِ إِذَا اتَّسَقَ', 'et par la lune quand elle devient pleine,', 18),
((SELECT id FROM public.surahs WHERE number = 84), 19, 'لَتَرْكَبُنَّ طَبَقًا عَن طَبَقٍ', 'vous passerez de planète en planète!', 19),
((SELECT id FROM public.surahs WHERE number = 84), 20, 'فَمَا لَهُمْ لَا يُؤْمِنُونَ', 'Qu''ont-ils à ne pas croire?', 20),
((SELECT id FROM public.surahs WHERE number = 84), 21, 'وَإِذَا قُرِئَ عَلَيْهِمُ الْقُرْآنُ لَا يَسْجُدُونَ', 'et à ne pas se prosterner quand on leur récite le Coran?', 21),
((SELECT id FROM public.surahs WHERE number = 84), 22, 'بَلِ الَّذِينَ كَفَرُوا يُكَذِّبُونَ', 'Mais ceux qui ne croient pas traitent de mensonge (le Coran).', 22),
((SELECT id FROM public.surahs WHERE number = 84), 23, 'وَاللَّهُ أَعْلَمُ بِمَا يُوعُونَ', 'Et Allah sait mieux ce qu''ils recèlent en eux-mêmes.', 23),
((SELECT id FROM public.surahs WHERE number = 84), 24, 'فَبَشِّرْهُمْ بِعَذَابٍ أَلِيمٍ', 'Annonce-leur donc un châtiment douloureux,', 24),
((SELECT id FROM public.surahs WHERE number = 84), 25, 'إِلَّا الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ لَهُمْ أَجْرٌ غَيْرُ مَمْنُونٍ', 'sauf ceux qui croient et accomplissent de bonnes œuvres: ils auront une récompense jamais interrompue.', 25)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 75: Al-Qiyama (40 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 75), 1, 'لَا أُقْسِمُ بِيَوْمِ الْقِيَامَةِ', 'Non!... Je jure par le Jour de la Résurrection,', 1),
((SELECT id FROM public.surahs WHERE number = 75), 2, 'وَلَا أُقْسِمُ بِالنَّفْسِ اللَّوَّامَةِ', 'et Non!... Je jure par l''âme qui ne cesse de se blâmer.', 2),
((SELECT id FROM public.surahs WHERE number = 75), 3, 'أَيَحْسَبُ الْإِنسَانُ أَن لَّن نَّجْمَعَ عِظَامَهُ', 'L''homme pense-t-il que Nous ne réunirons jamais ses os?', 3),
((SELECT id FROM public.surahs WHERE number = 75), 4, 'بَلَىٰ قَادِرِينَ عَلَىٰ أَن نُّسَوِّيَ بَنَانَهُ', 'Si! Nous sommes Capable de reconstituer ses phalanges.', 4),
((SELECT id FROM public.surahs WHERE number = 75), 5, 'بَلْ يُرِيدُ الْإِنسَانُ لِيَفْجُرَ أَمَامَهُ', 'Mais l''homme aime plutôt à aller vite et à commettre des péchés devant lui.', 5),
((SELECT id FROM public.surahs WHERE number = 75), 6, 'يَسْأَلُ أَيَّانَ يَوْمُ الْقِيَامَةِ', 'Il demande: «A quand le Jour de la Résurrection?»', 6),
((SELECT id FROM public.surahs WHERE number = 75), 7, 'فَإِذَا بَرِقَ الْبَصَرُ', 'Alors que la vue sera éblouie,', 7),
((SELECT id FROM public.surahs WHERE number = 75), 8, 'وَخَسَفَ الْقَمَرُ', 'et que la lune sera éclipsée,', 8),
((SELECT id FROM public.surahs WHERE number = 75), 9, 'وَجُمِعَ الشَّمْسُ وَالْقَمَرُ', 'et que le soleil et la lune seront réunis,', 9),
((SELECT id FROM public.surahs WHERE number = 75), 10, 'يَقُولُ الْإِنسَانُ يَوْمَئِذٍ أَيْنَ الْمَفَرُّ', 'l''homme dira ce Jour-là: «Où fuir?»', 10),
((SELECT id FROM public.surahs WHERE number = 75), 11, 'كَلَّا لَا وَزَرَ', 'Non! Point de refuge!', 11),
((SELECT id FROM public.surahs WHERE number = 75), 12, 'إِلَىٰ رَبِّكَ يَوْمَئِذٍ الْمُسْتَقَرُ', 'Vers ton Seigneur sera ce Jour-là le retour.', 12),
((SELECT id FROM public.surahs WHERE number = 75), 13, 'يُنَبَّأُ الْإِنسَانُ يَوْمَئِذٍ بِمَا قَدَّمَ وَأَخَّرَ', 'L''homme sera informé ce Jour-là de ce qu''il aura avancé et de ce qu''il aura retardé.', 13),
((SELECT id FROM public.surahs WHERE number = 75), 14, 'بَلِ الْإِنسَانُ عَلَىٰ نَفْسِهِ بَصِيرَةٌ', 'Mais l''homme sera un témoin perspicace contre lui-même,', 14),
((SELECT id FROM public.surahs WHERE number = 75), 15, 'وَلَوْ أَلْقَىٰ مَعَاذِيرَهُ', 'même s''il présente ses excuses.', 15),
((SELECT id FROM public.surahs WHERE number = 75), 16, 'لَا تُحَرِّكْ بِهِ لِسَانَكَ لِتَعْجَلَ بِهِ', 'Ne remue pas ta langue pour hâter sa récitation.', 16),
((SELECT id FROM public.surahs WHERE number = 75), 17, 'إِنَّ عَلَيْنَا جَمْعَهُ وَقُرْآنَهُ', 'Son rassemblement (dans ton cœur et sa fixation dans ta mémoire) Nous incombe, ainsi que la façon de le réciter.', 17),
((SELECT id FROM public.surahs WHERE number = 75), 18, 'فَإِذَا قَرَأْنَاهُ فَاتَّبِعْ قُرْآنَهُ', 'Quand Nous le récitons, suis donc sa récitation.', 18),
((SELECT id FROM public.surahs WHERE number = 75), 19, 'ثُمَّ إِنَّ عَلَيْنَا بَيَانَهُ', 'Ensuite, c''est à Nous de l''expliquer.', 19),
((SELECT id FROM public.surahs WHERE number = 75), 20, 'كَلَّا بَلْ تُحِبُّونَ الْعَاجِلَةَ', 'Non!... Mais vous aimez la vie immédiate,', 20),
((SELECT id FROM public.surahs WHERE number = 75), 21, 'وَتَذَرُونَ الْآخِرَةَ', 'et vous délaissez l''au-delà.', 21),
((SELECT id FROM public.surahs WHERE number = 75), 22, 'وُجُوهٌ يَوْمَئِذٍ نَّاضِرَةٌ', 'Ce Jour-là, il y aura des visages resplendissants,', 22),
((SELECT id FROM public.surahs WHERE number = 75), 23, 'إِلَىٰ رَبِّهَا نَاظِرَةٌ', 'regardant leur Seigneur;', 23),
((SELECT id FROM public.surahs WHERE number = 75), 24, 'وَوُجُوهٌ يَوْمَئِذٍ بَاسِرَةٌ', 'et il y aura ce Jour-là, des visages assombris,', 24),
((SELECT id FROM public.surahs WHERE number = 75), 25, 'تَظُنُّ أَن يُفْعَلَ بِهَا فَاقِرَةٌ', 'qui s''attendent à subir une catastrophe.', 25),
((SELECT id FROM public.surahs WHERE number = 75), 26, 'كَلَّا إِذَا بَلَغَتِ التَّرَاقِيَ', 'Non! Quand l''âme en arrive aux clavicules,', 26),
((SELECT id FROM public.surahs WHERE number = 75), 27, 'وَقِيلَ مَنْ ۛ رَاقٍ', 'et que l''on dit: «Qui est un exorciseur?»', 27),
((SELECT id FROM public.surahs WHERE number = 75), 28, 'وَظَنَّ أَنَّهُ الْفِرَاقُ', 'et qu''il (le mourant) croit que c''est la séparation (la mort),', 28),
((SELECT id FROM public.surahs WHERE number = 75), 29, 'وَالْتَفَّتِ السَّاقُ بِالسَّاقِ', 'et que la jambe s''enlace à la jambe,', 29),
((SELECT id FROM public.surahs WHERE number = 75), 30, 'إِلَىٰ رَبِّكَ يَوْمَئِذٍ الْمَسَاقُ', 'ce Jour-là, c''est vers ton Seigneur que l''on sera conduit.', 30),
((SELECT id FROM public.surahs WHERE number = 75), 31, 'فَلَا صَدَّقَ وَلَا صَلَّىٰ', 'Car il n''a ni cru, ni accompli la Salat,', 31),
((SELECT id FROM public.surahs WHERE number = 75), 32, 'وَلَٰكِن كَذَّبَ وَتَوَلَّىٰ', 'par contre, il a crié au mensonge et tourné le dos.', 32),
((SELECT id FROM public.surahs WHERE number = 75), 33, 'ثُمَّ ذَهَبَ إِلَىٰ أَهْلِهِ يَتَمَطَّىٰ', 'Puis il s''en est allé, plein de fierté, vers les siens.', 33),
((SELECT id FROM public.surahs WHERE number = 75), 34, 'أَوْلَىٰ لَكَ فَأَوْلَىٰ', 'Malheur à toi, et encore malheur!', 34),
((SELECT id FROM public.surahs WHERE number = 75), 35, 'ثُمَّ أَوْلَىٰ لَكَ فَأَوْلَىٰ', 'Encore malheur à toi, et encore malheur!', 35),
((SELECT id FROM public.surahs WHERE number = 75), 36, 'أَيَحْسَبُ الْإِنسَانُ أَن يُتْرَكَ سُدًى', 'L''homme pense-t-il qu''on le laissera sans obligation à observer?', 36),
((SELECT id FROM public.surahs WHERE number = 75), 37, 'أَلَمْ يَكُ نُطْفَةً مِّن مَّنِيٍّ يُمْنَىٰ', 'N''était-il pas une goutte de sperme éjaculé?', 37),
((SELECT id FROM public.surahs WHERE number = 75), 38, 'ثُمَّ كَانَ عَلَقَةً فَخَلَقَ فَسَوَّىٰ', 'Puis il devint une adhérence; alors Allah le créa et le forma de la meilleure façon,', 38),
((SELECT id FROM public.surahs WHERE number = 75), 39, 'فَجَعَلَ مِنْهُ الزَّوْجَيْنِ الذَّكَرَ وَالْأُنثَىٰ', 'et en fit le couple mâle et femelle.', 39),
((SELECT id FROM public.surahs WHERE number = 75), 40, 'أَلَيْسَ ذَٰلِكَ بِقَادِرٍ عَلَىٰ أَن يُحْيِيَ الْمَوْتَىٰ', 'Celui-là n''est-il pas capable de faire revivre les morts?', 40)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

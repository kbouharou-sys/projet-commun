/*
# Insert verses for surahs 74, 76

## Surahs added:
- 74: Al-Muddaththir (56 verses)
- 76: Al-Insan (31 verses)
*/

-- =========================================================
-- SURAH 74: Al-Muddaththir (56 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 74), 1, 'يَا أَيُّهَا الْمُدَّثِّرُ', 'Ô toi, le revêtu d''un manteau!', 1),
((SELECT id FROM public.surahs WHERE number = 74), 2, 'قُمْ فَأَنذِرْ', 'Lève-toi et avertis!', 2),
((SELECT id FROM public.surahs WHERE number = 74), 3, 'وَرَبَّكَ فَكَبِّرْ', 'Et de ton Seigneur, célèbre la grandeur.', 3),
((SELECT id FROM public.surahs WHERE number = 74), 4, 'وَثِيَابَكَ فَطَهِّرْ', 'Et tes vêtements, purifie-les.', 4),
((SELECT id FROM public.surahs WHERE number = 74), 5, 'وَالرُّجْزَ فَاهْجُرْ', 'Et l''idolâtrie, fuis-la.', 5),
((SELECT id FROM public.surahs WHERE number = 74), 6, 'وَلَا تَمْنُن تَسْتَكْثِرُ', 'Et ne fais pas de faveur pour chercher à recevoir plus.', 6),
((SELECT id FROM public.surahs WHERE number = 74), 7, 'وَلِرَبِّكَ فَاصْبِرْ', 'Et pour ton Seigneur, endure.', 7),
((SELECT id FROM public.surahs WHERE number = 74), 8, 'فَإِذَا نُقِرَ فِي النَّاقُورِ', 'Quand on sonnera la Trompette,', 8),
((SELECT id FROM public.surahs WHERE number = 74), 9, 'فَذَٰلِكَ يَوْمَئِذٍ يَوْمٌ عَسِيرٌ', 'ce Jour-là sera un jour difficile,', 9),
((SELECT id FROM public.surahs WHERE number = 74), 10, 'عَلَى الْكَافِرِينَ غَيْرُ يَسِيرٍ', 'non facile pour les infidèles.', 10),
((SELECT id FROM public.surahs WHERE number = 74), 11, 'ذَرْنِي وَمَنْ خَلَقْتُ وَحِيدًا', 'Laisse-Moi seul avec celui que J''ai créé,', 11),
((SELECT id FROM public.surahs WHERE number = 74), 12, 'وَجَعَلْتُ لَهُ مَالًا مَّمْدُودًا', 'et à qui J''ai accordé des biens étendus,', 12),
((SELECT id FROM public.surahs WHERE number = 74), 13, 'وَبَنِينَ شُهُودًا', 'et des enfants présents (qui se tiennent près de lui),', 13),
((SELECT id FROM public.surahs WHERE number = 74), 14, 'وَمَهَّدتُّ لَهُ تَمْهِيدًا', 'et lui ai préparé un lit spacieux,', 14),
((SELECT id FROM public.surahs WHERE number = 74), 15, 'ثُمَّ يَطْمَعُ أَنْ أَزِيدَ', 'et pourtant, il convoite que Je lui donne davantage.', 15),
((SELECT id FROM public.surahs WHERE number = 74), 16, 'كَلَّا ۖ إِنَّهُ كَانَ لِآيَاتِنَا عَنِيدًا', 'Non! Il s''oppose obstinément à Nos signes.', 16),
((SELECT id FROM public.surahs WHERE number = 74), 17, 'سَأُرْهِقُهُ صَعُودًا', 'Je vais lui imposer une ascension pénible.', 17),
((SELECT id FROM public.surahs WHERE number = 74), 18, 'إِنَّهُ فَكَّرَ وَقَدَّرَ', 'Il a réfléchi. Et il a décidé.', 18),
((SELECT id FROM public.surahs WHERE number = 74), 19, 'فَقُتِلَ كَيْفَ قَدَّرَ', 'Qu''il périsse! Qu''il ait décidé!', 19),
((SELECT id FROM public.surahs WHERE number = 74), 20, 'ثُمَّ قُتِلَ كَيْفَ قَدَّرَ', 'Encore une fois, qu''il périsse! Qu''il ait décidé!', 20),
((SELECT id FROM public.surahs WHERE number = 74), 21, 'ثُمَّ نَظَرَ', 'Puis, il a regardé.', 21),
((SELECT id FROM public.surahs WHERE number = 74), 22, 'ثُمَّ عَبَسَ وَبَسَرَ', 'Puis, il a froncé les sourcils et s''est durci.', 22),
((SELECT id FROM public.surahs WHERE number = 74), 23, 'ثُمَّ أَدْبَرَ وَاسْتَكْبَرَ', 'Puis, il s''est détourné, plein de fierté.', 23),
((SELECT id FROM public.surahs WHERE number = 74), 24, 'فَقَالَ إِنْ هَٰذَا إِلَّا سِحْرٌ يُؤْثَرُ', 'Il a dit: «Ceci n''est que magie apprise!', 24),
((SELECT id FROM public.surahs WHERE number = 74), 25, 'إِنْ هَٰذَا إِلَّا قَوْلُ الْبَشَرِ', 'Ceci n''est qu''une parole d''un humain.»', 25),
((SELECT id FROM public.surahs WHERE number = 74), 26, 'سَأُصْلِيهِ سَقَرَ', 'Je vais le brûler dans le Feu (Saqar).', 26),
((SELECT id FROM public.surahs WHERE number = 74), 27, 'وَمَا أَدْرَاكَ مَا سَقَرَ', 'Et qui te dira ce qu''est le Feu (Saqar)?', 27),
((SELECT id FROM public.surahs WHERE number = 74), 28, 'لَا تُبْقِي وَلَا تَذَرُ', 'Il ne laisse rien et n''épargne rien;', 28),
((SELECT id FROM public.surahs WHERE number = 74), 29, 'لَوَّاحَةٌ لِّلْبَشَرِ', 'il brûle la peau et la noircit.', 29),
((SELECT id FROM public.surahs WHERE number = 74), 30, 'عَلَيْهَا تِسْعَةَ عَشَرَ', 'Il y a, au-dessus, dix-neuf (gardiens).', 30),
((SELECT id FROM public.surahs WHERE number = 74), 31, 'وَمَا جَعَلْنَا أَصْحَابَ النَّارِ إِلَّا مَلَائِكَةً ۙ وَمَا جَعَلْنَا عِدَّتَهُمْ إِلَّا فِتْنَةً لِّلَّذِينَ كَفَرُوا لِيَسْتَيْقِنَ الَّذِينَ أُوتُوا الْكِتَابَ وَيَزْدَادَ الَّذِينَ آمَنُوا إِيمَانًا ۙ وَلَا يَرْتَابَ الَّذِينَ أُوتُوا الْكِتَابَ وَالْمُؤْمِنُونَ ۙ وَلِيَقُولَ الَّذِينَ فِي قُلُوبِهِم مَّرَضٌ وَالْكَافِرُونَ مَاذَا أَرَادَ اللَّهُ بِهَٰذَا مَثَلًا ۚ كَذَٰلِكَ يُضِلُّ اللَّهُ مَن يَشَاءُ وَيَهْدِي مَن يَشَاءُ ۚ وَمَا يَعْلَمُ جُنُودَ رَبِّكَ إِلَّا هُوَ ۚ وَمَا هِيَ إِلَّا ذِكْرَى لِلْبَشَرِ', 'Nous n''avons assigné comme gardiens du Feu que des Anges. Cependant, Nous n''en avons fixé le nombre que pour éprouver les infidèles, et aussi pour que ceux à qui le Livre a été apporté soient convaincus, et que croisse la foi de ceux qui croient, et pour que ceux à qui le Livre a été apporté, ainsi que les croyants, n''aient point de doute; et pour que ceux dont le cœur est malade, ainsi que les infidèles, disent: «Qu''a voulu Allah par cette parabole?» C''est ainsi qu''Allah égare qui Il veut et guide qui Il veut. Et nul ne connaît les armées de ton Seigneur, à part Lui. Et ce n''est là qu''un rappel pour les humains.', 31),
((SELECT id FROM public.surahs WHERE number = 74), 32, 'كَلَّا وَالْقَمَرِ', 'Non, par la lune!', 32),
((SELECT id FROM public.surahs WHERE number = 74), 33, 'وَاللَّيْلِ إِذْ أَدْبَرَ', 'Et par la nuit quand elle se retire!', 33),
((SELECT id FROM public.surahs WHERE number = 74), 34, 'وَالصُّبْحِ إِذَا أَسْفَرَ', 'Et par l''aube quand elle se découvre!', 34),
((SELECT id FROM public.surahs WHERE number = 74), 35, 'إِنَّهَا لَإِحْدَى الْكُبَرِ', 'C''est l''une des plus grandes (calamités),', 35),
((SELECT id FROM public.surahs WHERE number = 74), 36, 'نَذِيرًا لِّلْبَشَرِ', 'un avertissement pour les humains,', 36),
((SELECT id FROM public.surahs WHERE number = 74), 37, 'لِمَن شَاءَ مِنكُمْ أَن يَتَقَدَّمَ أَوْ يَتَأَخَّرَ', 'pour qui de vous qui veut avancer ou se replier.', 37),
((SELECT id FROM public.surahs WHERE number = 74), 38, 'كُلُّ نَفْسٍ بِمَا كَسَبَتْ رَهِينَةٌ', 'Toute âme est l''otage de ce qu''elle a acquis.', 38),
((SELECT id FROM public.surahs WHERE number = 74), 39, 'إِلَّا أَصْحَابَ الْيَمِينِ', 'Sauf les gens de la droite:', 39),
((SELECT id FROM public.surahs WHERE number = 74), 40, 'فِي جَنَّاتٍ يَتَسَاءَلُونَ', 'dans des Jardins, ils s''interrogent,', 40),
((SELECT id FROM public.surahs WHERE number = 74), 41, 'عَنِ الْمُجْرِمِينَ', 'au sujet des criminels:', 41),
((SELECT id FROM public.surahs WHERE number = 74), 42, 'مَا سَلَكَكُمْ فِي سَقَرَ', '«Qu''est-ce qui vous a fait entrer dans le Feu (Saqar)?»', 42),
((SELECT id FROM public.surahs WHERE number = 74), 43, 'قَالُوا لَمْ نَكُ مِنَ الْمُصَلِّينَ', 'Ils dirent: «Nous n''étions pas de ceux qui faisaient la Salat,', 43),
((SELECT id FROM public.surahs WHERE number = 74), 44, 'وَلَمْ نَكُ نُطْعِمُ الْمِسْكِينَ', 'et nous ne nourrissions pas le pauvre,', 44),
((SELECT id FROM public.surahs WHERE number = 74), 45, 'وَكُنَّا نَخُوضُ مَعَ الْخَائِضِينَ', 'et nous nous perdions avec ceux qui se perdaient,', 45),
((SELECT id FROM public.surahs WHERE number = 74), 46, 'وَكُنَّا نُكَذِّبُ بِيَوْمِ الدِّينِ', 'et nous traitions de mensonge le Jour de la Rétribution,', 46),
((SELECT id FROM public.surahs WHERE number = 74), 47, 'حَتَّىٰ أَتَانَا الْيَقِينُ', 'jusqu''à ce que nous vînt la certitude.»', 47),
((SELECT id FROM public.surahs WHERE number = 74), 48, 'فَمَا تَنفَعُهُمْ شَفَاعَةُ الشَّافِعِينَ', 'Donc, l''intercession des intercesseurs ne leur sera d''aucune utilité.', 48),
((SELECT id FROM public.surahs WHERE number = 74), 49, 'فَمَا لَهُمْ عَنِ التَّذْكِرَةِ مُعْرِضِينَ', 'Qu''ont-ils à se détourner du Rappel,', 49),
((SELECT id FROM public.surahs WHERE number = 74), 50, 'كَأَنَّهُمْ حُمُرٌ مُّسْتَنفِرَةٌ', 'comme s''ils étaient des onagres effarouchés,', 50),
((SELECT id FROM public.surahs WHERE number = 74), 51, 'فَرَّتْ مِن قَسْوَرَةٍ', 'fuyant devant un lion!', 51),
((SELECT id FROM public.surahs WHERE number = 74), 52, 'بَلْ يُرِيدُ كُلُّ امْرِئٍ مِّنْهُمْ أَن يُؤْتَىٰ صُحُفًا مُّنَشَّرَةً', 'Mais non! Chacun d''eux désire qu''on lui apporte des feuilles déployées.', 52),
((SELECT id FROM public.surahs WHERE number = 74), 53, 'كَلَّا ۖ بَلْ لَا يَخْفَوْنَ الْآخِرَةَ', 'Non! Ils ne craignent pas l''au-delà.', 53),
((SELECT id FROM public.surahs WHERE number = 74), 54, 'كَلَّا إِنَّهُ تَذْكِرَةٌ', 'Non! C''est en vérité un Rappel.', 54),
((SELECT id FROM public.surahs WHERE number = 74), 55, 'فَمَن شَاءَ ذَكَرَهُ', 'Que celui qui le veuille s''en souvienne!', 55),
((SELECT id FROM public.surahs WHERE number = 74), 56, 'وَمَا يَذْكُرُونَ إِلَّا أَن يَشَاءَ اللَّهُ ۚ هُوَ أَهْلُ التَّقْوَىٰ وَأَهْلُ الْمَغْفِرَةِ', 'Et ils ne s''en souviendront que si Allah le veut. Il est le Digne d''être craint, et le Digne de pardonner.', 56)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 76: Al-Insan (31 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 76), 1, 'هَلْ أَتَىٰ عَلَى الْإِنسَانِ حِينٌ مِّنَ الدَّهْرِ لَمْ يَكُن شَيْئًا مَّذْكُورًا', 'Ne s''est-il pas écoulé un long laps de temps durant lequel l''homme n''était même pas une chose mentionnable?', 1),
((SELECT id FROM public.surahs WHERE number = 76), 2, 'إِنَّا خَلَقْنَا الْإِنسَانَ مِن نُّطْفَةٍ أَمْشَاجٍ نَّبْتَلِيهِ فَجَعَلْنَاهُ سَمِيعًا بَصِيرًا', 'En vérité, Nous avons créé l''homme d''une goutte de sperme mélangé, pour l''éprouver. Nous l''avons fait entendant et voyant.', 2),
((SELECT id FROM public.surahs WHERE number = 76), 3, 'إِنَّا هَدَيْنَاهُ السَّبِيلَ إِمَّا شَاكِرًا وَإِمَّا كَفُورًا', 'En vérité, Nous l''avons guidé sur le chemin, soit il est reconnaissant, soit il est ingrat.', 3),
((SELECT id FROM public.surahs WHERE number = 76), 4, 'إِنَّا أَعْتَدْنَا لِلْكَافِرِينَ سَلَاسِلَ وَأَغْلَالًا وَسَعِيرًا', 'Nous avons préparé pour les infidèles des chaînes, des carcans et une Fournaise.', 4),
((SELECT id FROM public.surahs WHERE number = 76), 5, 'إِنَّ الْأَبْرَارَ يَشْرَبُونَ مِن كَأْسٍ كَانَ مِزَاجُهَا كَافُورًا', 'Les vertueux boiront d''une coupe dont le mélange sera de camphre.', 5),
((SELECT id FROM public.surahs WHERE number = 76), 6, 'عَيْنًا يَشْرَبُ بِهَا عِبَادُ اللَّهِ يُفَجِّرُونَهَا تَفْجِيرًا', 'D''une source à laquelle boiront les serviteurs d''Allah, qu''ils feront jaillir en abondance.', 6),
((SELECT id FROM public.surahs WHERE number = 76), 7, 'يُوفُونَ بِالنَّذْرِ وَيَخَافُونَ يَوْمًا كَانَ شَرُّهُ مُسْتَطِيرًا', 'Ils accomplissent leurs vœux et ils redoutent un Jour dont le mal s''étendra partout.', 7),
((SELECT id FROM public.surahs WHERE number = 76), 8, 'وَيُطْعِمُونَ الطَّعَامَ عَلَىٰ حُبِّهِ مِسْكِينًا وَيَتِيمًا وَأَسِيرًا', 'Et ils offrent la nourriture, malgré son amour, au pauvre, à l''orphelin et au prisonnier:', 8),
((SELECT id FROM public.surahs WHERE number = 76), 9, 'إِنَّمَا نُطْعِمُكُمْ لِوَجْهِ اللَّهِ لَا نُرِيدُ مِنكُمْ جَزَاءً وَلَا شُكُورًا', '«Nous vous nourrissons pour le visage d''Allah. Nous n''attendons de vous ni récompense ni gratitude.', 9),
((SELECT id FROM public.surahs WHERE number = 76), 10, 'إِنَّا نَخَافُ مِن رَّبِّنَا يَوْمًا عَبُوسًا قَمْطَرِيرًا', 'Nous redoutons de notre Seigneur un Jour menaçant et catastrophique.»', 10),
((SELECT id FROM public.surahs WHERE number = 76), 11, 'فَوَقَاهُمُ اللَّهُ شَرَّ ذَٰلِكَ الْيَوْمِ وَلَقَّاهُمْ نَضْرَةً وَسُرُورًا', 'Allah les protégera du mal de ce Jour-là, et leur fera rencontrer l''éclat (de la joie) et le bonheur,', 11),
((SELECT id FROM public.surahs WHERE number = 76), 12, 'وَجَزَاهُم بِمَا صَبَرُوا جَنَّةً وَحَرِيرًا', 'et les récompensera pour leur endurance par un Paradis et des (vêtements) de soie,', 12),
((SELECT id FROM public.surahs WHERE number = 76), 13, 'مُّتَّكِئِينَ فِيهَا عَلَى الْأَرَائِكِ لَا يَرَوْنَ فِيهَا شَمْسًا وَلَا زَمْهَرِيرًا', 'accoudés sur des lits, ils n''y verront ni soleil ni froid glacial.', 13),
((SELECT id FROM public.surahs WHERE number = 76), 14, 'وَدَانِيَةٌ عَلَيْهِمْ ظِلَالُهَا وَذُلِّلَتْ قُطُوفُهَا تَذْلِيلًا', 'Ses ombrages les couvriront de près, et ses fruits inclinés vers eux seront à leur portade.', 14),
((SELECT id FROM public.surahs WHERE number = 76), 15, 'وَيُطَافُ عَلَيْهِم بِآنِيَةٍ مِّن فِضَّةٍ وَأَكْوَابٍ كَانَتْ قَوَارِيرَا', 'On fera circuler parmi eux des récipients d''argent et des coupes de cristal,', 15),
((SELECT id FROM public.surahs WHERE number = 76), 16, 'قَوَارِيرَ مِن فِضَّةٍ قَدَّرُوهَا تَقْدِيرًا', 'de cristal d''argent, qu''ils auront mesurés avec précision.', 16),
((SELECT id FROM public.surahs WHERE number = 76), 17, 'وَيُسْقَوْنَ فِيهَا كَأْسًا كَانَ مِزَاجُهَا زَنجَبِيلًا', 'Et on leur y fera boire une coupe dont le mélange sera de gingembre,', 17),
((SELECT id FROM public.surahs WHERE number = 76), 18, 'عَيْنًا فِيهَا تُسَمَّىٰ سَلْسَبِيلًا', 'd''une source nommée Salsabil.', 18),
((SELECT id FROM public.surahs WHERE number = 76), 19, 'وَيَطُوفُ عَلَيْهِمْ وِلْدَانٌ مُّخَلَّدُونَ بِأَكْوَابٍ وَأَبَارِيقَ وَكَأْسٍ مِّن مَّعِينٍ', 'Des éphèbes immortels circuleront parmi eux, avec des coupes, des aiguières et des verres d''une boisson pure;', 19),
((SELECT id FROM public.surahs WHERE number = 76), 20, 'لَّا يُصَدَّعُونَ عَنْهَا وَلَا يُنزِفُونَ', 'on n''aura ni maux de tête ni ivresse.', 20),
((SELECT id FROM public.surahs WHERE number = 76), 21, 'وَفَاكِهَةٍ مِّمَّا يَتَخَيَّرُونَ', 'Et parmi les fruits de leur choix,', 21),
((SELECT id FROM public.surahs WHERE number = 76), 22, 'وَلَحْمِ طَيْرٍ مِّمَّا يَشْتَهُونَ', 'et de la chair d''oiseau qu''ils désirent.', 22),
((SELECT id FROM public.surahs WHERE number = 76), 23, 'كَأَنَّهُنَّ الْحُورُ الْمَقْنُونَةٌ', 'Ils auront des houris aux grands yeux, semblables à des perles cachées,', 23),
((SELECT id FROM public.surahs WHERE number = 76), 24, 'كَأَنَّهُنَّ بَيْضٌ مَّكْنُونٌ', 'comme si elles étaient des œufs bien préservés.', 24),
((SELECT id FROM public.surahs WHERE number = 76), 25, 'وَلَا يَسْمَعُونَ فِيهَا لَغْوًا وَلَا تَأْثِيمًا', 'Ils n''y entendront ni futilité ni péché,', 25),
((SELECT id FROM public.surahs WHERE number = 76), 26, 'إِلَّا قِيلًا سَلَامًا سَلَامًا', 'mais seulement le mot: «Salam! Salam!» (Paix! Paix!).', 26),
((SELECT id FROM public.surahs WHERE number = 76), 27, 'وَأَصْحَابُ الْيَمِينِ مَا أَصْحَابُ الْيَمِينِ', 'Et les gens de la droite, qu''en est-il des gens de la droite?', 27),
((SELECT id FROM public.surahs WHERE number = 76), 28, 'فِي سِدْرٍ مَّخْضُودٍ', 'Ils seront parmi les jujubiers sans épines,', 28),
((SELECT id FROM public.surahs WHERE number = 76), 29, 'وَطَلْحٍ مَّنضُودٍ', 'parmi des bananiers aux régimes bien fournis,', 29),
((SELECT id FROM public.surahs WHERE number = 76), 30, 'وَظِلٍّ مَّمْدُودٍ', 'dans une ombre étendue,', 30),
((SELECT id FROM public.surahs WHERE number = 76), 31, 'وَمَاءٍ مَّسْكُوبٍ', 'près d''une eau coulante en abondance.', 31)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

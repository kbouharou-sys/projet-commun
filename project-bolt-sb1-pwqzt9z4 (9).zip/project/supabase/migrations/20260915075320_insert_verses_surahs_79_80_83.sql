/*
# Insert verses for surahs 79, 80, 83

## Surahs added:
- 79: An-Naziat (46 verses)
- 80: Abasa (42 verses)
- 83: Al-Mutaffifin (36 verses)
*/

-- =========================================================
-- SURAH 79: An-Naziat (46 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 79), 1, 'وَالنَّازِعَاتِ غَرْقًا', 'Par ceux qui arrachent avec violence,', 1),
((SELECT id FROM public.surahs WHERE number = 79), 2, 'وَالنَّاشِطَاتِ نَشْطًا', 'et ceux qui tirent avec douceur,', 2),
((SELECT id FROM public.surahs WHERE number = 79), 3, 'وَالسَّابِحَاتِ سَبْحًا', 'et ceux qui glissent avec aisance,', 3),
((SELECT id FROM public.surahs WHERE number = 79), 4, 'فَالسَّابِقَاتِ سَبْقًا', 'et ceux qui prennent les devants avec rapidité,', 4),
((SELECT id FROM public.surahs WHERE number = 79), 5, 'فَالْمُدَبِّرَاتِ أَمْرًا', 'et ceux qui dirigent les affaires!', 5),
((SELECT id FROM public.surahs WHERE number = 79), 6, 'يَوْمَ تَرْجُفُ الرَّاجِفَةُ', 'Le Jour où le premier souffle fera trembler (la terre),', 6),
((SELECT id FROM public.surahs WHERE number = 79), 7, 'تَتْبَعُهَا الرَّادِفَةُ', 'suivi immédiatement par le second.', 7),
((SELECT id FROM public.surahs WHERE number = 79), 8, 'قُلُوبٌ يَوْمَئِذٍ وَاجِفَةٌ', 'Ce Jour-là, les cœurs frémiront d''effroi,', 8),
((SELECT id FROM public.surahs WHERE number = 79), 9, 'أَبْصَارُهَا خَاشِعَةٌ', 'et les regards seront humiliés.', 9),
((SELECT id FROM public.surahs WHERE number = 79), 10, 'يَقُولُونَ أَإِنَّا لَمَرْدُودُونَ فِي الْحَافِرَةِ', 'Ils disent: «Serons-nous vraiment ramenés à notre vie première,', 10),
((SELECT id FROM public.surahs WHERE number = 79), 11, 'أَإِذَا كُنَّا عِظَامًا نَّخِرَةً', 'alors que nous serons des ossements pourris?»', 11),
((SELECT id FROM public.surahs WHERE number = 79), 12, 'قَالُوا تِلْكَ إِذًا كَرَّةٌ خَاسِرَةٌ', 'Ils disent: «Ce serait alors un retour ruineux!»', 12),
((SELECT id FROM public.surahs WHERE number = 79), 13, 'فَإِنَّمَا هِيَ زَجْرَةٌ وَاحِدَةٌ', 'Il n''y aura en fait qu''un seul cri (le second souffle),', 13),
((SELECT id FROM public.surahs WHERE number = 79), 14, 'فَإِذَا هُم بِالسَّاهِرَةِ', 'et voilà qu''ils seront sur la terre (ressuscités).', 14),
((SELECT id FROM public.surahs WHERE number = 79), 15, 'هَلْ أَتَاكَ حَدِيثُ مُوسَىٰ', 'T''est-il parvenu le récit de Moïse?', 15),
((SELECT id FROM public.surahs WHERE number = 79), 16, 'إِذْ نَادَاهُ رَبُّهُ بِالْوَادِ الْمُقَدَّسِ طُوًى', 'Quand son Seigneur l''appela dans la vallée sanctifiée de Tuwa:', 16),
((SELECT id FROM public.surahs WHERE number = 79), 17, 'اذْهَبْ إِلَىٰ فِرْعَوْنَ إِنَّهُ طَغَىٰ', '«Va vers Pharaon. Il s''est rebellé.', 17),
((SELECT id FROM public.surahs WHERE number = 79), 18, 'فَقُلْ هَل لَّكَ إِلَىٰ أَن تَزَكَّىٰ', 'Puis dis-lui: «Veux-tu te purifier,', 18),
((SELECT id FROM public.surahs WHERE number = 79), 19, 'وَأَهْدِيَكَ إِلَىٰ رَبِّكَ فَتَخْشَىٰ', 'et que je te guide vers ton Seigneur pour que tu Le craignes?»', 19),
((SELECT id FROM public.surahs WHERE number = 79), 20, 'فَأَرَاهُ الْآيَةَ الْكُبْرَىٰ', 'Il lui montra le grand miracle.', 20),
((SELECT id FROM public.surahs WHERE number = 79), 21, 'فَكَذَّبَ وَعَصَىٰ', 'Mais il traita de mensonge et désobéit;', 21),
((SELECT id FROM public.surahs WHERE number = 79), 22, 'ثُمَّ أَدْبَرَ يَسْعَىٰ', 'ensuite, il tourna le dos, s''empressant (sur terre).', 22),
((SELECT id FROM public.surahs WHERE number = 79), 23, 'فَحَشَرَ فَنَادَىٰ', 'Puis il rassembla (les gens) et cria.', 23),
((SELECT id FROM public.surahs WHERE number = 79), 24, 'فَقَالَ أَنَا رَبُّكُمُ الْأَعْلَىٰ', 'Et il dit: «Je suis votre Seigneur, le Très-Haut.»', 24),
((SELECT id FROM public.surahs WHERE number = 79), 25, 'فَأَخَذَهُ اللَّهُ نَكَالَ الْآخِرَةِ وَالْأُولَىٰ', 'Alors Allah le saisit d''une punition exemplaire pour lui, dans l''au-delà et ici-bas.', 25),
((SELECT id FROM public.surahs WHERE number = 79), 26, 'إِنَّ فِي ذَٰلِكَ لَعِبْرَةً لِّمَن يَخْشَىٰ', 'Il y a en cela de quoi réfléchir pour celui qui craint.', 26),
((SELECT id FROM public.surahs WHERE number = 79), 27, 'أَأَنتُمْ أَشَدُّ خَلْقًا أَمِ السَّمَاءُ ۚ بَنَاهَا', 'Êtes-vous plus difficiles à créer que le ciel? Il l''a construit,', 27),
((SELECT id FROM public.surahs WHERE number = 79), 28, 'رَفَعَ سَمْكَهَا فَسَوَّاهَا', 'Il a élevé sa voûte, puis l''a perfectionnée,', 28),
((SELECT id FROM public.surahs WHERE number = 79), 29, 'وَأَغْطَشَ لَيْلَهَا وَأَخْرَجَ ضُحَاهَا', 'et a obscurci sa nuit et éclairé son jour.', 29),
((SELECT id FROM public.surahs WHERE number = 79), 30, 'وَالْأَرْضَ بَعْدَ ذَٰلِكَ دَحَاهَا', 'Et la terre, ensuite, Il l''a étendue,', 30),
((SELECT id FROM public.surahs WHERE number = 79), 31, 'أَخْرَجَ مِنْهَا مَاءَهَا وَمَرْعَاهَا', 'Il a fait sortir d''elle son eau et son pâturage,', 31),
((SELECT id FROM public.surahs WHERE number = 79), 32, 'وَالْجِبَالَ أَرْسَاهَا', 'et les montagnes, Il les a ancrées,', 32),
((SELECT id FROM public.surahs WHERE number = 79), 33, 'مَتَاعًا لَّكُمْ وَلِأَنْعَامِكُمْ', 'pour votre jouissance et celle de vos bestiaux.', 33),
((SELECT id FROM public.surahs WHERE number = 79), 34, 'فَإِذَا جَاءَتِ الطَّامَّةُ الْكُبْرَىٰ', 'Puis, quand viendra la grande calamité,', 34),
((SELECT id FROM public.surahs WHERE number = 79), 35, 'يَوْمَ يَتَذَكَّرُ الْإِنسَانُ مَا سَعَىٰ', 'le Jour où l''homme se rappellera ce à quoi il s''efforçait,', 35),
((SELECT id FROM public.surahs WHERE number = 79), 36, 'وَبُرِّزَتِ الْجَحِيمُ لِمَن يَرَىٰ', 'et que la Fournaise sera rendue visible à celui qui regarde...', 36),
((SELECT id FROM public.surahs WHERE number = 79), 37, 'فَأَمَّا مَن طَغَىٰ', 'Quant à celui qui se sera rebellé,', 37),
((SELECT id FROM public.surahs WHERE number = 79), 38, 'وَآثَرَ الْحَيَاةَ الدُّنْيَا', 'et aura préféré la vie immédiate,', 38),
((SELECT id FROM public.surahs WHERE number = 79), 39, 'فَإِنَّ الْجَحِيمَ هِيَ الْمَأْوَىٰ', 'la Fournaise sera son refuge.', 39),
((SELECT id FROM public.surahs WHERE number = 79), 40, 'وَأَمَّا مَنْ خَافَ مَقَامَ رَبِّهِ وَنَهَى النَّفْسَ عَنِ الْهَوَىٰ', 'Mais quant à celui qui aura redouté la station devant son Seigneur, et préservé son âme de la passion,', 40),
((SELECT id FROM public.surahs WHERE number = 79), 41, 'فَإِنَّ الْجَنَّةَ هِيَ الْمَأْوَىٰ', 'le Paradis sera alors son refuge.', 41),
((SELECT id FROM public.surahs WHERE number = 79), 42, 'يَسْأَلُونَكَ عَنِ السَّاعَةِ أَيَّانَ مُرْسَاهَا', 'Ils t''interrogent sur l''Heure: «Quand sera son apparition?»', 42),
((SELECT id FROM public.surahs WHERE number = 79), 43, 'فِيمَ أَنتَ مِن ذِكْرَاهَا', 'En quoi pourrais-tu en parler?', 43),
((SELECT id FROM public.surahs WHERE number = 79), 44, 'إِلَىٰ رَبِّكَ مُنتَهَاهَا', 'Vers ton Seigneur aboutit sa connaissance.', 44),
((SELECT id FROM public.surahs WHERE number = 79), 45, 'إِنَّمَا أَنتَ مُنذِرُ مَن يَخْشَاهَا', 'Tu n''es qu''un avertisseur pour ceux qui la craignent.', 45),
((SELECT id FROM public.surahs WHERE number = 79), 46, 'كَأَنَّهُمْ يَوْمَ يَرَوْنَهَا لَمْ يَلْبَثُوا إِلَّا عَشِيَّةً أَوْ ضُحَاهَا', 'Le Jour où ils la verront, il leur semblera n''avoir passé (sur terre) qu''un soir ou un matin.', 46)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 80: Abasa (42 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 80), 1, 'عَبَسَ وَتَوَلَّىٰ', 'Il s''est renfrogné et s''est détourné,', 1),
((SELECT id FROM public.surahs WHERE number = 80), 2, 'أَن جَاءَهُ الْأَعْمَىٰ', 'parce que l''aveugle est venu à lui.', 2),
((SELECT id FROM public.surahs WHERE number = 80), 3, 'وَمَا يُدْرِيكَ لَعَلَّهُ يَزَّكَّىٰ', 'Et qui te dit? Peut-être se purifie-t-il,', 3),
((SELECT id FROM public.surahs WHERE number = 80), 4, 'أَوْ يَذَّكَّرُ فَتَنفَعَهُ الذِّكْرَىٰ', 'ou se rappelle, et le rappel lui soit utile.', 4),
((SELECT id FROM public.surahs WHERE number = 80), 5, 'أَمَّا مَنِ اسْتَغْنَىٰ', 'Quant à celui qui se croit riche,', 5),
((SELECT id FROM public.surahs WHERE number = 80), 6, 'فَأَنتَ لَهُ تَصَدَّىٰ', 'tu lui accordes ton attention,', 6),
((SELECT id FROM public.surahs WHERE number = 80), 7, 'وَمَا عَلَيْكَ أَلَّا يَزَّكَّىٰ', 'alors que tu n''as pas à répondre de ce qui le purifie.', 7),
((SELECT id FROM public.surahs WHERE number = 80), 8, 'وَأَمَّا مَن جَاءَكَ يَسْعَىٰ', 'Et quant à celui qui vient à toi avec empressement,', 8),
((SELECT id FROM public.surahs WHERE number = 80), 9, 'وَهُوَ يَخْشَىٰ', 'tout en craignant (Allah),', 9),
((SELECT id FROM public.surahs WHERE number = 80), 10, 'فَأَنتَ عَنْهُ تَلَهَّىٰ', 'tu t''en détournes.', 10),
((SELECT id FROM public.surahs WHERE number = 80), 11, 'كَلَّا إِنَّهَا تَذْكِرَةٌ', 'Non! C''est vraiment un Rappel.', 11),
((SELECT id FROM public.surahs WHERE number = 80), 12, 'فَمَن شَاءَ ذَكَرَهُ', 'Que celui qui veut s''en souvienne,', 12),
((SELECT id FROM public.surahs WHERE number = 80), 13, 'فِي صُحُفٍ مُّكَرَّمَةٍ', 'consignées dans des feuilles honorées,', 13),
((SELECT id FROM public.surahs WHERE number = 80), 14, 'مَرْفُوعَةٍ مُّطَهَّرَةٍ', 'élevées, purifiées,', 14),
((SELECT id FROM public.surahs WHERE number = 80), 15, 'بِأَيْدِي سَفَرَةٍ', 'par les mains de scribes,', 15),
((SELECT id FROM public.surahs WHERE number = 80), 16, 'كِرَامٍ بَرَرَةٍ', 'nobles, vertueux.', 16),
((SELECT id FROM public.surahs WHERE number = 80), 17, 'قُتِلَ الْإِنسَانُ مَا أَكْفَرَهُ', 'Que périsse l''homme! Qu''il est ingrat!', 17),
((SELECT id FROM public.surahs WHERE number = 80), 18, 'مِنْ أَيِّ شَيْءٍ خَلَقَهُ', 'De quelle chose l''a-t-Il créé?', 18),
((SELECT id FROM public.surahs WHERE number = 80), 19, 'مِن نُّطْفَةٍ خَلَقَهُ فَقَدَّرَهُ', 'D''une goutte de sperme, Il l''a créé et a déterminé son destin;', 19),
((SELECT id FROM public.surahs WHERE number = 80), 20, 'ثُمَّ السَّبِيلَ يَسَّرَهُ', 'puis Il lui a facilité le chemin,', 20),
((SELECT id FROM public.surahs WHERE number = 80), 21, 'ثُمَّ أَمَاتَهُ فَأَقْبَرَهُ', 'puis Il l''a fait mourir, et l''a mis dans la tombe;', 21),
((SELECT id FROM public.surahs WHERE number = 80), 22, 'ثُمَّ إِذَا شَاءَ أَنشَرَهُ', 'puis, quand Il voudra, Il le ressuscitera.', 22),
((SELECT id FROM public.surahs WHERE number = 80), 23, 'كَلَّا لَمَّا يَقْضِ مَا أَمَرَهُ', 'Non! L''homme n''accomplit pas ce qu''Il lui a ordonné.', 23),
((SELECT id FROM public.surahs WHERE number = 80), 24, 'فَلْيَنظُرِ الْإِنسَانُ إِلَىٰ طَعَامِهِ', 'Que l''homme regarde sa nourriture:', 24),
((SELECT id FROM public.surahs WHERE number = 80), 25, 'أَنَّا صَبَبْنَا الْمَاءَ صَبًّا', 'C''est Nous qui avons versé l''eau en abondance,', 25),
((SELECT id FROM public.surahs WHERE number = 80), 26, 'ثُمَّ شَقَقْنَا الْأَرْضَ شَقًّا', 'puis fendu la terre par de profondes fissures,', 26),
((SELECT id FROM public.surahs WHERE number = 80), 27, 'فَأَنبَتْنَا فِيهَا حَبًّا', 'y avons fait pousser des grains,', 27),
((SELECT id FROM public.surahs WHERE number = 80), 28, 'وَعِنَبًا وَقَضْبًا', 'des vignes et des légumes,', 28),
((SELECT id FROM public.surahs WHERE number = 80), 29, 'وَزَيْتُونًا وَنَخْلًا', 'des oliviers et des palmiers,', 29),
((SELECT id FROM public.surahs WHERE number = 80), 30, 'وَحَدَائِقَ غُلْبًا', 'et des jardins luxuriants,', 30),
((SELECT id FROM public.surahs WHERE number = 80), 31, 'وَفَاكِهَةً وَأَبًّا', 'des fruits et des herbages,', 31),
((SELECT id FROM public.surahs WHERE number = 80), 32, 'مَتَاعًا لَّكُمْ وَلِأَنْعَامِكُمْ', 'pour votre jouissance et celle de vos bestiaux.', 32),
((SELECT id FROM public.surahs WHERE number = 80), 33, 'فَإِذَا جَاءَتِ الصَّاخَّةُ', 'Puis, quand viendra le grand fracas,', 33),
((SELECT id FROM public.surahs WHERE number = 80), 34, 'يَوْمَ يَفِرُّ الْمَرْءُ مِنْ أَخِيهِ', 'le Jour où l''homme fuira son frère,', 34),
((SELECT id FROM public.surahs WHERE number = 80), 35, 'وَأُمِّهِ وَأَبِيهِ', 'sa mère et son père,', 35),
((SELECT id FROM public.surahs WHERE number = 80), 36, 'وَصَاحِبَتِهِ وَبَنِيهِ', 'sa compagne et ses enfants,', 36),
((SELECT id FROM public.surahs WHERE number = 80), 37, 'لِكُلِّ امْرِئٍ مِّنْهُمْ يَوْمَئِذٍ شَأْنٌ يُغْنِيهِ', 'car chacun d''eux, ce Jour-là, aura son propre cas pour l''occuper.', 37),
((SELECT id FROM public.surahs WHERE number = 80), 38, 'وُجُوهٌ يَوْمَئِذٍ مُّسْفِرَةٌ', 'Ce Jour-là, il y aura des visages resplendissants,', 38),
((SELECT id FROM public.surahs WHERE number = 80), 39, 'ضَاحِكَةٌ مُّسْتَبْشِرَةٌ', 'riants, réjouis,', 39),
((SELECT id FROM public.surahs WHERE number = 80), 40, 'وَوُجُوهٌ يَوْمَئِذٍ عَلَيْهَا غَبَرَةٌ', 'et des visages, ce Jour-là, couverts de poussière,', 40),
((SELECT id FROM public.surahs WHERE number = 80), 41, 'تَرْهَقُهَا قَتَرَةٌ', 'obscurcis par la noirceur.', 41),
((SELECT id FROM public.surahs WHERE number = 80), 42, 'أُولَٰئِكَ هُمُ الْكَفَرَةُ الْفَجَرَةُ', 'Ce sont eux qui sont infidèles, pervers.', 42)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

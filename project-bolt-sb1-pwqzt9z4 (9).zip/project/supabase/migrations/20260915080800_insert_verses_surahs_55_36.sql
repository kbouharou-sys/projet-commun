/*
# Insert verses for surahs 55 (Ar-Rahman) and 36 (Ya-Sin)

## Surahs added:
- 55: Ar-Rahman (78 verses) — partial: first 30 verses
- 36: Ya-Sin (83 verses) — partial: first 20 verses
*/

-- =========================================================
-- SURAH 55: Ar-Rahman (first 30 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 55), 1, 'الرَّحْمَٰنُ', 'Le Tout Miséricordieux!', 1),
((SELECT id FROM public.surahs WHERE number = 55), 2, 'عَلَّمَ الْقُرْآنَ', 'Il a enseigné le Coran.', 2),
((SELECT id FROM public.surahs WHERE number = 55), 3, 'خَلَقَ الْإِنسَانَ', 'Il a créé l''homme,', 3),
((SELECT id FROM public.surahs WHERE number = 55), 4, 'عَلَّمَهُ الْبَيَانَ', 'et lui a enseigné à s''exprimer clairement.', 4),
((SELECT id FROM public.surahs WHERE number = 55), 5, 'الشَّمْسُ وَالْقَمَرُ بِحُسْبَانٍ', 'Le soleil et la lune évoluent selon un calcul minutieux.', 5),
((SELECT id FROM public.surahs WHERE number = 55), 6, 'وَالنَّجْمُ وَالشَّجَرُ يَسْجُدَانِ', 'Les plantes et les arbres se prosternent.', 6),
((SELECT id FROM public.surahs WHERE number = 55), 7, 'وَالسَّمَاءَ رَفَعَهَا وَوَضَعَ الْمِيزَانَ', 'Et le ciel, Il l''a élevé et a établi la balance,', 7),
((SELECT id FROM public.surahs WHERE number = 55), 8, 'أَلَّا تَطْغَوْا فِي الْمِيزَانِ', 'afin que vous ne transgressiez pas dans la balance.', 8),
((SELECT id FROM public.surahs WHERE number = 55), 9, 'وَأَقِيمُوا الْوَزْنَ بِالْقِسْطِ وَلَا تُخْسِرُوا الْمِيزَانَ', 'Établissez la pesée avec équité et ne faussez pas la balance.', 9),
((SELECT id FROM public.surahs WHERE number = 55), 10, 'وَالْأَرْضَ وَضَعَهَا لِلْأَنَامِ', 'Et la terre, Il l''a préparée pour les êtres vivants.', 10),
((SELECT id FROM public.surahs WHERE number = 55), 11, 'فِيهَا فَاكِهَةٌ وَالنَّخْلُ ذَاتُ الْأَكْمَامِ', 'Il y a des fruits, ainsi que des palmiers aux régimes protégés,', 11),
((SELECT id FROM public.surahs WHERE number = 55), 12, 'وَالْحَبُّ ذُو الْعَصْفِ وَالرَّيْحَانُ', 'des céréales pour la paille et le grain, et des plantes aromatiques.', 12),
((SELECT id FROM public.surahs WHERE number = 55), 13, 'فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ', 'Lequel donc des bienfaits de votre Seigneur nierez-vous?', 13),
((SELECT id FROM public.surahs WHERE number = 55), 14, 'خَلَقَ الْإِنسَانَ مِن صَلْصَالٍ كَالْفَخَّارِ', 'Il a créé l''homme d''argile sonnante comme la poterie.', 14),
((SELECT id FROM public.surahs WHERE number = 55), 15, 'وَخَلَقَ الْجَانَّ مِن مَّارِجٍ مِّن نَّارٍ', 'Et Il a créé les djinns d''un feu de chaleur pure.', 15),
((SELECT id FROM public.surahs WHERE number = 55), 16, 'فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ', 'Lequel donc des bienfaits de votre Seigneur nierez-vous?', 16),
((SELECT id FROM public.surahs WHERE number = 55), 17, 'رَبُّ الْمَشْرِقَيْنِ وَرَبُّ الْمَغْرِبَيْنِ', 'Seigneur des deux Levants et Seigneur des deux Couchants!', 17),
((SELECT id FROM public.surahs WHERE number = 55), 18, 'فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ', 'Lequel donc des bienfaits de votre Seigneur nierez-vous?', 18),
((SELECT id FROM public.surahs WHERE number = 55), 19, 'مَرَجَ الْبَحْرَيْنِ يَلْتَقِيَانِ', 'Il a givené les deux mers se rencontrer,', 19),
((SELECT id FROM public.surahs WHERE number = 55), 20, 'بَيْنَهُمَا بَرْزَخٌ لَّا يَبْغِيَانِ', 'entre lesquelles il y a une barrière qu''elles ne franchissent pas.', 20),
((SELECT id FROM public.surahs WHERE number = 55), 21, 'فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ', 'Lequel donc des bienfaits de votre Seigneur nierez-vous?', 21),
((SELECT id FROM public.surahs WHERE number = 55), 22, 'يَخْرُجُ مِنْهُمَا اللُّؤْلُؤُ وَالْمَرْجَانُ', 'Des deux sortent la perle et le corail.', 22),
((SELECT id FROM public.surahs WHERE number = 55), 23, 'فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ', 'Lequel donc des bienfaits de votre Seigneur nierez-vous?', 23),
((SELECT id FROM public.surahs WHERE number = 55), 24, 'وَلَهُ الْجَوَارِ الْمُنشِئَاتُ فِي الْبَحْرِ كَالْأَعْلَامِ', 'À Lui appartiennent les navires élevés sur la mer comme des montagnes.', 24),
((SELECT id FROM public.surahs WHERE number = 55), 25, 'فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ', 'Lequel donc des bienfaits de votre Seigneur nierez-vous?', 25),
((SELECT id FROM public.surahs WHERE number = 55), 26, 'كُلُّ مَنْ عَلَيْهَا فَانٍ', 'Tout ce qui est sur elle (la terre) disparaîtra.', 26),
((SELECT id FROM public.surahs WHERE number = 55), 27, 'وَيَبْقَىٰ وَجْهُ رَبِّكَ ذُو الْجَلَالِ وَالْإِكْرَامِ', 'Et seule subsistera la Face de ton Seigneur, pleine de majesté et de munificence.', 27),
((SELECT id FROM public.surahs WHERE number = 55), 28, 'فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ', 'Lequel donc des bienfaits de votre Seigneur nierez-vous?', 28),
((SELECT id FROM public.surahs WHERE number = 55), 29, 'يَسْأَلُهُ مَن فِي السَّمَاوَاتِ وَالْأَرْضِ ۚ كُلَّ يَوْمٍ هُوَ فِي شَأْنٍ', 'Ceux qui sont dans les cieux et sur la terre L''interrogent. Chaque jour, Il est à l''œuvre.', 29),
((SELECT id FROM public.surahs WHERE number = 55), 30, 'فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ', 'Lequel donc des bienfaits de votre Seigneur nierez-vous?', 30)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 36: Ya-Sin (first 20 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 36), 1, 'يس', 'Ya-Sin.', 1),
((SELECT id FROM public.surahs WHERE number = 36), 2, 'وَالْقُرْآنِ الْحَكِيمِ', 'Par le Coran plein de sagesse!', 2),
((SELECT id FROM public.surahs WHERE number = 36), 3, 'إِنَّكَ لَمِنَ الْمُرْسَلِينَ', 'Tu (Muhammad) es certes du nombre des Messagers,', 3),
((SELECT id FROM public.surahs WHERE number = 36), 4, 'عَلَىٰ صِرَاطٍ مُّسْتَقِيمٍ', 'sur un droit chemin.', 4),
((SELECT id FROM public.surahs WHERE number = 36), 5, 'تَنزِيلَ الْعَزِيزِ الرَّحِيمِ', 'C''est une révélation de la part du Tout-Puissant, du Très Miséricordieux,', 5),
((SELECT id FROM public.surahs WHERE number = 36), 6, 'لِتُنذِرَ قَوْمًا مَّا أُنذِرَ آبَاؤُهُمْ فَهُمْ غَافِلُونَ', 'pour que tu avertisses un peuple dont les ancêtres n''ont pas été avertis: ils sont donc insouciants.', 6),
((SELECT id FROM public.surahs WHERE number = 36), 7, 'لَقَدْ حَقَّ الْقَوْلُ عَلَىٰ أَكْثَرِهِمْ فَهُمْ لَا يُؤْمِنُونَ', 'En vérité, la Parole s''est vérifiée contre la plupart d''entre eux: ils ne croiront donc pas.', 7),
((SELECT id FROM public.surahs WHERE number = 36), 8, 'إِنَّا جَعَلْنَا فِي أَعْنَاقِهِمْ أَغْلَالًا فَهِيَ إِلَى الْأَذْقَانِ فَهُم مُّقْمَحُونَ', 'Nous avons mis des carcans à leurs cous, et il y en a jusqu''aux mentons, de sorte qu''ils ne peuvent incliner la tête.', 8),
((SELECT id FROM public.surahs WHERE number = 36), 9, 'وَجَعَلْنَا مِن بَيْنِ أَيْدِيهِمْ سَدًّا وَمِنْ خَلْفِهِمْ سَدًّا فَأَغْشَيْنَاهُمْ فَهُمْ لَا يُبْصِرُونَ', 'Et Nous avons mis devant eux une barrière, et derrière eux une barrière; Nous les avons enveloppés, de sorte qu''ils ne voient plus.', 9),
((SELECT id FROM public.surahs WHERE number = 36), 10, 'وَسَوَاءٌ عَلَيْهِمْ ءَأَنذَرْتَهُمْ أَمْ لَمْ تُنذِرْهُمْ لَا يُؤْمِنُونَ', 'Que tu les avertisses ou que tu ne les avertisses pas: ils ne croiront pas.', 10),
((SELECT id FROM public.surahs WHERE number = 36), 11, 'إِنَّمَا تُنذِرُ مَنِ اتَّبَعَ الذِّكْرَ وَخَشَيَ الرَّحْمَٰنَ بِالْغَيْبِ ۖ فَبَشِّرْهُ بِمَغْفِرَةٍ وَأَجْرٍ كَرِيمٍ', 'Tu avertis seulement celui qui suit le Rappel (le Coran), et craint le Tout Miséricordieux, en secret. Annonce-lui donc un pardon et une récompense généreuse.', 11),
((SELECT id FROM public.surahs WHERE number = 36), 12, 'إِنَّا نَحْنُ نُحْيِي الْمَوْتَىٰ وَنَكْتُبُ مَا قَدَّمُوا وَآثَارَهُمْ ۚ وَكُلَّ شَيْءٍ أَحْصَيْنَاهُ فِي إِمَامٍ مُّبِينٍ', 'C''est Nous qui ressuscitons les morts, et écrivons ce qu''ils ont avancé et leurs traces. Et Nous avons dénombré toute chose dans un livre-guide clair.', 12),
((SELECT id FROM public.surahs WHERE number = 36), 13, 'وَاضْرِبْ لَهُم مَّثَلًا أَصْحَابَ الْقَرْيَةِ إِذْ جَاءَهَا الْمُرْسَلُونَ', 'Et propose-leur l''exemple des gens de la cité, quand les Messagers lui furent envoyés.', 13),
((SELECT id FROM public.surahs WHERE number = 36), 14, 'إِذْ أَرْسَلْنَا إِلَيْهِمُ اثْنَيْنِ فَكَذَّبُوهُمَا فَعَزَّزْنَا بِثَالِثٍ فَقَالُوا إِنَّا إِلَيْكُم مُّرْسَلُونَ', 'Quand Nous leur en envoyâmes deux; et ils les traitèrent de menteurs. Nous les renforcâmes alors d''un troisième; ils dirent: «Nous sommes certes envoyés à vous.»', 14),
((SELECT id FROM public.surahs WHERE number = 36), 15, 'قَالُوا مَا أَنتُم إِلَّا بَشَرٌ مِّثْلُنَا وَمَا أَنزَلَ الرَّحْمَٰنُ مِن شَيْءٍ إِنْ أَنتُمْ إِلَّا تَكْذِبُونَ', 'Ils (les habitants) dirent: «Vous n''êtes que des êtres humains comme nous. Le Tout Miséricordieux n''a rien fait descendre; vous ne dites que des mensonges.»', 15),
((SELECT id FROM public.surahs WHERE number = 36), 16, 'قَالُوا رَبُّنَا يَعْلَمُ إِنَّا إِلَيْكُمْ لَمُرْسَلُونَ', 'Ils (les Messagers) dirent: «Notre Seigneur sait qu''en vérité nous sommes envoyés à vous.', 16),
((SELECT id FROM public.surahs WHERE number = 36), 17, 'وَمَا عَلَيْنَا إِلَّا الْبَلَاغُ الْمُبِينُ', 'Et il ne Nous incombe que de transmettre clairement (le Message).»', 17),
((SELECT id FROM public.surahs WHERE number = 36), 18, 'قَالُوا إِنَّا تَطَيَّرْنَا بِكُمْ ۖ لَئِن لَّمْ تَنتَهُوا لَنَرْجُمَنَّكُمْ وَلَيَمَسَّنَّكُم مِّنَّا عَذَابٌ أَلِيمٌ', 'Ils (les habitants) dirent: «Nous vous voyons comme des porteurs de mauvais présage. Si vous ne cessez pas, nous vous lapiderons et vous infligerons un châtiment douloureux.»', 18),
((SELECT id FROM public.surahs WHERE number = 36), 19, 'قَالُوا طَائِرُكُم مَّعَكُمْ ۚ أَئِن ذُكِّرْتُم ۚ بَلْ أَنتُمْ قَوْمٌ مُّسْرِفُونَ', 'Ils (les Messagers) dirent: «Votre mauvais présage est avec vous-mêmes. Est-ce parce qu''on vous a rappelé (le Message)? Mais vous êtes des gens qui outragent.»', 19),
((SELECT id FROM public.surahs WHERE number = 36), 20, 'وَجَاءَ مِنْ أَقْصَى الْمَدِينَةِ رَجُلٌ يَسْعَىٰ قَالَ يَا قَوْمِ اتَّبِعُوا الْمُرْسَلِينَ', 'Et vint de l''autre bout de la cité un homme courant. Il dit: «Ô mon peuple, suivez les Messagers!', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

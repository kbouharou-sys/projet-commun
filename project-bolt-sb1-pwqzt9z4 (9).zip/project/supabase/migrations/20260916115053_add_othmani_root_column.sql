-- Add othmani_root column to roots table
ALTER TABLE roots ADD COLUMN IF NOT EXISTS othmani_root text;

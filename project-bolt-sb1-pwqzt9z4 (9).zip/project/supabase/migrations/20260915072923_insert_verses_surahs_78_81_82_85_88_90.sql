/*
# Insert verses for surahs 78, 81, 82, 85, 88, 90

## Surahs added:
- 78: An-Naba (40 verses)
- 81: At-Takwir (29 verses)
- 82: Al-Infitar (19 verses)
- 85: Al-Buruj (22 verses)
- 88: Al-Ghashiya (26 verses)
- 90: Al-Balad (20 verses)
*/

-- =========================================================
-- SURAH 78: An-Naba (40 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 78), 1, 'عَمَّ يَتَسَاءَلُونَ', 'De quoi s''interrogent-ils mutuellement?', 1),
((SELECT id FROM public.surahs WHERE number = 78), 2, 'عَنِ النَّبَإِ الْعَظِيمِ', 'De la grande nouvelle,', 2),
((SELECT id FROM public.surahs WHERE number = 78), 3, 'الَّذِي هُمْ فِيهِ مُخْتَلِفُونَ', 'au sujet de laquelle ils divergent.', 3),
((SELECT id FROM public.surahs WHERE number = 78), 4, 'كَلَّا سَيَعْلَمُونَ', 'Non! Ils sauront bientôt!', 4),
((SELECT id FROM public.surahs WHERE number = 78), 5, 'ثُمَّ كَلَّا سَيَعْلَمُونَ', 'Encore une fois, non! Ils sauront bientôt!', 5),
((SELECT id FROM public.surahs WHERE number = 78), 6, 'أَلَمْ نَجْعَلِ الْأَرْضَ مِهَادًا', 'N''avons-Nous pas fait de la terre un berceau,', 6),
((SELECT id FROM public.surahs WHERE number = 78), 7, 'وَالْجِبَالَ أَوْتَادًا', 'et des montagnes des piquets?', 7),
((SELECT id FROM public.surahs WHERE number = 78), 8, 'وَخَلَقْنَاكُمْ أَزْوَاجًا', 'et vous avons créés par couples,', 8),
((SELECT id FROM public.surahs WHERE number = 78), 9, 'وَجَعَلْنَا نَوْمَكُمْ سُبَاتًا', 'et fait de votre sommeil un repos,', 9),
((SELECT id FROM public.surahs WHERE number = 78), 10, 'وَجَعَلْنَا اللَّيْلَ لِبَاسًا', 'et fait de la nuit une couverture,', 10),
((SELECT id FROM public.surahs WHERE number = 78), 11, 'وَجَعَلْنَا النَّهَارَ مَعَاشًا', 'et fait du jour un temps pour le gagne-pain,', 11),
((SELECT id FROM public.surahs WHERE number = 78), 12, 'وَبَنَيْنَا فَوْقَكُمْ سَبْعًا شِدَادًا', 'et construit au-dessus de vous sept cieux solides,', 12),
((SELECT id FROM public.surahs WHERE number = 78), 13, 'وَجَعَلْنَا سِرَاجًا وَهَّاجًا', 'et placé une lampe ardente (le soleil),', 13),
((SELECT id FROM public.surahs WHERE number = 78), 14, 'وَأَنزَلْنَا مِنَ الْمُعْصِرَاتِ مَاءً ثَجَّاجًا', 'et fait descendre des nuages chargés de pluie en abondance,', 14),
((SELECT id FROM public.surahs WHERE number = 78), 15, 'لِنُخْرِجَ بِهِ حَبًّا وَنَبَاتًا', 'pour faire sortir par elle des grains et des plantes,', 15),
((SELECT id FROM public.surahs WHERE number = 78), 16, 'وَجَنَّاتٍ أَلْفَافًا', 'et des jardins luxuriants.', 16),
((SELECT id FROM public.surahs WHERE number = 78), 17, 'إِنَّ يَوْمَ الْفَصْلِ كَانَ مِيقَاتًا', 'En vérité, le Jour de la Décision a son temps fixé,', 17),
((SELECT id FROM public.surahs WHERE number = 78), 18, 'يَوْمَ يُنفَخُ فِي الصُّورِ فَتَأْتُونَ أَفْوَاجًا', 'le Jour où l''on soufflera dans la Trompette, vous viendrez par troupes,', 18),
((SELECT id FROM public.surahs WHERE number = 78), 19, 'وَفُتِحَتِ السَّمَاءُ فَكَانَتْ أَبْوَابًا', 'et le ciel sera ouvert et aura des portes,', 19),
((SELECT id FROM public.surahs WHERE number = 78), 20, 'وَسُيِّرَتِ الْجِبَالُ فَكَانَتْ سَرَابًا', 'et les montagnes seront mises en marche et deviendront mirage.', 20),
((SELECT id FROM public.surahs WHERE number = 78), 21, 'إِنَّ جَهَنَّمَ كَانَتْ مِرْصَادًا', 'En vérité, la Fournaise est un guet,', 21),
((SELECT id FROM public.surahs WHERE number = 78), 22, 'لِّلطَّاغِينَ مَآبًا', 'pour les rebelles un refuge,', 22),
((SELECT id FROM public.surahs WHERE number = 78), 23, 'لَّابِثِينَ فِيهَا أَحْقَابًا', 'où ils demeureront des siècles successifs.', 23),
((SELECT id FROM public.surahs WHERE number = 78), 24, 'لَّا يَذُوقُونَ فِيهَا بَرْدًا وَلَا شَرَابًا', 'Ils n''y goûteront ni fraîcheur ni breuvage,', 24),
((SELECT id FROM public.surahs WHERE number = 78), 25, 'إِلَّا حَمِيمًا وَغَسَّاقًا', 'sauf une eau bouillante et un pus', 25),
((SELECT id FROM public.surahs WHERE number = 78), 26, 'جَزَاءً وِفَاقًا', 'comme rétribution équitable.', 26),
((SELECT id FROM public.surahs WHERE number = 78), 27, 'إِنَّهُمْ كَانُوا لَا يَرْجُونَ حِسَابًا', 'Ils ne s''attendaient pas à des comptes,', 27),
((SELECT id FROM public.surahs WHERE number = 78), 28, 'وَكَذَّبُوا بِآيَاتِنَا كِذَّابًا', 'et traitaient de mensonges Nos signes, avec obstination,', 28),
((SELECT id FROM public.surahs WHERE number = 78), 29, 'وَكُلَّ شَيْءٍ أَحْصَيْنَاهُ كِتَابًا', 'tandis que Nous avons comptabilisé toute chose par écrit.', 29),
((SELECT id FROM public.surahs WHERE number = 78), 30, 'فَذُوقُوا فَلَن نَّزِيدَكُمْ إِلَّا عَذَابًا', 'Goûtez donc! Nous n''augmenterons pour vous que le châtiment!', 30),
((SELECT id FROM public.surahs WHERE number = 78), 31, 'إِنَّ لِلْمُتَّقِينَ مَفَازًا', 'En vérité, pour les pieux sera un succès,', 31),
((SELECT id FROM public.surahs WHERE number = 78), 32, 'حَدَائِقَ وَأَعْنَابًا', 'des jardins et des vignes,', 32),
((SELECT id FROM public.surahs WHERE number = 78), 33, 'وَكَوَاعِبَ أَتْرَابًا', 'et des jeunes filles d''égale jeunesse,', 33),
((SELECT id FROM public.surahs WHERE number = 78), 34, 'وَكَأْسًا دِهَاقًا', 'et des coupes débordantes.', 34),
((SELECT id FROM public.surahs WHERE number = 78), 35, 'لَّا يَسْمَعُونَ فِيهَا لَغْوًا وَلَا كِذَّابًا', 'Ils n''y entendront ni futilité ni mensonge,', 35),
((SELECT id FROM public.surahs WHERE number = 78), 36, 'جَزَاءً مِّن رَّبِّكَ عَطَاءً حِسَابًا', 'en rétribution de ton Seigneur, un don calculé sans défaut.', 36),
((SELECT id FROM public.surahs WHERE number = 78), 37, 'رَّبِّ السَّمَاوَاتِ وَالْأَرْضِ وَمَا بَيْنَهُمَا الرَّحْمَٰنِ ۖ لَا يَمْلِكُونَ مِنْهُ خِطَابًا', 'Seigneur des cieux et de la terre et de ce qui est entre eux, le Tout Miséricordieux; ils n''osent Lui adresser la parole,', 37),
((SELECT id FROM public.surahs WHERE number = 78), 38, 'يَوْمَ يَقُومُ الرُّوحُ وَالْمَلَائِكَةُ صَفًّا ۖ لَّا يَتَكَلَّمُونَ إِلَّا مَنْ أَذِنَ لَهُ الرَّحْمَٰنُ وَقَالَ صَوَابًا', 'le Jour où l''Esprit et les Anges se tiendront debout en rangs; nul ne parlera, sauf celui à qui le Tout Miséricordieux aura accordé permission, et qui dira la vérité.', 38),
((SELECT id FROM public.surahs WHERE number = 78), 39, 'ذَٰلِكَ الْيَوْمُ الْحَقُّ ۖ فَمَن شَاءَ اتَّخَذَ إِلَىٰ رَبِّهِ مَآبًا', 'Ce Jour-là est la vérité. Que celui qui veut prenne un refuge auprès de son Seigneur.', 39),
((SELECT id FROM public.surahs WHERE number = 78), 40, 'إِنَّا أَنذَرْنَاكُمْ عَذَابًا قَرِيبًا يَوْمَ يَنظُرُ الْمَرْءُ مَا قَدَّمَتْ يَدَاهُ وَيَقُولُ الْكَافِرُ يَا لَيْتَنِي كُنتُ تُرَابًا', 'Nous vous avons avertis d''un châtiment proche, le Jour où l''homme verra ce que ses deux mains ont préparé; et l''infidèle dira: Hélas pour moi! Si seulement j''étais de la poussière!', 40)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 81: At-Takwir (29 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 81), 1, 'إِذَا الشَّمْسُ كُوِّرَتْ', 'Quand le soleil sera obscurci,', 1),
((SELECT id FROM public.surahs WHERE number = 81), 2, 'وَإِذَا النُّجُومُ انكَدَرَتْ', 'et que les étoiles tomberont,', 2),
((SELECT id FROM public.surahs WHERE number = 81), 3, 'وَإِذَا الْجِبَالُ سُيِّرَتْ', 'et que les montagnes seront mises en marche,', 3),
((SELECT id FROM public.surahs WHERE number = 81), 4, 'وَإِذَا الْعِشَارُ عُطِّلَتْ', 'et que les chamelles à dix mois seront négligées,', 4),
((SELECT id FROM public.surahs WHERE number = 81), 5, 'وَإِذَا الْوُحُوشُ حُشِرَتْ', 'et que les bêtes sauvages seront rassemblées,', 5),
((SELECT id FROM public.surahs WHERE number = 81), 6, 'وَإِذَا الْبِحَارُ سُجِّرَتْ', 'et que les mers bouillonnantes seront portées à ébullition,', 6),
((SELECT id FROM public.surahs WHERE number = 81), 7, 'وَإِذَا النُّفُوسُ زُوِّجَتْ', 'et que les âmes seront accouplées,', 7),
((SELECT id FROM public.surahs WHERE number = 81), 8, 'وَإِذَا الْمَوْءُودَةُ سُئِلَتْ', 'et que la petite fille enterrée vivante sera interrogée,', 8),
((SELECT id FROM public.surahs WHERE number = 81), 9, 'بِأَيِّ ذَنبٍ قُتِلَتْ', 'pour quel péché elle a été tuée,', 9),
((SELECT id FROM public.surahs WHERE number = 81), 10, 'وَإِذَا الصُّحُفُ نُشِرَتْ', 'et que les feuilles seront déployées,', 10),
((SELECT id FROM public.surahs WHERE number = 81), 11, 'وَإِذَا السَّمَاءُ كُشِطَتْ', 'et que le ciel sera écorché,', 11),
((SELECT id FROM public.surahs WHERE number = 81), 12, 'وَإِذَا سَعِيرَ سُعِّرَتْ', 'et que la Fournaise sera attisée,', 12),
((SELECT id FROM public.surahs WHERE number = 81), 13, 'وَإِذَا الْجَنَّةُ أُزْلِفَتْ', 'et que le Paradis sera rapproché,', 13),
((SELECT id FROM public.surahs WHERE number = 81), 14, 'عَلِمَتْ نَفْسٌ مَّا أَحْضَرَتْ', 'chaque âme saura ce qu''elle a présenté.', 14),
((SELECT id FROM public.surahs WHERE number = 81), 15, 'فَلَا أُقْسِمُ بِالْخُنَّسِ', 'Non! Je jure par les planètes qui se cachent,', 15),
((SELECT id FROM public.surahs WHERE number = 81), 16, 'الْجَوَارِ الْكُنَّسِ', 'qui courent et se cachent,', 16),
((SELECT id FROM public.surahs WHERE number = 81), 17, 'وَاللَّيْلِ إِذَا عَسْعَسَ', 'et par la nuit quand elle s''assombrit,', 17),
((SELECT id FROM public.surahs WHERE number = 81), 18, 'وَالصُّبْحِ إِذَا تَنَفَّسَ', 'et par l''aube quand elle exhale son souffle,', 18),
((SELECT id FROM public.surahs WHERE number = 81), 19, 'إِنَّهُ لَقَوْلُ رَسُولٍ كَرِيمٍ', 'C''est certes là la parole d''un noble Messager,', 19),
((SELECT id FROM public.surahs WHERE number = 81), 20, 'ذِي قُوَّةٍ عِندَ ذِي الْعَرْشِ مَكِينٍ', 'doué d''une force, auprès du Maître du Trône établi fermement,', 20),
((SELECT id FROM public.surahs WHERE number = 81), 21, 'مُطَاعٍ ثَمَّ أَمِينٍ', 'obéi là-haut et digne de confiance.', 21),
((SELECT id FROM public.surahs WHERE number = 81), 22, 'وَمَا صَاحِبُكُم بِمَجْنُونٍ', 'Votre compagnon n''est nullement fou;', 22),
((SELECT id FROM public.surahs WHERE number = 81), 23, 'وَلَقَدْ رَآهُ بِالْأُفُقِ الْمُبِينِ', 'il l''a vu, en plein horizon lumineux,', 23),
((SELECT id FROM public.surahs WHERE number = 81), 24, 'وَمَا هُوَ عَلَى الْغَيْبِ ضَنِينٍ', 'et il ne se montre pas avare en ce qui concerne l''Inconnaissable.', 24),
((SELECT id FROM public.surahs WHERE number = 81), 25, 'وَمَا هُوَ بِقَوْلِ شَيْطَانٍ رَّجِيمٍ', 'Et ceci n''est point la parole d''un diable banni.', 25),
((SELECT id FROM public.surahs WHERE number = 81), 26, 'فَأَيْنَ تَذْهَبُونَ', 'Où allez-vous donc?', 26),
((SELECT id FROM public.surahs WHERE number = 81), 27, 'إِنْ هُوَ إِلَّا ذِكْرٌ لِّلْعَالَمِينَ', 'Ceci n''est qu''un rappel pour l''univers,', 27),
((SELECT id FROM public.surahs WHERE number = 81), 28, 'لِمَن شَاءَ مِنكُمْ أَن يَسْتَقِيمَ', 'pour celui qui veut suivre le droit chemin.', 28),
((SELECT id FROM public.surahs WHERE number = 81), 29, 'وَمَا تَشَاءُونَ إِلَّا أَن يَشَاءَ اللَّهُ رَبُّ الْعَالَمِينَ', 'Et vous ne le voulez que si Allah le veut, le Seigneur de l''univers.', 29)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 82: Al-Infitar (19 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 82), 1, 'إِذَا السَّمَاءُ انفَطَرَتْ', 'Quand le ciel se fendra,', 1),
((SELECT id FROM public.surahs WHERE number = 82), 2, 'وَإِذَا الْكَوَاكِبُ انتَثَرَتْ', 'et que les étoiles se disperseront,', 2),
((SELECT id FROM public.surahs WHERE number = 82), 3, 'وَإِذَا الْبِحَارُ فُجِّرَتْ', 'et que les mers seront mises en ébullition,', 3),
((SELECT id FROM public.surahs WHERE number = 82), 4, 'وَإِذَا الْقُبُورُ بُعْثِرَتْ', 'et que les tombes seront bouleversées,', 4),
((SELECT id FROM public.surahs WHERE number = 82), 5, 'عَلِمَتْ نَفْسٌ مَّا قَدَّمَتْ وَأَخَّرَتْ', 'chaque âme saura ce qu''elle a avancé et retardé.', 5),
((SELECT id FROM public.surahs WHERE number = 82), 6, 'يَا أَيُّهَا الْإِنسَانُ مَا غَرَّكَ بِرَبِّكَ الْكَرِيمِ', 'Ô homme! Qu''est-ce qui t''a trompé au sujet de ton Seigneur, le Noble,', 6),
((SELECT id FROM public.surahs WHERE number = 82), 7, 'الَّذِي خَلَقَكَ فَسَوَّاكَ فَعَدَلَكَ', 'Qui t''a créé, puis t''a harmonieusement façonné, puis t''a proportionné,', 7),
((SELECT id FROM public.surahs WHERE number = 82), 8, 'فِي أَيِّ صُورَةٍ مَّا شَاءَ رَكَّبَكَ', 't''a composé sous la forme qu''Il a voulue?', 8),
((SELECT id FROM public.surahs WHERE number = 82), 9, 'كَلَّا بَلْ تُكَذِّبُونَ بِالدِّينِ', 'Non! Mais vous traitez de mensonge la rétribution.', 9),
((SELECT id FROM public.surahs WHERE number = 82), 10, 'وَإِنَّ عَلَيْكُمْ لَحَافِظِينَ', 'Alors qu''il y a auprès de vous des gardiens,', 10),
((SELECT id FROM public.surahs WHERE number = 82), 11, 'كِرَامًا كَاتِبِينَ', 'nobles, qui écrivent,', 11),
((SELECT id FROM public.surahs WHERE number = 82), 12, 'يَعْلَمُونَ مَا تَفْعَلُونَ', 'qui savent ce que vous faites.', 12),
((SELECT id FROM public.surahs WHERE number = 82), 13, 'إِنَّ الْأَبْرَارَ لَفِي نَعِيمٍ', 'Les vertueux seront certes dans un jardin de délice,', 13),
((SELECT id FROM public.surahs WHERE number = 82), 14, 'وَإِنَّ الْفُجَّارَ لَفِي جَحِيمٍ', 'et les pervers seront certes dans une Fournaise;', 14),
((SELECT id FROM public.surahs WHERE number = 82), 15, 'يَصْلَوْنَهَا يَوْمَ الدِّينِ', 'ils y brûleront le Jour de la Rétribution,', 15),
((SELECT id FROM public.surahs WHERE number = 82), 16, 'وَمَا أَدْرَاكَ مَا يَوْمُ الدِّينِ', 'et qui te dira ce qu''est le Jour de la Rétribution?', 16),
((SELECT id FROM public.surahs WHERE number = 82), 17, 'ثُمَّ مَا أَدْرَاكَ مَا يَوْمُ الدِّينِ', 'Encore une fois, qui te dira ce qu''est le Jour de la Rétribution?', 17),
((SELECT id FROM public.surahs WHERE number = 82), 18, 'يَوْمَ لَا تَمْلِكُ نَفْسٌ لِّنَفْسٍ شَيْئًا وَالْأَمْرُ يَوْمَئِذٍ لِّلَّهِ', 'Le Jour où nulle âme ne pourra rien pour une autre, et le commandement, ce Jour-là, appartiendra à Allah.', 18),
((SELECT id FROM public.surahs WHERE number = 82), 19, 'يَوْمَ لَا تَمْلِكُ نَفْسٌ لِّنَفْسٍ شَيْئًا وَالْأَمْرُ يَوْمَئِذٍ لِّلَّهِ', 'Le Jour où nulle âme ne pourra rien pour une autre, et le commandement, ce Jour-là, appartiendra à Allah.', 19)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 85: Al-Buruj (22 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 85), 1, 'وَالسَّمَاءِ ذَاتِ الْبُرُوجِ', 'Par le ciel aux constellations!', 1),
((SELECT id FROM public.surahs WHERE number = 85), 2, 'وَالْيَوْمِ الْمَوْعُودِ', 'Et par le Jour promis!', 2),
((SELECT id FROM public.surahs WHERE number = 85), 3, 'وَشَاهِدٍ وَمَشْهُودٍ', 'Et par le témoin et ce qui est témoigné!', 3),
((SELECT id FROM public.surahs WHERE number = 85), 4, 'قُتِلَ أَصْحَابُ الْأُخْدُودِ', 'Périssent les gens de l''Ukhdud,', 4),
((SELECT id FROM public.surahs WHERE number = 85), 5, 'النَّارِ ذَاتِ الْوَقُودِ', 'du feu alimenté sans cesse,', 5),
((SELECT id FROM public.surahs WHERE number = 85), 6, 'إِذْ هُمْ عَلَيْهَا قُعُودٌ', 'quand ils étaient assis autour,', 6),
((SELECT id FROM public.surahs WHERE number = 85), 7, 'وَهُمْ عَلَىٰ مَا يَفْعَلُونَ بِالْمُؤْمِنِينَ شُهُودٌ', 'témoins de ce qu''ils faisaient aux croyants,', 7),
((SELECT id FROM public.surahs WHERE number = 85), 8, 'وَمَا نَقَمُوا مِنْهُمْ إِلَّا أَن يُؤْمِنُوا بِاللَّهِ الْعَزِيزِ الْحَمِيدِ', 'dont la seule faute était de croire en Allah, le Puissant, le Digne de louange,', 8),
((SELECT id FROM public.surahs WHERE number = 85), 9, 'الَّذِي لَهُ مُلْكُ السَّمَاوَاتِ وَالْأَرْضِ ۚ وَاللَّهُ عَلَىٰ كُلِّ شَيْءٍ شَهِيدٌ', 'à Qui appartient la royauté des cieux et de la terre. Et Allah est Témoin de toute chose.', 9),
((SELECT id FROM public.surahs WHERE number = 85), 10, 'إِنَّ الَّذِينَ فَتَنُوا الْمُؤْمِنِينَ وَالْمُؤْمِنَاتِ ثُمَّ لَمْ يَتُوبُوا فَلَهُمْ عَذَابُ جَهَنَّمَ وَلَهُمْ عَذَابُ الْحَرِيقِ', 'Ceux qui ont fait subir une épreuve aux croyants et aux croyantes, puis ne se sont pas repentis, auront le châtiment de la Fournaise et celui du feu brûlant.', 10),
((SELECT id FROM public.surahs WHERE number = 85), 11, 'إِنَّ الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ لَهُمْ جَنَّاتٌ تَجْرِي مِن تَحْتِهَا الْأَنْهَارُ ۚ ذَٰلِكَ الْفَوْزُ الْكَبِيرُ', 'Ceux qui croient et accomplissent de bonnes œuvres auront des Jardins sous lesquels coulent les ruisseaux. C''est le succès éclatant.', 11),
((SELECT id FROM public.surahs WHERE number = 85), 12, 'إِنَّ بَطْشَ رَبِّكَ لَشَدِيدٌ', 'La riposte de ton Seigneur est certes redoutable.', 12),
((SELECT id FROM public.surahs WHERE number = 85), 13, 'إِنَّهُ هُوَ يُبْدِئُ وَيُعِيدُ', 'C''est Lui, certes, Qui commence la création puis la refait,', 13),
((SELECT id FROM public.surahs WHERE number = 85), 14, 'وَهُوَ الْغَفُورُ الْوَدُودُ', 'et Il est le Pardonneur, le Tout-Aimant,', 14),
((SELECT id FROM public.surahs WHERE number = 85), 15, 'ذُو الْعَرْشِ الْمَجِيدُ', 'le Maître du Trône, le Glorieux,', 15),
((SELECT id FROM public.surahs WHERE number = 85), 16, 'فَعَّالٌ لِّمَا يُرِيدُ', 'qui fait tout ce qu''Il veut.', 16),
((SELECT id FROM public.surahs WHERE number = 85), 17, 'هَلْ أَتَاكَ حَدِيثُ الْجُنُودِ', 'T''est-il parvenu le récit des armées,', 17),
((SELECT id FROM public.surahs WHERE number = 85), 18, 'فِرْعَوْنَ وَثَمُودَ', 'de Pharaon et de Thamud?', 18),
((SELECT id FROM public.surahs WHERE number = 85), 19, 'بَلِ الَّذِينَ كَفَرُوا فِي تَكْذِيبٍ', 'Mais ceux qui ne croient pas plongent dans le mensonge,', 19),
((SELECT id FROM public.surahs WHERE number = 85), 20, 'وَاللَّهُ مِن وَرَائِهِم مُّحِيطٌ', 'alors qu''Allah, par-derrière, les cerne.', 20),
((SELECT id FROM public.surahs WHERE number = 85), 21, 'بَلْ هُوَ قُرْآنٌ مَّجِيدٌ', 'C''est plutôt un Coran glorieux,', 21),
((SELECT id FROM public.surahs WHERE number = 85), 22, 'فِي لَوْحٍ مَّحْفُوظٍ', 'conservé sur une Tablette auprès d''Allah.', 22)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 88: Al-Ghashiya (26 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 88), 1, 'هَلْ أَتَاكَ حَدِيثُ الْغَاشِيَةِ', 'T''est-il parvenu le récit de l''enveloppante?', 1),
((SELECT id FROM public.surahs WHERE number = 88), 2, 'وُجُوهٌ يَوْمَئِذٍ خَاشِعَةٌ', 'Ce Jour-là, il y aura des visages humiliés,', 2),
((SELECT id FROM public.surahs WHERE number = 88), 3, 'عَامِلَةٌ نَّاصِبَةٌ', 'travaillant et fatigués,', 3),
((SELECT id FROM public.surahs WHERE number = 88), 4, 'تَصْلَىٰ نَارًا حَامِيَةً', 'brûlant dans un Feu ardent,', 4),
((SELECT id FROM public.surahs WHERE number = 88), 5, 'تُسْقَىٰ مِنْ عَيْنٍ آنِيَةٍ', 'abreuvés à une source bouillante,', 5),
((SELECT id FROM public.surahs WHERE number = 88), 6, 'لَّيْسَ لَهُمْ طَعَامٌ إِلَّا مِن ضَرِيعٍ', 'ils n''auront d''autre nourriture que des plantes épineuses', 6),
((SELECT id FROM public.surahs WHERE number = 88), 7, 'لَا يُسْمِنُ وَلَا يُغْنِي مِن جُوعٍ', 'qui n''engraisse ni n''apaise la faim.', 7),
((SELECT id FROM public.surahs WHERE number = 88), 8, 'وُجُوهٌ يَوْمَئِذٍ نَّاعِمَةٌ', 'Ce Jour-là, il y aura des visages éclatants,', 8),
((SELECT id FROM public.surahs WHERE number = 88), 9, 'لِّسَعْيِهَا رَاضِيَةٌ', 'satisfaits de leur effort,', 9),
((SELECT id FROM public.surahs WHERE number = 88), 10, 'فِي جَنَّةٍ عَالِيَةٍ', 'dans un Jardin sublime,', 10),
((SELECT id FROM public.surahs WHERE number = 88), 11, 'لَّا تَسْمَعُ فِيهَا لَاغِيَةً', 'où on n''entend aucune futilité.', 11),
((SELECT id FROM public.surahs WHERE number = 88), 12, 'فِيهَا عَيْنٌ جَارِيَةٌ', 'Il y aura là une source coulante,', 12),
((SELECT id FROM public.surahs WHERE number = 88), 13, 'فِيهَا سُرُرٌ مَّرْفُوعَةٌ', 'et des lits surélevés,', 13),
((SELECT id FROM public.surahs WHERE number = 88), 14, 'وَأَكْوَابٌ مَّوْضُوعَةٌ', 'et des coupes posées,', 14),
((SELECT id FROM public.surahs WHERE number = 88), 15, 'وَنَمَارِقُ مَصْفُوفَةٌ', 'et des coussins rangés,', 15),
((SELECT id FROM public.surahs WHERE number = 88), 16, 'وَزَرَابِيُّ مَبْثُوثَةٌ', 'et des tapis étendus.', 16),
((SELECT id FROM public.surahs WHERE number = 88), 17, 'أَفَلَا يَنظُرُونَ إِلَى الْإِبِلِ كَيْفَ خُلِقَتْ', 'Ne considèrent-ils pas les chameaux: comment ils ont été créés,', 17),
((SELECT id FROM public.surahs WHERE number = 88), 18, 'وَإِلَى السَّمَاءِ كَيْفَ رُفِعَتْ', 'et le ciel: comment il a été élevé,', 18),
((SELECT id FROM public.surahs WHERE number = 88), 19, 'وَإِلَى الْجِبَالِ كَيْفَ نُصِبَتْ', 'et les montagnes: comment elles ont été dressées,', 19),
((SELECT id FROM public.surahs WHERE number = 88), 20, 'وَإِلَى الْأَرْضِ كَيْفَ سُطِحَتْ', 'et la terre: comment elle a été nivelée?', 20),
((SELECT id FROM public.surahs WHERE number = 88), 21, 'فَذَكِّرْ إِنَّمَا أَنتَ مُذَكِّرٌ', 'Rappelle donc, car tu n''es qu''un rappeleur,', 21),
((SELECT id FROM public.surahs WHERE number = 88), 22, 'لَّسْتَ عَلَيْهِم بِمُصَيْطِرٍ', 'tu n''as aucun pouvoir de contrainte sur eux.', 22),
((SELECT id FROM public.surahs WHERE number = 88), 23, 'إِلَّا مَن تَوَلَّىٰ وَكَفَرَ', 'Sauf celui qui tourne le dos et mécroit,', 23),
((SELECT id FROM public.surahs WHERE number = 88), 24, 'فَيُعَذِّبُهُ اللَّهُ الْعَذَابَ الْأَكْبَرَ', 'Allah lui infligera le plus grand châtiment.', 24),
((SELECT id FROM public.surahs WHERE number = 88), 25, 'إِنَّ إِلَيْنَا إِيَابَهُمْ', 'Vers Nous, certes, sera leur retour,', 25),
((SELECT id FROM public.surahs WHERE number = 88), 26, 'ثُمَّ إِنَّ عَلَيْنَا حِسَابَهُم', 'puis, certes, c''est à Nous que reviendra leur compte.', 26)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- =========================================================
-- SURAH 90: Al-Balad (20 verses)
-- =========================================================
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 90), 1, 'لَا أُقْسِمُ بِهَٰذَا الْبَلَدِ', 'Non! Je jure par cette cité!', 1),
((SELECT id FROM public.surahs WHERE number = 90), 2, 'وَأَنتَ حِلٌّ بِهَٰذَا الْبَلَدِ', 'et toi, tu es un résident dans cette cité,', 2),
((SELECT id FROM public.surahs WHERE number = 90), 3, 'وَوَالِدٍ وَمَا وَلَدَ', 'Et par un père et ce qu''il a engendré!', 3),
((SELECT id FROM public.surahs WHERE number = 90), 4, 'لَقَدْ خَلَقْنَا الْإِنسَانَ فِي كَبَدٍ', 'Nous avons certes créé l''homme dans une lutte continue.', 4),
((SELECT id FROM public.surahs WHERE number = 90), 5, 'أَيَحْسَبُ أَن لَّن يَقْدِرَ عَلَيْهِ أَحَدٌ', 'S''imagine-t-il que personne ne pourra rien contre lui?', 5),
((SELECT id FROM public.surahs WHERE number = 90), 6, 'يَقُولُ أَهْلَكْتُ مَالًا لُّبَدًا', 'Il dit: J''ai gaspillé des biens en abondance.', 6),
((SELECT id FROM public.surahs WHERE number = 90), 7, 'أَيَحْسَبُ أَن لَّمْ يَرَهُ أَحَدٌ', 'S''imagine-t-il que personne ne l''a vu?', 7),
((SELECT id FROM public.surahs WHERE number = 90), 8, 'أَلَمْ نَجْعَل لَّهُ عَيْنَيْنِ', 'Ne lui avons-Nous pas assigné deux yeux,', 8),
((SELECT id FROM public.surahs WHERE number = 90), 9, 'وَلِسَانًا وَشَفَتَيْنِ', 'une langue et deux lèvres?', 9),
((SELECT id FROM public.surahs WHERE number = 90), 10, 'وَهَدَيْنَاهُ النَّجْدَيْنِ', 'Ne lui avons-Nous pas montré les deux voies?', 10),
((SELECT id FROM public.surahs WHERE number = 90), 11, 'فَلَا اقْتَحَمَ الْعَقَبَةَ', 'Mais il n''a pas gravi la pente!', 11),
((SELECT id FROM public.surahs WHERE number = 90), 12, 'وَمَا أَدْرَاكَ مَا الْعَقَبَةُ', 'Et qui te dira ce qu''est la pente?', 12),
((SELECT id FROM public.surahs WHERE number = 90), 13, 'فَكُّ رَقَبَةٍ', 'C''est affranchir un esclave,', 13),
((SELECT id FROM public.surahs WHERE number = 90), 14, 'أَوْ إِطْعَامٌ فِي يَوْمٍ ذِي مَسْغَبَةٍ', 'ou nourrir, un jour de famine,', 14),
((SELECT id FROM public.surahs WHERE number = 90), 15, 'يَتِيمًا ذَا مَقْرَبَةٍ', 'un orphelin proche parent,', 15),
((SELECT id FROM public.surahs WHERE number = 90), 16, 'أَوْ مِسْكِينًا ذَا مَتْرَبَةٍ', 'ou un nécessiteux dans la poussière.', 16),
((SELECT id FROM public.surahs WHERE number = 90), 17, 'ثُمَّ كَانَ مِنَ الَّذِينَ آمَنُوا وَتَوَاصَوْا بِالصَّبْرِ وَتَوَاصَوْا بِالْمَرْحَمَةِ', 'Puis d''être parmi ceux qui croient et s''enjoignent mutuellement la patience et la compassion.', 17),
((SELECT id FROM public.surahs WHERE number = 90), 18, 'أُولَٰئِكَ أَصْحَابُ الْمَيْمَنَةِ', 'Ceux-là sont les gens de la droite.', 18),
((SELECT id FROM public.surahs WHERE number = 90), 19, 'وَالَّذِينَ كَفَرُوا بِآيَاتِنَا هُمْ أَصْحَابُ الْمَشْأَمَةِ', 'Et ceux qui ne croient pas en Nos signes sont les gens de la gauche.', 19),
((SELECT id FROM public.surahs WHERE number = 90), 20, 'عَلَيْهِمْ نَارٌ مُّؤْصَدَةٌ', 'Sur eux il y aura un Feu fermé de toutes parts.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

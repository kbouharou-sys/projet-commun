/*
# Fix RLS: Lock down surahs and verses to admin-only writes

## Problem
The `surahs` and `verses` tables had permissive INSERT/UPDATE/DELETE policies
that allowed ANY authenticated user to modify or delete data (using `true`
as the check predicate). This is a security vulnerability — any logged-in
user with the `lecteur` role could insert, update, or delete surahs and verses.

## Changes
1. **surahs**: Replace `auth_insert_surahs` (WITH CHECK true) and
   `auth_update_surahs` (USING true, WITH CHECK true) with admin-only
   policies using `is_admin()`. The existing `admin_delete_surahs` is
   already correct. SELECT stays public (anon + authenticated).

2. **verses**: Replace `auth_insert_verses`, `auth_update_verses`, and
   `auth_delete_verses` (all using `true`) with admin-only policies using
   `is_admin()`. SELECT stays public (anon + authenticated).

3. **roots, variations, verse_words**: Already have correct admin-only
   INSERT/UPDATE/DELETE policies — no changes needed.

## Security
- SELECT on all five tables: public (anon, authenticated) — read-only access for all.
- INSERT/UPDATE/DELETE on all five tables: `is_admin()` only.
- No data is lost; only policies are replaced.
*/

-- ── surahs: fix INSERT policy ──
DROP POLICY IF EXISTS "auth_insert_surahs" ON surahs;
CREATE POLICY "admin_insert_surahs" ON surahs FOR INSERT
  TO authenticated WITH CHECK (is_admin());

-- ── surahs: fix UPDATE policy ──
DROP POLICY IF EXISTS "auth_update_surahs" ON surahs;
CREATE POLICY "admin_update_surahs" ON surahs FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

-- ── verses: fix INSERT policy ──
DROP POLICY IF EXISTS "auth_insert_verses" ON verses;
CREATE POLICY "admin_insert_verses" ON verses FOR INSERT
  TO authenticated WITH CHECK (is_admin());

-- ── verses: fix UPDATE policy ──
DROP POLICY IF EXISTS "auth_update_verses" ON verses;
CREATE POLICY "admin_update_verses" ON verses FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

-- ── verses: fix DELETE policy ──
DROP POLICY IF EXISTS "auth_delete_verses" ON verses;
CREATE POLICY "admin_delete_verses" ON verses FOR DELETE
  TO authenticated USING (is_admin());

/*
# Insert first 20 verses for surahs 21, 23, 26, 27, 28, 29

## Surahs added (first 20 verses each):
- 21: Al-Anbiya'
- 23: Al-Mu'minun
- 26: Ash-Shu'ara'
- 27: An-Naml
- 28: Al-Qasas
- 29: Al-Ankabut
*/

-- SURAH 21: Al-Anbiya' (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 21), 1, 'اقْتَرَبَ لِلنَّاسِ حِسَابُهُمْ وَهُمْ فِي غَفْلَةٍ مُّعْرِضُونَ', 'Le compte des hommes approche, et ils sont dans l''insouciance, détournés.', 1),
((SELECT id FROM public.surahs WHERE number = 21), 2, 'مَا يَأْتِيهِم مِّن ذِكْرٍ مِّن رَّبِّهِم مُّحْدَثٍ إِلَّا اسْتَمَعُوهُ وَهُمْ يَلْعَبُونَ', 'Aucun rappel nouveau de leur Seigneur ne leur vient qu''ils ne l''écoutent en s''amusant,', 2),
((SELECT id FROM public.surahs WHERE number = 21), 3, 'لَاهِيَةً قُلُوبُهُمْ', 'leurs cœurs distraits.', 3),
((SELECT id FROM public.surahs WHERE number = 21), 4, 'وَأَسَرُّوا النَّجْوَى الَّذِينَ ظَلَمُوا', 'Les injustes tiennent des conversations secrètes:', 4),
((SELECT id FROM public.surahs WHERE number = 21), 5, 'هَلْ هَٰذَا إِلَّا بَشَرٌ مِّثْلُكُمْ', 'Celui-ci n''est-il qu''un humain comme vous?', 5),
((SELECT id FROM public.surahs WHERE number = 21), 6, 'أَفَتَأْتُونَ السِّحْرَ وَأَنتُمْ تُبْصِرُونَ', 'Allez-vous accorder foi à la magie alors que vous voyez?', 6),
((SELECT id FROM public.surahs WHERE number = 21), 7, 'قَالَ رَبِّي يَعْلَمُ الْقَوْلَ فِي السَّمَاءِ وَالْأَرْضِ', 'Il dit: Mon Seigneur connaît la parole au ciel et sur la terre.', 7),
((SELECT id FROM public.surahs WHERE number = 21), 8, 'وَهُوَ السَّمِيعُ الْعَلِيمُ', 'C''est Lui l''Audient, l''Omniscient.', 8),
((SELECT id FROM public.surahs WHERE number = 21), 9, 'بَلْ قَالُوا أَضْغَاثُ أَحْلَامٍ', 'Mais ils dirent: Amas de songes confus!', 9),
((SELECT id FROM public.surahs WHERE number = 21), 10, 'بَلِ افْتَرَاهُ بَلْ هُوَ شَاعِرٌ', 'Il l''a forgé! C''est un poète!', 10),
((SELECT id FROM public.surahs WHERE number = 21), 11, 'فَلْيَأْتِنَا بِآيَةٍ كَمَا أُرْسِلَ الْأَوَّلُونَ', 'Qu''il nous apporte un signe comme les anciens Messagers furent envoyés!', 11),
((SELECT id FROM public.surahs WHERE number = 21), 12, 'مَا آمَنَتْ قَبْلَهُم مِّن قَرْيَةٍ أَهْلَكْنَاهَا', 'Aucune cité que Nous ayons anéantie avant eux n''a cru.', 12),
((SELECT id FROM public.surahs WHERE number = 21), 13, 'أَفَلَمْ يَرَوْا فِي الْأَرْضِ كَمْ أَهْلَكْنَا قَبْلَهُمْ', 'N''ont-ils pas vu sur la terre combien Nous avons anéanti avant eux?', 13),
((SELECT id FROM public.surahs WHERE number = 21), 14, 'إِنَّا كُنَّا فَاعِلِينَ', 'Nous le faisions.', 14),
((SELECT id FROM public.surahs WHERE number = 21), 15, 'فَلَوْلَا كَانَتْ قَرْيَةٌ آمَنَتْ فَنَفَعَهَا إِيمَانُهَا', 'Si seulement une cité avait cru, sa foi lui aurait profité!', 15),
((SELECT id FROM public.surahs WHERE number = 21), 16, 'إِلَّا قَوْمَ يُونُسَ لَمَّا آمَنُوا كَشَفْنَا عَنْهُمْ عَذَابَ الْخِزْيِ', 'Sauf le peuple de Jonas: quand il crut, Nous écartâmes de lui le châtiment d''ignominie.', 16),
((SELECT id FROM public.surahs WHERE number = 21), 17, 'فِي الْحَيَاةِ الدُّنْيَا وَمَتَّعْنَاهُمْ إِلَىٰ حِينٍ', 'dans la vie d''ici-bas, et les fîmes jouir jusqu''à un terme.', 17),
((SELECT id FROM public.surahs WHERE number = 21), 18, 'وَلَوْ شَاءَ رَبُّكَ لَآمَنَ مَن فِي الْأَرْضِ كُلُّهُمْ جَمِيعًا', 'Si ton Seigneur voulait, tous ceux qui sont sur terre croiraient.', 18),
((SELECT id FROM public.surahs WHERE number = 21), 19, 'أَفَأَنتَ تُكْرِهُ النَّاسَ حَتَّىٰ يَكُونُوا مُؤْمِنِينَ', 'Contraindras-tu les gens à devenir croyants?', 19),
((SELECT id FROM public.surahs WHERE number = 21), 20, 'وَمَا كَانَ لِنَفْسٍ أَن تُؤْمِنَ إِلَّا بِإِذْنِ اللَّهِ', 'Nulle âme ne croit sans la permission d''Allah.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 23: Al-Mu'minun (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 23), 1, 'قَدْ أَفْلَحَ الْمُؤْمِنُونَ', 'Les croyants ont réussi,', 1),
((SELECT id FROM public.surahs WHERE number = 23), 2, 'الَّذِينَ هُمْ فِي صَلَاتِهِمْ خَاشِعُونَ', 'ceux qui sont humbles dans leur Salat,', 2),
((SELECT id FROM public.surahs WHERE number = 23), 3, 'وَالَّذِينَ هُمْ عَنِ اللَّغْوِ مُعْرِضُونَ', 'qui se détournent des futilités,', 3),
((SELECT id FROM public.surahs WHERE number = 23), 4, 'وَالَّذِينَ هُمْ لِلزَّكَاةِ فَاعِلُونَ', 'qui s''acquittent de la Zakat,', 4),
((SELECT id FROM public.surahs WHERE number = 23), 5, 'وَالَّذِينَ هُمْ لِفُرُوجِهِمْ حَافِظُونَ', 'qui préservent leurs parties intimes,', 5),
((SELECT id FROM public.surahs WHERE number = 23), 6, 'إِلَّا عَلَىٰ أَزْوَاجِهِمْ أَوْ مَا مَلَكَتْ أَيْمَانُهُمْ', 'sauf envers leurs épouses ou ce que leurs mains possèdent,', 6),
((SELECT id FROM public.surahs WHERE number = 23), 7, 'فَمَنِ ابْتَغَىٰ وَرَاءَ ذَٰلِكَ فَأُولَٰئِكَ هُمُ الْعَادُونَ', 'quiconque cherche au-delà, ceux-là sont les transgresseurs.', 7),
((SELECT id FROM public.surahs WHERE number = 23), 8, 'وَالَّذِينَ هُمْ لِأَمَانَاتِهِمْ وَعَهْدِهِمْ رَاعُونَ', 'Et ceux qui préservent leurs dépôts et leurs engagements,', 8),
((SELECT id FROM public.surahs WHERE number = 23), 9, 'وَالَّذِينَ هُمْ عَلَىٰ صَلَوَاتِهِمْ يُحَافِظُونَ', 'et ceux qui préservent leurs Salat:', 9),
((SELECT id FROM public.surahs WHERE number = 23), 10, 'أُولَٰئِكَ هُمُ الْوَارِثُونَ', 'ceux-là sont les héritiers', 10),
((SELECT id FROM public.surahs WHERE number = 23), 11, 'الَّذِينَ يَرِثُونَ الْفِرْدَوْسَ هُمْ فِيهَا خَالِدُونَ', 'qui hériteront du Firdaws, où ils demeureront éternellement.', 11),
((SELECT id FROM public.surahs WHERE number = 23), 12, 'وَلَقَدْ خَلَقْنَا الْإِنسَانَ مِن سُلَالَةٍ مِّن طِينٍ', 'Nous avons certes créé l''homme d''un extrait d''argile.', 12),
((SELECT id FROM public.surahs WHERE number = 23), 13, 'ثُمَّ جَعَلْنَاهُ نُطْفَةً فِي قَرَارٍ مَّكِينٍ', 'Puis Nous en avons fait une goutte dans un reposoir sûr.', 13),
((SELECT id FROM public.surahs WHERE number = 23), 14, 'ثُمَّ خَلَقْنَا النُّطْفَةَ عَلَقَةً', 'Puis Nous avons fait de la goutte une adhérence,', 14),
((SELECT id FROM public.surahs WHERE number = 23), 15, 'فَخَلَقْنَا الْعَلَقَةَ مُضْغَةً', 'et de l''adhérence un embryon, puis de l''embryon des os,', 15),
((SELECT id FROM public.surahs WHERE number = 23), 16, 'فَكَسَوْنَا الْعِظَامَ لَحْمًا', 'et Nous avons revêtu les os de chair.', 16),
((SELECT id FROM public.surahs WHERE number = 23), 17, 'ثُمَّ أَنشَأْنَاهُ خَلْقًا آخَرَ', 'Puis Nous en avons fait une autre création.', 17),
((SELECT id FROM public.surahs WHERE number = 23), 18, 'فَتَبَارَكَ اللَّهُ أَحْسَنُ الْخَالِقِينَ', 'Béni soit Allah, le meilleur des créateurs!', 18),
((SELECT id FROM public.surahs WHERE number = 23), 19, 'ثُمَّ إِنَّكُمْ بَعْدَ ذَٰلِكَ لَمَيِّتُونَ', 'Puis, après cela, vous mourrez.', 19),
((SELECT id FROM public.surahs WHERE number = 23), 20, 'ثُمَّ إِنَّكُمْ يَوْمَ الْقِيَامَةِ تُبْعَثُونَ', 'Puis, le Jour de la Résurrection, vous serez ressuscités.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 26: Ash-Shu'ara' (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 26), 1, 'طسم', 'Ta Sin Mim.', 1),
((SELECT id FROM public.surahs WHERE number = 26), 2, 'تِلْكَ آيَاتُ الْكِتَابِ الْمُبِينِ', 'Voici les versets du Livre clair.', 2),
((SELECT id FROM public.surahs WHERE number = 26), 3, 'لَعَلَّكَ بَاخِعٌ نَّفْسَكَ أَلَّا يَكُونُوا مُؤْمِنِينَ', 'Tu te consumes peut-être de chagrin qu''ils ne soient pas croyants!', 3),
((SELECT id FROM public.surahs WHERE number = 26), 4, 'إِن نَّشَأْ نُنزِلْ عَلَيْهِم مِّنَ السَّمَاءِ آيَةً فَظَلَّتْ أَعْنَاقُهُمْ لَهَا خَاضِعِينَ', 'Si Nous voulons, Nous ferions descendre du ciel un signe, et leurs nuques s''en soumettraient.', 4),
((SELECT id FROM public.surahs WHERE number = 26), 5, 'وَمَا يَأْتِيهِم مِّن ذِكْرٍ مِّنَ الرَّحْمَٰنِ مُحْدَثٍ إِلَّا كَانُوا عَنْهُ مُعْرِضِينَ', 'Aucun rappel nouveau du Tout Miséricordieux ne leur vient sans qu''ils ne s''en détournent.', 5),
((SELECT id FROM public.surahs WHERE number = 26), 6, 'فَقَدْ كَذَّبُوا فَسَيَأْتِيهِمْ أَنبَاءُ مَا كَانُوا بِهِ يَسْتَهْزِئُونَ', 'Ils ont traité de mensonge. Les nouvelles de ce qu''ils raillaient leur parviendront.', 6),
((SELECT id FROM public.surahs WHERE number = 26), 7, 'أَوَلَمْ يَرَوْا إِلَى الْأَرْضِ كَمْ أَنبَتْنَا فِيهَا مِن كُلِّ زَوْجٍ كَرِيمٍ', 'N''ont-ils pas vu la terre, combien Nous y avons fait pousser de toute sorte de plantes nobles?', 7),
((SELECT id FROM public.surahs WHERE number = 26), 8, 'إِنَّ فِي ذَٰلِكَ لَآيَةً ۖ وَمَا كَانَ أَكْثَرُهُم مُّؤْمِنِينَ', 'Il y a là un signe. Mais la plupart d''entre eux ne croient pas.', 8),
((SELECT id FROM public.surahs WHERE number = 26), 9, 'وَإِنَّ رَبَّكَ لَهُوَ الْعَزِيزُ الرَّحِيمُ', 'Et ton Seigneur, c''est Lui le Tout-Puissant, le Très Miséricordieux.', 9),
((SELECT id FROM public.surahs WHERE number = 26), 10, 'وَإِذْ نَادَىٰ رَبُّكَ مُوسَىٰ أَنِ ائْتِ الْقَوْمَ الظَّالِمِينَ', 'Et quand ton Seigneur interpella Moïse: Va vers le peuple injuste,', 10),
((SELECT id FROM public.surahs WHERE number = 26), 11, 'قَوْمَ فِرْعَوْنَ ۚ أَلَا يَتَّقُونَ', 'le peuple de Pharaon. Ne craindront-ils pas?', 11),
((SELECT id FROM public.surahs WHERE number = 26), 12, 'قَالَ رَبِّ إِنِّي أَخَافُ أَن يُكَذِّبُونِ', 'Il dit: Seigneur! Je crains qu''ils ne me traitent de menteur.', 12),
((SELECT id FROM public.surahs WHERE number = 26), 13, 'وَيَضِيقُ صَدْرِي وَلَا يَنطَلِقُ لِسَانِي فَأَرْسِلْ إِلَىٰ هَارُونَ', 'Ma poitrine se serre, ma langue ne se délie pas. Envoie donc vers Aaron.', 13),
((SELECT id FROM public.surahs WHERE number = 26), 14, 'وَلَهُمْ عَلَيَّ ذَنبٌ فَأَخَافُ أَن يَقْتُلُونِ', 'Ils ont un grief contre moi, je crains qu''ils ne me tuent.', 14),
((SELECT id FROM public.surahs WHERE number = 26), 15, 'قَالَ كَلَّا ۖ فَاذْهَبَا بِآيَاتِنَا إِنَّا مَعَكُم مُّسْتَمِعُونَ', 'Allah dit: Jamais! Allez avec Nos signes. Nous sommes avec vous, à l''écoute.', 15),
((SELECT id FROM public.surahs WHERE number = 26), 16, 'فَأْتِيَا فِرْعَوْنَ فَقُولَا إِنَّا رَسُولُ رَبِّ الْعَالَمِينَ', 'Allez vers Pharaon et dites: Nous sommes les Messagers du Seigneur de l''univers.', 16),
((SELECT id FROM public.surahs WHERE number = 26), 17, 'أَنْ أَرْسِلْ مَعَنَا بَنِي إِسْرَائِيلَ', 'Laisse partir avec nous les Enfants d''Israël.', 17),
((SELECT id FROM public.surahs WHERE number = 26), 18, 'قَالَ أَلَمْ نُرَبِّكَ فِينَا وَلِيدًا وَلَبِثْتَ فِينَا مِنْ عُمُرِكَ سِنِينَ', 'Pharaon dit: Ne t''avons-nous pas élevé enfant? Et n''as-tu pas vécu parmi nous des années?', 18),
((SELECT id FROM public.surahs WHERE number = 26), 19, 'وَفَعَلْتَ فَعْلَتَكَ الَّتِي فَعَلْتَ وَأَنتَ مِنَ الْكَافِرِينَ', 'Et tu as commis l''acte que tu as commis, alors que tu étais infidèle.', 19),
((SELECT id FROM public.surahs WHERE number = 26), 20, 'قَالَ فَعَلْتُهَا إِذًا وَأَنَا مِنَ الضَّالِّينَ', 'Il dit: Je l''ai commis alors que j''étais égaré.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 27: An-Naml (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 27), 1, 'طس ۚ تِلْكَ آيَاتُ الْقُرْآنِ وَكِتَابٍ مُّبِينٍ', 'Ta Sin. Voici les versets du Coran et d''un Livre clair,', 1),
((SELECT id FROM public.surahs WHERE number = 27), 2, 'هُدًى وَبُشْرَىٰ لِلْمُؤْمِنِينَ', 'une guidée et une bonne annonce pour les croyants,', 2),
((SELECT id FROM public.surahs WHERE number = 27), 3, 'الَّذِينَ يُقِيمُونَ الصَّلَاةَ وَيُؤْتُونَ الزَّكَاةَ وَهُم بِالْآخِرَةِ هُمْ يُوقِنُونَ', 'qui accomplissent la Salat, acquittent la Zakat et ont la certitude de l''au-delà.', 3),
((SELECT id FROM public.surahs WHERE number = 27), 4, 'إِنَّ الَّذِينَ لَا يُؤْمِنُونَ بِالْآخِرَةِ زَيَّنَّا لَهُمْ أَعْمَالَهُمْ فَهُمْ يَعْمَهُونَ', 'Ceux qui ne croient pas en l''au-delà, Nous avons embelli leurs actions: ils s''égarent.', 4),
((SELECT id FROM public.surahs WHERE number = 27), 5, 'أُولَٰئِكَ الَّذِينَ لَهُمْ سُوءُ الْعَذَابِ وَهُمْ فِي الْآخِرَةِ هُمُ الْأَخْسَرُونَ', 'Ceux-là auront le pire châtiment et seront les plus perdants dans l''au-delà.', 5),
((SELECT id FROM public.surahs WHERE number = 27), 6, 'وَإِنَّكَ لَتُلَقَّى الْقُرْآنَ مِن لَّدُنْ حَكِيمٍ عَلِيمٍ', 'Et toi, tu reçois le Coran de la part d''un Sage, Omniscient.', 6),
((SELECT id FROM public.surahs WHERE number = 27), 7, 'إِذْ قَالَ مُوسَىٰ لِأَهْلِهِ إِنِّي آنَسْتُ نَارًا سَآتِيكُم مِّنْهَا بِخَبَرٍ', 'Quand Moïse dit à sa famille: J''ai aperçu un feu. Je vous en apporterai des nouvelles,', 7),
((SELECT id FROM public.surahs WHERE number = 27), 8, 'أَوْ آتِيكُم بِشِهَابٍ قَبَسٍ لَّعَلَّكُمْ تَصْطَلُونَ', 'ou un tison enflammé, pour que vous vous réchauffiez.', 8),
((SELECT id FROM public.surahs WHERE number = 27), 9, 'فَلَمَّا جَاءَهَا نُودِيَ أَن بُورِكَ مَن فِي النَّارِ وَمَنْ حَوْلَهَا', 'Quand il y arriva, on l''interpella: Béni soit Celui qui est dans le feu et autour de lui!', 9),
((SELECT id FROM public.surahs WHERE number = 27), 10, 'وَسُبْحَانَ اللَّهِ رَبِّ الْعَالَمِينَ', 'Gloire à Allah, Seigneur de l''univers!', 10),
((SELECT id FROM public.surahs WHERE number = 27), 11, 'يَا مُوسَىٰ إِنَّهُ أَنَا اللَّهُ الْعَزِيزُ الْحَكِيمُ', 'Ô Moïse! C''est Moi, Allah, le Tout-Puissant, le Sage.', 11),
((SELECT id FROM public.surahs WHERE number = 27), 12, 'وَأَلْقِ عَصَاكَ ۚ فَلَمَّا رَآهَا تَهْتَزُّ كَأَنَّهَا جَانٌّ وَلَّىٰ مُدْبِرًا', 'Jette ton bâton. Quand il le vit remuer comme un serpent, il s''enfuit sans se retourner.', 12),
((SELECT id FROM public.surahs WHERE number = 27), 13, 'لَا تَخَفْ إِنَّكَ مِنَ الْآمِنِينَ', 'Ne crains pas! Tu es en sécurité.', 13),
((SELECT id FROM public.surahs WHERE number = 27), 14, 'اسْلُكْ يَدَكَ فِي جَيْبِكَ تَخْرُجْ بَيْضَاءَ مِنْ غَيْرِ سُوءٍ', 'Mets ta main dans ton col, elle ressortira blanche sans mal.', 14),
((SELECT id FROM public.surahs WHERE number = 27), 15, 'فِي تِسْعِ آيَاتٍ إِلَىٰ فِرْعَوْنَ وَقَوْمِهِ', 'parmi neuf signes vers Pharaon et son peuple.', 15),
((SELECT id FROM public.surahs WHERE number = 27), 16, 'إِنَّهُمْ كَانُوا قَوْمًا فَاسِقِينَ', 'Ils étaient un peuple pervers.', 16),
((SELECT id FROM public.surahs WHERE number = 27), 17, 'فَلَمَّا جَاءَتْهُمْ آيَاتُنَا مُبْصِرَةً قَالُوا هَٰذَا سِحْرٌ مُّبِينٌ', 'Quand Nos signes évidents leur vinrent, ils dirent: C''est de la magie évidente!', 17),
((SELECT id FROM public.surahs WHERE number = 27), 18, 'وَجَحَدُوا بِهَا وَاسْتَيْقَنَتْهَا أَنفُسُهُمْ ظُلْمًا وَعُلُوًّا', 'Ils les nièrent injustement et par orgueil, alors qu''ils en étaient convaincus.', 18),
((SELECT id FROM public.surahs WHERE number = 27), 19, 'فَانظُرْ كَيْفَ كَانَ عَاقِبَةُ الْمُفْسِدِينَ', 'Regarde quelle fut la fin des corrupteurs.', 19),
((SELECT id FROM public.surahs WHERE number = 27), 20, 'وَلَقَدْ آتَيْنَا دَاوُودَ وَسُلَيْمَانَ عِلْمًا', 'Nous avons donné à David et Salomon la science.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 28: Al-Qasas (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 28), 1, 'طسم', 'Ta Sin Mim.', 1),
((SELECT id FROM public.surahs WHERE number = 28), 2, 'تِلْكَ آيَاتُ الْكِتَابِ الْمُبِينِ', 'Voici les versets du Livre clair.', 2),
((SELECT id FROM public.surahs WHERE number = 28), 3, 'نَتْلُو عَلَيْكَ مِن نَّبَإِ مُوسَىٰ وَفِرْعَوْنَ بِالْحَقِّ لِقَوْمٍ يُؤْمِنُونَ', 'Nous te racontons en vérité le récit de Moïse et de Pharaon, pour un peuple qui croit.', 3),
((SELECT id FROM public.surahs WHERE number = 28), 4, 'إِنَّ فِرْعَوْنَ عَلَا فِي الْأَرْضِ وَجَعَلَ أَهْلَهَا شِيَعًا', 'Pharaon s''éleva sur terre et réduisit son peuple en factions,', 4),
((SELECT id FROM public.surahs WHERE number = 28), 5, 'يَسْتَضْعِفُ طَائِفَةً مِّنْهُمْ يُذَبِّحُ أَبْنَاءَهُمْ وَيَسْتَحْيِي نِسَاءَهُمْ', 'affaiblissant un groupe parmi eux: il égorgeait leurs fils et épargnait leurs femmes.', 5),
((SELECT id FROM public.surahs WHERE number = 28), 6, 'إِنَّهُ كَانَ مِنَ الْمُفْسِدِينَ', 'Il était du nombre des corrupteurs.', 6),
((SELECT id FROM public.surahs WHERE number = 28), 7, 'وَنُرِيدُ أَن نَّمُنَّ عَلَى الَّذِينَ اسْتُضْعِفُوا فِي الْأَرْضِ', 'Et Nous voulions accorder Sa grâce à ceux qui étaient affaiblis sur terre,', 7),
((SELECT id FROM public.surahs WHERE number = 28), 8, 'وَنَجْعَلَهُمْ أَئِمَّةً وَنَجْعَلَهُمُ الْوَارِثِينَ', 'en faire des dirigeants et des héritiers,', 8),
((SELECT id FROM public.surahs WHERE number = 28), 9, 'وَنُمَكِّنَ لَهُمْ فِي الْأَرْضِ وَنُرِيَ فِرْعَوْنَ وَهَامَانَ وَجُنُودَهُمَا', 'les établir sur terre, et montrer à Pharaon, Haman et leurs armées', 9),
((SELECT id FROM public.surahs WHERE number = 28), 10, 'مِنْهُم مَّا كَانُوا يَحْذَرُونَ', 'ce qu''ils redoutaient.', 10),
((SELECT id FROM public.surahs WHERE number = 28), 11, 'وَأَوْحَيْنَا إِلَىٰ أُمِّ مُوسَىٰ أَنْ أَرْضِعِيهِ', 'Et Nous révélâmes à la mère de Moïse: Allaites-le.', 11),
((SELECT id FROM public.surahs WHERE number = 28), 12, 'فَإِذَا خِفْتِ عَلَيْهِ فَأَلْقِيهِ فِي الْيَمِّ وَلَا تَخَافِي وَلَا تَحْزَنِي', 'Si tu crains pour lui, mets-le dans le fleuve. Ne crains pas, ne t''afflige pas.', 12),
((SELECT id FROM public.surahs WHERE number = 28), 13, 'إِنَّا رَادُّوهُ إِلَيْكِ وَجَاعِلُوهُ مِنَ الْمُرْسَلِينَ', 'Nous te le rendrons et ferons de lui un Messager.', 13),
((SELECT id FROM public.surahs WHERE number = 28), 14, 'فَالْتَقَطَهُ آلُ فِرْعَوْنَ لِيَكُونَ لَهُمْ عَدُوًّا وَحَزَنًا', 'La famille de Pharaon le recueillit pour qu''il devienne leur ennemi et leur affliction.', 14),
((SELECT id FROM public.surahs WHERE number = 28), 15, 'إِنَّ فِرْعَوْنَ وَهَامَانَ وَجُنُودَهُمَا كَانُوا خَاطِئِينَ', 'Pharaon, Haman et leurs armées étaient fautifs.', 15),
((SELECT id FROM public.surahs WHERE number = 28), 16, 'وَقَالَتِ امْرَأَتُ فِرْعَوْنَ قُرَّةُ عَيْنٍ لِّي وَلَكَ', 'L''épouse de Pharaon dit: C''est une joie pour moi et pour toi.', 16),
((SELECT id FROM public.surahs WHERE number = 28), 17, 'لَا تَقْتُلُوهُ عَسَىٰ أَن يَنفَعَنَا أَوْ نَتَّخِذَهُ وَلَدًا وَهُمْ لَا يَشْعُرُونَ', 'Ne le tuez pas. Il pourrait nous être utile, ou nous l''adopterons. Ils ne sentaient pas.', 17),
((SELECT id FROM public.surahs WHERE number = 28), 18, 'وَأَصْبَحَ فُؤَادُ أُمِّ مُوسَىٰ فَارِغًا', 'Le cœur de la mère de Moïse devint vide.', 18),
((SELECT id FROM public.surahs WHERE number = 28), 19, 'إِن كَادَتْ لَتُبْدِي بِهِ لَوْلَا أَن رَّبَطْنَا عَلَىٰ قَلْبِهَا', 'Elle faillait le divulguer, si Nous n''avions affermi son cœur.', 19),
((SELECT id FROM public.surahs WHERE number = 28), 20, 'لِتَكُونَ مِنَ الْمُؤْمِنِينَ', 'pour qu''elle soit du nombre des croyants.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 29: Al-Ankabut (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 29), 1, 'الٓمٓ', 'Alif Lam Mim.', 1),
((SELECT id FROM public.surahs WHERE number = 29), 2, 'أَحَسِبَ النَّاسُ أَن يُتْرَكُوا أَن يَقُولُوا آمَنَّا وَهُمْ لَا يُفْتَنُونَ', 'Les hommes pensent-ils qu''on les laissera dire: Nous croyons, sans être éprouvés?', 2),
((SELECT id FROM public.surahs WHERE number = 29), 3, 'وَلَقَدْ فَتَنَّا الَّذِينَ مِن قَبْلِهِمْ ۖ فَلَيَعْلَمَنَّ اللَّهُ الَّذِينَ صَدَقُوا', 'Nous avons éprouvé ceux avant eux. Allah connaîtra les véridiques', 3),
((SELECT id FROM public.surahs WHERE number = 29), 4, 'وَلَيَعْلَمَنَّ الْكَاذِبِينَ', 'et connaîtra les menteurs.', 4),
((SELECT id FROM public.surahs WHERE number = 29), 5, 'أَمْ حَسِبَ الَّذِينَ يَعْمَلُونَ السَّيِّئَاتِ أَن يَسْبِقُونَا ۚ سَاءَ مَا يَحْكُمُونَ', 'Ou ceux qui font le mal pensent-ils Nous devancer? Quel mauvais jugement!', 5),
((SELECT id FROM public.surahs WHERE number = 29), 6, 'مَن كَانَ يَرْجُو لِقَاءَ اللَّهِ فَإِنَّ أَجَلَ اللَّهِ لَآتٍ', 'Quiconque espère la rencontre d''Allah, le terme d''Allah arrive.', 6),
((SELECT id FROM public.surahs WHERE number = 29), 7, 'وَهُوَ السَّمِيعُ الْعَلِيمُ', 'C''est Lui l''Audient, l''Omniscient.', 7),
((SELECT id FROM public.surahs WHERE number = 29), 8, 'وَالَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ لَنُكَفِّرَنَّ عَنْهُمْ سَيِّئَاتِهِمْ', 'Et ceux qui croient et font le bien, Nous effacerons leurs mauvaises actions,', 8),
((SELECT id FROM public.surahs WHERE number = 29), 9, 'وَلَنَجْزِيَنَّهُمْ أَحْسَنَ الَّذِي كَانُوا يَعْمَلُونَ', 'et les rétribuerons selon le meilleur de ce qu''ils faisaient.', 9),
((SELECT id FROM public.surahs WHERE number = 29), 10, 'وَوَصَّيْنَا الْإِنسَانَ بِوَالِدَيْهِ حُسْنًا', 'Et Nous avons recommandé à l''homme envers ses parents le bien.', 10),
((SELECT id FROM public.surahs WHERE number = 29), 11, 'وَإِن جَاهَدَاكَ لِتُشْرِكَ بِي مَا لَيْسَ لَكَ بِهِ عِلْمٌ فَلَا تُطِعْهُمَا', 'S''ils te forcent à M''associer ce dont tu n''as pas science, ne leur obéis pas.', 11),
((SELECT id FROM public.surahs WHERE number = 29), 12, 'إِلَيَّ مَرْجِعُكُمْ فَأُنَبِّئُكُم بِمَا كُنتُمْ تَعْمَلُونَ', 'Vers Moi est votre retour, Je vous informerai de ce que vous faisiez.', 12),
((SELECT id FROM public.surahs WHERE number = 29), 13, 'وَالَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ لَنُدْخِلَنَّهُمْ فِي الصَّالِحِينَ', 'Et ceux qui croient et font le bien, Nous les ferons entrer parmi les vertueux.', 13),
((SELECT id FROM public.surahs WHERE number = 29), 14, 'وَلَقَدْ أَرْسَلْنَا نُوحًا إِلَىٰ قَوْمِهِ فَلَبِثَ فِيهِمْ أَلْفَ سَنَةٍ إِلَّا خَمْسِينَ عَامًا', 'Nous avons envoyé Noé à son peuple. Il resta parmi eux mille ans moins cinquante.', 14),
((SELECT id FROM public.surahs WHERE number = 29), 15, 'فَأَخَذَهُمُ الطُّوفَانُ وَهُمْ ظَالِمُونَ', 'Le déluge les saisit alors qu''ils étaient injustes.', 15),
((SELECT id FROM public.surahs WHERE number = 29), 16, 'فَأَنجَيْنَاهُ وَأَصْحَابَ السَّفِينَةِ وَجَعَلْنَاهَا آيَةً لِّلْعَالَمِينَ', 'Nous le sauvâmes, lui et les occupants du vaisseau, et en fîmes un signe pour l''univers.', 16),
((SELECT id FROM public.surahs WHERE number = 29), 17, 'وَإِبْرَاهِيمَ إِذْ قَالَ لِقَوْمِهِ اعْبُدُوا اللَّهَ وَاتَّقُوهُ', 'Et Abraham, quand il dit à son peuple: Adorez Allah et craignez-Le.', 17),
((SELECT id FROM public.surahs WHERE number = 29), 18, 'ذَٰلِكُمْ خَيْرٌ لَّكُمْ إِن كُنتُمْ تَعْلَمُونَ', 'Cela est meilleur pour vous, si vous saviez.', 18),
((SELECT id FROM public.surahs WHERE number = 29), 19, 'إِنَّمَا تَعْبُدُونَ مِن دُونِ اللَّهِ أَوْثَانًا', 'Vous n''adorez en dehors d''Allah que des idoles.', 19),
((SELECT id FROM public.surahs WHERE number = 29), 20, 'وَتَخْلُقُونَ إِفْكًا', 'Et vous forgez un mensonge.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

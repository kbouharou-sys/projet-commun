/*
# Insert verses for surahs 50, 51, 52, 53, 54, 56, 77

## Surahs added:
- 50: Qaf (45 verses)
- 51: Ad-Dhariyat (60 verses)
- 52: At-Tur (49 verses)
- 53: An-Najm (62 verses)
- 54: Al-Qamar (55 verses)
- 56: Al-Waqi'a (96 verses)
- 77: Al-Mursalat (50 verses)
*/

-- SURAH 50: Qaf (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 50), 1, 'ق ۚ وَالْقُرْآنِ الْمَجِيدِ', 'Qaf. Par le Coran glorieux!', 1),
((SELECT id FROM public.surahs WHERE number = 50), 2, 'بَلْ عَجِبُوا أَن جَاءَهُم مُّنذِرٌ مِّنْهُمْ فَقَالَ الْكَافِرُونَ هَٰذَا شَيْءٌ عَجِيبٌ', 'Mais ils s''étonnent qu''un avertisseur des leurs soit venu à eux. Les infidèles disent: «Chose étonnante!»', 2),
((SELECT id FROM public.surahs WHERE number = 50), 3, 'أَإِذَا مِتْنَا وَكُنَّا تُرَابًا ۖ ذَٰلِكَ رَجْعٌ بَعِيدٌ', 'Quoi! Quand nous serons morts et devenus poussière... Ce serait un retour bien lointain!»', 3),
((SELECT id FROM public.surahs WHERE number = 50), 4, 'قَدْ عَلِمْنَا مَا تَنقُصُ الْأَرْضُ مِنْهُمْ ۖ وَعِندَنَا كِتَابٌ حَفِيظٌ', 'Nous savons ce que la terre ronge d''eux. Et auprès de Nous est un Livre qui conserve tout.', 4),
((SELECT id FROM public.surahs WHERE number = 50), 5, 'بَلْ كَذَّبُوا بِالْحَقِّ لَمَّا جَاءَهُمْ فَهُمْ فِي أَمْرٍ مَّرِجٍ', 'Mais ils ont traité de mensonge la vérité qui leur est parvenue. Les voilà donc dans une situation confuse.', 5),
((SELECT id FROM public.surahs WHERE number = 50), 6, 'أَفَلَمْ يَنظُرُوا إِلَى السَّمَاءِ فَوْقَهُمْ كَيْفَ بَنَيْنَاهَا وَزَيَّنَّاهَا وَمَا لَهَا مِن فُرُوجٍ', 'N''ont-ils pas regardé le ciel au-dessus d''eux, comment Nous l''avons construit et orné, sans qu''il ait de fissures?', 6),
((SELECT id FROM public.surahs WHERE number = 50), 7, 'وَالْأَرْضَ مَدَدْنَاهَا وَأَلْقَيْنَا فِيهَا رَوَاسِيَ وَأَنبَتْنَا فِيهَا مِن كُلِّ زَوْجٍ بَهِيجٍ', 'Et la terre, Nous l''avons étendue, y avons jeté des montagnes fermement enracinées, et y avons fait pousser toute sorte de plantes splendides.', 7),
((SELECT id FROM public.surahs WHERE number = 50), 8, 'تَبْصِرَةً وَذِكْرَىٰ لِكُلِّ عَبْدٍ مُّنِيبٍ', 'Pour l''instruction et le rappel de tout serviteur repentant.', 8),
((SELECT id FROM public.surahs WHERE number = 50), 9, 'وَنَزَّلْنَا مِنَ السَّمَاءِ مَاءً مُّبَارَكًا فَأَنبَتْنَا بِهِ جَنَّاتٍ وَحَبَّ الْحَصِيدِ', 'Et du ciel, Nous avons fait descendre une eau bénie, avec laquelle Nous avons fait pousser des jardins et le grain de la moisson,', 9),
((SELECT id FROM public.surahs WHERE number = 50), 10, 'وَالنَّخْلَ بَاسِقَاتٍ لَّهَا طَلْعٌ نَّضِيدٌ', 'et les palmiers hauts aux régimes empilés,', 10),
((SELECT id FROM public.surahs WHERE number = 50), 11, 'رِزْقًا لِّلْعِبَادِ ۖ وَأَحْيَيْنَا بِهِ بَلْدَةً مَّيْتًا ۚ كَذَٰلِكَ الْخُرُوجُ', 'comme subsistance pour les serviteurs. Et par elle, Nous avons redonné la vie à une contrée morte. Ainsi se fera la résurrection.', 11),
((SELECT id FROM public.surahs WHERE number = 50), 12, 'كَذَّبَتْ قَبْلَهُمْ قَوْمُ نُوحٍ وَأَصْحَابُ الرَّسِّ وَثَمُودُ', 'Avant eux, le peuple de Noé, les gens du Rass et Thamud ont traité de mensonge,', 12),
((SELECT id FROM public.surahs WHERE number = 50), 13, 'وَعَادٌ وَفِرْعَوْنُ وَإِخْوَانُ لُوطٍ', 'et les Aad, Pharaon, les frères de Loth,', 13),
((SELECT id FROM public.surahs WHERE number = 50), 14, 'وَأَصْحَابُ الْأَيْكَةِ وَقَوْمُ تُبَّعٍ ۚ كُلٌّ كَذَّبَ الرُّسُلَ فَحَقَّ وَعِيدِ', 'et les gens d''Al-Ayka et le peuple de Tubba. Tous traitèrent de menteurs les Messagers. Ma menace s''est donc réalisée.', 14),
((SELECT id FROM public.surahs WHERE number = 50), 15, 'أَفَعَيِينَا بِالْخَلْقِ الْأَوَّلِ ۚ بَلْ هُمْ فِي لَبْسٍ مِّنْ خَلْقٍ جَدِيدٍ', 'Avons-Nous faibli lors de la première création? Mais ils sont dans le doute au sujet d''une nouvelle création.', 15),
((SELECT id FROM public.surahs WHERE number = 50), 16, 'وَلَقَدْ خَلَقْنَا الْإِنسَانَ وَنَعْلَمُ مَا تُوَسْوِسُ بِهِ نَفْسُهُ ۖ وَنَحْنُ أَقْرَبُ إِلَيْهِ مِنْ حَبْلِ الْوَرِيدِ', 'Nous avons certes créé l''homme et Nous savons ce que son âme lui murmure, et Nous sommes plus près de lui que sa veine jugulaire.', 16),
((SELECT id FROM public.surahs WHERE number = 50), 17, 'إِذْ يَتَلَقَّى الْمُتَلَقِّيَانِ عَنِ الْيَمِينِ وَعَنِ الشِّمَالِ قَعِيدٌ', 'Quand les deux recueillants, assis à droite et à gauche, recueillent [ses actes].', 17),
((SELECT id FROM public.surahs WHERE number = 50), 18, 'مَا يَلْفِظُ مِن قَوْلٍ إِلَّا لَدَيْهِ رَقِيبٌ عَتِيدٌ', 'Il ne prononce pas un mot sans qu''un observateur prêt ne l''enregistre.', 18),
((SELECT id FROM public.surahs WHERE number = 50), 19, 'وَجَاءَتْ سَكْرَةُ الْمَوْتِ بِالْحَقِّ ۖ ذَٰلِكَ مَا كُنتَ مِنْهُ تَحِيدُ', 'Et l''agonie de la mort apporte la vérité: «Voilà ce dont tu te détournais!»', 19),
((SELECT id FROM public.surahs WHERE number = 50), 20, 'وَنُفِخَ فِي الصُّورِ ۚ ذَٰلِكَ يَوْمُ الْوَعِيدِ', 'Et l''on soufflera dans la Trompette: voilà le Jour de la Menace.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 51: Ad-Dhariyat (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 51), 1, 'وَالذَّارِيَاتِ ذَرْوًا', 'Par les vents qui éparpillent!', 1),
((SELECT id FROM public.surahs WHERE number = 51), 2, 'فَالْحَامِلَاتِ وِقْرًا', 'Par les porteuses de fardeaux!', 2),
((SELECT id FROM public.surahs WHERE number = 51), 3, 'فَالْجَارِيَاتِ يُسْرًا', 'Par les glisseuses avec aisance!', 3),
((SELECT id FROM public.surahs WHERE number = 51), 4, 'فَالْمُقَسِّمَاتِ أَمْرًا', 'Par les distributrices de commandement!', 4),
((SELECT id FROM public.surahs WHERE number = 51), 5, 'إِنَّمَا تُوعَدُونَ لَصَادِقٌ', 'Ce qu''on vous promet est certainement vrai.', 5),
((SELECT id FROM public.surahs WHERE number = 51), 6, 'وَإِنَّ الدِّينَ لَوَاقِعٌ', 'Et le Jugement aura lieu certainement.', 6),
((SELECT id FROM public.surahs WHERE number = 51), 7, 'وَالسَّمَاءِ ذَاتِ الْحُبُكِ', 'Par le ciel aux voies tracées!', 7),
((SELECT id FROM public.surahs WHERE number = 51), 8, 'إِنَّكُمْ لَفِي قَوْلٍ مُّخْتَلِفٍ', 'Vous êtes, en vérité, dans des propos divergents.', 8),
((SELECT id FROM public.surahs WHERE number = 51), 9, 'يُؤْفَكُ عَنْهُ مَنْ أُفِكَ', 'Est détourné de la vérité quiconque est détourné.', 9),
((SELECT id FROM public.surahs WHERE number = 51), 10, 'قُتِلَ الْخَرَّاصُونَ', 'Que périssent les conjecturateurs,', 10),
((SELECT id FROM public.surahs WHERE number = 51), 11, 'الَّذِينَ هُمْ فِي غَمْرَةٍ سَاهُونَ', 'qui sont dans l''insouciance, plongés dans l''illusion,', 11),
((SELECT id FROM public.surahs WHERE number = 51), 12, 'يَسْأَلُونَ أَيَّانَ يَوْمُ الدِّينِ', 'Ils demandent: «A quand le Jour de la Rétribution?»', 12),
((SELECT id FROM public.surahs WHERE number = 51), 13, 'يَوْمَ هُمْ عَلَى النَّارِ يُفْتَنُونَ', 'Le Jour où ils seront éprouvés au Feu:', 13),
((SELECT id FROM public.surahs WHERE number = 51), 14, 'ذُوقُوا فِتْنَتَكُمْ هَٰذَا الَّذِي كُنتُم بِهِ تَسْتَعْجِلُونَ', '«Goûtez à votre épreuve! Voilà ce que vous réclamiez avec précipitation.»', 14),
((SELECT id FROM public.surahs WHERE number = 51), 15, 'إِنَّ الْمُتَّقِينَ فِي جَنَّاتٍ وَعُيُونٍ', 'Les pieux seront parmi des jardins et des sources,', 15),
((SELECT id FROM public.surahs WHERE number = 51), 16, 'آخِذِينَ مَا آتَاهُمْ رَبُّهُمْ ۚ إِنَّهُمْ كَانُوا قَبْلَ ذَٰلِكَ مُحْسِنِينَ', 'prenant ce que leur Seigneur leur a accordé. Car ils étaient auparavant des bienfaiteurs.', 16),
((SELECT id FROM public.surahs WHERE number = 51), 17, 'كَانُوا قَلِيلًا مِّنَ اللَّيْلِ مَا يَهْجَعُونَ', 'Ils dormaient peu la nuit,', 17),
((SELECT id FROM public.surahs WHERE number = 51), 18, 'وَبِالْأَسْحَارِ هُمْ يَسْتَغْفِرُونَ', 'et aux dernières heures de la nuit, ils imploraient le pardon,', 18),
((SELECT id FROM public.surahs WHERE number = 51), 19, 'وَفِي أَمْوَالِهِمْ حَقٌّ لِّلسَّائِلِ وَالْمَحْرُومِ', 'et dans leurs biens, il y avait un droit pour le mendiant et le démuni.', 19),
((SELECT id FROM public.surahs WHERE number = 51), 20, 'وَفِي الْأَرْضِ آيَاتٌ لِّلْمُوقِنِينَ', 'Et sur la terre, il y a des signes pour ceux qui croient avec certitude,', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 52: At-Tur (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 52), 1, 'وَالطُّورِ', 'Par le Mont Tur!', 1),
((SELECT id FROM public.surahs WHERE number = 52), 2, 'وَكِتَابٍ مَّسْطُورٍ', 'Et par un Livre écrit,', 2),
((SELECT id FROM public.surahs WHERE number = 52), 3, 'فِي رَقٍّ مَّنشُورٍ', 'sur un parchemin déployé!', 3),
((SELECT id FROM public.surahs WHERE number = 52), 4, 'وَالْبَيْتِ الْمَعْمُورِ', 'Et par la Maison peuplée!', 4),
((SELECT id FROM public.surahs WHERE number = 52), 5, 'وَالسَّقْفِ الْمَرْفُوعِ', 'Et par le toit élevé,', 5),
((SELECT id FROM public.surahs WHERE number = 52), 6, 'وَالْبَحْرِ الْمَسْجُورِ', 'et par la mer enflammée!', 6),
((SELECT id FROM public.surahs WHERE number = 52), 7, 'إِنَّ عَذَابَ رَبِّكَ لَوَاقِعٌ', 'Le châtiment de ton Seigneur aura lieu certainement,', 7),
((SELECT id FROM public.surahs WHERE number = 52), 8, 'مَّا لَهُ مِن دَافِعٍ', 'nul ne pourra le repousser.', 8),
((SELECT id FROM public.surahs WHERE number = 52), 9, 'يَوْمَ تَمُورُ السَّمَاءُ مَوْرًا', 'Le Jour où le ciel vacillera d''un vacillement,', 9),
((SELECT id FROM public.surahs WHERE number = 52), 10, 'وَتَسِيرُ الْجِبَالُ سَيْرًا', 'et les montagnes iront d''une marche rapide.', 10),
((SELECT id FROM public.surahs WHERE number = 52), 11, 'فَوَيْلٌ يَوْمَئِذٍ لِّلْمُكَذِّبِينَ', 'Malheur, ce Jour-là, à ceux qui traitent de mensonge!', 11),
((SELECT id FROM public.surahs WHERE number = 52), 12, 'الَّذِينَ هُمْ فِي خَوْضٍ يَلْعَبُونَ', 'Ceux qui s''ébattent dans le divertissement.', 12),
((SELECT id FROM public.surahs WHERE number = 52), 13, 'يَوْمَ يُدَعُّونَ إِلَىٰ نَارِ جَهَنَّمَ دَعًّا', 'Le Jour où ils seront brutalement poussés au Feu de l''Enfer:', 13),
((SELECT id FROM public.surahs WHERE number = 52), 14, 'هَٰذِهِ النَّارُ الَّتِي كُنتُم بِهَا تُكَذِّبُونَ', '«Voici le Feu que vous traitiez de mensonge.', 14),
((SELECT id FROM public.surahs WHERE number = 52), 15, 'أَفَسِحْرٌ هَٰذَا أَمْ أَنتُمْ لَا تُبْصِرُونَ', 'Est-ce de la magie? Ou ne voyez-vous pas clairement?»', 15),
((SELECT id FROM public.surahs WHERE number = 52), 16, 'اصْلَوْهَا فَاصْطَبِرُوا أَوْ لَا تَصْبِرُوا سَوَاءٌ عَلَيْكُمْ', 'Brûlez dedans! Que vous endurez ou non, c''est égal pour vous.', 16),
((SELECT id FROM public.surahs WHERE number = 52), 17, 'إِنَّ الْمُتَّقِينَ فِي جَنَّاتٍ وَنَعِيمٍ', 'Les pieux seront dans des Jardins de délice,', 17),
((SELECT id FROM public.surahs WHERE number = 52), 18, 'فَاكِهِينَ بِمَا آتَاهُمْ رَبُّهُمْ وَوَقَاهُمْ رَبُّهُمْ عَذَابَ الْجَحِيمِ', 'se réjouissant de ce que leur Seigneur leur a accordé, et leur Seigneur les aura protégés du châtiment de la Fournaise.', 18),
((SELECT id FROM public.surahs WHERE number = 52), 19, 'كُلُوا وَاشْرَبُوا هَنِيئًا بِمَا كُنتُمْ تَعْمَلُونَ', '«Mangez et buvez en paix, en récompense de ce que vous faisiez!»', 19),
((SELECT id FROM public.surahs WHERE number = 52), 20, 'مُّتَّكِئِينَ عَلَىٰ سُرُرٍ مَّصْفُوفَةٍ ۖ وَزَوَّجْنَاهُم بِحُورٍ عِينٍ', 'Accoudés sur des lits rangés, et Nous les aurons mariés à des houris aux grands yeux.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 53: An-Najm (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 53), 1, 'وَالنَّجْمِ إِذَا هَوَىٰ', 'Par l''étoile quand elle décline!', 1),
((SELECT id FROM public.surahs WHERE number = 53), 2, 'مَا ضَلَّ صَاحِبُكُمْ وَمَا غَوَىٰ', 'Votre compagnon ne s''est pas égaré et n''a pas été induit en erreur,', 2),
((SELECT id FROM public.surahs WHERE number = 53), 3, 'وَمَا يَنطِقُ عَنِ الْهَوَىٰ', 'et il ne prononce rien de sa propre inclination.', 3),
((SELECT id FROM public.surahs WHERE number = 53), 4, 'إِنْ هُوَ إِلَّا وَحْيٌ يُوحَىٰ', 'Ce n''est rien d''autre qu''une révélation inspirée.', 4),
((SELECT id FROM public.surahs WHERE number = 53), 5, 'عَلَّمَهُ شَدِيدُ الْقُوَىٰ', 'Que lui a enseigne a la force redoutable,', 5),
((SELECT id FROM public.surahs WHERE number = 53), 6, 'ذُو مِرَّةٍ فَاسْتَوَىٰ', 'doué de sagacité; il se tint en majesté,', 6),
((SELECT id FROM public.surahs WHERE number = 53), 7, 'وَهُوَ بِالْأُفُقِ الْأَعْلَىٰ', 'alors qu''il se trouvait à l''horizon suprême.', 7),
((SELECT id FROM public.surahs WHERE number = 53), 8, 'ثُمَّ دَنَا فَتَدَلَّىٰ', 'Puis il se rapprocha et descendit,', 8),
((SELECT id FROM public.surahs WHERE number = 53), 9, 'فَكَانَ قَابَ قَوْسَيْنِ أَوْ أَدْنَىٰ', 'et fut à deux portées d''arc, ou plus près encore.', 9),
((SELECT id FROM public.surahs WHERE number = 53), 10, 'فَأَوْحَىٰ إِلَىٰ عَبْدِهِ مَا أَوْحَىٰ', 'Et il révéla à Son serviteur ce qu''il révéla.', 10),
((SELECT id FROM public.surahs WHERE number = 53), 11, 'مَا كَذَبَ الْفُؤَادُ مَا رَأَىٰ', 'Le cœur n''a pas menti sur ce qu''il a vu.', 11),
((SELECT id FROM public.surahs WHERE number = 53), 12, 'أَفَتُمَارُونَهُ عَلَىٰ مَا يَرَىٰ', 'Allez-vous donc lui disputer ce qu''il voit?', 12),
((SELECT id FROM public.surahs WHERE number = 53), 13, 'وَلَقَدْ رَآهُ نَزْلَةً أُخْرَىٰ', 'Et il l''a vu lors d''une autre descente,', 13),
((SELECT id FROM public.surahs WHERE number = 53), 14, 'عِندَ سِدْرَةِ الْمُنتَهَىٰ', 'près du Lotus de la limite,', 14),
((SELECT id FROM public.surahs WHERE number = 53), 15, 'عِندَهَا جَنَّةُ الْمَأْوَىٰ', 'près duquel se trouve le Jardin du Séjour:', 15),
((SELECT id FROM public.surahs WHERE number = 53), 16, 'إِذْ يَغْشَى السِّدْرَةَ مَا يَغْشَىٰ', 'au moment où le Lotus enveloppait ce qu''il enveloppait.', 16),
((SELECT id FROM public.surahs WHERE number = 53), 17, 'مَا زَاغَ الْبَصَرُ وَمَا طَغَىٰ', 'La vue n''a pas dévié ni outrepassé la mesure.', 17),
((SELECT id FROM public.surahs WHERE number = 53), 18, 'لَقَدْ رَأَىٰ مِنْ آيَاتِ رَبِّهِ الْكُبْرَىٰ', 'Il a certes vu les plus grands signes de son Seigneur.', 18),
((SELECT id FROM public.surahs WHERE number = 53), 19, 'أَفَرَأَيْتُمُ اللَّاتَ وَالْعُزَّىٰ', 'Avez-vous considéré Al-Lat et Al-Uzza,', 19),
((SELECT id FROM public.surahs WHERE number = 53), 20, 'وَمَنَاةَ الثَّالِثَةَ الْأُخْرَىٰ', 'ainsi que Manat, la troisième, l''autre?', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 54: Al-Qamar (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 54), 1, 'اقْتَرَبَتِ السَّاعَةُ وَانشَقَّ الْقَمَرُ', 'L''Heure approche et la lune s''est fendue.', 1),
((SELECT id FROM public.surahs WHERE number = 54), 2, 'وَإِن يَرَوْا آيَةً يُعْرِضُوا وَيَقُولُوا سِحْرٌ مُّسْتَمِرٌّ', 'Et s''ils voient un miracle, ils s''en détournent et disent: «C''est une magie persistante.»', 2),
((SELECT id FROM public.surahs WHERE number = 54), 3, 'وَكَذَّبُوا وَاتَّبَعُوا أَهْوَاءَهُمْ ۚ وَكُلُّ أَمْرٍ مُّسْتَقِرٌّ', 'Et ils ont crié au mensonge et suivi leurs passions. Mais toute chose a son terme fixé.', 3),
((SELECT id FROM public.surahs WHERE number = 54), 4, 'وَلَقَدْ جَاءَهُم مِّنَ الْأَنبَاءِ مَا فِيهِ مُزْدَجَرٌ', 'Il leur est parvenu des récits contenant de quoi les réfréner,', 4),
((SELECT id FROM public.surahs WHERE number = 54), 5, 'حِكْمَةٌ بَالِغَةٌ فَمَا تُغْنِي النُّذُرُ', 'une sagesse parfaite. Mais les avertissements ne servent à rien.', 5),
((SELECT id FROM public.surahs WHERE number = 54), 6, 'فَأَعْرِضْ عَنْهُمْ ۘ يَوْمَ يَدْعُو الدَّاعِي إِلَىٰ شَيْءٍ نُّكُرٍ', 'Détourne-toi donc d''eux. Le Jour où le crieur appellera à une chose terrible,', 6),
((SELECT id FROM public.surahs WHERE number = 54), 7, 'خُشَّعًا أَبْصَارُهُمْ يَخْرُجُونَ مِنَ الْأَجْدَاثِ كَأَنَّهُمْ جَرَادٌ مُّنتَشِرٌ', 'les regards humiliés, ils sortiront des tombes comme des sauterelles dispersées,', 7),
((SELECT id FROM public.surahs WHERE number = 54), 8, 'مُّهْطِعِينَ إِلَى الدَّاعِي ۖ يَقُولُ الْكَافِرُونَ هَٰذَا يَوْمٌ عَسِيرٌ', 'courant le cou tendu vers le crieur. Les infidèles diront: «Voilà un Jour difficile!»', 8),
((SELECT id FROM public.surahs WHERE number = 54), 9, 'كَذَّبَتْ قَبْلَهُمْ قَوْمُ نُوحٍ فَكَذَّبُوا عَبْدَنَا وَقَالُوا مَجْنُونٌ وَازْدُجِرَ', 'Avant eux, le peuple de Noé a crié au mensonge. Ils traitèrent Notre serviteur de menteur et dirent: «Fou!» et il fut repoussé.', 9),
((SELECT id FROM public.surahs WHERE number = 54), 10, 'فَدَعَا رَبَّهُ أَنِّي مَغْلُوبٌ فَانتَصِرْ', 'Il invoqua son Seigneur: «Je suis vaincu, accorde-moi Ton secours!»', 10),
((SELECT id FROM public.surahs WHERE number = 54), 11, 'فَفَتَحْنَا أَبْوَابَ السَّمَاءِ بِمَاءٍ مُّنْهَمِرٍ', 'Nous ouvrîmes alors les portes du ciel à une eau torrentielle,', 11),
((SELECT id FROM public.surahs WHERE number = 54), 12, 'وَفَجَّرْنَا الْأَرْضَ عُيُونًا فَالْتَقَى الْمَاءُ عَلَىٰ أَمْرٍ قَدْ مُّقْدَرٍ', 'et fissurâmes la terre en sources. Les eaux se rencontrèrent d''après un ordre qui était déjà décrété.', 12),
((SELECT id FROM public.surahs WHERE number = 54), 13, 'وَحَمَلْنَاهُ عَلَىٰ ذَاتِ أَلْوَاحٍ وَدُسُرٍ', 'Et Nous le portâmes sur un vaisseau fait de planches et de clous,', 13),
((SELECT id FROM public.surahs WHERE number = 54), 14, 'تَجْرِي بِأَعْيُنَا جَزَاءً لِّمَن كَانَ كُفِرَ', 'voguant sous Nos yeux, en récompense de celui que l''on avait renié.', 14),
((SELECT id FROM public.surahs WHERE number = 54), 15, 'وَلَقَد تَّرَكْنَاهَا آيَةً فَهَلْ مِن مُّدَّكِرٍ', 'Et Nous l''avons laissée comme signe. Y a-t-il quelqu''un pour s''en souvenir?', 15),
((SELECT id FROM public.surahs WHERE number = 54), 16, 'فَكَيْفَ كَانَ عَذَابِي وَنُذُرِ', 'Qu''a donc été Mon châtiment et Mes avertissements?', 16),
((SELECT id FROM public.surahs WHERE number = 54), 17, 'وَلَقَدْ يَسَّرْنَا الْقُرْآنَ لِلذِّكْرِ فَهَلْ مِن مُّدَّكِرٍ', 'En vérité, Nous avons rendu le Coran facile à mémoriser. Y a-t-il quelqu''un pour s''en souvenir?', 17),
((SELECT id FROM public.surahs WHERE number = 54), 18, 'كَذَّبَتْ عَادٌ فَكَيْفَ كَانَ عَذَابِي وَنُذُرِ', 'Les Aad ont crié au mensonge. Qu''a donc été Mon châtiment et Mes avertissements?', 18),
((SELECT id FROM public.surahs WHERE number = 54), 19, 'إِنَّا أَرْسَلْنَا عَلَيْهِمْ رِيحًا صَرْصَرًا فِي يَوْمِ نَحْسٍ مُّسْتَمِرٍّ', 'Nous lâchâmes sur eux, en un jour de malheur persistant, un vent glacial,', 19),
((SELECT id FROM public.surahs WHERE number = 54), 20, 'تَنزِعُ النَّاسَ كَأَنَّهُمْ أَعْجَازُ نَخْلٍ مُّنقَعِرٍ', 'qui arrachait les gens comme des souches de palmiers déracinés.', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 56: Al-Waqi'a (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 56), 1, 'إِذَا وَقَعَتِ الْوَاقِعَةُ', 'Quand l''inévitable se produira,', 1),
((SELECT id FROM public.surahs WHERE number = 56), 2, 'لَيْسَ لِوَقْعَتِهَا كَاذِبَةٌ', 'nul ne traitera son avènement de mensonge.', 2),
((SELECT id FROM public.surahs WHERE number = 56), 3, 'خَافِضَةٌ رَّافِعَةٌ', 'Elle abaissera, elle élèvera.', 3),
((SELECT id FROM public.surahs WHERE number = 56), 4, 'إِذَا رُجَّتِ الْأَرْضُ رَجًّا', 'Quand la terre sera secouée d''une secousse,', 4),
((SELECT id FROM public.surahs WHERE number = 56), 5, 'وَبُسَّتِ الْجِبَالُ بَسًّا', 'et que les montagnes seront pulvérisées en miettes,', 5),
((SELECT id FROM public.surahs WHERE number = 56), 6, 'فَكَانَتْ هَبَاءً مُّنْبَثًّا', 'et deviendront poussière dispersée...', 6),
((SELECT id FROM public.surahs WHERE number = 56), 7, 'وَكُنتُمْ أَزْوَاجًا ثَلَاثَةً', 'vous serez alors divisés en trois catégories:', 7),
((SELECT id FROM public.surahs WHERE number = 56), 8, 'فَأَصْحَابُ الْمَيْمَنَةِ مَا أَصْحَابُ الْمَيْمَنَةِ', 'Ceux de la droite — qu''est-ce que ceux de la droite?', 8),
((SELECT id FROM public.surahs WHERE number = 56), 9, 'وَأَصْحَابُ الْمَشْأَمَةِ مَا أَصْحَابُ الْمَشْأَمَةِ', 'Et ceux de la gauche — qu''est-ce que ceux de la gauche?', 9),
((SELECT id FROM public.surahs WHERE number = 56), 10, 'وَالسَّابِقُونَ السَّابِقُونَ', 'Et les devanciers, les devanciers,', 10),
((SELECT id FROM public.surahs WHERE number = 56), 11, 'أُولَٰئِكَ الْمُقَرَّبُونَ', 'ceux-là sont les rapprochés,', 11),
((SELECT id FROM public.surahs WHERE number = 56), 12, 'فِي جَنَّاتِ النَّعِيمِ', 'dans les Jardins du délice.', 12),
((SELECT id FROM public.surahs WHERE number = 56), 13, 'ثُلَّةٌ مِّنَ الْأَوَّلِينَ', 'Une multitude des premiers,', 13),
((SELECT id FROM public.surahs WHERE number = 56), 14, 'وَقَلِيلٌ مِّنَ الْآخِرِينَ', 'et un petit nombre des derniers,', 14),
((SELECT id FROM public.surahs WHERE number = 56), 15, 'عَلَىٰ سُرُرٍ مَّوْضُونَةٍ', 'sur des lits ornés,', 15),
((SELECT id FROM public.surahs WHERE number = 56), 16, 'مُّتَّكِئِينَ عَلَيْهَا مُتَقَابِلِينَ', 'accoudés, face à face.', 16),
((SELECT id FROM public.surahs WHERE number = 56), 17, 'يَطُوفُ عَلَيْهِمْ وِلْدَانٌ مُّخَلَّدُونَ', 'Des éphèbes immortels circuleront parmi eux,', 17),
((SELECT id FROM public.surahs WHERE number = 56), 18, 'بِأَكْوَابٍ وَأَبَارِيقَ وَكَأْسٍ مِّن مَّعِينٍ', 'avec des coupes, des aiguières et des verres d''une boisson pure;', 18),
((SELECT id FROM public.surahs WHERE number = 56), 19, 'لَا يُصَدَّعُونَ عَنْهَا وَلَا يُنزِفُونَ', 'on n''aura ni maux de tête ni ivresse,', 19),
((SELECT id FROM public.surahs WHERE number = 56), 20, 'وَفَاكِهَةٍ مِّمَّا يَتَخَيَّرُونَ', 'et des fruits de leur choix,', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

-- SURAH 77: Al-Mursalat (first 20 verses)
INSERT INTO public.verses (surah_id, verse_number, arabic_uthmani, french_pretranslation, order_index)
VALUES
((SELECT id FROM public.surahs WHERE number = 77), 1, 'وَالْمُرْسَلَاتِ عُرْفًا', 'Par les vents envoyés en rafales!', 1),
((SELECT id FROM public.surahs WHERE number = 77), 2, 'فَالْعَاصِفَاتِ عَصْفًا', 'Par les tempêtes qui soufflent avec violence!', 2),
((SELECT id FROM public.surahs WHERE number = 77), 3, 'وَالنَّاشِرَاتِ نَشْرًا', 'Par les vents qui dispersent largement!', 3),
((SELECT id FROM public.surahs WHERE number = 77), 4, 'فَالْفَارِقَاتِ فَرْقًا', 'Par les anges qui distinguent avec discernement,', 4),
((SELECT id FROM public.surahs WHERE number = 77), 5, 'فَالْمُلْقِيَاتِ ذِكْرًا', 'par les anges qui transmettent le Rappel,', 5),
((SELECT id FROM public.surahs WHERE number = 77), 6, 'عُذْرًا أَوْ نُذْرًا', 'en excuse ou en avertissement,', 6),
((SELECT id FROM public.surahs WHERE number = 77), 7, 'إِنَّمَا تُوعَدُونَ لَوَاقِعٌ', 'Ce qu''on vous promet aura certainement lieu.', 7),
((SELECT id FROM public.surahs WHERE number = 77), 8, 'فَإِذَا النُّجُومُ طُمِسَتْ', 'Quand les étoiles seront effacées,', 8),
((SELECT id FROM public.surahs WHERE number = 77), 9, 'وَإِذَا السَّمَاءُ فُرِجَتْ', 'et que le ciel sera fendu,', 9),
((SELECT id FROM public.surahs WHERE number = 77), 10, 'وَإِذَا الْجِبَالُ نُسِفَتْ', 'et que les montagnes seront pulvérisées,', 10),
((SELECT id FROM public.surahs WHERE number = 77), 11, 'وَإِذَا الرُّسُلُ أُقِّتَتْ', 'et que les Messagers seront rassemblés au terme fixé...', 11),
((SELECT id FROM public.surahs WHERE number = 77), 12, 'لِأَيِّ يَوْمٍ أُجِّلَتْ', 'Pour quel jour a-t-on fixé ce rendez-vous?', 12),
((SELECT id FROM public.surahs WHERE number = 77), 13, 'لِيَوْمِ الْفَصْلِ', 'Pour le Jour de la Décision.', 13),
((SELECT id FROM public.surahs WHERE number = 77), 14, 'وَمَا أَدْرَاكَ مَا يَوْمُ الْفَصْلِ', 'Et qui te dira ce qu''est le Jour de la Décision?', 14),
((SELECT id FROM public.surahs WHERE number = 77), 15, 'وَيْلٌ يَوْمَئِذٍ لِّلْمُكَذِّبِينَ', 'Malheur, ce Jour-là, à ceux qui traitent de mensonge!', 15),
((SELECT id FROM public.surahs WHERE number = 77), 16, 'أَلَمْ نُهْلِكِ الْأَوَّلِينَ', 'N''avons-Nous pas fait périr les premiers?', 16),
((SELECT id FROM public.surahs WHERE number = 77), 17, 'ثُمَّ نُتْبِعُهُمُ الْآخِرِينَ', 'Puis Nous les ferons suivre par les derniers.', 17),
((SELECT id FROM public.surahs WHERE number = 77), 18, 'كَذَٰلِكَ نَفْعَلُ بِالْمُجْرِمِينَ', 'Ainsi agissons-Nous envers les criminels.', 18),
((SELECT id FROM public.surahs WHERE number = 77), 19, 'وَيْلٌ يَوْمَئِذٍ لِّلْمُكَذِّبِينَ', 'Malheur, ce Jour-là, à ceux qui traitent de mensonge!', 19),
((SELECT id FROM public.surahs WHERE number = 77), 20, 'أَلَمْ نَخْلُقكُم مِّن مَّاءٍ مَّهِينٍ', 'Ne vous avons-Nous pas créés d''une eau méprisable,', 20)
ON CONFLICT (surah_id, verse_number) DO NOTHING;

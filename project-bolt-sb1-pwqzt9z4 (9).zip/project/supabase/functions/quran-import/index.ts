import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const FRENCH_RESOURCE_ID = 31;
const API_BASE = "https://api.quran.com/api/v4";
const PAGE_SIZE = 50;

interface ApiUthmaniVerse {
  verse_number: number;
  text_uthmani: string;
}

interface ApiTranslationVerse {
  verse_number: number;
  text: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { surahNumber, surahId } = await req.json();

    if (typeof surahNumber !== "number" || typeof surahId !== "string") {
      return new Response(
        JSON.stringify({ error: "surahNumber (number) and surahId (string) are required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // 1. Fetch ALL Arabic Uthmani verses by paginating through the API
    // The API returns max 50 verses per page, so we loop until we have all.
    const allUthmani: ApiUthmaniVerse[] = [];
    let page = 1;

    while (true) {
      const url = `${API_BASE}/quran/verses/uthmani?chapter_number=${surahNumber}&page=${page}&per_page=${PAGE_SIZE}`;
      const res = await fetch(url, { headers: { Accept: "application/json" } });
      if (!res.ok) {
        return new Response(
          JSON.stringify({ error: `Arabe page ${page}: HTTP ${res.status} ${res.statusText}` }),
          { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }
      const json = await res.json();
      const verses: ApiUthmaniVerse[] = json.verses ?? [];
      if (verses.length === 0) break;
      allUthmani.push(...verses);
      if (verses.length < PAGE_SIZE) break;
      page++;
    }

    if (allUthmani.length === 0) {
      return new Response(
        JSON.stringify({ error: "aucun verset recu de l API" }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // 2. Fetch ALL French translations by paginating
    const frenchMap: Map<number, string> = new Map();
    try {
      let frPage = 1;
      while (true) {
        const frUrl = `${API_BASE}/quran/translations/${FRENCH_RESOURCE_ID}?chapter_number=${surahNumber}&page=${frPage}&per_page=${PAGE_SIZE}`;
        const frRes = await fetch(frUrl, { headers: { Accept: "application/json" } });
        if (!frRes.ok) break;
        const frJson = await frRes.json();
        const frVerses: ApiTranslationVerse[] = frJson.translations ?? [];
        if (frVerses.length === 0) break;
        for (const fv of frVerses) {
          const frText = fv.text ?? "";
          const cleaned = frText.replace(/<[^>]*>/g, "").trim();
          if (cleaned) {
            frenchMap.set(fv.verse_number, cleaned);
          }
        }
        if (frVerses.length < PAGE_SIZE) break;
        frPage++;
      }
    } catch {
      // French translation is optional — continue with empty
    }

    // 3. Build rows combining Arabic + French
    const rows = allUthmani.map((v) => ({
      surah_id: surahId,
      verse_number: v.verse_number,
      arabic_uthmani: v.text_uthmani,
      french_pretranslation: frenchMap.get(v.verse_number) ?? "",
      order_index: v.verse_number,
    }));

    // 4. Insert into Supabase using service role key
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { error } = await supabase.from("verses").upsert(rows, {
      onConflict: "surah_id,verse_number",
    });

    if (error) {
      return new Response(
        JSON.stringify({ error: `DB: ${error.message}` }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const frCount = rows.filter((r) => r.french_pretranslation !== "").length;

    return new Response(
      JSON.stringify({
        success: true,
        imported: rows.length,
        frenchTranslations: frCount,
        pages: page - 1,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    const errMsg = err instanceof Error ? err.message : "erreur inconnue";
    return new Response(
      JSON.stringify({ error: errMsg }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});

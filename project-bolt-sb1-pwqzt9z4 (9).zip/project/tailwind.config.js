/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        arabic: ['Noto Naskh Arabic', 'Amiri', 'serif'],
        amiri: ['Amiri', 'serif'],
      },
      colors: {
        primary: {
          50: '#f0f7f4',
          100: '#dbede4',
          200: '#b9dcc9',
          300: '#8cc4a8',
          400: '#5ea884',
          500: '#3d8c6b',
          600: '#2d7055',
          700: '#245944',
          800: '#1e4738',
          900: '#193a2e',
        },
        accent: {
          50: '#fef9ec',
          100: '#fdf0c9',
          200: '#fbe08e',
          300: '#f8ca4f',
          400: '#f5b32a',
          500: '#e09817',
          600: '#bc7a13',
          700: '#975c14',
          800: '#7c4917',
          900: '#6a3d17',
        },
        beige: {
          DEFAULT: '#f5f0e6',
          light: '#faf7f0',
        },
      },
    },
  },
  plugins: [],
};
